"""Portable verification entry point. Existing derived outputs may be regenerated."""
from pathlib import Path
import os,sys,subprocess,json,platform,hashlib,sqlite3,time
ROOT=Path(__file__).resolve().parents[1]
# Set before importing numerical modules, including in child processes.
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS']:
 os.environ[k]='1'
import numpy as np
import pandas as pd
import scipy
OUT=ROOT/'verification';OUT.mkdir(exist_ok=True)
steps=['scripts/reproduce_amplitude_scan.py','scripts/build_results_library.py','scripts/calculate_signal_to_noise.py','constituent_snr/scripts/constituent_snr.py','scripts/assemble_snr_table.py']
execution=[]
for step in steps:
 start=time.monotonic()
 with (OUT/(Path(step).stem+'.log')).open('w') as log:
  done=subprocess.run([sys.executable,str(ROOT/step)],cwd=ROOT,stdout=log,stderr=subprocess.STDOUT,env=os.environ)
 execution.append({'script':step,'returncode':done.returncode,'elapsed_seconds':time.monotonic()-start})
 if done.returncode: raise SystemExit('Failed '+step+'; see verification log')
comparisons=[]
for expected in sorted((ROOT/'expected').rglob('*.csv')):
 rel=expected.relative_to(ROOT/'expected')
 actual=ROOT/rel
 if rel.name=='constituent_snr.csv':actual=ROOT/'constituent_snr/results'/rel.name
 if rel.name=='SNR_TABLE.csv':actual=ROOT/'results'/rel.name
 a=pd.read_csv(actual);e=pd.read_csv(expected)
 assert list(a.columns)==list(e.columns) and a.shape==e.shape,(rel,a.shape,e.shape)
 maximum=0.0
 for col in a:
  av=pd.to_numeric(a[col],errors='coerce');ev=pd.to_numeric(e[col],errors='coerce')
  numeric=av.notna()|ev.notna()
  if numeric.any():
   np.testing.assert_allclose(av[numeric],ev[numeric],rtol=2e-8,atol=2e-10,equal_nan=True)
   maximum=max(maximum,float(np.nanmax(np.abs(av[numeric].astype(float)-ev[numeric].astype(float)))))
  # Provenance/status text must also remain the same; tolerate CSV float rendering in array strings.
  elif a[col].dtype==object and col!='target_pair_covariance_e36':
   assert a[col].fillna('').equals(e[col].fillna('')),(str(rel),col)
 comparisons.append({'file':str(rel),'n_rows':len(a),'numeric_max_abs_difference':maximum,'status':'PASS'})
# Consolidated machine-readable summaries; observations remain in dedicated inputs.
tables={}
for folder,prefix in [(ROOT/'results_library',''),(ROOT/'results_library/signal_to_noise','snr_'),(ROOT/'constituent_snr/results','constituent_')]:
 for f in sorted(folder.glob('*.csv')):
  tables[prefix+f.stem]={'file':str(f.relative_to(ROOT)),'rows':pd.read_csv(f).replace({np.nan:None}).to_dict('records')}
tables['manuscript_snr_table']={'file':'results/SNR_TABLE.csv','rows':pd.read_csv(ROOT/'results/SNR_TABLE.csv').replace({np.nan:None}).to_dict('records')}
metadata={str(f.relative_to(ROOT)):json.loads(f.read_text()) for f in [ROOT/'results_library/legacy_loading_status.json',ROOT/'results_library/exploratory_solid_loading_fit.json',ROOT/'results_library/signal_to_noise/RESULTS.json',ROOT/'constituent_snr/results/RESULTS.json',ROOT/'results/SNR_TABLE.json']}
summary={'schema_version':1,'scope':'Derived results only. Original one-second data and v29 reconstruction are not included.','tables':tables,'metadata':metadata}
(ROOT/'RESULTS_LIBRARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False))
# Explicit replacement is confined to this generated database.
dbpath=ROOT/'RESULTS_LIBRARY.sqlite'
if dbpath.exists():dbpath.unlink()
with sqlite3.connect(dbpath) as db:
 for name,tab in tables.items():
  if not tab['rows']:continue
  pd.DataFrame(tab['rows']).to_sql(name,db,index=False)
 db.execute('CREATE TABLE metadata (key TEXT PRIMARY KEY, value_json TEXT NOT NULL)')
 db.executemany('INSERT INTO metadata VALUES (?,?)',[(k,json.dumps(v)) for k,v in metadata.items()])
 assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
report={'status':'PASS','run_directory':str(ROOT),'software':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__},'threads':1,'randomness':'None','steps':execution,'comparisons':comparisons,'scope':'Reproduced numerical auxiliary analyses from frozen processed means, templates, and frequency grid; no primary v29 reconstruction or raw preprocessing','tables_exported':len(tables)}
(OUT/'VALIDATION.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'status':report['status'],'files_compared':len(comparisons),'tables_exported':len(tables),'software':report['software']},indent=2))
