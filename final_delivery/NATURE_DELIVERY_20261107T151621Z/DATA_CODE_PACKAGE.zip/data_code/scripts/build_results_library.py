"""Build the traceable methods-closure library from frozen non-overlapping data.

No v29 result is reconstructed. New exploratory solid/loading fits are explicitly
separated from the legacy author-reported loading coefficient. Default paths are
relative to this manuscript. First stage additionally supplies --constituents and
--v29-text; later runs need neither original source path.
"""
from pathlib import Path
import argparse
import hashlib
import json
import platform
import shutil

import numpy as np
import pandas as pd
import scipy
from scipy.signal import find_peaks

ROOT = Path(__file__).resolve().parents[1]
LIB = ROOT/'results_library'
INP = LIB/'inputs'
C, G0 = 299792458.0, 9.80665
CM = 100*C*C/G0*1e-18
NAMES = ['Q1','O1','P1','K1','N2','M2','S2','K2']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def project(a, seg):
    z = (seg[:, None] == np.unique(seg)[None, :]).astype(float)
    q = z/np.linalg.norm(z, axis=0)
    return a-q@(q.T@a), q


def fit_two(y, x, seg):
    yp, q = project(y, seg)
    xp = x-q@(q.T@x)
    beta, _, rank, _ = np.linalg.lstsq(xp, yp, rcond=None)
    assert rank == 2
    residual = yp-xp@beta
    gram = xp.T@xp
    dof = len(y)-q.shape[1]-2
    scale = float(residual@residual/dof)
    cov = scale*np.linalg.inv(gram)
    return beta, cov, residual, xp, q, dof


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--constituents', type=Path)
    p.add_argument('--v29-text', type=Path)
    args = p.parse_args()
    INP.mkdir(parents=True, exist_ok=True)
    if args.constituents or args.v29_text:
        assert args.constituents and args.v29_text
        assert not (INP/'MANIFEST.json').exists(), 'Staged inputs exist; run without staging options.'
        A = ROOT/'data/amplitude_spectrum'
        paths = {'bins.csv': A/'inputs/bins.csv', 'template.csv': A/'inputs/template.csv',
                 'amplitude_scan.csv': A/'amplitude_scan.csv', 'amplitude_RESULTS.json': A/'RESULTS.json',
                 'original_RESULTS.json': A/'inputs/RESULTS.json',
                 'constituents.csv': args.constituents, 'V29_LOADING_EXCERPT.txt': args.v29_text}
        manifest = []
        for name, source in paths.items():
            shutil.copy2(source, INP/name)
            manifest.append({'file': name, 'source': str(source.resolve()), 'sha256': sha(source)})
        (INP/'MANIFEST.json').write_text(json.dumps(manifest, indent=2))
    manifest = json.loads((INP/'MANIFEST.json').read_text())
    for item in manifest:
        assert sha(INP/item['file']) == item['sha256']
    b = pd.read_csv(INP/'bins.csv')
    model = b[['t_utc']].merge(pd.read_csv(INP/'template.csv'), on='t_utc', how='left',
                             validate='many_to_one', sort=False)
    np.testing.assert_allclose(model.solid+model.loading, model.total, rtol=1e-12, atol=1e-12)
    assert len(b) == 3299 and b.seg.nunique() == 54
    seconds = pd.to_datetime(b.t_utc, utc=True).dt.as_unit('ns').astype('int64').to_numpy()/1e9
    t = seconds-seconds.min()
    seg, y = b.seg.to_numpy(), b.y.to_numpy()
    days = pd.to_datetime(b.t_utc, utc=True).dt.strftime('%Y-%m-%d').to_numpy()
    old = json.loads((INP/'original_RESULTS.json').read_text())
    freqs, ray = old['spectrum']['frequency_Hz'], old['spectrum']['rayleigh_uHz']
    scan = pd.read_csv(INP/'amplitude_scan.csv')
    observed = []
    for target in NAMES:
        freq = freqs[target]*1e6
        exact = np.flatnonzero(np.isclose(scan.frequency_uHz, freq, rtol=0, atol=1e-10))
        assert len(exact) == 1
        peaks, _ = find_peaks(scan.observed_peak_amplitude_1e18.to_numpy())
        candidates = peaks[np.abs(scan.frequency_uHz.to_numpy()[peaks]-freq) <= ray]
        near = int(candidates[np.argmax(scan.observed_peak_amplitude_1e18.to_numpy()[candidates])]) if len(candidates) else None
        for kind, ix in [('exact_astronomical_frequency', int(exact[0])), ('local_observed_amplitude_peak', near)]:
            rec = {'target': target, 'selection': kind, 'status': 'EXTRACTED_EXISTING_SCAN',
                   'target_frequency_uHz': freq, 'found': ix is not None,
                   'nuisance': 'S54 constants only; one free cosine/sine pair; equal weights',
                   'amplitude_uncertainty': None,
                   'uncertainty_status': 'Not estimated for this scan; no noise significance or CI inferred.'}
            if ix is not None:
                rec.update(scan.iloc[ix].to_dict())
                rec['source_csv_zero_based_row'] = ix
            observed.append(rec)
    pd.DataFrame(observed).to_csv(LIB/'eight_constituent_amplitudes.csv', index=False)
    (LIB/'eight_constituent_amplitudes.json').write_text(json.dumps(observed, indent=2))
    # Full frozen model projections: these contain leakage from all modeled terms.
    all_model = model[['solid','loading','total']].to_numpy()
    mp, q = project(all_model, seg)
    modelrows, projected_pairs = [], {}
    for target in NAMES:
        f = freqs[target]
        pair = np.column_stack([np.cos(2*np.pi*f*t), np.sin(2*np.pi*f*t)])
        pair -= q@(q.T@pair)
        projected_pairs[target] = np.linalg.qr(pair, mode='reduced')[0]
        co, _, rank, _ = np.linalg.lstsq(pair, mp, rcond=None)
        assert rank == 2
        for k, name in enumerate(['full_solid_template','full_loading_template','full_total_template']):
            modelrows.append({'target': target, 'frequency_uHz': f*1e6, 'template': name,
                'status': 'NEW_MODEL_PROJECTION', 'cos_1e18': float(co[0,k]), 'sin_1e18': float(co[1,k]),
                'peak_amplitude_1e18': float(np.hypot(*co[:,k])),
                'peak_amplitude_cm': float(np.hypot(*co[:,k])*CM),
                'interpretation': 'Projection of complete frozen template, includes sampling leakage; not a pure constituent phasor or observed independent loading.'})
    pd.DataFrame(modelrows).to_csv(LIB/'model_spectral_projections.csv', index=False)
    ctable = pd.read_csv(INP/'constituents.csv').set_index('constituent')
    phasors = []
    for target in NAMES:
        solid = complex(ctable.loc[target,'solid_real'], ctable.loc[target,'solid_imag'])
        load = complex(ctable.loc[target,'loading_real'], ctable.loc[target,'loading_imag'])
        for name, z in [('solid',solid),('loading',load),('total',solid+load)]:
            phasors.append({'target': target, 'component': name, 'status': 'FROZEN_PHASOR_MAGNITUDE',
                'stored_real_1e18': z.real, 'stored_imag_1e18': z.imag,
                'modulus_1e18': abs(z), 'modulus_cm': abs(z)*CM,
                'stored_complex_argument_deg': float(np.degrees(np.angle(z))),
                'interpretation': 'Stored physical constituent phasor, prior to sampled-time projection and nodal synthesis; not fitted data amplitude.'})
    pd.DataFrame(phasors).to_csv(LIB/'physical_model_phasors.csv', index=False)
    geometry = []
    for i, first in enumerate(NAMES):
        for second in NAMES[i+1:]:
            sv = np.linalg.svd(projected_pairs[first].T@projected_pairs[second], compute_uv=False)
            geometry.append({'first': first, 'second': second, 'max_canonical_correlation': float(sv[0]),
                'min_canonical_correlation': float(sv[-1]),
                'least_retained_target_energy_fraction_after_other_pair': float(1-sv[0]**2),
                'status': 'NEW_DESIGN_GEOMETRY', 'nuisance': 'S54 constants only, equal weights'})
    pd.DataFrame(geometry).to_csv(LIB/'harmonic_pair_identifiability.csv', index=False)
    # New exploratory two-template fit; both complete templates free, no repeated remainder.
    x = model[['solid','loading']].to_numpy()
    beta, ls_cov, residual, xp, q, dof = fit_two(y, x, seg)
    xnorm = xp/np.linalg.norm(xp, axis=0)
    corr = float(xnorm[:,0]@xnorm[:,1])
    reps, deletion_rows = [], []
    for day in np.unique(days):
        keep = days != day
        bb, _, _, _, qq, _ = fit_two(y[keep], x[keep], seg[keep])
        reps.append(bb)
        deletion_rows.append({'deleted_UTC_day': day, 'retained_n': int(keep.sum()),
                             'retained_segments': qq.shape[1], 'A_solid': bb[0], 'A_loading': bb[1]})
    reps = np.array(reps)
    d = reps-reps.mean(axis=0)
    jk_cov = (len(reps)-1)/len(reps)*(d.T@d)
    # Independent direct design with all 54 offsets confirms the partial regression.
    z = (seg[:,None] == np.unique(seg)[None,:]).astype(float)
    direct, _, rank, _ = np.linalg.lstsq(np.column_stack([z,x]), y, rcond=None)
    np.testing.assert_allclose(direct[-2:], beta, atol=1e-11, rtol=1e-11)
    result = {
        'status': 'NEW_AUXILIARY_EXPLORATORY',
        'model': 'y_i = c_segment(i) + A_solid * full_solid_i + A_loading * full_loading_i + epsilon_i',
        'data_route': '3299 non-overlapping means; equal weights; 54 segment constants; not v29 triangular-filter route',
        'template_remainder': 'Frozen full solid + frozen full loading equals frozen total. No extra remainder subtracted or fitted.',
        'coefficients_order': ['A_solid','A_loading'], 'coefficients': beta.tolist(),
        'scaled_LS_SE': np.sqrt(np.diag(ls_cov)).tolist(), 'scaled_LS_covariance': ls_cov.tolist(),
        'UTC_day_delete_one_SE': np.sqrt(np.diag(jk_cov)).tolist(), 'UTC_day_jackknife_covariance': jk_cov.tolist(),
        'UTC_day_jackknife_coefficient_correlation': float(jk_cov[0,1]/np.sqrt(jk_cov[0,0]*jk_cov[1,1])),
        'design_correlation_after_S54': corr,
        'normalized_two_column_design_condition_number': float(np.linalg.cond(xnorm)),
        'remaining_loading_template_energy_fraction_after_solid': float(1-corr**2),
        'projected_template_RMS_1e18': dict(zip(['solid','loading'], np.sqrt(np.mean(xp*xp,axis=0)).tolist())),
        'degrees_of_freedom': dof, 'residual_RMS_1e18': float(np.sqrt(np.mean(residual**2))),
        'n_UTC_delete_blocks': len(reps), 'n_rows': len(y), 'n_segments': 54,
        'independent_direct_design_rank': int(rank),
        'independent_direct_coefficient_max_abs_difference': float(np.max(np.abs(direct[-2:]-beta))),
        'uncertainty_definition': 'Scaled LS uses RSS/(n-rank); UTC day delete-one refits both coefficients and all surviving segment offsets, with (D-1)/D covariance. Not a new calibrated bootstrap CI.',
        'limitations': 'Exploratory shared-observation estimate; model systematic uncertainty not included. Not a reproduction/replacement of 0.89 +/- 0.55. No independent loading detection claim or p-value.',
    }
    (LIB/'exploratory_solid_loading_fit.json').write_text(json.dumps(result, indent=2))
    pd.DataFrame(deletion_rows).to_csv(LIB/'exploratory_solid_loading_delete_day.csv', index=False)
    pd.DataFrame([{'coefficient': n, 'estimate': beta[i], 'scaled_LS_SE': np.sqrt(ls_cov[i,i]),
                   'UTC_day_delete_one_SE': np.sqrt(jk_cov[i,i]), 'status': 'NEW_AUXILIARY_EXPLORATORY'}
                  for i,n in enumerate(['A_solid','A_loading'])]).to_csv(LIB/'exploratory_solid_loading_fit.csv',index=False)
    legacy = {
        'value': 0.89, 'reported_uncertainty': 0.55, 'status': 'LEGACY_AUTHOR_REPORTED_NOT_REPRODUCED',
        'source': 'inputs/V29_LOADING_EXCERPT.txt, Discussion paragraph beginning On the present baseline',
        'source_sha256': sha(INP/'V29_LOADING_EXCERPT.txt'),
        'missing': ['Exact v29 retained one-second mask and triangular-filter output',
                    'Aligned v29 direct-potential solid/loading model arrays',
                    'Exact loading-fit columns, treatment of any remainder and weighting specification',
                    'Error procedure specifically responsible for +/- 0.55'],
        'non_substitution_rule': 'New non-overlapping exploratory fit is separately labelled and cannot close these original-route provenance gaps.'}
    (LIB/'legacy_loading_status.json').write_text(json.dumps(legacy, indent=2))
    meta = {'input_manifest': manifest, 'n_rows': len(y), 'n_segments': 54, 'n_UTC_days': len(reps),
        'frequency_origin_UTC': b.t_utc.iloc[0], 'base_grid_step_uHz': old['spectrum']['grid_step_uHz'],
        'inverse_span_scale_uHz': ray, 'g0_m_s2': G0, 'c_m_s': C, 'cm_per_1e18': CM,
        'software': {'python': platform.python_version(), 'numpy': np.__version__, 'pandas': pd.__version__, 'scipy': scipy.__version__},
        'randomness': 'None; deterministic extraction, model projections and delete-one refits.',
        'script_sha256': sha(Path(__file__)),
        'files': {p.name: sha(p) for p in LIB.iterdir() if p.is_file() and p.name != 'MANIFEST.json'}}
    (LIB/'MANIFEST.json').write_text(json.dumps(meta, indent=2))
    print(json.dumps({'exploratory_fit': result,
                      'exact_frequency_amplitudes': [r for r in observed if r['selection']=='exact_astronomical_frequency']}, indent=2))


if __name__ == '__main__':
    main()
