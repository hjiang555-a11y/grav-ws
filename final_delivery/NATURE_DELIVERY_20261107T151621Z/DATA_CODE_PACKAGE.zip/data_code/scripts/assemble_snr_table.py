from pathlib import Path
import json,hashlib,platform
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parents[1]
BASE=R.parent
G=R/'results_library/signal_to_noise'
C=R/'constituent_snr'
r=json.loads((G/'RESULTS.json').read_text()); d=pd.read_csv(G/'inputs/primary_rows.csv'); ops=np.load(G/'estimator_rows.npz')
orig=json.loads((G/'inputs/original_RESULTS.json').read_text())['primary']; load=json.loads((G/'inputs/exploratory_solid_loading_fit.json').read_text())
rows=[]
c=pd.read_csv(C/'results/constituent_snr.csv')
for name,label in [('M2','Lunar semidiurnal constituent (M₂)'),('S2','Solar-frequency semidiurnal constituent (S₂)')]:
 sub=c[c.constituent==name].set_index('covariance_model')
 rows.append({'signal':name,'label':label,'amplitude':float(sub.iloc[0].amplitude_1e18),'amplitude_unit':'1e-18 fractional frequency','white':float(sub.loc['common_alpha540_white','rho_amplitude_over_SE']),'period_noise':float(sub.loc['actual_period_noise','rho_amplitude_over_SE']),'day_jackknife':float(sub.loc['existing_UTC_day_jackknife','rho_amplitude_over_SE']),'estimator':'Equal-weight M2/S2/N2/K2 joint sine-cosine fit and 54 offsets; local scalar amplitude propagation'})
for key,label,op,i,A,u in [('diurnal_group_nonoverlap','Diurnal tidal group','groups_nonoverlap',2,orig['A'][2],orig['day_jackknife'][2]),('loading_new_auxiliary','Ocean-loading template','solid_loading_new',1,load['coefficients'][1],load['UTC_day_delete_one_SE'][1])]:
 h=ops[op][i];uw=float(540*np.sqrt(np.sum(h*h/d.n.to_numpy())));up=float(np.sqrt(np.sum(h*h*d.sigma.to_numpy()**2)))
 old=next(x for x in r['same_estimator_noise_predictions'] if x['signal']==key)
 np.testing.assert_allclose([uw,up],[old['u_white_same_estimator'],old['u_periodnoise_same_estimator']],rtol=1e-12)
 rows.append({'signal':key,'label':label,'amplitude':A,'amplitude_unit':'dimensionless template response','white':abs(A)/uw,'period_noise':abs(A)/up,'day_jackknife':abs(A)/u,'u_white':uw,'u_period':up,'u_day_jackknife':u,'estimator':'Period-noise-weighted three-group fit and 54 offsets' if i==2 else 'Equal-weight complete solid-Earth/loading two-template fit and 54 offsets'})
inputs=[G/'RESULTS.json',G/'estimator_rows.npz',G/'inputs/primary_rows.csv',G/'inputs/original_RESULTS.json',G/'inputs/exploratory_solid_loading_fit.json',C/'results/constituent_snr.csv']
result={'rows':rows,'n_bins':len(d),'T_seconds':int(d.n.sum()),'input_sha256':{str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in inputs},'software':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__},'randomness':'none','scope':'Algebraic re-evaluation of saved operators; no data reselection, new fit, or time-exponent estimation.'}
(R/'results/SNR_TABLE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
pd.DataFrame(rows).to_csv(R/'results/SNR_TABLE.csv',index=False)
print(pd.DataFrame(rows)[['label','white','period_noise','day_jackknife']].to_string(index=False))
