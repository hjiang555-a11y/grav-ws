from pathlib import Path
import json
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
INP=ROOT/'results_library/inputs'
def scan(t, Y, f, Q, chunk=128):
    """Equal-weight paired LS with the same S54 projection on y, cos and sin."""
    Y = Y - Q @ (Q.T @ Y)
    bc = np.empty((len(f), Y.shape[1]))
    bs = np.empty_like(bc)
    delta = np.empty_like(bc)
    for lo in range(0, len(f), chunk):
        sl = slice(lo, lo + chunk)
        arg = 2 * np.pi * t[:, None] * f[sl]
        co, si = np.cos(arg), np.sin(arg)
        co -= Q @ (Q.T @ co)
        si -= Q @ (Q.T @ si)
        cc, ss, cs = (co * co).sum(0), (si * si).sum(0), (co * si).sum(0)
        cy, sy = co.T @ Y, si.T @ Y
        det = cc * ss - cs**2
        assert np.all(det > 1e-10)
        bc[sl] = (ss[:, None]*cy - cs[:, None]*sy) / det[:, None]
        bs[sl] = (cc[:, None]*sy - cs[:, None]*cy) / det[:, None]
        delta[sl] = np.maximum(0, cy*bc[sl] + sy*bs[sl])
    return bc, bs, delta


b=pd.read_csv(INP/'bins.csv'); ref=pd.read_csv(INP/'amplitude_scan.csv')
m=b[['t_utc']].merge(pd.read_csv(INP/'template.csv'),on='t_utc',sort=False,validate='many_to_one')
s=pd.to_datetime(b.t_utc,utc=True).dt.as_unit('ns').astype('int64').to_numpy()/1e9;t=s-s.min()
z=(b.seg.to_numpy()[:,None]==np.unique(b.seg)[None,:]).astype(float);q=z/np.linalg.norm(z,axis=0)
y=np.column_stack([b.y.to_numpy(),b.y.to_numpy()-m.total.to_numpy()])
bc,bs,delta=scan(t,y,ref.frequency_uHz.to_numpy()*1e-6,q)
out=pd.DataFrame({'frequency_uHz':ref.frequency_uHz});cm=100*299792458.**2/9.80665*1e-18
for k,name in enumerate(['observed','after_unit_physical_prediction']):
 out[name+'_cos_1e18']=bc[:,k];out[name+'_sin_1e18']=bs[:,k]
 out[name+'_peak_amplitude_1e18']=np.hypot(bc[:,k],bs[:,k]);out[name+'_peak_amplitude_cm']=np.hypot(bc[:,k],bs[:,k])*cm
 out[name+'_delta_rss_1e36']=delta[:,k];out[name+'_nominal_fractional_PSD_per_uHz']=600*delta[:,k]*1e-42
for col in ref.columns:
 np.testing.assert_allclose(out[col],ref[col],rtol=2e-7,atol=1e-10 if 'PSD' not in col else 1e-46)
(ROOT/'results').mkdir(exist_ok=True)
out.to_csv(ROOT/'results/amplitude_scan_reproduced.csv',index=False)
(ROOT/'results/SCAN_VALIDATION.json').write_text(json.dumps({'n_frequencies':len(ref),'scope':'Same saved 5–40 microHz grid, equal weights, S54, observed and after fixed unit complete prediction; coefficients and amplitude regenerated, not square-root PSD','max_amplitude_abs_difference_1e18':float(np.max(np.abs(out.observed_peak_amplitude_1e18-ref.observed_peak_amplitude_1e18)))},indent=2))
print('Amplitude scan verified:',len(ref),'frequencies')
