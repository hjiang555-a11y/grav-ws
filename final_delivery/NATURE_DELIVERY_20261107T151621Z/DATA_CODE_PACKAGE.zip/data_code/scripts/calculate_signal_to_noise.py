"""Reported A/u and finite-design noise predictions, preserving each estimator.

First run: --primary-rows PATH stages the frozen A_v81 primary rows. Later runs
use relative inputs. No time-growth exponents are fitted and no noise is simulated.
"""
from pathlib import Path
import argparse
import hashlib
import json
import platform
import shutil
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'results_library/signal_to_noise'
INP=OUT/'inputs'
ALPHA=540.0  # 1e-18 * sqrt(second), assumed common white-frequency-noise coefficient


def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()


def solve(X,y,w):
    sw=np.sqrt(w)
    Q,R=np.linalg.qr(X*sw[:,None],mode='reduced')
    H=np.linalg.solve(R,Q.T)*sw[None,:]
    beta=H@y
    residual=y-X@beta
    unscaled_cov=H@((1/w)[:,None]*H.T)
    scale=float(np.sum(w*residual**2)/(len(y)-X.shape[1]))
    return beta,H,scale*unscaled_cov,scale


def main():
    p=argparse.ArgumentParser();p.add_argument('--primary-rows',type=Path);args=p.parse_args()
    INP.mkdir(parents=True,exist_ok=True)
    if args.primary_rows:
        assert not (INP/'MANIFEST.json').exists()
        sources={
            'primary_rows.csv':args.primary_rows,
            'bins.csv':ROOT/'results_library/inputs/bins.csv',
            'template.csv':ROOT/'results_library/inputs/template.csv',
            'original_RESULTS.json':ROOT/'results_library/inputs/original_RESULTS.json',
            'FULL_TIDE.json':ROOT/'data/amplitude_spectrum/inputs/FULL_TIDE.json',
            'exploratory_solid_loading_fit.json':ROOT/'results_library/exploratory_solid_loading_fit.json',
        }
        manifest=[]
        for name,src in sources.items():
            shutil.copy2(src,INP/name)
            manifest.append({'file':name,'source':str(src.resolve()),'sha256':sha(src)})
        (INP/'MANIFEST.json').write_text(json.dumps(manifest,indent=2))
    manifest=json.loads((INP/'MANIFEST.json').read_text())
    for rec in manifest: assert sha(INP/rec['file'])==rec['sha256']
    rows=pd.read_csv(INP/'primary_rows.csv');b=pd.read_csv(INP/'bins.csv')
    assert rows.t_utc.equals(b.t_utc) and rows.seg.equals(b.seg) and rows.n.equals(b.n)
    np.testing.assert_allclose(rows.y,b.y,atol=1e-12,rtol=1e-12)
    np.testing.assert_allclose(rows.sigma,b.sigma,atol=1e-12,rtol=1e-12)
    model=b[['t_utc']].merge(pd.read_csv(INP/'template.csv'),on='t_utc',how='left',validate='many_to_one',sort=False)
    np.testing.assert_allclose(model.solid+model.loading,model.total,atol=1e-12,rtol=1e-12)
    group=rows[['lunar','near12','diurnal']].to_numpy()
    np.testing.assert_allclose(group.sum(1)+rows.fixed_remainder,model.total,atol=1e-10,rtol=1e-10)
    n=rows.n.to_numpy(float);T=float(n.sum());sigma=rows.sigma.to_numpy()
    Z=(rows.seg.to_numpy()[:,None]==np.unique(rows.seg)[None,:]).astype(float)
    raw=rows.y.to_numpy()
    frozen=json.loads((INP/'original_RESULTS.json').read_text())
    full=json.loads((INP/'FULL_TIDE.json').read_text())
    load=json.loads((INP/'exploratory_solid_loading_fit.json').read_text())
    reported=[]
    def reported_row(key,A,u,route,definition,status):
        reported.append({'signal':key,'A':float(A),'u_reported':float(u),'rho_absolute_A_over_u':abs(float(A))/float(u),
                         'route':route,'uncertainty_definition':definition,'status':status})
    reported_row('full_nonoverlap',full['A'],full['SE'],'600s_nonoverlap_period_weight',
                 'Larger of scaled LS and UTC-day jackknife','EXISTING_REPRODUCIBLE_FIT')
    for k,name in enumerate(['lunar_group_nonoverlap','near12_group_nonoverlap','diurnal_group_nonoverlap']):
        reported_row(name,frozen['primary']['A'][k],frozen['primary']['u'][k],'600s_nonoverlap_period_weight',
                     'Larger of scaled LS and UTC-day jackknife','EXISTING_REPRODUCIBLE_FIT')
    for key,A,u in [('full_triangular',.90,.12),('lunar_group_triangular',.97,.14),
                    ('near12_group_triangular',.90,.29),('diurnal_twoband_triangular',.36,.50)]:
        reported_row(key,A,u,'v29_triangular_author_report',
                     'Residual calibrated for full/lunar; max scaled LS/day jackknife for near12/diurnal',
                     'LEGACY_REPORTED_RATIO_ONLY_NO_DESIGN_RECONSTRUCTION')
    reported_row('loading_v29',.89,.55,'v29_triangular_author_report',
                 'Specific error provenance unresolved','LEGACY_AUTHOR_REPORTED_NOT_REPRODUCED')
    for k,name in enumerate(['solid_new_auxiliary','loading_new_auxiliary']):
        reported_row(name,load['coefficients'][k],load['UTC_day_delete_one_SE'][k],
                     '600s_nonoverlap_equal_weight_two_full_templates','43-day delete-one jackknife, all parameters refit',
                     'NEW_AUXILIARY_EXPLORATORY')
    pd.DataFrame(reported).to_csv(OUT/'reported_signal_to_noise.csv',index=False)
    models=[
        {'key':'full_nonoverlap','signal_names':['full_nonoverlap'],'S':model[['total']].to_numpy(),'y':raw,
         'w':1/sigma**2,'weighting':'existing_period_noise','reference_A':[full['A']],
         'reference_scaled_ls':[full['scaled_LS']] if 'scaled_LS' in full else None,
         'remainder':'Full prediction, all terms scaled by one coefficient.'},
        {'key':'groups_nonoverlap','signal_names':['lunar_group_nonoverlap','near12_group_nonoverlap','diurnal_group_nonoverlap'],
         'S':group,'y':raw-rows.fixed_remainder.to_numpy(),'w':1/sigma**2,'weighting':'existing_period_noise',
         'reference_A':frozen['primary']['A'],'reference_scaled_ls':frozen['primary']['scaled_ls'],
         'remainder':'Fixed remainder subtracted once; three templates jointly free.'},
        {'key':'solid_loading_new','signal_names':['solid_new_auxiliary','loading_new_auxiliary'],
         'S':model[['solid','loading']].to_numpy(),'y':raw,'w':np.ones(len(raw)),'weighting':'equal_weight',
         'reference_A':load['coefficients'],'reference_scaled_ls':load['scaled_LS_SE'],
         'remainder':'Two complete templates sum to total; no additional remainder.'},
    ]
    same=[];optimal=[];verification=[];operators={}
    for m in models:
        S=m['S'];k=S.shape[1];X=np.column_stack([S,Z])
        A,H,cov,scale=solve(X,m['y'],m['w'])
        np.testing.assert_allclose(A[:k],m['reference_A'],atol=1e-9,rtol=1e-9)
        if m['reference_scaled_ls'] is not None:
            np.testing.assert_allclose(np.sqrt(np.diag(cov)[:k]),m['reference_scaled_ls'],atol=1e-9,rtol=1e-9)
        verification.append({'model':m['key'],'point_estimate_max_abs_difference':float(np.max(np.abs(A[:k]-m['reference_A']))),
                             'reproduced_A':A[:k].tolist(),'reproduced_scaled_LS_SE':np.sqrt(np.diag(cov)[:k]).tolist(),
                             'residual_scale':scale,'rank':X.shape[1],'remainder':m['remainder']})
        operators[m['key']]=H[:k]
        wopt=n/ALPHA**2
        Aopt,Hopt,_,_=solve(X,m['y'],wopt)
        swopt=np.sqrt(wopt)
        Zq=np.linalg.qr(Z*swopt[:,None],mode='reduced')[0]
        for i,name in enumerate(m['signal_names']):
            refA=float(m['reference_A'][i]);h=H[i]
            uwhite=float(ALPHA*np.sqrt(np.sum(h*h/n)))
            uperiod=float(np.sqrt(np.sum(h*h*sigma*sigma)))
            q=float(np.sqrt(np.sum(n*S[:,i]**2)/T))
            eta=float(ALPHA/(q*np.sqrt(T)*uwhite))
            rho=abs(refA)/uwhite
            np.testing.assert_allclose(rho,abs(refA)*q/ALPHA*np.sqrt(T)*eta,atol=1e-12,rtol=1e-12)
            same.append({'signal':name,'status':'SAME_ESTIMATOR_NOISE_PREDICTION','fitted_weighting':m['weighting'],
                'reference_A':refA,'assumed_white_alpha_1e18_sqrt_s':ALPHA,'T_retained_member_s':T,
                'member_weighted_template_RMS_1e18':q,'u_white_same_estimator':uwhite,
                'rho_white_same_estimator':rho,'unit_response_rho_white':1/uwhite,'eta_actual_white':eta,
                'u_periodnoise_same_estimator':uperiod,'rho_periodnoise_same_estimator':abs(refA)/uperiod,
                'definition':'h is row of existing full LS estimator; u_white²=alpha² sum(h²/n), u_period²=sum(h² sigma²).',
                'noise_scope':'Finite-design conditional prediction; no residual scale/jackknife calibration or model uncertainty included.'})
            s=S[:,i]*swopt
            nuisance=np.column_stack([Z,S[:,np.arange(k)!=i]])*swopt[:,None]
            Qn=np.linalg.qr(nuisance,mode='reduced')[0]
            sp=s-Qn@(Qn.T@s);sz=s-Zq@(Zq.T@s)
            information=float(sp@sp);uopt=float(1/np.sqrt(information))
            direct=float(ALPHA*np.sqrt(np.sum(Hopt[i]**2/n)))
            np.testing.assert_allclose(uopt,direct,atol=1e-11,rtol=1e-11)
            etaoff=float(np.linalg.norm(sz)/np.linalg.norm(s))
            etacoupling=float(np.linalg.norm(sp)/np.linalg.norm(sz))
            optimal.append({'signal':name,'status':'OPTIMAL_COMMON_WHITE_DESIGN','weighting':'W=n/alpha²',
                'reference_A':refA,'refitted_A_with_optimal_white_weights':float(Aopt[i]),
                'unit_response_SE':uopt,'unit_response_rho':1/uopt,'rho_at_reference_A':abs(refA)/uopt,
                'rho_at_refitted_A':float(abs(Aopt[i])/uopt),'projected_information':information,
                'eta_total':float(np.linalg.norm(sp)/np.linalg.norm(s)),
                'eta_offset_only':etaoff,'eta_other_templates_given_offsets':etacoupling,
                'definition':'rho=|A| sqrt(s^T W R_N s), all other fitted columns in N.',
                'not_same_estimator_warning':'White-optimal weights may differ from existing estimator; use same-estimator table for comparison with reported errors.'})
    pd.DataFrame(same).to_csv(OUT/'same_estimator_noise_predictions.csv',index=False)
    pd.DataFrame(optimal).to_csv(OUT/'optimal_common_white_predictions.csv',index=False)
    np.savez(OUT/'estimator_rows.npz',**operators)
    result={'reported_ratios':reported,'same_estimator_noise_predictions':same,
            'optimal_common_white_design':optimal,'existing_fit_verification':verification,
            'definitions':{'reported_rho':'|A| / quoted u; descriptive amplitude/error ratio, not a p-value.',
                'same_estimator':'H=(X^T W X)^-1 X^T W calculated by QR; fixed remainder handled before H y.',
                'white_noise_covariance':'diag(alpha²/n_k); alpha=540 in units of 1e-18 sqrt(s).',
                'period_noise_covariance':'diag(sigma_k²) from frozen primary rows; no extra residual scale.',
                'eta_actual':'alpha/(q sqrt(T) uwhite), q²=sum(n_k s_k²)/T; estimator losses are included.',
                'time_scaling':'For assumed coherent signal and independent white noise only: rho=|A| q eta sqrt(T)/alpha, a=1,b=1/2 at fixed q and eta.',
                'T':'sum of retained nominal one-second members, no >=2 day selection; all window effects remain in eta.',
                'legacy':'Triangular estimates give reported ratios only; no invented sampling/estimator to predict their errors.'},
            'reported_value_sources': {
                'full_nonoverlap':'inputs/FULL_TIDE.json: A, SE',
                'groups_nonoverlap':'inputs/original_RESULTS.json: primary.A, primary.u',
                'new_solid_loading':'inputs/exploratory_solid_loading_fit.json: coefficients, UTC_day_delete_one_SE',
                'legacy_triangular':{'path':'../inputs/V29_REPORTED_EXCERPTS.txt','sha256':sha(ROOT/'results_library/inputs/V29_REPORTED_EXCERPTS.txt'),
                    'scope':'Author-reported rounded values transcribed into reported table; no estimator reconstruction.'}},
            'n_rows':len(rows),'n_segments':Z.shape[1],'T_retained_member_s':T,'T_retained_member_h':T/3600,
            'software':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__},
            'randomness':'None: algebraic propagation and finite-design fits, no simulation or fitted coherence exponent.',
            'input_manifest':manifest,'script_sha256':sha(Path(__file__))}
    (OUT/'RESULTS.json').write_text(json.dumps(result,indent=2))
    print(pd.DataFrame(same)[['signal','reference_A','u_white_same_estimator','rho_white_same_estimator','eta_actual_white','rho_periodnoise_same_estimator']].to_string(index=False))
    print(pd.DataFrame(reported)[['signal','rho_absolute_A_over_u']].to_string(index=False))


if __name__=='__main__': main()
