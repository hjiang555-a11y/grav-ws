# Packaging changes

No input observation or template value was changed. The original files remain read only.

- `assemble_snr_table.py`: replace two historical sibling-directory paths by paths inside this package.
- `build_results_library.py`: legacy source pointer now names the exact loading-only excerpt; missing-input status and numerical calculation are unchanged.
- `calculate_signal_to_noise.py`: legacy source pointer now names numbered excerpts covering the reported values; numerical operators and reported values are unchanged.
- `reproduce_amplitude_scan.py`: reuse the validated scan function, with a numeric-only entry point that reads the frozen grid and compares every output ordinate. It does not render figures or require original Fig. 3 panels.
- `run_all.py`: new orchestration, single-thread environment, frozen-output checks and summary JSON/SQLite export. Generated outputs may be overwritten on an explicit rerun; inputs and expected references are not changed.
- No publication tools, credentials, full old manuscript, raw one-second acquisitions or unrelated project files are included. Source machine paths in provenance remain documentary only.
