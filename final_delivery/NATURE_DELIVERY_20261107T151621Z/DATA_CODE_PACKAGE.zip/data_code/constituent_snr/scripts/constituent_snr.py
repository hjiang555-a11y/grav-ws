"""Scalar M2/S2 amplitude SNR in the unchanged equal-weight joint harmonic fit."""
from pathlib import Path
import argparse
import hashlib
import json
import platform
import shutil
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
INP=ROOT/'inputs';OUT=ROOT/'results'
ALPHA=540.0
C=299792458.0;G0=9.80665;CM=100*C*C/G0*1e-18


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def matrix(pairs,seg):
    z=(seg[:,None]==np.unique(seg)[None,:]).astype(float)
    return np.column_stack([pairs,z])


def main():
    p=argparse.ArgumentParser();p.add_argument('--rows',type=Path);p.add_argument('--existing',type=Path);args=p.parse_args()
    INP.mkdir(parents=True,exist_ok=True);OUT.mkdir(parents=True,exist_ok=True)
    if args.rows or args.existing:
        assert args.rows and args.existing and not (INP/'MANIFEST.json').exists()
        manifest=[]
        for name,src in [('primary_rows.csv',args.rows),('existing_NUMERIC_RESULTS.json',args.existing)]:
            shutil.copy2(src,INP/name);manifest.append({'file':name,'source':str(src.resolve()),'sha256':sha(src)})
        (INP/'MANIFEST.json').write_text(json.dumps(manifest,indent=2))
    manifest=json.loads((INP/'MANIFEST.json').read_text())
    for rec in manifest:assert sha(INP/rec['file'])==rec['sha256']
    b=pd.read_csv(INP/'primary_rows.csv');old=json.loads((INP/'existing_NUMERIC_RESULTS.json').read_text())
    assert len(b)==3299 and b.seg.nunique()==54
    stamps=pd.to_datetime(b.t_utc,utc=True)
    sec=stamps.dt.as_unit('ns').astype('int64').to_numpy()/1e9;t=sec-sec.min()
    days=stamps.dt.strftime('%Y-%m-%d').to_numpy()
    names=['M2','S2','N2','K2']
    pairs=np.column_stack([fun(2*np.pi*old['frequency_Hz'][name]*t) for name in names for fun in [np.cos,np.sin]])
    y=b.y.to_numpy();seg=b.seg.to_numpy();n=b.n.to_numpy(float);sigma=b.sigma.to_numpy()
    X=matrix(pairs,seg);Q,R=np.linalg.qr(X,mode='reduced')
    H=np.linalg.solve(R,Q.T);beta=H@y;h4=H[:4]
    residual=y-X@beta;dof=len(y)-X.shape[1]
    ls_cov=(residual@residual/dof)*(h4@h4.T)
    np.testing.assert_allclose(beta[:4],old['joint_coefficients_e18'],rtol=1e-11,atol=1e-11)
    np.testing.assert_allclose(ls_cov,old['joint_scaled_LS_covariance_e36'],rtol=1e-11,atol=1e-11)
    # Refit every remaining parameter in each delete-one UTC-day sample.
    reps=[];dayrows=[]
    for day in np.unique(days):
        keep=days!=day;Xd=matrix(pairs[keep],seg[keep])
        qd,rd=np.linalg.qr(Xd,mode='reduced')
        bd=np.linalg.solve(rd,qd.T@y[keep])[:4]
        reps.append(bd);dayrows.append({'deleted_UTC_day':day,'n_retained':int(keep.sum()),
            'M2_cos':bd[0],'M2_sin':bd[1],'S2_cos':bd[2],'S2_sin':bd[3]})
    reps=np.array(reps);z=reps-reps.mean(0)
    jk_cov=(len(reps)-1)/len(reps)*(z.T@z)
    np.testing.assert_allclose(jk_cov,old['joint_UTC_day_jackknife_covariance_e36'],rtol=1e-10,atol=1e-10)
    period_cov=(h4*sigma[None,:])@(h4*sigma[None,:]).T
    white_cov=(h4*(ALPHA/np.sqrt(n))[None,:])@(h4*(ALPHA/np.sqrt(n))[None,:]).T
    covs={'actual_period_noise':period_cov,'common_alpha540_white':white_cov,
          'existing_scaled_LS':np.asarray(old['joint_scaled_LS_covariance_e36']),
          'existing_UTC_day_jackknife':np.asarray(old['joint_UTC_day_jackknife_covariance_e36'])}
    results=[];h_amp=[];T=float(n.sum())
    for i,name in enumerate(['M2','S2']):
        sl=slice(2*i,2*i+2);coef=beta[sl];amplitude=float(np.linalg.norm(coef));J=coef/amplitude
        h=J@h4[sl];h_amp.append(h)
        phase_matched_unit=pairs[:,sl]@J
        q=float(np.sqrt(np.sum(n*phase_matched_unit**2)/T))
        for label,cov in covs.items():
            ua=float(np.sqrt(J@cov[sl,sl]@J));rho=amplitude/ua
            rec={'constituent':name,'covariance_model':label,'frequency_uHz':old['frequency_Hz'][name]*1e6,
                'cos_1e18':float(coef[0]),'sin_1e18':float(coef[1]),'amplitude_1e18':amplitude,
                'amplitude_cm':amplitude*CM,'amplitude_SE_local_delta_1e18':ua,'amplitude_SE_local_delta_cm':ua*CM,
                'rho_amplitude_over_SE':rho,'J_cos':float(J[0]),'J_sin':float(J[1]),
                'target_pair_covariance_e36':cov[sl,sl].tolist(),
                'scope':'Local scalar delta propagation in the same M2/S2/N2/K2 + S54 equal-weight joint estimator; not a calibrated CI or Gaussian detection significance.'}
            if label=='actual_period_noise':
                direct=float(np.sqrt(np.sum(h*h*sigma*sigma)))
                np.testing.assert_allclose(ua,direct,rtol=1e-12,atol=1e-12)
                rec['direct_phase_aligned_operator_SE_1e18']=direct
            if label=='common_alpha540_white':
                direct=float(ALPHA*np.sqrt(np.sum(h*h/n)))
                np.testing.assert_allclose(ua,direct,rtol=1e-12,atol=1e-12)
                eta=ALPHA/(q*np.sqrt(T)*ua)
                np.testing.assert_allclose(rho,amplitude*q*eta*np.sqrt(T)/ALPHA,atol=1e-12,rtol=1e-12)
                rec.update({'direct_phase_aligned_operator_SE_1e18':direct,'T_retained_member_s':T,
                            'phase_matched_unit_member_RMS':q,'eta_actual_white':eta})
            results.append(rec)
        np.testing.assert_allclose(h@y,amplitude,atol=1e-11,rtol=1e-11)
    pd.DataFrame(results).to_csv(OUT/'constituent_snr.csv',index=False)
    pd.DataFrame(dayrows).to_csv(OUT/'delete_day_coefficients.csv',index=False)
    np.savez(OUT/'estimator_rows.npz',H_joint_four=h4,h_amplitude_M2=h_amp[0],h_amplitude_S2=h_amp[1])
    info={'status':'COMPUTED_SAME_ESTIMATOR_SINGLE_CONSTITUENT_SCALAR_SNR',
        'model':'raw y = M2 cos/sin + S2 cos/sin + N2 cos/sin + K2 cos/sin + 54 offsets; all free, equal fit weights.',
        'phase_origin_UTC':b.t_utc.iloc[0],'n_rows':len(b),'n_segments':54,'n_UTC_delete_days':len(reps),
        'T_retained_member_s':T,'T_retained_member_h':T/3600,'fit_rank':X.shape[1],'residual_dof':dof,
        'fit_weighting':'Equal. Period noise changes propagated covariance only, not fitted coefficients or H.',
        'noise_models':{'actual_period_noise':'diag(sigma_k²) from existing period-dependent sigma; assumes independent bin errors, propagated H Sigma H^T.',
                       'common_alpha540_white':'diag(540²/n_k), alpha corresponds to about5.4e-16 sqrt(s).',
                       'existing_scaled_LS':'Existing residual-scaled LS covariance, independently reproduced.',
                       'existing_UTC_day_jackknife':'Existing covariance of four joint coefficients, independently reproduced by 43 deletions.'},
        'scalar_definition':'A=hypot(beta_cos,beta_sin); J=(beta_cos,beta_sin)/A; uA=sqrt(J C_pair J^T); rho=A/uA.',
        'operator_definition':'h_A=J H_pair; actual period noise uA²=sum(h_A,k² sigma_k²).',
        'interpretation':'Measured-phase local linearization, especially approximate at low S2 SNR; not a nonlinear amplitude CI, p-value or independent detection significance.',
        'coefficient_order':old['joint_order'],'covariance_e36':{key:value.tolist() for key,value in covs.items()},
        'results':results,
        'verification':{'coefficient_max_abs_difference':float(np.max(np.abs(beta[:4]-old['joint_coefficients_e18']))),
                        'scaled_LS_covariance_max_abs_difference':float(np.max(np.abs(ls_cov-old['joint_scaled_LS_covariance_e36']))),
                        'UTC_day_covariance_max_abs_difference':float(np.max(np.abs(jk_cov-old['joint_UTC_day_jackknife_covariance_e36'])))},
        'input_manifest':manifest,'script_sha256':sha(Path(__file__)),
        'software':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__},
        'randomness':'None: deterministic fits, analytic covariance propagation, and delete-day refits; no simulated noise.',
        'code_and_result_hashes':{name:sha(OUT/name) for name in ['constituent_snr.csv','delete_day_coefficients.csv','estimator_rows.npz']}}
    (OUT/'RESULTS.json').write_text(json.dumps(info,indent=2))
    print(pd.DataFrame(results)[['constituent','covariance_model','amplitude_1e18','amplitude_SE_local_delta_1e18','rho_amplitude_over_SE']].to_string(index=False))


if __name__=='__main__':main()
