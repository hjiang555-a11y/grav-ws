from pathlib import Path
import argparse,subprocess,re,json,shutil,sys,platform
from docx import Document
from docx.shared import Pt,Mm
R=Path(__file__).resolve().parents[1]
a=argparse.ArgumentParser();a.add_argument('--out',type=Path,required=True);args=a.parse_args()
O=args.out.resolve();O.mkdir(parents=True,exist_ok=False)
parts=[]
for name in ['opening','results_discussion','methods','primary_methods_figure','auxiliary_methods','author_contributions','references','figures_tables','extended_data','supplementary_methods']:
 s=(R/'sections'/f'{name}.md').read_text()
 if name=='supplementary_methods':s='\\clearpage\n\n'+s
 if name=='opening':
  first,rest=s.split('\n',1);s=first+'\n\n::: authors\n'+(R/'sections/author_block.md').read_text()+'\n:::\n'+rest
 s=re.sub(r'\bref\.\s+(\d+)(?![\d^])',r'ref. ^\1^',s)
 if name=='methods':s=re.sub(r'\[([\d,– -]+)\]',r'^\1^',s).replace('ref. ^','ref. ^')
 if name=='primary_methods_figure':s=s.replace('.pdf){width=100%}', '.png){width=100%}')
 if name in ['figures_tables','extended_data','supplementary_methods']:
  s=re.sub(r'^# (Figures and Table|Extended Data)\n', '',s,flags=re.M)
  s=re.sub(r'(?m)(^!\[|^\*\*(?:Extended Data Table|Table 1))',r'\\clearpage\n\n\1',s)
  s=s.replace('.pdf){width=100%}', '.png){width=100%}')
 parts.append(s)
source='\n\n'.join(parts)
# Source section numbers remain stable; the compiled manuscript follows first citation order.
authors=re.search(r'::: authors\n.*?\n:::',source,re.S).group(0)
reference_source=(R/'sections/references.md').read_text()
source=source.replace(authors,'__AUTHOR_BLOCK__').replace(reference_source,'__REFERENCES__')
ref_entries={int(m.group(1)):m.group(2) for m in re.finditer(r'(?m)^(\d+)\. (.+)$',reference_source)}
order=[]
def expand_refs(value):
 result=[]
 for piece in value.split(','):
  piece=piece.strip()
  if not piece:continue
  bounds=re.split('[–-]',piece)
  if len(bounds)==2:result.extend(range(int(bounds[0]),int(bounds[1])+1))
  else:result.append(int(piece))
 return result
for hit in re.finditer(r'\^([\d,– -]+)\^',source):
 for value in expand_refs(hit.group(1)):
  if value not in order:order.append(value)
assert set(order)<=set(ref_entries), 'Citation without reference entry'
uncited=sorted(set(ref_entries)-set(order))
# Uncited entries remain in the source library; omit from compiled references.
mapping={old:i+1 for i,old in enumerate(order)}
def cite_repl(m):
 vals=sorted({mapping[v] for v in expand_refs(m.group(1))});chunks=[];i=0
 while i<len(vals):
  j=i
  while j+1<len(vals) and vals[j+1]==vals[j]+1:j+=1
  if j-i>=2:chunks.append(str(vals[i])+'–'+str(vals[j]))
  else:chunks.extend(str(v) for v in vals[i:j+1])
  i=j+1
 return '^'+','.join(chunks)+'^'
source=re.sub(r'\^([\d,– -]+)\^',cite_repl,source)
refs='## References\n\n'+'\n'.join(f'{mapping[old]}. {ref_entries[old]}' for old in order)+'\n'
source=source.replace('__AUTHOR_BLOCK__',authors).replace('__REFERENCES__',refs)
(R/'CITATION_NUMBER_MAP.json').write_text(json.dumps({'source_to_compiled':mapping,'uncited_source_ids':uncited,'reference_count':len(mapping)},indent=2))
(R/'NATURE_ARTICLE_FINAL.md').write_text(source)
header=r'''\usepackage{setspace}
\usepackage{lineno}
\usepackage{fancyhdr}
\usepackage{sectsty}
\allsectionsfont{\raggedright}
\usepackage{float}
\floatplacement{figure}{H}
\setlength{\emergencystretch}{3em}
\widowpenalty=10000
\clubpenalty=10000
\setlength{\tabcolsep}{3pt}
\pagestyle{fancy}\fancyhf{}
\fancyhead[L]{\footnotesize Tidal potential measured with distant optical clocks}
\fancyfoot[C]{\thepage}
\setlength{\headheight}{14pt}
'''
(O/'header.tex').write_text(header)
ref=Document();sec=ref.sections[0];sec.page_width=Mm(210);sec.page_height=Mm(297)
sec.left_margin=sec.right_margin=Mm(20);sec.top_margin=sec.bottom_margin=Mm(20)
ref.styles['Normal'].font.name='Times New Roman';ref.styles['Normal'].font.size=Pt(11)
ref.styles['Normal'].paragraph_format.line_spacing=1.5
ref.save(O/'reference.docx')
logs=[]
for stem in ['NATURE_ARTICLE_FINAL']:
 s=(R/(stem+'.md')).read_text()
 chunks=s.split('\\clearpage');joined=[];idx=0
 while idx<len(chunks):
  chunk=chunks[idx]
  if chunk.strip() in ['## Figures and Table','## Extended Data'] and idx+1<len(chunks):
   joined.append(chunk+'\n\n'+chunks[idx+1]);idx+=2
  else:joined.append(chunk);idx+=1
 # Prevent headings being left alone before a figure.
 s='\n\n\\clearpage\n\n'.join('\n::: display\n'+c.strip()+'\n:::\n' if ('![' in c or c.lstrip().startswith('**Extended Data Table') or c.lstrip().startswith('**Table 1')) else c for c in joined)
 for ext in ['tex','pdf','docx']:
  t=s
  if ext in ['pdf','tex']:
   t=re.sub(r'(figures/[^)]+)\.png',r'\1.pdf',t)
   t=('\\onehalfspacing\n\\linenumbers\n\n' if stem.startswith('NATURE') else '\\singlespacing\n\n')+t
  inp=O/(stem+'_'+ext+'.md');inp.write_text(t)
  cmd=['pandoc',str(inp),'--standalone','--from=markdown-implicit_figures','--resource-path='+str(R),'--lua-filter='+str(R/'scripts/layout.lua'),'-o',str(O/(stem+'.'+ext))]
  if ext in ['pdf','tex']:
   cmd+=['-V','mainfont=DejaVu Serif','-V','sansfont=DejaVu Sans','-V','papersize=a4','-V','geometry:margin=20mm','-V','fontsize=11pt','-H',str(O/'header.tex')]
   if ext=='pdf':cmd+=['--pdf-engine=xelatex','--pdf-engine-opt=-no-shell-escape']
  else:cmd+=['--reference-doc='+str(O/'reference.docx')]
  p=subprocess.run(cmd,cwd=R,capture_output=True,text=True)
  (O/(stem+'_'+ext+'.log')).write_text(p.stderr)
  logs.append({'stem':stem,'format':ext,'code':p.returncode})
  if p.returncode:print(p.stderr);raise SystemExit(p.returncode)
 d=Document(O/(stem+'.docx'))
 if stem=='NATURE_ARTICLE_FINAL':
  in_authors=False
  for par in d.paragraphs:
   if par.text.startswith('Lei Hou') and 'Xiang Zhang' in par.text:in_authors=True
   if par.text.startswith(('Optical clocks measure','The Moon and the Sun')):in_authors=False
   if in_authors:
    par.paragraph_format.line_spacing=1
    par.paragraph_format.space_after=Pt(4)
    for run in par.runs:run.font.size=Pt(9)
 for par in d.paragraphs:
  if stem=='COVER_LETTER' or par.text.startswith(('Fig.','Extended Data','Table 1')) or par._p.xpath('.//w:drawing'):par.paragraph_format.line_spacing=1
 for table in d.tables:
  for row in table.rows:
   for cell in row.cells:
    for par in cell.paragraphs:
     par.paragraph_format.line_spacing=1
     for run in par.runs:run.font.size=Pt(9)
 d.save(O/(stem+'.docx'))
 for ext in ['pdf','tex','docx']:shutil.copy2(O/(stem+'.'+ext),R/(stem+'.'+ext))
(O/'BUILD_LOG.json').write_text(json.dumps(logs,indent=2))
(R/'DOCUMENT_ENVIRONMENT.json').write_text(json.dumps({'python':sys.version,'platform':platform.platform(),'pandoc':subprocess.run(['pandoc','--version'],capture_output=True,text=True).stdout.splitlines()[0],'xelatex':subprocess.run(['xelatex','--version'],capture_output=True,text=True).stdout.splitlines()[0]},indent=2))
print(json.dumps(logs))
