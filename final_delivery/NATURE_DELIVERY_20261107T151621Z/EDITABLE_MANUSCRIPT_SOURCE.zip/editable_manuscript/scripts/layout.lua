function RawBlock(el)
  if el.format == 'tex' and el.text:match('\\clearpage') and FORMAT:match('docx') then
    return pandoc.RawBlock('openxml', '<w:p><w:r><w:br w:type="page"/></w:r></w:p>')
  end
end
function Div(el)
  if el.classes:includes('authors') and FORMAT:match('latex') then
    local content={pandoc.RawBlock('latex','\\begingroup\\singlespacing\\small\\nolinenumbers')}
    for _,v in ipairs(el.content) do table.insert(content,v) end
    table.insert(content,pandoc.RawBlock('latex','\\endgroup'))
    return content
  end
  if el.classes:includes('display') and FORMAT:match('latex') then
    local content={pandoc.RawBlock('latex','\\par\\noindent\\begin{minipage}[t]{\\linewidth}\\vspace{0pt}\\singlespacing\\small\\nolinenumbers')}
    for _,v in ipairs(el.content) do table.insert(content,v) end
    table.insert(content,pandoc.RawBlock('latex','\\end{minipage}\\par'))
    return content
  end
end
