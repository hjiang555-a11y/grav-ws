# Editable manuscript source

This package contains the selected combined manuscript, its section sources,
all preserved figure assets, and the document build script. It is a manuscript
source package, not the analysis code package. Some figures were extracted from
the author-supplied earlier manuscripts; this archive does not imply that every
figure has been regenerated from raw observations.

Run in an extracted copy with Python 3, python-docx, Pandoc, XeLaTeX, DejaVu Serif
and DejaVu Sans installed:

```sh
python scripts/build.py --out build_reproduced
```

Choose a new output directory. The script also regenerates NATURE_ARTICLE_FINAL
files in the extracted root. Preserve the provided files before editing if exact
comparison is needed. Section source references have stable original IDs;
CITATION_NUMBER_MAP.json maps them to the compiled manuscript numbering.

The separate manuscript/SI files in the delivery folder are presentation variants
of this same scientific version. Submission declarations and Extended Data count
still require the actions described in the red author checklist.
