## Methods

### Clocks, frequency transfer and sampling

The Sr optical lattice clock is located in Shanghai (31.130° N, 121.570° E, height approximately 5 m) and the Yb optical lattice clock in Wuhan (30.529° N, 114.357° E, approximately 30 m). The tidal model is insensitive to the absolute heights: changing the Shanghai height by 5 m changes the differential model by $4\times10^{-23}$. The geopotential difference between the clocks, $280.042\pm0.085\ \mathrm{m^2\,s^{-2}}$, was determined by first-order levelling [12]. It enters the static frequency ratio and is absorbed by the fitted offsets. The clocks, fibre link and frequency chain are described in ref. [12]. The evaluated systematic uncertainties of the Sr and Yb clocks are $9.2\times10^{-19}$ and $1.3\times10^{-18}$, respectively [21,22]; optical frequency dissemination over field fibres of comparable length has also been demonstrated [23,24].

A 1,550-nm carrier referenced to the Sr clock through a frequency comb in Shanghai is transmitted to Wuhan, where its beat against the Yb-referenced comb is recorded at 1-s intervals. In the 2026 campaigns, the beat frequency is 33.6 MHz and a deviation of 1 Hz corresponds to $5.17\times10^{-15}$ in Yb/Sr. In 2025, the counter recorded the beat after division by two; these deviations are therefore multiplied by two. Fitting the September–October 2025 campaign alone gives $A=1.28\pm0.31$, consistent with this scale and sign. The white-frequency-noise level of the tide-corrected ratio, $\sigma_y\sqrt{\tau}$, obtained from the overlapping Allan deviation [26] at averaging times of 256–4,096 s, is $7.9\times10^{-16}$ in September–October 2025 and $4.2$–$5.3\times10^{-16}$ in the 2026 campaigns.

The record contains five campaigns: September–October 2025, January 2026, April 2026, May 2026 and June–August 2026. The 54 segments were defined by the experiment team; the summer segments are those used in ref. [12]. There are 38 segments and 270 h before June and 16 segments and 274 h in June–August, giving 544 h, or approximately 23 days, of retained data. The analysis distinguishes these five campaigns from eight observation periods and 29 operating groups. Campaigns define the seasonal subsets and campaign-specific daily terms; observation periods are the units of held-out prediction; operating groups are the units of group bootstrap resampling; segments carry the offsets in the primary fit. These levels are not treated as interchangeable independent samples.

### Data selection

The same selection procedure is applied to every segment. The time axis of each data file is reconstructed from its first time stamp and the sample index. Samples more than 10 Hz from the segment median are removed, the longest uninterrupted run is retained, and leading and trailing samples deviating from the median by more than 1% of the peak-to-peak range are trimmed. The 10-Hz threshold corresponds to approximately $5\times10^{-14}$ in Yb/Sr. To identify smaller transient excursions, the retained 1-s data are averaged over 300 s and compared with a running median over ±30 min. Averages deviating by more than six robust standard deviations of these differences within the segment are removed together with their neighbours. This step removes 0.4% of the samples, or 2.2 h, including an excursion of approximately $-2\times10^{-16}$ lasting about 20 min on 7 July 2026.

The transient criterion uses no tidal model. Its invariance to tidal additions and sensitivity to screening choices are documented in Supplementary Methods SM2. Injection simulations use the selected data because the tested additions leave selection unchanged and the subsequent filter is linear.

Durations refer to retained 1-s samples; exposure measured from the filtered data at 600-s steps, used for temperature overlap, is slightly shorter. The last April segment ends at 18:00 on 19 April. Time stamps are in local time (UTC+8). Endpoint and timing checks are given in Supplementary Methods SM2. Long-period tides are outside the analysis.

### Solid Earth tide and ocean loading

The solid Earth contribution at each clock is computed directly as

$$
\delta W=\sum_m(1+k_{2m})V_{2m}+(1+k_3)V_3-g u_r.
$$

Here $V_{2m}$ are the degree-2 tide-generating potentials of the Moon and Sun separated by order $m$, $V_3$ is the lunar degree-3 potential, and $u_r$ is radial displacement. The IERS algorithm supplies displacement and frequency-dependent Love numbers [16]; their values and constituent definitions are given in Supplementary Methods SM1.

The ocean-loading potential is computed by grid convolution:

$$
\delta W_{\rm ocean}(t)=\sum_{\rm ocean}\rho_w\zeta(\mathbf r',t)G_W(\psi)\,\mathrm dA,
\qquad
G_W(\psi)=\frac{ga}{M_E}\sum_n(1+k'_n-h'_n)P_n(\cos\psi).
$$

The ocean elevation $\zeta$ is taken from FES2022 on a $1/30^\circ$ grid [17,18], with $\rho_w=1,025\ \mathrm{kg\,m^{-3}}$. Here $a$ and $M_E$ are Earth's radius and mass, and $\psi$ is angular distance. The Green's function [19] uses PREM load Love numbers [27,28]. We remove the ocean mean and synthesize eight constituents with astronomical arguments and nodal corrections. Numerical implementation and displacement validation are given in Supplementary Methods SM1.

Coastal-mask changes shift the fitted response by 0.06–0.07, approximately half the lunar statistical uncertainty. These are physical-model sensitivity tests, not independent Gaussian errors or an exhaustive loading uncertainty (Supplementary Methods SM1).

### Tidal fits and uncertainty

The 1-s observations and model are filtered identically using a 1,200-s triangular window stepped by 600 s. The whole-template model is fitted by least squares as $y(t)=c_i+A s(t)$, with an offset $c_i$ for segment $i$. The diurnal constituents are the lunisolar diurnal tide, K₁, the principal lunar diurnal tide, O₁, the principal solar diurnal tide, P₁, and the larger lunar elliptic diurnal tide, Q₁. For the band analysis, the eight-constituent model is divided either into semidiurnal (M₂, S₂, N₂, K₂) and diurnal (K₁, O₁, P₁, Q₁) bands, or into lunar (M₂, N₂), near-12-h (S₂, K₂) and diurnal groups with separate amplitudes. The primary grouped fit contains no empirical daily terms. If the full physical model is correct, fitting the solid Earth tide alone on the actual sampling is expected to give $A=1.32$, because loading adds to the solid tide with an M₂ phase difference of approximately 20°.

Where indicated, uncertainty is the larger of the scaled least-squares standard error^52^ and the day-by-day jackknife error. For the full template, semidiurnal band and lunar group, uncertainty is calibrated by residual resampling. The fitted residuals are shifted circularly within each continuous run of the filtered record and added to the model with $A=1$; the standard deviation of the refitted amplitude over 200 realizations supplies the calibrated error. These shifts retain the within-run residual structure under circular wrapping. Calibration uses two independent sets of 200 realizations for the lunar group; disturbance coverage is checked with 5,000 realizations per scenario (Supplementary Methods SM3).

Calibrated errors are used for the whole-template and semidiurnal responses of individual campaigns and of the full record. For the diurnal and near-12-h groups, fits containing empirical daily terms, and fitted daily amplitudes, the larger of the scaled least-squares and jackknife errors is used. In the resampled data, these errors differ from the calibrated uncertainty by factors of 0.8–1.3. Unless otherwise specified, quoted ± uncertainties denote one standard deviation or one standard error as defined by the applicable procedure.

Group-bootstrap intervals are obtained by drawing the 29 operating groups with replacement and refitting 1,000 times; the segment bootstrap instead draws the 54 segments. These procedures permit correlations within each resampling unit but assume independence between units. In the phase test, each tidal band has in-phase and quadrature templates, the latter formed by shifting every constituent by 90°; uncertainty uses segment bootstrap resampling (Supplementary Methods SM3).

The phase-folded summer display is formed after subtracting the fitted segment offsets and non-lunar groups and then averaging in 30° M₂-phase bins; the M₂+N₂ model is folded with the same sampling. Its day-by-day jackknife error bars hold the fitted non-lunar terms fixed. They are conditional display uncertainties and do not propagate uncertainty in those fitted terms; they are distinct from the uncertainty of the joint lunar-amplitude estimate. The summer time-series display uses 3-h averages. Gaps longer than 6 h are removed from the horizontal axis and their locations are marked.

The eight constituents explain 99.84% of model variance; the remaining component, with an r.m.s. of $0.18\times10^{-18}$, is held at its predicted value. Remainder and loading checks are given in Supplementary Methods SM1.

### Daily disturbances and validation

Daily sensitivity fits add terms $a_1\cos\omega t+b_1\sin\omega t+a_2\cos2\omega t+b_2\sin2\omega t$, where $\omega=2\pi/(1\ \mathrm{day})$ and $t$ is local time. Common coefficients and campaign-specific coefficients are examined. A physically constrained alternative uses a free-amplitude 24-h term in each campaign with the phase of the 24-h harmonic of hourly ERA5 2-m air temperature at the two sites [25], averaged over that campaign. Another alternative includes the air-temperature anomalies at both sites relative to a 24-h running mean as two regressors. Within a short campaign, a 24-h term is partly degenerate with diurnal tides and segment offsets.

The sensitivity of the lunar estimate to $B\cos(\omega t-\varphi)$ is evaluated using the lunar row $h$ of the operator $H$ defined below, evaluated for the primary fit. For a common phase, the maximum amplitude change is

$$
B\sqrt{(h\cdot\cos\omega t)^2+(h\cdot\sin\omega t)^2}.
$$

For phases independent between campaigns, the maximum is the sum of the corresponding campaign norms. These bounds describe the specified sinusoidal disturbances and phase assumptions; they do not exclude arbitrary time-varying daily effects.

Injection tests use circularly shifted residuals of the full-template fit, adding either the full tidal model ($A=1$) or the model without its lunar group ($A=0$). Four daily-disturbance scenarios are considered: no added daily disturbance; campaign-specific 24-h terms with air-temperature phases and amplitudes fitted to the observations; common 24-h and 12-h terms with fitted amplitudes and phases; and the fitted summer 24-h and 12-h terms. We use 300 realizations per scenario and injected amplitude; biases and coverage, conditional on these residual and disturbance models, are reported in Supplementary Methods SM3.

Campaign information shares are calculated by projecting the lunar template onto the complement of the near-12-h and diurnal templates and segment offsets, then summing its squared projected values within each campaign.

Held-out prediction estimates the amplitude from the other observation periods and applies it to the excluded period, fitting that period's segment offsets. Results are given in Supplementary Methods SM4.

### Primary spectral diagnostics

The full-record and April spectra show sinusoidal power, defined as squared sinusoidal amplitude divided by two, after projection of segment offsets and before and after subtraction of the fitted whole template (Extended Data Figs. 4 and 11). Its 99% threshold is the quantile of the maximum over 5–40 μHz in 200 resampled residual series. For the April record, pointwise 99% thresholds and the 99% threshold of the maximum over 15–50 μHz are obtained from 1,000 resampled residual series. No frequency exceeds the latter threshold after tidal correction; the largest residual feature, near 39 μHz, is away from the tidal frequencies. The four-day April record combines neighbouring constituents into broad diurnal and semidiurnal bands. Spectral displays use a linear vertical scale. A decrease in spectral power after fitted-template subtraction is a consistency check, not an independent detection statistic.

Segment-wise and independent ten-day-baseline processing are cross-checks on shared observations, not independent measurements (Extended Data Table 5; Supplementary Methods SM5).

### Fibre-link phase locking and monitoring

The 1,350-km link extends the earlier 2,067-km dissemination system, which uses bias-free noise compensation based on digital radio-frequency phase recording [12,24]. Frequency counter B continuously monitors the out-of-loop round-trip signal, and the optical phase-locked loops in the frequency chain are monitored to assess the operating state [12]. Maintaining lock preserves the phase connection needed for coherent accumulation. Lock continuity refers to the phase-locked loops remaining locked; it is distinct from the sampling intervals and gaps in the clock record.

The round-trip beat of the fibre link is recorded at the Shanghai end near 10 MHz with 1-s resolution. Its deviations are normalized by the optical carrier frequency without division by two and filtered in the same way as the clock ratio. Samples more than 10 Hz from the median are excluded. Monitor excursions reaching $10^{-12}$ leave the recorded ratio unchanged. Excluding 300-s monitor blocks deviating by more than $5\times10^{-16}$ changes the regression result by less than 0.005. The monitor covers 474 h of the analysed data. On that overlap, the lunar and whole-template amplitudes are 0.93 and 0.80; including the monitor as an additional regressor changes each by less than 0.005.

### Environmental analysis

The Sr vacuum-chamber temperature is the mean of 20 PT100 sensors sampled every 20 s, available from 28 June to 7 July 2026 and overlapping 98 h of the filtered summer record. The blackbody sensitivity is $6.26\times10^{-17}\ \mathrm{K^{-1}}$ at 294.3 K; a temperature increase raises Yb/Sr. The daily temperature profile is obtained after subtracting a 24-h running mean and excluding the chamber-temperature transient on 30 June. Both clocks apply blackbody corrections in real time, so the recorded ratio already includes them. The regression therefore tests correction errors proportional to chamber temperature; its expected coefficient is zero.

Temperature-regression results and disturbance checks are given in Supplementary Methods SM4.

The triangular-filter analysis reports a separately fitted loading coefficient of $0.89\pm0.55$ (Supplementary Methods SM4). It is distinct from the auxiliary complete-template loading fit described below.
