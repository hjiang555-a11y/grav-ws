# Extended Data

![Extended Data Figure 1](figures/ed1.pdf){width=100%}

**Extended Data Fig. 1 | Tidal records in all campaigns.** Three-hour averages of the filtered frequency ratio after subtraction of fitted segment offsets (blue), with the tidal model (red). Measurement-time axes compress gaps longer than 6 h, marked by vertical lines; gaps longer than 5 days are labelled. The vertical range is ±15 × 10⁻¹⁸, and triangles mark values outside this range. The actual calendar-time axis is retained for the April campaign in Extended Data Fig. 4a.

![Extended Data Figure 2](figures/ed2.pdf){width=100%}

**Extended Data Fig. 2 | Folds by tidal phase and local time.** **a,** All observations folded at the M₂ phase after subtracting fitted segment offsets and all tidal constituents except M₂ from the full-model fit. Points are means in 30° bins with day-by-day jackknife uncertainties; the curve is the M₂ model. These phase-bin uncertainties are conditional on the fitted terms removed before folding, which are held fixed. **b,** Tidally corrected residuals folded by local time in 2-h bins for summer, May (light symbols), the other three campaigns, and summer observations overlapping the temperature record from 28 June to 7 July (open circles). Error bars are day-by-day jackknife uncertainties; bins covering fewer than three days are omitted. The dashed curve is the mean daily blackbody-radiation shift computed from the Sr chamber temperature from 28 June to 7 July 2026 after removing a 24-h running mean and excluding the temperature transient on 30 June. The real-time correction removes this chamber-temperature shift from the recorded frequency ratio.

![Extended Data Figure 3](figures/ed3.pdf){width=100%}

**Extended Data Fig. 3 | Campaign-resolved tidal amplitudes.** **a,** Full-model and semidiurnal amplitude factors for each campaign and the combined observations, fitted with segment offsets. Combined-data estimates also include the lunar group and the solid Earth tide alone. Short campaigns constrain the semidiurnal band as a whole; the joint fit separates the lunar group. **b,** Diurnal amplitude fitted jointly with the semidiurnal band in a two-band fit; the combined estimate is 0.36 ± 0.50. The arrow marks an uncertainty extending beyond the plotted range. Error bars represent one standard deviation, calibrated by residual resampling for the full model, semidiurnal band and lunar group; for the diurnal band and solid Earth tide alone they are the larger of the scaled least-squares and day-by-day jackknife uncertainties. Thin lines in the combined-data rows show 95% intervals from resampling operating groups, or segments for the lunar group.

![Extended Data Figure 4](figures/ed4.pdf){width=100%}

**Extended Data Fig. 4 | April campaign in calendar time and frequency.** **a,** Frequency-ratio observations after the 1,200-s triangular filter and removal of fitted segment offsets, their 3-h averages, and predictions with and without ocean loading. The horizontal axis retains actual calendar dates and gaps (local time, UTC+8). **b,** Sinusoidal power before and after subtracting the model, expressed as amplitude squared divided by two on a linear vertical axis, in units of 10⁻³⁶. The dashed curve is the 99% level at each frequency; the dotted line is the 99% level for the maximum over 15–50 μHz, both obtained from 1,000 resampled residual series. The four-day record combines K₁, P₁ and O₁ into a diurnal band and M₂, S₂ and N₂ into a semidiurnal band. Power below 8 μHz exceeds the displayed range.

![Extended Data Figure 5](figures/ed5.pdf){width=100%}

**Extended Data Fig. 5 | Transient excursions and sample exclusion.** **a,** Sixty-second averages around the excursion on 7 July 2026; red points indicate the 1-s samples excluded by the criterion in Methods. **b,** Distribution of deviations of 300-s means from a running median over ±30 min, divided by the robust standard deviation within each segment. The dashed line marks the threshold of six. The count axis is logarithmic. **c,** Observation time excluded in each campaign.

![Extended Data Figure 6](figures/ed6.pdf){width=100%}

**Extended Data Fig. 6 | Radial-displacement validation of the loading convolution.** **a,b,** Amplitude ratios (**a**) and phase differences (**b**) between radial displacements calculated with the loading Green's function and the FES2022 load-tide grid in the centre-of-mass frame, at Shanghai and Wuhan, for eight constituents. Methods discusses the S₂ discrepancy.

![Extended Data Figure 7](figures/ed7.pdf){width=100%}

**Extended Data Fig. 7 | Local spectra and sampling-response checks on the auxiliary 600-s non-overlapping reduction.** All panels retain 3,299 recorded bin-centre times and the gaps between them, use equal weights and 54 segment constants, and share a linear ordinate and identical density normalization. **a,** The existing observed spectrum, reproduced from the frozen observations, and the stored spectrum after subtraction of the fixed unit physical prediction. **b,** Spectra before subtraction, after subtracting the fitted M₂ waveform, after subtracting the fitted S₂ waveform, and after subtracting both. The two waveforms are obtained from one simultaneous freely phased fit with N₂ and K₂ controlled by their own sine–cosine pairs. **c,** Local scans around M₂ conditioned on S₂, and around S₂ conditioned on M₂; N₂ and K₂ remain controlled. Both the response and the scanned sine–cosine pair undergo the same nuisance projection. The grey curve is the baseline from b. **d,** Deterministic M₂-only, S₂-only and combined fitted-waveform injections through the same sampling and projection operator, compared with the observed spectrum. Individual injected powers need not sum to the combined power because of interference. Dotted vertical lines mark N₂, M₂, S₂ and K₂, in ascending frequency. The ordinate is the nominal-600-s least-squares density defined in Methods, not the amplitude²/2 power in the main triangular-filter analysis. No observations are added in gaps, and these auxiliary estimates do not replace the main lunar-group response.


![Extended Data Figure 8](figures/ed8.pdf){width=100%}

**Extended Data Fig. 8 | Compensation sensitivity on the auxiliary 600-s record.** a,c,e, Subtracting a scaled M₂ waveform and re-estimating S₂; b,d,f, the reverse. a,b, Target amplitude; c,d, absolute phase; e,f, nominal 600-s least-squares density. Solid curves use donor waveforms from the joint fit; dotted curves use single-frequency donor fits. All target-only fits retain segment offsets and free N₂/K₂ pairs. Dashed grey curves also control the donor pair and are invariant by construction. The power improvement for these curves is conditional on the donor and therefore has a different baseline from the target-only curves. λ = 1 denotes subtraction of the selected estimated waveform. Curves describe deterministic sensitivity conditional on the fitted waveforms. Amplitude and density panels share their respective vertical scales across directions, and density axes are linear with zero baselines.


![Extended Data Figure 9](figures/ed9.pdf){width=100%}

**Extended Data Fig. 9 | Harmonic geometry and joint-coefficient correlations on the auxiliary 600-s record.** a, Correlations of the M₂ and S₂ cosine and sine design columns after projecting out 54 segment constants and free N₂/K₂ pairs. b, Normalized lag correlations of the fitted templates, evaluated on the original timestamps without interpolating missing observations; these describe template similarity, not propagation delay. c,d, Correlations between the four coefficients estimated jointly, obtained by normalizing the existing scaled least-squares covariance (c) and UTC-day delete-one jackknife covariance (d). Coefficient order is M₂ cosine, M₂ sine, S₂ cosine and S₂ sine. The three matrices use the same −1 to +1 colour scale. Joint-coefficient covariance describes uncertainty coupling and is distinct from the design-column correlations in a. The 43 UTC days define deletion blocks for the jackknife, not 43 independent measurements. The joint correlations complement the conditional and subtraction evidence for the detected frequency components.

![Extended Data Figure 10](figures/ed10.pdf){width=100%}

**Extended Data Fig. 10 | Sampling aliases and compensation response.** a,b, Observed spectra, spectra after subtraction of a joint-fit donor, and spectra of that donor alone on the identical timestamps and nuisance projection. Vertical markers identify three off-centre local maxima selected from the injection. c,d, Observed power at those fixed candidate frequencies as the compensation factor varies. The curves equal the quadratic responses predicted from the complex coefficient subtraction; this agreement is an operator check rather than an independent alias attribution. All density axes are linear and share scales within rows.

![Extended Data Figure 11](figures/primary_response_methods.pdf){width=100%}

**Extended Data Fig. 11 | Primary grouped responses and full-record harmonic power.** **a,** Amplitude factors for the full model and the semidiurnal band, each fitted with one amplitude, and for the lunar (M₂, N₂), near-12-h (S₂, K₂) and diurnal groups fitted jointly. All fits include segment offsets and omit empirical daily terms. Error bars are one standard deviation, calibrated by residual resampling for the full model, semidiurnal band and lunar group; for the near-12-h and diurnal groups, the larger of the scaled least-squares and day-by-day jackknife uncertainties is used. The dashed line denotes the prediction, *A* = 1. **b,** Joint covariance contours at radii one and two for the lunar and near-12-h amplitudes, using the least-squares correlation and scaling the covariance to the quoted marginal uncertainties. These radii do not denote joint 68% and 95% confidence regions. The cross denotes the model prediction. **c,** Sinusoidal power of the full record after projection of segment offsets, before and after subtracting the fitted full model. Power is the squared sinusoidal amplitude divided by two, plotted on a linear vertical axis in units of 10⁻³⁶; it is not a power spectral density per unit frequency. The dotted line is the 99% quantile of the maximum power over 5–40 μHz from 200 resampled residual series.

\clearpage

**Extended Data Table 1 | Noise-model simulations of the alternative processing.** Bias and coverage of nominal 95% intervals based on the largest of the least-squares, delete-day and delete-period standard errors. *T* denotes the full template without daily terms, and *L* the lunar group with daily terms, using the ten-day calendar-baseline design in Extended Data Table 5 and the actual observation times. Gaussian scenarios contain 1,024 simulations; Student-*t* and moving-average scenarios contain 4,096. OU denotes Ornstein–Uhlenbeck noise and MA(1) a first-order moving-average process.

| Noise model | Bias (*T*) | Coverage (*T*), % | Bias (*L*) | Coverage (*L*), % |
|:--|--:|--:|--:|--:|
| White | −0.000 | 96.7 | −0.001 | 98.3 |
| White + OU, 1 h | −0.007 | 94.5 | −0.002 | 96.9 |
| White + OU, 12 h | −0.002 | 96.1 | +0.031 | 98.8 |
| White + OU, 3 d | +0.003 | 95.9 | +0.004 | 99.8 |
| White + period constants | +0.001 | 96.0 | +0.004 | 98.3 |
| Student-*t*₇ MA(1) | +0.002 | 98.3 | +0.004 | 98.2 |
| Student-*t*₅ MA(1) | +0.001 | 98.9 | +0.003 | 98.3 |
| Student-*t*₇ MA(1) + OU | +0.001 | 97.2 | +0.005 | 98.5 |

**Extended Data Table 2 | Injection tests of the main estimator.** Lunar amplitudes fitted with segment offsets and no empirical daily terms to resampled residuals plus either the full tidal model (*A*true = 1) or the model without the lunar group (*A*true = 0). The four daily-disturbance scenarios are defined in Methods, with 300 realizations per row. Bias and standard deviation describe the fitted amplitude. The median standard error is that computed within each realization, before the final residual-based calibration. Coverage is the fraction of intervals containing the injected amplitude; the accompanying 95% binomial interval refers to one-standard-error coverage. The last column gives the fraction with *A* > 3σ.

| Disturbance | *A*true | Bias | s.d. | Median error | 1σ coverage | 95% binomial interval | 1.96σ coverage | *A* > 3σ |
|:--|--:|--:|--:|--:|--:|:--|--:|--:|
| None | 0 | −0.026 | 0.134 | 0.135 | 0.70 | 0.645–0.751 | 0.94 | 0.003 |
| None | 1 | −0.003 | 0.135 | 0.137 | 0.71 | 0.659–0.764 | 0.94 | 1.000 |
| 24 h, air-temperature phase | 0 | −0.013 | 0.141 | 0.136 | 0.61 | 0.549–0.662 | 0.93 | 0.000 |
| 24 h, air-temperature phase | 1 | −0.007 | 0.145 | 0.138 | 0.64 | 0.579–0.691 | 0.94 | 1.000 |
| Common 24 h + 12 h | 0 | −0.013 | 0.148 | 0.140 | 0.63 | 0.573–0.685 | 0.90 | 0.000 |
| Common 24 h + 12 h | 1 | −0.024 | 0.148 | 0.139 | 0.60 | 0.546–0.659 | 0.92 | 1.000 |
| Summer 24 h + 12 h | 0 | −0.021 | 0.138 | 0.140 | 0.67 | 0.610–0.720 | 0.95 | 0.000 |
| Summer 24 h + 12 h | 1 | −0.016 | 0.150 | 0.137 | 0.59 | 0.529–0.643 | 0.92 | 1.000 |

**Extended Data Table 3 | Daily terms and campaign-specific tidal amplitudes.** Amplitude and local time of maximum of the 24-h term, and amplitude of the 12-h term, fitted jointly with the full tidal model within each campaign. Daily amplitudes are expressed in 10⁻¹⁸. Their uncertainties are the larger of the scaled least-squares and day-by-day jackknife values; uncertainties in the time of maximum are jackknife estimates. Weak sinusoidal amplitudes are biased positive. The full-template amplitude *A*, fitted without daily terms, and its residual-calibrated uncertainty are those in Extended Data Fig. 3a. The last column gives the lunar amplitude fitted independently to each campaign with the main estimator.

| Campaign | Days | 24-h amplitude | 24-h maximum, h | 12-h amplitude | *A* | *A*lunar |
|:--|--:|:--|:--|:--|:--|:--|
| Sep–Oct 2025 | 4 | 5.1 ± 2.7 | 20.7 ± 5.6 | 5.0 ± 9.7 | 1.28 ± 0.31 | 0.04 ± 0.74 |
| Jan 2026 | 4 | 2.1 ± 3.0 | 17.2 ± 3.9 | 4.1 ± 1.8 | 1.27 ± 0.30 | 1.36 ± 0.37 |
| Apr 2026 | 5 | 2.9 ± 2.2 | 1.9 ± 1.4 | 1.0 ± 3.9 | 0.91 ± 0.13 | 0.66 ± 0.42 |
| May 2026 | 4 | 5.2 ± 3.3 | 3.8 ± 2.4 | 3.1 ± 2.6 | 0.97 ± 0.18 | 0.28 ± 0.68 |
| Jun–Aug 2026 | 22 | 2.8 ± 1.3 | 15.8 ± 1.5 | 0.6 ± 0.7 | 0.67 ± 0.18 | 0.87 ± 0.18 |


**Extended Data Table 4 | Free sinusoidal coefficients in the auxiliary reduction.** Joint M₂ and S₂ cosine–sine coefficients, after controlling 54 segment constants and freely phased N₂ and K₂ terms. Coefficients and standard errors are in units of $10^{-18}$. Phases refer to 6 September 2025, 16:05 UTC. Scaled least-squares errors use the residual variance; UTC-day jackknife errors delete each of the 43 observed dates and refit all coefficients. The full covariance matrices are retained with the analysis. These errors describe this auxiliary harmonic model and are not substituted for the primary lunar-group uncertainty.

| Coefficient | Estimate | Scaled LS standard error | UTC-day jackknife standard error |
|:--|--:|--:|--:|
| M₂ cosine | -1.667 | 0.688 | 0.880 |
| M₂ sine | -4.185 | 0.679 | 0.635 |
| S₂ cosine | -0.460 | 0.738 | 0.701 |
| S₂ sine | -1.866 | 0.750 | 1.043 |


**Extended Data Table 5 | Related tidal estimates.** These estimates share observations and are not combined. The last column specifies each uncertainty definition. Applying the segment-wise estimator of Hou et al.^12^ to the summer record with the tidal model used here gives 0.78 ± 0.19.

| Analysis | Data and model | Amplitude factor *A* | Uncertainty |
|:--|:--|:--|:--|
| Hou et al.^12^ | Summer; 16 segments; their tidal model and segment-wise correlation | 0.87(15) | Reported weighted statistical error |
| Main analysis | 54 segments; lunar group; segment offsets; astronomical ephemerides | 0.97 ± 0.14 | Calibrated by residual resampling |
| Full-template analysis | Same observations; full template; segment offsets | 0.90 ± 0.12 | Calibrated by residual resampling |
| Alternative processing | 2026 observations; 600-s means; ten-day calendar baselines; full template | 0.88 ± 0.10 | Largest of least-squares, delete-day and delete-period standard errors |
| Alternative processing | Same observations and baselines; lunar group; daily terms in each ten-day block | 0.89 ± 0.28 | Largest of least-squares, delete-day and delete-period standard errors |


**Extended Data Table 6 | Template-response signal-to-noise ratios.** The first four rows use the non-overlapping full-template or three-group fits; their empirical errors are the larger of scaled-least-squares and UTC-day-jackknife errors. The final two rows use the equal-weight complete solid-Earth/loading fit with UTC-day-jackknife errors. The common-white-noise calculation retains each estimator and uses $\alpha=5.4\times10^{-16}\sqrt{\mathrm{s}}$. The dimensionless factor $\eta_i$ is defined in Methods.

| Fit and coefficient | $\hat A_i\pm u_i$ | $\rho_i$ | $\rho_{i,\mathrm{white}}$ | $\eta_i$ |
|:--|:--|--:|--:|--:|
| Full tide, one template | $0.955\pm0.108$ | 8.83 | 9.79 | 0.865 |
| Lunar group, three-group fit | $1.000\pm0.132$ | 7.58 | 7.50 | 0.840 |
| Near-12-h group (S₂, K₂) | $0.925\pm0.365$ | 2.54 | 3.14 | 0.856 |
| Diurnal group, three-group fit | $0.579\pm0.538$ | 1.08 | 1.55 | 0.740 |
| Solid Earth, two-template fit | $1.082\pm0.322$ | 3.36 | 5.81 | 0.611 |
| Ocean loading, two-template fit | $0.486\pm0.544$ | 0.89 | 1.17 | 0.612 |
