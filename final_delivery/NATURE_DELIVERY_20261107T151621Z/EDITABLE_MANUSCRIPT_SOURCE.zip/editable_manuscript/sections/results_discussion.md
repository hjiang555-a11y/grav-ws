## Results

### Measuring a coastal–inland potential difference

The Shanghai Sr clock and Wuhan Yb clock measure tidal changes in potential difference along a 692-km baseline (Fig. 1a). A 1,350-km phase-stabilized fibre link connects them through Hefei.^24^ The comparison instability is about $5.4\times10^{-16}/\sqrt{\tau/\mathrm{s}}$, where $\tau$ is the averaging time, and is dominated by the clocks. Changes in their frequency ratio track the changing potential, while a fitted offset for each observing segment absorbs the static contribution.

Ocean loading contributes appreciably along the coastal–inland baseline. The solid-Earth calculation follows the IERS conventions.^16^ The FES2022 loading calculation^17,18^ includes water attraction, induced Earth potential and clock displacement.^19^ For the principal lunar semidiurnal tide, M₂, the differential solid-tide and loading amplitudes are $3.41\times10^{-18}$ and $1.42\times10^{-18}$ in fractional frequency. Their 20° phase difference gives a combined amplitude of $4.77\times10^{-18}$ (Fig. 1b).

The record spans 353 days, five campaigns and 54 observing segments (Fig. 1c). The primary triangular-filter reduction retains approximately 544 h after transient screening and applies a 1,200-s filter at 600-s steps identically to observations and model. The auxiliary reduction used in Fig. 3 contains 3,299 non-overlapping 600-s means formed from 545.924 h of retained samples. It supports the frequency-domain checks without the triangular filter. The reductions have distinct selections, weights and physical-template realizations, with segment offsets in both (Methods).

### Tidal amplitude, phase and observation coverage

The auxiliary full-template response is $0.96\pm0.11$, consistent with the combined potential prediction (Fig. 3a). Its error is the larger of scaled least squares and UTC-day jackknife, with observations weighted by each period's noise. A response of one denotes agreement with the predicted frequency-ratio change. To separate the semidiurnal contributions, we group M₂ with the larger lunar elliptic semidiurnal tide, N₂, associated with the Moon's elliptical orbit. The neighbouring group combines the principal solar semidiurnal tide, S₂, with the lunisolar semidiurnal tide, K₂, associated with lunar and solar declination. Within each group, relative amplitudes and phases follow the physical model.

The primary reduction gives lunar and neighbouring responses of $0.97\pm0.14$ and $0.90\pm0.29$ (Fig. 2 and Extended Data Fig. 11). Residual resampling calibrates the lunar uncertainty. The neighbouring-group error is the larger of scaled least squares and day-by-day jackknife. A free-phase lunar fit gives amplitude $0.98\pm0.11$ and phase offset $-6°\pm8°$, with segment-bootstrap uncertainties. The auxiliary phase fit also agrees with the predicted timing (Fig. 3b; Methods). The primary grouped estimate contains no empirical daily terms. Additional fits test their influence.

The lunar and solar semidiurnal periods are approximately 12.42 h and 12 h. Their changing relative phase lets the summer observations distinguish them: the two-month campaign covers the full relative phase cycle, whereas shorter campaigns cover narrower intervals (Fig. 1d). The five campaign estimates are mutually consistent (Extended Data Fig. 3 and Table 3). Figure 2 shows the summer time series and its lunar-phase dependence after removal of fitted offsets and non-lunar groups. The lunar model is folded using the same sampling. Gaps are compressed and marked on the time axis; Extended Data Fig. 4 retains calendar time. The phase and amplitude results agree with the predicted tidal variation.

### Amplitude spectrum and separate semidiurnal detections

The equivalent-height amplitude spectrum has lunar and solar-frequency peaks of 4.87 and 2.87 cm at 22.361 and 23.148 μHz (Fig. 3c). These are sinusoidal peak amplitudes from separate frequency scans with equal weights and 54 segment offsets. Subtracting the fixed unit-amplitude complete physical prediction reduces the amplitudes at these frequencies to 0.71 and 1.02 cm. The calendar span sets the nominal frequency scale; the actual gaps and offset projection shape the spectral response (Methods). The plotted heights express the same measured potential variation through the gravitational redshift relation.

Each principal frequency retains structure when the other is controlled with a freely phased sinusoid (Extended Data Fig. 7). These conditional scans also control N₂ and K₂. Joint fitting gives M₂ and S₂ amplitudes of $4.50\times10^{-18}$ and $1.92\times10^{-18}$, with coefficient uncertainties in Extended Data Table 4. They differ from the scan peaks because neighbouring frequencies are fitted simultaneously. Unlike the physical groups above, the individual sinusoidal contributions have independent phases. The conditional spectra therefore support two contributions without imposing their astronomical phase relation.

### Reliability of the separated signals

Reciprocal subtraction tests their coupling on the recorded sampling (Extended Data Fig. 8). Removing the jointly fitted lunar waveform changes the solar-frequency amplitude from $2.918\times10^{-18}$ to $1.921\times10^{-18}$; removing the solar-frequency waveform changes the lunar amplitude from $4.857\times10^{-18}$ to $4.505\times10^{-18}$. Both remain identifiable. The maximum canonical correlation, measuring the strongest overlap between linear combinations of the projected sine–cosine pairs, is 0.290 (Extended Data Fig. 9). Together, the conditional spectra, reciprocal subtraction and correlation analysis support separation while quantifying the coupling introduced by the sampling.

The primary lunar estimate also remains consistent under explicit daily-disturbance models (Fig. 4). A $10^{-18}$ fractional-frequency sinusoid at 24 h or 12 h changes the response by at most 0.020 when its phase is fixed across the record. Allowing independent campaign phases increases these bounds to 0.032 and 0.12, respectively. These limits apply to the specified amplitudes and phase assumptions. Both clocks correct blackbody shifts in real time; temperature regressions and the chamber-temperature record provide further checks (Methods and Extended Data Fig. 2).

Adding the fibre-link monitor on matching samples changes the lunar and full-template responses by less than 0.005. Retaining excluded transients likewise leaves the lunar result consistent. Fits improve predictions for most withheld observation periods (Methods). Coastal-model sensitivity is larger: extending the ocean mask near Shanghai by 0.3° or 0.6° changes the response by about −0.06 or −0.07. These model shifts are reported separately from statistical uncertainty. Thus the checks distinguish small instrumental and processing effects from the appreciable sensitivity to coastal loading representation.

### Ocean loading and diurnal response

The primary triangular-filter record constrains separate ocean loading and the once-daily tidal band less precisely. The loading coefficient is $0.89\pm0.55$ (Methods). A joint diurnal–semidiurnal fit gives a diurnal response of $0.36\pm0.50$, using the larger scaled-least-squares or day-jackknife error (Extended Data Fig. 3b). This is a physical tidal response, distinct from the empirical 24-h disturbances tested above. The combined potential agrees with the observations, while the separate contributions remain more weakly constrained; refining coastal loading would sharpen this comparison.^15^

## Discussion

The precision of each tidal component depends on signal strength, noise and phase coverage. Sampling interval, continuous observation length and total span affect different parts of the measurement. For uniformly sampled, band-limited signals, the Nyquist condition requires sampling faster than twice the highest signal frequency. Within short observing segments, a slowly varying tide can be absorbed into the fitted offset. Continuous runs of at least two days would cover successive diurnal cycles. Maintaining phase lock preserves the phase connection throughout these runs (Methods, “Fibre-link phase locking and monitoring”). Shorter runs provide less information about slow signals per unit exposure. A longer calendar span separates neighbouring frequencies, while gaps create sidelobes. Their response to lunar-waveform subtraction identifies features associated with the sampling window (Extended Data Fig. 10; Supplementary Methods SM7).

For a specified estimator, the amplitude signal-to-noise ratio scales locally as

$$
\rho_i(T)\simeq\rho_i(T_0)
\frac{\eta_i(T)}{\eta_i(T_0)}
\left(\frac{T}{T_0}\right)^{a_i-b_i}.\tag{1}
$$

Here $T$ is retained exposure, defined consistently at $T_0$, and $\rho_i=S/R$. The exponents $a_i$ and $b_i$ describe accumulation of the unnormalized, phase-aligned signal and noise standard deviation. The factor $\eta_i$ accounts for the sampling window, weights and parameter coupling. For a coherent signal and independent white noise, $a_i=1$ and $b_i=1/2$, giving $\rho_i\propto\sqrt{T}$ at fixed $\eta_i$. The white-noise calculation uses the measured amplitudes and actual sampling, with covariance propagation described in Methods.

::: display
**Table 1 | Calculated and measured signal-to-noise ratios.**

| Evaluation | Lunar M₂ | Solar S₂ | Diurnal group | Ocean loading |
|:--|--:|--:|--:|--:|
| $S/R$ (white noise) | 7.17 | 2.78 | 1.55 | 1.17 |
| $S/R$ (measured) | 7.02 | 1.96 | 1.08 | 0.89 |

Here $S=|\hat A|$ is the measured amplitude or template-response magnitude, $R=u(\hat A)$ is its standard error, and $S/R=\rho$. The white-noise row uses the common noise coefficient and actual sampling; the measured row uses UTC-day-jackknife covariance. All entries use the auxiliary non-overlapping reduction. M₂ and S₂ use their joint sine–cosine fit, the diurnal group uses the three-group fit, and ocean loading uses the complete solid-Earth/loading fit (Methods).
:::

The lunar precision closely matches the white-noise estimate, whereas the solar-frequency contribution has a larger empirical uncertainty (Table 1). Measurements at this frequency may also be affected by the 12-h harmonic of daily laboratory activity. The diurnal group and separate ocean-loading response have signal-to-noise ratios near unity. Short segments constrain diurnal cycles poorly after offset removal, while ocean loading has a smaller predicted amplitude and overlaps the solid-Earth waveform. Unmodelled changes in loading amplitude or phase may further weaken accumulation against a fixed template.^18^ The present estimates do not quantify such coherence loss. The calculated sensitivities account for much of the difference in precision between components under the same assumed time exponents.

Sustained network operation would improve phase coverage and separation, while better clock stability would increase sensitivity within a given observing time. Stable endpoints, local environmental records and additional sites would help identify weaker changes after subtraction of the tidal background. These measurements extend demonstrated sub-centimetre-equivalent clock performance^29^ towards time-varying geophysical observations, alongside applications to ultralight-dark-matter searches^38^ and future clock-based gravitational-wave detectors.^58^

## Summary

We measured tidal potential differences between Shanghai and Wuhan optical clocks and separately detected lunar and solar-frequency semidiurnal contributions, with equivalent-height amplitude-spectrum peaks of 4.87 and 2.87 cm. Conditional spectra, reciprocal subtraction and correlation analysis support their separation. We also developed a sensitivity estimate based on signal strength, noise and sampling that broadly agrees with the precision achieved in the measurements. Sustained observations at more sites would extend this capability to weaker potential changes and their spatial structure.

The 274-h summer record was also used in the absolute-frequency-ratio study by Hou et al.; Extended Data Table 5 relates those estimates to the present tidal analysis.^12^ An independent study has also reported tidal potential variations in a European optical-clock network.^20^
