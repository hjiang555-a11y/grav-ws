### Auxiliary grouped-response and phase estimates

Figure 3 uses the non-overlapping reduction, with 3,299 means, 1,965,327 nominal one-second members and 54 segment constants. The 545.924 member-hours span 353.39 days. This reduction retains its existing valid-interval selection and does not apply the primary analysis's triangular filter or additional transient screening. The template realization is also distinct from the direct-potential primary model. Its solid-Earth sequence converts the IERS radial displacements into fractional frequency as

$$
y_{\rm solid}=-\frac{1+k_2-h_2}{h_2}\frac{g(u_{\rm Wuhan}-u_{\rm Shanghai})}{c^2},
$$

with $h_2=0.6078$, $k_2=0.3010$ and $g=9.794\ \mathrm{m/s^2}$. Its ocean-loading sequence uses the effective-potential convolution with direct water attraction, induced potential and clock displacement, synthesizing 18 loading constituents. Eight named constituents form the lunar, neighbouring semidiurnal and diurnal groups; the remaining terms form a fixed remainder $r_0$.

For the complete-template estimate, a single coefficient multiplies the full prediction, $y_i=c_{s(i)}+A_T(s_{L,i}+s_{S,i}+s_{D,i}+r_{0,i})+\epsilon_i$. For the grouped estimate, the remainder is subtracted once and the three groups are fitted jointly, $y_i-r_{0,i}=c_{s(i)}+A_Ls_{L,i}+A_Ss_{S,i}+A_Ds_{D,i}+\epsilon_i$. The phase-relaxed model adds a quarter-cycle-shifted lunar template while retaining the prescribed internal M₂/N₂ relationship. All models retain the same segment constants. They do not average amplitudes fitted separately to individual segments.

The amplitude fits use $W_{ii}=1/\sigma_i^2$, where $\sigma_i=\alpha_{p(i)}/\sqrt{\Delta t_i}$ and $\Delta t_i=n_i\delta t$ is the retained exposure in bin $i$, with $n_i$ one-second members and $\delta t=1\,\mathrm{s}$. The coefficient $\alpha_p$ describes white frequency noise in observing period $p$ and has units $\sqrt{\mathrm{s}}$. The coefficients are derived from overlapping Allan deviations at 256–4,096 s within acquisition segments. The reported marginal errors are the larger of the residual-scaled least-squares and UTC-day-deletion jackknife standard errors; each deletion refits the coefficients. Grouped and phase-relaxed responses are summarized in Fig. 3 and Supplementary Methods SM6. The contours in Fig. 3b instead use the scaled-least-squares covariance at radii one and two; its quadrature marginal standard error is 0.1273. These contours are covariance summaries, not independently calibrated joint confidence regions.

### Signal-to-noise ratios for the retained sampling

We use $S/R=\rho_i=|\hat A_i|/u(\hat A_i)$, where $S$ is the fitted amplitude or template-response magnitude and $R$ is its standard error. To evaluate the coherent-white-noise case of equation (1), we retain the fitted design matrix $X$, weights $W$ and exposures $\Delta t_k=n_k\delta t$. The operator $H=(X^{\mathsf T}WX)^{-1}X^{\mathsf T}W$ maps observations to fitted coefficients. For white frequency noise with $\alpha=5.4\times10^{-16}\sqrt{\mathrm{s}}$, the bin variance is $\alpha^2/\Delta t_k$, giving

$$
u_{i,\mathrm{white}}^2=\alpha^2\sum_k\frac{H_{ik}^2}{\Delta t_k},
\qquad
\rho_{i,\mathrm{white}}=\frac{|\hat A_i|}{u_{i,\mathrm{white}}}.\tag{2}
$$

The retained exposure is $T=\sum_k\Delta t_k=1,965,327\,\mathrm{s}$. For template $s_i(t_k)$ per unit response at bin-centre time $t_k$, define $s_{i,\mathrm{rms}}^2=\sum_k\Delta t_k\,s_i(t_k)^2/T$ and $\eta_i=\alpha/(s_{i,\mathrm{rms}}\sqrt{T}\,u_{i,\mathrm{white}})$. Then

$$
\rho_{i,\mathrm{white}}=
\frac{|\hat A_i|s_{i,\mathrm{rms}}}{\alpha}\,\eta_i\sqrt{T}.\tag{3}
$$

All retained samples contribute to $T$. The sampling window, fitted offsets, template coupling and chosen weights enter $\eta_i$. No two-day minimum is applied to this record. Equation (3) gives the $a_i=1$, $b_i=1/2$ sensitivity at the measured amplitude; the time exponents are not fitted.

The first four rows of Extended Data Table 6 use the existing non-overlapping full-template or three-group fits and their larger scaled-least-squares or UTC-day-jackknife errors. To quantify separate loading sensitivity on the same record, we fit the complete solid-Earth and loading templates with two free coefficients and 54 segment offsets, using equal weights. Their sum equals the complete prediction, so no fixed remainder is added separately. This auxiliary fit gives $A_{\rm solid}=1.08\pm0.32$ and $A_{\rm loading}=0.49\pm0.54$. Errors are from deleting each of the 43 UTC days and refitting both coefficients and all remaining offsets. This is distinct from the triangular-filter loading estimate reported above.

For Table 1, the individual M₂ and S₂ estimates retain the equal-weight joint fit of M₂, S₂, N₂ and K₂ sine–cosine pairs and 54 segment offsets. For each target pair, $\hat A=(\beta_c^2+\beta_s^2)^{1/2}$ and $J=(\beta_c,\beta_s)/\hat A$. We propagate the full fitted coefficient covariance and take the target block $C_i$, giving $u^2(\hat A)=JC_iJ^{\mathsf T}$. For the white-noise row, $C_\beta=H\Sigma H^{\mathsf T}$ with $\Sigma_{kk}=\alpha^2/\Delta t_k$. The measured row of Table 1 propagates the coefficient covariance from 43 UTC-day deletion fits through the same gradient. These are local scalar amplitude-to-error ratios, rather than calibrated Gaussian detection significances. The measured amplitudes and propagated errors are listed in Supplementary Methods SM6.

The diurnal and loading columns of Table 1 use their original template estimators; the loading column refers to the auxiliary complete-template fit. Within each column, the estimator, amplitude and physical target are unchanged between the white-noise calculation and measured uncertainty (Supplementary Methods SM6).

### Local amplitude spectrum in Figure 3

Figure 3c uses the original fractional-frequency means of the auxiliary reduction, equal row weights and their stored UTC bin-centre times. At each trial frequency, we fit a freely phased sinusoid and the same 54 segment constants:

$$
y_i=c_{s(i)}+a_f\cos[2\pi f(t_i-t_0)]+b_f\sin[2\pi f(t_i-t_0)]+\epsilon_i.
$$

The plotted scalar is the sinusoidal peak amplitude $A_y(f)=\sqrt{a_f^2+b_f^2}$. For the residual curve, the fixed unit-amplitude complete physical prediction is first subtracted from the time series, and the sinusoidal fit is then repeated. The response coefficients of Fig. 3a are not applied in this subtraction.

The left axis gives equivalent-height peak amplitude $A_{h,\mathrm{cm}}=100c^2A_y/g_0$ in cm, with conventional standard gravity $g_0=9.80665\ \mathrm{m/s^2}$ and $c=299,792,458\ \mathrm{m/s}$. The right axis gives the same amplitude in fractional-frequency units. Both axes are linear and start at zero. This conversion expresses a potential difference as an equivalent height without changing the physical model's gravity value. It is neither a root-mean-square amplitude nor an amplitude spectral density.

The plotted band is 21–24.5 μHz. The elapsed span $T_{\rm span}=353.3889$ d gives the nominal Rayleigh frequency scale $1/T_{\rm span}=0.03275$ μHz. The basic scan spacing is $1/(12T_{\rm span})=0.002729$ μHz, with the prescribed astronomical frequencies also included. The grid oversamples the Rayleigh scale; the actual sampling window and offset projection determine the peak shapes and coupling. Scan peaks are selected as local amplitude maxima within one Rayleigh scale of each prescribed frequency. These fits control segment offsets only; the joint constituent estimates below also control neighbouring frequencies.

### Auxiliary frequency-domain analysis

The analyses in Extended Data Figs. 7–10 use the same non-overlapping observations and UTC bin-centre convention as Fig. 3c. Fractional-frequency values are expressed numerically in units of 10⁻¹⁸. Spectral fits use equal weights; the physical-template estimates in Fig. 3a,b use the period-dependent noise weights.

For a nuisance matrix N, we form its orthonormal basis Q and apply R = I − QQᵀ to both the observation vector and each trial cosine–sine pair. The spectral score ΔRSS is the reduction in residual sum of squares when the projected pair is fitted. We use the nominal-600-s normalization, D(f) = 600 × 10⁻⁴² ΔRSS per µHz. This convention provides a common scale for comparisons on these gapped observations; integrating it is not asserted to recover the time-domain variance. Extended Data Fig. 7a uses segment constants only. Extended Data Fig. 7b–d add freely phased N₂ and K₂ terms. All sinusoidal phases refer to 6 September 2025, 16:05 UTC, the first stored bin centre.

The M₂ and S₂ subtraction waveforms come from a simultaneous four-coefficient fit after the same nuisance projection. Conditional scans add the other principal pair to N and scan within ±0.16 µHz of the target. No physical amplitude ratio or phase constraint links the two principal components. As a nuisance sensitivity check, their joint amplitudes without N₂/K₂ control are 4.63 and 1.82 × 10⁻¹⁸. Scaled least-squares and UTC-day-deletion covariances quantify the joint coefficient uncertainties (Extended Data Table 4 and Extended Data Fig. 9). Synthetic injection curves contain only the fitted principal sinusoidal waveform evaluated at the measured times, with no added random noise.

### Compensation sensitivity and template correlation

Compensation tests subtract a fixed fitted donor waveform and re-estimate the target with the same nuisance terms. Re-fitting both principal pairs after subtraction is an algebraic control: the target is necessarily unchanged. Pure-injection peaks define the candidate sidelobes. The compensation operator, selection rule, template correlations and coefficient-correlation matrices are detailed in Supplementary Methods SM7 (Extended Data Figs. 8–10).

Identification of the S₂-frequency contribution does not by itself assign its entire amplitude to the astronomical tide: a laboratory variation at exactly 12 h occupies the same frequency. Environmental and daily-term checks are described above.
