# 原图提取与图表核对

- 从 `sources/V29.pdf` 对应的原始文稿逐图裁切，来源 SHA256 为 `3483abc17e4b2c44d8f4c76fd9877b7f8b90119be5cca2304222da0a5c4fef7b`。共 4 张主图、6 张 Extended Data 图；逐图来源页、坐标及输出哈希见 `extraction_manifest.json`。本次实际运行输入是同级旧包 `final_merge_v29_v87_20261107T053526Z/sources/V29.pdf`。
- 保留 PDF 矢量对象，未重绘观测值、未重算科学数据、未增加谱面板。新图不包含旧合稿的 source-preview 红条。原始科学绘图程序缺失；`scripts/extract_figures.py` 可重复执行本次图像提取，不能替代从原始观测生成科学结果的程序。
- 使用 Poppler 将十张图渲染至 PNG，并人工核对 `contact_sheet.png`。图框、轴标签、图例和面板编号完整；Fig. 3c 与 Extended Data Fig. 4b 的谱纵轴为线性，统计量是 amplitude²/2，非单位频率的功率谱密度。Fig. 4b 为干扰幅度响应，其纵轴同样为线性。Extended Data Fig. 5b 的对数轴是样本计数分布，不是频谱。
- 正文图注说明 Fig. 2 / Extended Data Fig. 1 压缩间断、Extended Data Fig. 4 保留实际 UTC 日期、相位平均误差在固定已拟合干扰项条件下计算。没有将模型扣除后的峰降低写成泄漏证明。
- Table 1 与三个 Extended Data 表逐行参照 `V29_LAYOUT_TEXT.txt` 原表转录；数值沿用原文，本轮没有新的仿真或拟合。频谱图注描述现有检验及重采样阈值，未加入新的显著性结论。

运行方法：在文稿根目录运行 `/data/AI_Research/environments/python/sci/bin/python scripts/extract_figures.py --source sources/V29.pdf --output figures_reproduced`。输出目录应为空，脚本拒绝覆盖已存在的图 PDF。软件版本记录在 JSON manifest。
