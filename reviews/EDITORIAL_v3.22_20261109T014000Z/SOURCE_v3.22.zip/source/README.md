# v3.22 editorial source

Rebuilds manuscript layout only, not the underlying scientific analysis.
Requires Python 3, pandoc, XeLaTeX, Liberation Serif/Sans, Latin Modern Math and DejaVu Serif.

    python scripts/build_formal.py --out formal_build_01 --include-author-contributions

Optional Word companion requires python-docx:

    python scripts/export_editable.py

Optional cover-letter PDF/Word (python-docx, pandoc, XeLaTeX):

    python scripts/export_letter.py

Provisional author contributions and explicit correspondence placeholders are included under author instruction. Confirm all metadata before submission.
Only referenced figure PDFs and available SVG counterparts are packaged; all are unchanged from v3.21. Compiled TeX uses relative figure paths.
The package also archives validate_editorial.py, inspect_pdf.py, check_word.py and
check_source_rebuild.py so the logic behind the supplied audit JSON can be inspected.
These are editorial/layout checks, not independent scientific reproduction, and
not all checks are portable within this source ZIP:

- validate_editorial.py requires the original frozen workstation baseline at the
  sibling editorial_v321_20261109T010919Z directory, the original evidence/
  BASELINE_V321_HASHES.json (including its absolute baseline paths), and generated
  formal_build_01 outputs/JSON/logs. The frozen baseline and hash evidence are not
  bundled; the supplied audit/FINAL_VALIDATION.json records the workstation run.
- inspect_pdf.py requires PyMuPDF and Pillow plus PDFs generated in formal_build_01;
  it writes visual_check_01 contact sheets, text and PDF_CHECKS.json. It can run
  after the layout build with those dependencies installed.
- check_word.py requires PyMuPDF, both generated DOCX files and existing LibreOffice
  PDF conversions in evidence/word_preview_01. Generate the DOCX files with the two
  exporters above and arrange LibreOffice previews separately; this script does
  not create previews and the preview files are not bundled.
- check_source_rebuild.py runs from the original workstation project, using its
  evidence/BRANCH_METADATA.json handoff path, delivered SOURCE_v3.22.zip and final
  PDFs. It requires PyMuPDF and the layout build dependencies above, creates a
  fresh evidence/source_rebuild_01 directory and writes the handoff rebuild JSON.
  The handoff metadata is not bundled, so this script is not a standalone check
  inside the extracted ZIP. The build command above is the portable layout entry
  point; rebuild audit results must only be claimed after an actual successful run.

Only evidence/APPROVED_ABSTRACT_SOURCE.md is bundled at its original evidence path;
audit/ JSON and reviews/ records retain existing checks for inspection rather than
supplying every workstation input needed to rerun them.
