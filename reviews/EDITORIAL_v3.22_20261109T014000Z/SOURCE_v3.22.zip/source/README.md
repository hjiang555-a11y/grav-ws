# v3.22 current author-review source

Rebuild the reading PDF, main text PDF and text-only SI:

    python scripts/build_formal.py --out formal_build_01

Export editable Word (python-docx):

    python scripts/export_editable.py

Requires Python 3, pandoc, XeLaTeX and the fonts named in build_formal.py. No scientific refitting is performed. Source artwork is already embedded as PDF/SVG.

`formatting_sources/` contains frozen pre-formatting figure/table inputs and scripts for traceability; it is not a second current manuscript. Native figure restyling requires PyMuPDF, Pillow, Poppler and the licensed Arial/Symbol fonts at documented paths (adapt paths for another machine); fonts are not redistributed. ED composition uses its frozen `inputs/` folder. Table rendering uses frozen Markdown inputs. Reports distinguish permitted reference/time-label edits from numerical results.

Only manuscript layout rebuilding is validated from this ZIP; scientific analysis was not rerun. Author contributions remain absent under the author's instruction. No raw frequency observations or font binaries are included.
