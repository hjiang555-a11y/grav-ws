# v3.22 current editorial source

Layout rebuild only; no underlying scientific analysis is run.
Requires Python 3, pandoc, XeLaTeX, Liberation Serif/Sans, Latin Modern Math and DejaVu Serif.

    python scripts/build_formal.py --out formal_build_01

Editable Word companion (requires python-docx):

    python scripts/export_editable.py

Only active manuscript sections, referenced figure PDFs and available SVG counterparts,
the two build/export scripts and the approved-abstract check source are included.
The author-directed deletion is applied. Historical review records are not included.
All figure files retain their previously delivered bytes. No raw observations are packaged.
