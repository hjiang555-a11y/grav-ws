# v3.22 current editorial source

Layout rebuild (Python 3, pandoc, XeLaTeX and the named fonts in build_formal.py):

    python scripts/build_formal.py --out formal_build_01

Editable Word (python-docx):

    python scripts/export_editable.py

Figure formatting source and frozen original figure PDFs are under figure_format_sources.
Those scripts require PyMuPDF and their documented font files/environment variables.
No font binaries or raw experimental observations are packaged. Scientific values are not recalculated.
The author-directed section deletion remains applied; no historical contribution content is included.
