# 图4 Option B 独立有限复核

**结论：PASS，可采用；建议同步一处布局说明到图注。** 没有发现结果遗漏、区间截断、标签语义丢失或可见重叠。此次只审阅图4，没有改论文或交付目录，没有重新计算科学结果。

对照 `inputs/figure4_original.pdf`、最终 `figure4.pdf/png`、生成脚本及来源记录；原/新PDF实际SHA256绑定在 `REVIEW_CHECKS.json`。读取当前 `editorial_v322_20261109T014000Z/sections/figures_tables.md:17` 的图注。

| 项目 | 结果 |
|:--|:--|
| panel a完整性 | 17个估计行全部保留，分为左侧9行与中间8行；共18条区间，包含主结果下方的额外95% bootstrap区间。逐条核对最终PDF矢量线段与原图按布局变换后的坐标，最大偏差小于0.001 pt，属PDF坐标精度。没有重拟合或按图估计结果值。 |
| 横轴 | 两列同用明确标注的0.5–1.5范围。直接检查原图18条区间的全部端点均落在新裁剪范围内，含无夏季的最宽灰色区间；没有裁去误差线。参考线和主结果带在两列中保持。 |
| 标签 | 全17个简写标签与原标签逐一对应；operating-group/observation-period offsets、24 h/12 h共相位或逐campaign、summer/omit campaign、keep segment ends/excursions等条件均保留。两个列标题明确分组，未改变拟合条件含义。 |
| panel b | 两频率、两相位情形的四根柱均保留；逐一匹配原矢量矩形的布局变换与颜色，最大坐标偏差小于0.002 pt。坐标刻度、10⁻¹⁸条件、相位图例和主估计误差虚线完整；减少中间刻度未改变线性标度。 |
| 字体 | 从最终PDF实际文本span检查，全部可见文字为Arial。a/b为8 pt Arial Bold；普通标签/刻度/图例6.5 pt；轴标题与组标题7 pt；上标−18为6 pt。变量A使用Arial Italic。符合本次指定的字体/字号方案。 |
| 可读性 | 已目视原图和最终PNG。左右两列及panel b无标签压线、图例重叠或裁字；全部文字包围盒在页内。版面183 mm宽、约67.73 mm高。最终插入稿件时须保留此宽度关系，不应缩小后仍宣称实际字号保持6.5/7/8 pt。 |

## 图注最小同步建议

当前图注对滤波验证身份、各项检查、共享观测、95%区间、灰色无夏季区间和panel b扰动定义均仍正确，不需要改科学解释。新增的两列布局最好明确为同一个panel a，避免读者把中间一列误认为panel b。

建议在panel a第一句之后只追加：

> Panel a is arranged in two columns: model and daily-term checks at left, and campaign and selection checks at centre.

并把panel b起句的 `**b,** Change in ...` 最小改为 `**b,** At right, change in ...`。其余图注保持。无需更换数值、检出措辞、误差定义，也无需把“Main result”误说成正文主分析：原图注开头仍明确两panel属于filtered validation / primary reduction。

## 验证范围

`review_figure4.py` 为此次只读矢量/字体检查代码，已实际执行；`REVIEW_CHECKS.json` 为其输出。`review_original.png` 是原PDF的核对渲染。图形坐标检查只用于确认原图内容在排版变换后完整，不属于科学数据重算。本报告不复核其他图、不认证新稿整页布局，也不将现有科学作者待决事项视为关闭。
