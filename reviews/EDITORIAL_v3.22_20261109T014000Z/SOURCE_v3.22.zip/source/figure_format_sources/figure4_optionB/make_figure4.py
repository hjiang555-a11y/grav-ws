"""Layout-only vector reflow of the frozen scientific plot; no fitting or data generation."""
from pathlib import Path
import pymupdf as f
import json,hashlib,textwrap,os
R=Path(__file__).resolve().parent
S=R/'inputs/figure4_original.pdf'
src=f.open(S);page=src[0]
# Original axis: 0 at177.56pt, .5 at217.46pt, 1 at257.37pt, 1.5 at297.27pt.
# Use a labelled .5–1.5 window containing all original intervals; no point digitization.
zero,unit=177.56874084472656,257.37493896484375
x0,x1=(zero+unit)/2,unit+(unit-zero)/2
labels=['Main result','Offsets per operating group','Offsets per observation period','24-h terms, phase of air temperature','Air-temperature regressors','Common 24-h and 12-h terms','24-h terms per campaign','12-h terms per campaign','24-h and 12-h terms per campaign','Summer only','Without Sep–Oct 2025','Without Jan 2026','Without Apr 2026','Without May 2026','Without Jun–Aug 2026','Without trimming of segment ends','Without removal of excursions']
short=['Main result','Operating-group offsets','Observation-period offsets','24 h: air-temperature phase','Air-temperature regressors','Common 24 h + 12 h','24 h per campaign','12 h per campaign','24 h + 12 h per campaign','Summer only','Omit Sep–Oct 2025','Omit Jan 2026','Omit Apr 2026','Omit May 2026','Omit Jun–Aug 2026','Keep segment ends','Keep excursions']
# Clip heights encompass original marks, including first-row secondary 95% interval.
centres=[18.92+11.5*i for i in range(17)]
BLUE=(.18,.43,.70);GREY=(.34,.34,.34);GREEN=(.08,.66,.51)
FONT_BASE=Path('/home/room115/.cache/camoufox/fonts/windows')
FONT_PATHS={'helv':Path(os.environ.get('FIGURE4_ARIAL_REG',FONT_BASE/'arial.ttf')),
 'hebo':Path(os.environ.get('FIGURE4_ARIAL_BOLD',FONT_BASE/'arialbd.ttf')),
 'heit':Path(os.environ.get('FIGURE4_ARIAL_ITALIC',FONT_BASE/'ariali.ttf'))}
FONTS={key:f.Font(fontfile=str(path)) for key,path in FONT_PATHS.items()}
FONT_IDS={'helv':'FigureArial','hebo':'FigureArialBold','heit':'FigureArialItalic'}
def length(s,size=7,font='helv'):
 return FONTS[font].text_length(s,fontsize=size)
def mixed_label(p,parts,cx,y,size=7):
 widths=[length(s,size,font) for s,font in parts]
 x=cx-sum(widths)/2
 for (s,font),w in zip(parts,widths):text(p,s,x,y,size,font);x+=w
def text(p,s,x,y,size=7,font='helv',color=(.1,.1,.1)):
 p.insert_font(fontname=FONT_IDS[font],fontfile=str(FONT_PATHS[font]))
 p.insert_text((x,y),s,fontsize=size,fontname=FONT_IDS[font],color=color)
def line(p,a,b,color=(.2,.2,.2),width=.5,dashes=None):p.draw_line(a,b,color=color,width=width,dashes=dashes)
def rows(p,ids,lx,ax,aw,top,pitch,fs=7,compact=False):
 bottom=top+pitch*(9 if len(ids) in (8,9) else len(ids))
 # Continuous reference band/line through row gaps.
 p.draw_rect(f.Rect(ax+aw*(243.97235107421875-x0)/(x1-x0),top-5,ax+aw*(266.3465576171875-x0)/(x1-x0),bottom-5),fill=(.9281568629,.9711372566,.9582745099),color=None)
 line(p,(ax+aw*.5,top-5),(ax+aw*.5,bottom-5),color=(.2,.2,.2),dashes='[2 2]')
 scale=aw/(x1-x0);half=5.6
 for j,i in enumerate(ids):
  cy=top+pitch*j+pitch/2
  clip=f.Rect(x0,centres[i]-half,x1,centres[i]+half)
  dh=clip.height*scale
  # Uniform transform preserves every mark/interval exactly, without stretching circles.
  p.show_pdf_page(f.Rect(ax,cy-dh/2,ax+aw,cy+dh/2),src,0,clip=clip,keep_proportion=True)
  s=short[i] if compact else labels[i]
  maxwidth=ax-lx-7
  # Fit complete label; wrap only at spaces.
  words=s.split();ls=[];curr=''
  for w in words:
   trial=(curr+' '+w).strip()
   if length(trial,fs)>maxwidth and curr:ls.append(curr);curr=w
   else:curr=trial
  ls.append(curr)
  for k,v in enumerate(ls):text(p,v,lx,cy+(k-(len(ls)-1)/2)*fs*1.05+fs*.32,fs)
 yy=bottom+1
 line(p,(ax,yy),(ax+aw,yy))
 for q in [0,.5,1]:
  xx=ax+aw*q;line(p,(xx,yy),(xx,yy+3));text(p,f'{.5+q:.1f}',xx-5,yy+11,fs)
 mixed_label(p,[('Lunar amplitude factor ','helv'),('A','heit')],ax+aw/2,yy+23,7)
 return bottom

def bars(p,x,y,w,h,legend_y=None,fs=7):
 # Keep source bars as vectors; crop text, then replace labels without stretching fonts.
 oldtop,oldbottom=38.55118,187.93701
 span=oldbottom-oldtop
 clip=f.Rect(394.24252,46.2,508.36536,oldbottom)
 dy=(46.2-oldtop)/span*h
 p.show_pdf_page(f.Rect(x,y+dy,x+w,y+h),src,0,clip=clip,keep_proportion=False)
 line(p,(x,y),(x,y+h));line(p,(x,y+h),(x+w,y+h))
 gy=y+(45.66479-oldtop)/span*h
 line(p,(x,gy),(x+w,gy),color=GREEN,width=.5,dashes='[3 2]')
 for v in [0,.04,.08,.12,.14]:
  yy=y+(oldbottom-v/.02*20.29873-oldtop)/span*h
  line(p,(x-2.5,yy),(x,yy))
  text(p,f'{v:.2f}',x-20,yy+2,fs)
 for q,lab in [(.23262,'24 h'),(.76738,'12 h')]:
  line(p,(x+w*q,y+h),(x+w*q,y+h+2.5))
  text(p,lab,x+w*q-length(lab,fs)/2,y+h+11,fs)
 parts=[('Change of lunar ','helv'),('A','heit'),(' per ','helv'),('10','helv')]
 width=sum(length(t,7,ff) for t,ff in parts)+length('−18',6)
 xx=x+w/2-width/2
 for t,ff in parts:text(p,t,xx,y+h+25,7,ff);xx+=length(t,7,ff)
 text(p,'−18',xx,y+h+21.8,6)
 text(p,'uncertainty',x+w-length('uncertainty',fs),gy-4,fs)
 ly=legend_y if legend_y is not None else y-25
 for j,(s,c) in enumerate([('Phase common to all campaigns',BLUE),('Independent phase per campaign',GREY)]):
  p.draw_rect(f.Rect(x-10,ly+j*10-5,x-2,ly+j*10),fill=c,color=None);text(p,s,x+2,ly+j*10,fs)

def save(name,w,h,setup):
 d=f.open();p=d.new_page(width=w,height=h);setup(p)
 d.subset_fonts()
 d.save(R/(name+'.pdf'),garbage=4,deflate=True)
 p.get_pixmap(matrix=f.Matrix(3,3),alpha=False).save(R/(name+'.png'))
 # SVG retains vector figure content and labels.
 (R/(name+'.svg')).write_text(p.get_svg_image(text_as_path=False))
 d.close()

# Author-approved Option B: two subcolumns within a, b to the right.
def final_B(p):
 text(p,'a',5,12,8,'hebo')
 text(p,'Model / daily terms',20,12,7,'hebo')
 text(p,'Campaign / selection',190,12,7,'hebo')
 rows(p,list(range(9)),5,111,65,22,15,6.5,True)
 rows(p,list(range(9,17)),181,287,65,22,15,6.5,True)
 text(p,'b',366,12,8,'hebo')
 bars(p,397,66,111,92,legend_y=35,fs=6.5)
save('figure4',183/25.4*72,192,final_B)
meta={'operation':'Author-approved Option B replacement; formatting only',
 'source':str(S),'source_sha256':hashlib.sha256(S.read_bytes()).hexdigest(),
 'layout':'two columns of panel a, panel b right','width_mm':183,'height_mm':192/72*25.4,
 'fonts':{k:{'file':str(v),'sha256':hashlib.sha256(v.read_bytes()).hexdigest(),'name':FONTS[k].name} for k,v in FONT_PATHS.items()},
 'font_sizes_pt':{'ordinary':6.5,'axis_labels_and_group_headings':7,'superscript':6,'panel_letters_bold':8},
 'all_17_rows_and_18_intervals_retained':True,'a_axis_range':[.5,1.5],
 'labels':dict(zip(labels,short)),
 'policy_url':'https://research-figure-guide.nature.com/figures/preparing-figures-our-specifications/',
 'no_scientific_recalculation':True}
(R/'FIGURE4_FORMAT_PROVENANCE.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
print(json.dumps({'pdf':str(R/'figure4.pdf'),'fonts':meta['font_sizes_pt']}))
