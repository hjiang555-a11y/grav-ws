"""Read-only figure-geometry/font review; no scientific fitting or regeneration."""
from pathlib import Path
import hashlib,json
import pymupdf as f
R=Path(__file__).resolve().parent
orig=f.open(R/'inputs/figure4_original.pdf')[0]
final=f.open(R/'figure4.pdf')[0]
src_intervals=[]
for d in orig.get_drawings():
 for it in d['items']:
  if it[0]=='l':
   a,b=it[1:]
   if abs(a.y-b.y)<.01 and 165<a.x<350 and 165<b.x<350 and 12<a.y<210:
    src_intervals.append((a.x,b.x,a.y))
assert len(src_intervals)==18
zero,unit=177.56874084472656,257.37493896484375
x0,x1=(zero+unit)/2,unit+(unit-zero)/2
assert all(x0<a<b<x1 for a,b,y in src_intervals)
scale=65/(x1-x0)
all_final_lines=[]
for d in final.get_drawings():
 for it in d['items']:
  if it[0]=='l': all_final_lines.append((it[1].x,it[2].x,it[1].y,it[2].y))
matches=[]
for a,b,y in src_intervals:
 i=0 if y<25 else round((y-18.92)/11.5)
 assert 0<=i<17
 j=i if i<9 else i-9
 ax=111 if i<9 else 287
 cy=22+15*j+7.5
 ey=cy+(y-(18.92+11.5*i))*scale
 ex0,ex1=ax+(a-x0)*scale,ax+(b-x0)*scale
 err=min(max(abs(ex0-c),abs(ex1-d),abs(ey-e),abs(ey-g)) for c,d,e,g in all_final_lines)
 assert err<.01,(i,err)
 matches.append({'source_row':i+1,'max_coordinate_error_pt':err})
source_bars=[d for d in orig.get_drawings() if d['fill'] is not None and d['fill']!=(1.,1.,1.) and d['rect'].x0>390 and d['rect'].width>10 and d['rect'].height>6]
assert len(source_bars)==4
# Select bars in actual panel-b viewport by its shared bottom baseline; exclude
# clipped, invisible copies of original PDF content embedded in panel-a crops.
final_bars=[d for d in final.get_drawings() if d['fill'] is not None and d['fill']!=(1.,1.,1.) and d['rect'].x0>397 and abs(d['rect'].y1-158)<.01 and d['rect'].width>10 and d['rect'].height>6]
assert len(final_bars)==4
sx=111/(508.36536-394.24252)
sy=92/(187.93701-38.55118)
bar_errors=[]
for a,b in zip(source_bars,final_bars):
 expected=f.Rect(397+(a['rect'].x0-394.24252)*sx,66+(a['rect'].y0-38.55118)*sy,397+(a['rect'].x1-394.24252)*sx,66+(a['rect'].y1-38.55118)*sy)
 error=max(abs(u-v) for u,v in zip(expected,b['rect']))
 assert error<.01 and a['fill']==b['fill']
 bar_errors.append(error)
spans=[s for b in final.get_text('dict')['blocks'] for l in b.get('lines',[]) for s in l['spans']]
assert all('Arial' in s['font'] for s in spans)
assert {(s['text'],round(s['size'],1),s['font']) for s in spans if s['text'] in ['a','b']}=={('a',8.0,'Arial Bold'),('b',8.0,'Arial Bold')}
assert {round(s['size'],1) for s in spans}=={6.,6.5,7.,8.}
assert all(final.rect.contains(f.Rect(s['bbox'])) for s in spans)
result={'scope':'Geometry/fonts only; original scientific vectors preserved',
 'original_sha256':hashlib.sha256((R/'inputs/figure4_original.pdf').read_bytes()).hexdigest(),
 'final_sha256':hashlib.sha256((R/'figure4.pdf').read_bytes()).hexdigest(),
 'rows':17,'intervals':18,'all_interval_endpoints_inside_0_5_to_1_5_view':True,
 'interval_geometry_matches':matches,'panel_b_bars':4,'panel_b_max_coordinate_errors_pt':bar_errors,
 'all_visible_text_Arial':True,'font_sizes_pt':sorted({round(s['size'],1) for s in spans}),
 'panel_letters_8pt_bold':True,'all_text_inside_page':True}
(R/'REVIEW_CHECKS.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
