"""Read-only final typography checks after visual review; no figure regeneration."""
from pathlib import Path
import pymupdf as f
import json,hashlib
R=Path(__file__).resolve().parent
audit=json.loads((R/'TYPOGRAPHY_AUDIT.json').read_text())
records=[]
for a in audit['files']:
    q=R/'outputs'/a['path'];p=f.open(q)[0]
    assert hashlib.sha256(q.read_bytes()).hexdigest()==a['output_sha256']
    spans=[s for b in p.get_text('dict')['blocks']for l in b.get('lines',[])for s in l['spans']]
    bad=[{'text':s['text'],'bbox':s['bbox']}for s in spans if not p.rect.contains(f.Rect(s['bbox']))]
    panels=[{'label':s['text'],'font':s['font'],'size':s['size'],'bbox':s['bbox']}for s in spans if s['text'].strip() in list('abcdefg') and ('Bold'in s['font']or s['flags']&16)]
    assert not bad,(q,bad)
    assert all('Arial'in s['font']for s in spans)
    assert all(abs(s['size']-8)<.01 for s in panels)
    if a['changed']:
        assert all(5.59<=s['size']<=8.01 for s in spans)
        assert all(s['size']<=7.01 for s in spans if not (s['text'].strip()in list('abcdefg')and ('Bold'in s['font']or s['flags']&16)))
    records.append({'path':a['path'],'output_sha256':a['output_sha256'],'changed':a['changed'],
                    'fonts':sorted(set(s['font']for s in spans)),
                    'size_min_pt':min(s['size']for s in spans),'size_max_pt':max(s['size']for s in spans),
                    'panel_letters':panels,'out_of_page_text':bad})
assert len(records)==14 and sum(x['changed']for x in records)==13
ed3=next(a for a in audit['files']if a['path']=='figures/ed3.pdf')
assert ed3['source_sha256']==ed3['output_sha256']
(R/'INDEPENDENT_FONT_EDGE_CHECKS.json').write_text(json.dumps({
    'scope':'Font and page-boundary checks after targeted fixes; no scientific recalculation',
    'records':records},ensure_ascii=False,indent=2))
print({'figures':len(records),'changed':sum(x['changed']for x in records),
       'all_text_inside_page':True,'fonts_Arial':True,'panel_letters_8pt_bold':True})
