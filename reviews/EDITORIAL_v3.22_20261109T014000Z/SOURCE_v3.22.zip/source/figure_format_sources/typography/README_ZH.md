# v3.22 图件字体与排版核查

本轮按作者明确指示检查 Nature 图件字体、字号和重叠。研究数据、统计估计、误差线、扫描曲线、模型、坐标范围和图中数值均未重算；本任务是组稿排版，不是新的数据分析。样本量、实验设计及不确定度沿用既有图和图注，本轮不产生统计结果。

输入为当前 v3.22 的 14 张活动图（不包括由主代理另行制作的图4 Option B），冻结副本保存在 `inputs/figures/`。输出在 `outputs/figures/`，映射见 `FIGURE_MAPPING.json`。其中13张调整；`ed3.pdf`已经符合要求，逐字节保留。

依据 Nature 官方图件规范：https://research-figure-guide.nature.com/figures/preparing-figures-our-specifications/ 。183 mm图件宽度，普通文字5.6–7 pt，分图字母8 pt粗体；Arial字族，文字保持可编辑，TrueType嵌入。5.6 pt下限为稿件166 mm显示宽度预留缩放空间。嵌入稿件后的分图字母也会随整体缩放；独立投稿图件保留8 pt。

修复包括较小上下标、字体混用、部分图件缩放后过大字号，以及3处贴边文字。Figure 2的a/b字母仅下移1.8 pt；`primary_response_methods.pdf`的Near-12-h标签仅右移1.8 pt。SI Figure 1（ed4.pdf）的左侧完整旋转纵轴标签右移2 pt。ED Figure 4的b、c、d原图例与谱峰相交，图例文字及11条示例线共同右移90 pt（b4条、c3条、d4条），数据曲线、坐标轴和谱峰不动。图3中Unicode上/下标改为相同内容的原生基线偏移字符，以确保字号可控。

脚本 `normalize_typography.py` 从冻结输入复现输出，不依赖现稿后续变化。使用 Python 3.12 / PyMuPDF；具体PyMuPDF版本、字体SHA256、输入/输出SHA256及修改明细见 `TYPOGRAPHY_AUDIT.json`。运行：

```
/data/AI_Research/environments/python/tide-review-20261108T121212Z/bin/python normalize_typography.py
```

Arial字体通过环境变量 `ARIAL_FONT_DIR` 指定；默认本机 `/home/room115/.cache/camoufox/fonts/windows`，须提供arial.ttf、arialbd.ttf、ariali.ttf、arialbi.ttf。图3原Unicode排版宽度通过 `ARIAL_UNICODE_FONT` 指定，默认使用本机 `/home/room115/.cache/camoufox/fonts/macos/Supplemental/Arial Unicode.ttf`。不打包独立字体二进制。源图已嵌入的原字体资源可能仍列在PDF字体资源表中，实际可见文字均按新Arial排版。

验证实际执行：13张输出的所有非空白字符顺序与源图相同（仅统一Unicode规范等价字符、Arial共享字形的软连字符/连字符与中点、相同科学含义的Unicode/原生上下标）；矢量路径数量、几何、颜色、线宽、虚线、透明度、端帽和连接方式相同，ED4明确登记的11条图例线平移除外；图像像素及出现位置相同。PDF序列化坐标容差0.01 pt。`ed3.pdf` SHA256完全相同。没有重新绘制科学数据。

曾试用文字redaction发现库会改变ED2空心标记的虚线继承，因此最终脚本直接清除PDF文字对象并保留原矢量操作；废弃试验未作为交付。最终输出全部通过严格验证。逐图PNG/SVG可供视觉复核，CONTACT_*.png仅为缩略联系表。由独立审阅代理另行检查字体、页边裁切与重叠；其审阅结论由主代理收录。
