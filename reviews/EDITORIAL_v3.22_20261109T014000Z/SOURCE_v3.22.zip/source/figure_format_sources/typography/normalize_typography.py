#!/usr/bin/env python3
"""Typography-only vector-PDF normalization; no statistical computation."""
from pathlib import Path
import os, json, shutil, hashlib, collections, math, unicodedata, re, copy
import pymupdf as f
BASE=Path(__file__).resolve().parent
SOURCE=Path(os.environ.get('FIGURE_SOURCE','/data/AI_Research/projects/grav-ws/manuscript_48h/editorial_v322_20261109T014000Z'))
FONTROOT=Path(os.environ.get('ARIAL_FONT_DIR','/home/room115/.cache/camoufox/fonts/windows'))
FILES=['figure1_v319.pdf','figure2_v1.pdf','amplitude/figure3.pdf','primary_response_methods.pdf','ed3.pdf','ed1.pdf','ED_Figure_4_v35.pdf','ED_Figure_5_v35.pdf','ED_Figure_6_v35.pdf','ed2.pdf','ed4.pdf','SI_Figure_2_v35.pdf','ed5.pdf','SI_Figure_4_v36.pdf']
FONTS={'regular':'arial.ttf','bold':'arialbd.ttf','italic':'ariali.ttf','bolditalic':'arialbi.ttf'}
FONT={k:f.Font(fontfile=str(FONTROOT/v))for k,v in FONTS.items()}
UNICODE_FONT_PATH=Path(os.environ.get('ARIAL_UNICODE_FONT','/home/room115/.cache/camoufox/fonts/macos/Supplemental/Arial Unicode.ttf'))
UNICODE_FONT=f.Font(fontfile=str(UNICODE_FONT_PATH))
WIDTH=183/25.4*72

def lines(p):return [l for b in p.get_text('dict')['blocks'] for l in b.get('lines',[])]
def canonical(t):return unicodedata.normalize('NFC',t).replace('\u00ad','-').replace('ꞏ','·').translate(str.maketrans('⁻¹⁸₂','−182'))
def chars(ls):return collections.Counter(c for l in ls for s in l['spans'] for c in canonical(s['text']) if not c.isspace())
def checksum(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def kind(s):
 font=s['font'].lower(); bold='bold'in font or bool(s['flags']&16);italic='italic'in font or 'oblique'in font or bool(s['flags']&2)
 return 'bolditalic' if bold and italic else 'bold' if bold else 'italic' if italic else 'regular'
def proj(pt,d):return pt[0]*d[0]+pt[1]*d[1]
def normalize(name):
 src=BASE/'inputs'/'figures'/name;out=BASE/'outputs'/'figures'/name
 src.parent.mkdir(parents=True,exist_ok=True);out.parent.mkdir(parents=True,exist_ok=True)
 if not src.exists():shutil.copy2(SOURCE/'figures'/name,src)
 original=f.open(src);op=original[0]
 if name=='ed3.pdf':
  shutil.copy2(src,out);return {'path':'figures/'+name,'changed':False,'source_sha256':checksum(src),'output_sha256':checksum(out),'reason':'Existing 183 mm Arial artwork compliant.'}
 doc=f.open();p=doc.new_page(width=WIDTH,height=op.rect.height*WIDTH/op.rect.width)
 p.show_pdf_page(p.rect,original,0)
 ls=lines(p);before_images=sorted((i['digest'].hex(),tuple(round(v,3)for v in i['transform']))for i in p.get_image_info(hashes=True));before_drawings=p.get_drawings();before_chars=chars(ls)
 # Remove PDF text objects without MuPDF redaction's graphics-state rewriting.
 for x in range(1,doc.xref_length()):
  if not doc.xref_is_stream(x):continue
  if doc.xref_get_key(x,'Subtype')[1]=='/Form' or x in p.get_contents():
   stream=doc.xref_stream(x)
   if name=='ED_Figure_4_v35.pdf':
    pattern=rb'295\.444488 ([0-9.]+) m\s+300\.944488 \1 l\s+306\.444488 \1 l'
    def move_legend(m):
     y=float(m.group(1)); return m.group(0).replace(b'295.444488',b'385.444488').replace(b'300.944488',b'390.944488').replace(b'306.444488',b'396.444488') if (390<y<430 or 180<y<215) else m.group(0)
    stream=re.sub(pattern,move_legend,stream)
    pattern_c=rb'51\.636614 ([0-9.]+) m\s+57\.136614 \1 l\s+62\.636614 \1 l'
    def move_legend_c(m):
     return m.group(0).replace(b'51.636614',b'141.636614').replace(b'57.136614',b'147.136614').replace(b'62.636614',b'152.636614') if 190<float(m.group(1))<215 else m.group(0)
    stream=re.sub(pattern_c,move_legend_c,stream)
   newstream=re.sub(rb'(?<![A-Za-z])BT(?=[\s/]).*?\sET(?![A-Za-z])',b'',stream,flags=re.S)
   if newstream!=stream:doc.update_stream(x,newstream)
 p=doc.reload_page(p)
 assert not lines(p),'Text deletion incomplete'
 assert len(p.get_drawings())==len(before_drawings),'Vector path count changed'
 for k,v in FONTS.items():p.insert_font(fontname='NArial'+k,fontfile=str(FONTROOT/v))
 log=[]
 for l in ls:
  d=l['dir']; ss=[]
  for source_span in l['spans']:
   if not any(c in source_span['text'] for c in '⁻¹⁸₂'):
    ss.append(source_span);continue
   offset=0.0
   for token in re.findall(r'[⁻¹⁸]+|₂|[^⁻¹⁸₂]+',source_span['text']):
    s=copy.deepcopy(source_span);s['text']=token
    origin=f.Point(source_span['origin'])+f.Point(d)*offset
    if any(c in token for c in '⁻¹⁸₂'):
     s['text']=canonical(token);s['size']=source_span['size']*.7
     origin+=f.Point(-d[1],d[0])*(source_span['size']*(.23 if token=='₂' else -.36))
    s['origin']=tuple(origin);ss.append(s)
    offset+=UNICODE_FONT.text_length(token,fontsize=source_span['size'])
  widths=[];new_sizes=[];old_widths=[]
  for s in ss:
   panel=(s['text'].strip() in list('abcdefg') and 'bold'in kind(s) and s['size']>7.3)
   size=8.0 if panel else min(7.0,max(5.6,s['size']))
   new_sizes.append(size)
   ff=FONT[kind(s)]
   assert all(ff.has_glyph(ord(c))for c in unicodedata.normalize('NFC', s['text']).replace('\u00ad','-') if not c.isspace()),(name,s['text'])
   widths.append(ff.text_length(s['text'],fontsize=size))
   old_widths.append(ff.text_length(s['text'],fontsize=s['size']))
  # Keep intentional inter-span gaps and baselines; allow script glyphs to grow.
  shifts=[0.0]
  for i in range(1,len(ss)):
   shifts.append(shifts[-1]+widths[i-1]-old_widths[i-1])
  delta=shifts[-1]+widths[-1]-old_widths[-1]
  # Preserve line centre, including centred tick and rotated axis labels.
  anchor=-delta/2
  for i,s in enumerate(ss):
   point=f.Point(s['origin'])+f.Point(d)*(shifts[i]+anchor)
   if name=='ed4.pdf' and d==(0.0,-1.0) and s['origin'][0]<15:point.x+=2
   if name=='figure2_v1.pdf' and s['text'].strip() in ['a','b'] and new_sizes[i]==8.0:point.y+=1.8
   if name=='ED_Figure_4_v35.pdf' and 309<s['origin'][0]<390 and (55<s['origin'][1]<90 or 270<s['origin'][1]<302):point.x+=90
   if name=='ED_Figure_4_v35.pdf' and 65<s['origin'][0]<145 and 270<s['origin'][1]<292:point.x+=90
   if name=='primary_response_methods.pdf' and ''.join(z['text']for z in ss).startswith('Near-12-h'):point.x+=1.8
   # Font metrics alone cannot predict page edge clipping; keep glyph boxes on canvas.
   mat=f.Matrix(d[0],-d[1],d[1],d[0],0,0)
   color=f.sRGB_to_pdf(s['color'])
   p.insert_text(point,unicodedata.normalize('NFC',s['text']),fontname='NArial'+kind(s),fontsize=new_sizes[i],color=color,morph=(point,mat))
   if abs(new_sizes[i]-s['size'])>.01 or not s['font'].startswith('Arial'):
    log.append({'text':s['text'],'from_font':s['font'],'old_size':round(s['size'],4),'size':new_sizes[i],'origin':list(point),'direction':d})
 doc.subset_fonts()
 doc.save(out,garbage=4,deflate=True)
 check=f.open(out);cp=check[0];after_chars=chars(lines(cp))
 assert before_chars==after_chars, (name,'text mismatch',before_chars-after_chars,after_chars-before_chars)
 def ordered_text(blocks):return ''.join(c for l in blocks for span in l['spans']for c in canonical(span['text'])if not c.isspace())
 assert ordered_text(ls)==ordered_text(lines(cp)),(name,'ordered text mismatch')
 assert len(cp.get_drawings())==len(before_drawings),(name,'path count')
 after_images=sorted((i['digest'].hex(),tuple(round(v,3)for v in i['transform']))for i in cp.get_image_info(hashes=True))
 assert len(before_images)==len(after_images) and all(a[0]==b[0] and all(abs(x-y)<.01 for x,y in zip(a[1],b[1]))for a,b in zip(before_images,after_images)),(name,'image bytes/placement')
 # Paths are compared exactly up to floating serialization precision.
 def geom(ds):
  def clean(x):
   if isinstance(x,(f.Point,f.Rect,f.Quad)):return [clean(v) for v in x]
   if isinstance(x,(list,tuple)):return [clean(v)for v in x]
   if isinstance(x,float):return round(x,3)
   return x
  return [{k:clean(q.get(k))for k in ['items','color','fill','width','dashes','fill_opacity','stroke_opacity','closePath','even_odd','lineCap','lineJoin']}for q in ds]
 
 def close(a,b):
  if isinstance(a,(float,int)) and isinstance(b,(float,int)): return abs(a-b)<0.01
  if isinstance(a,dict) and isinstance(b,dict): return a.keys()==b.keys() and all(close(a[k],b[k])for k in a)
  if isinstance(a,list) and isinstance(b,list): return len(a)==len(b) and all(close(x,y)for x,y in zip(a,b))
  return a==b
 if name=='ED_Figure_4_v35.pdf':
  for idx in [91,92,93,94,139,140,141,188,189,190,191]:
   before_drawings[idx]['items']=[(item[0],*(f.Point(pt.x+90,pt.y)for pt in item[1:]))for item in before_drawings[idx]['items']]
 assert close(geom(before_drawings),geom(cp.get_drawings())),(name,'vector geometry')
 cp.get_pixmap(matrix=f.Matrix(2.5,2.5),alpha=False).save(out.with_suffix('.png'))
 out.with_suffix('.svg').write_text(cp.get_svg_image(text_as_path=False))
 sizes=[s['size']for l in lines(cp)for s in l['spans']]
 return {'path':'figures/'+name,'changed':True,'source_sha256':checksum(src),'output_sha256':checksum(out),'width_mm':cp.rect.width/72*25.4,'height_mm':cp.rect.height/72*25.4,'visible_size_range_pt':[min(sizes),max(sizes)],'text_characters_preserved':True,'ordered_text_preserved':True,'image_pixels_and_placements_preserved':True,'data_vector_geometry_and_styles_preserved':True,'legend_translation_exception':({'panel_b_indices':[91,92,93,94],'panel_c_indices':[139,140,141],'panel_d_indices':[188,189,190,191],'dx_pt':90,'reason':'Prevent existing legend overlap with spectral peaks; labels and handles moved together.'} if name=='ED_Figure_4_v35.pdf' else None),'vector_paths_preserved':len(before_drawings),'modified_spans':log}

if __name__=='__main__':
 report={'scope':'Typography only; source scientific geometry untouched.','nature_specifications':'https://research-figure-guide.nature.com/figures/preparing-figures-our-specifications/','pymupdf':f.VersionBind,'unicode_metrics_font_sha256':checksum(UNICODE_FONT_PATH),'font_sha256':{v:checksum(FONTROOT/v)for v in FONTS.values()},'text_comparison':'Ordered non-whitespace sequence: NFC; Arial shared glyph aliases soft-hyphen/ASCII hyphen and A78F/B7 middle-dot; Unicode mathscripts compared with identical native baseline-shifted characters.','files':[]}
 for name in FILES:
  print(name,flush=True);report['files'].append(normalize(name))
 (BASE/'TYPOGRAPHY_AUDIT.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
 (BASE/'FIGURE_MAPPING.json').write_text(json.dumps({r['path']:str(BASE/'outputs'/r['path'])for r in report['files'] if r['changed']},indent=2)+'\n')
