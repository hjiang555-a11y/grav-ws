from pathlib import Path
import re,subprocess,json
R=Path('/data/AI_Research/projects/grav-ws/manuscript_48h/editorial_v322_20261109T014000Z/sections')
O=Path(__file__).resolve().parent
items={}
for filename,prefix in [('extended_data.md','ED'),('supplementary_methods.md','SI')]:
 t=(R/filename).read_text()
 for m in re.finditer(r'\*\*(?:Extended Data|Supplementary) Table (\d+) \|([^*]+)\*\*.*?\n\n((?:\|[^\n]+\n)+)',t,re.S):
  items[prefix+m[1]]={'title':m[2].strip(),'table':m[3]}
groups=[['SI4','ED3','SI3'],['ED1','SI1','SI2','ED2']]
widths={'ED1':[.17,.05,.16,.17,.15,.15,.15],'ED2':[.18,.45,.11,.26],'ED3':[.20,.07,.07,.07,.08,.09,.19,.10,.13],'SI1':[.22,.13,.325,.325],'SI2':[.44,.2,.12,.12,.12],'SI3':[.40,.15,.15,.15,.15],'SI4':[.14,.40,.46]}
header=r'''\usepackage{fontspec}
\usepackage{unicode-math}
\setmainfont{Arial}[Path=/home/room115/.cache/camoufox/fonts/windows/,UprightFont=arial.ttf,BoldFont=arialbd.ttf,ItalicFont=ariali.ttf]
\setmathfont{Latin Modern Math}
\usepackage{newunicodechar}
\newunicodechar{₂}{\textsubscript{2}}\newunicodechar{₇}{\textsubscript{7}}\newunicodechar{₅}{\textsubscript{5}}
\pagestyle{empty}
\AtBeginDocument{\fontsize{7}{8.2}\selectfont}
\setlength{\tabcolsep}{2pt}
\renewcommand{\arraystretch}{1}
\setlength{\parskip}{1pt}
\setlength{\LTpre}{2pt}\setlength{\LTpost}{3pt}
'''
(O/'probe_header.tex').write_text(header)
for i,group in enumerate(groups,1):
 md='\n\n'.join('**'+chr(97+j)+' | '+items[k]['title']+'**\n\n'+items[k]['table']for j,k in enumerate(group))
 (O/f'table{i}_probe.md').write_text(md)
 seq='{'+','.join('{'+','.join(map(str,widths[k]))+'}'for k in group)+'}'
 (O/f'width{i}.lua').write_text('local n=0\nlocal widths='+seq+'\nfunction Table(t) n=n+1; for i=1,#t.colspecs do t.colspecs[i][2]=widths[n][i] end; return t end')
 cmd=['pandoc',str(O/f'table{i}_probe.md'),'--standalone','--lua-filter='+str(O/f'width{i}.lua'),'-H',str(O/'probe_header.tex'),'-V','geometry:paperwidth=180mm','-V','geometry:paperheight=170mm','-V','geometry:margin=2mm','-o',str(O/f'table{i}_probe.tex')]
 subprocess.run(cmd,check=True)
 p=subprocess.run(['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error',f'table{i}_probe.tex'],cwd=O,capture_output=True,text=True)
 (O/f'table{i}_compile.txt').write_text(p.stdout+p.stderr)
 assert p.returncode==0,p.stdout[-3500:]
print(json.dumps({'groups':groups,'source_tables':list(items)},indent=2))
