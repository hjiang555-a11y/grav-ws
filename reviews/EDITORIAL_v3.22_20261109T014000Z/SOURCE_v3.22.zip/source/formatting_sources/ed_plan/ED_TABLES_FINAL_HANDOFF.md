# ED表最终交付与SHA256

状态：两张表已完成引用12→23、输入冻结、5.5pt上下标、仅底部空白裁切及450dpi LZW TIFF输出。7原表42数据行全部保留；仅授权的两格展示引用、一格544h标签删除及一格文献上标重排发生内容性差别，原格均保留溯源。双引擎与字体/边界/数值检查通过。

最终PDF CropBox：179.9907×133.3930 mm、179.9907×125.8280 mm。最后横线后3mm，原生文字/矢量坐标与字号均未缩放。TIFF1：822690 bytes、3188×2363 px；TIFF2：695710 bytes、3188×2229 px。均450dpi、LZW、低于10MB。完整稿件PDF集成由root执行，此报告不替代整体投稿门禁。

下表列全部最终成品、构建/验证代码、说明及冻结输入的SHA256；不包含中间probe、归档或本清单自身。

|文件|SHA256|
|:--|:--|
|`ED_Table_1.pdf`|`c107485286438769e353bbd5166e9400ab1dcf7697c3100d04897d99f9c390ba`|
|`ED_Table_1.svg`|`27a61e3dbd20e8f290eaf73cd1a6d6aab8db57808f75094eae3b8f91e6c89e03`|
|`ED_Table_1.png`|`5c2c67c63bd7349be4c7aa7ed527e60f96ef86ec3d4f410d86ea675bddce73af`|
|`ED_Table_1_600dpi.png`|`2b29e678e7762e5c86506c72f066e4c8d6411e0c5ca670aabcc09d86116e0c55`|
|`ED_Table_1_poppler.png`|`1582c82469b6afa5899aa25bc7d1a8568a249cad79690ad6c5fba66a54d17ceb`|
|`ED_Table_1_450dpi_LZW.tiff`|`16d266506c0532d97093327ee6ff868575e758f98defafde1b9f879c99cb5387`|
|`ED_Table_1.md`|`d194ee9a4a9958832a6bc2b93020217c83e97294c3dae5400bea3c837aca8428`|
|`ED_Table_1.tex`|`408adda1fe9524741111c5c1a04c96e7ea67c4c1c62ab992b1b6f59c45db3bc7`|
|`ED_Table_1_compile.txt`|`b01010ae09f38ae37138fbbc5b1e481e50a717fd3469815dd1d1abbb9b75bc34`|
|`ED_Table_2.pdf`|`f6f3eabe78677a7596a66c0e42ab7bf5db59c0527fd96dc5f6058d8533d4bd05`|
|`ED_Table_2.svg`|`cb62c11911c50e8db7d554a07804b40508d1d2dca64c2ebe48a10a174e7d6662`|
|`ED_Table_2.png`|`6110143a293687218870b56df6965df777469ae71664396b161a8512fbae0bc5`|
|`ED_Table_2_600dpi.png`|`03cb0805d2ee01abbd797f95cebd790d1d2ed9153e73274cdf5e609c73a2c2fa`|
|`ED_Table_2_poppler.png`|`526db4fb234795eab2c89179caa36c7ab1ba1e564446c43c9436a929bde9b5ee`|
|`ED_Table_2_450dpi_LZW.tiff`|`e34972f175e67fbd31b074ce0e52157cf46b51ecb38437e02c4c2b167b8b3b71`|
|`ED_Table_2.md`|`3601905e53e9c429062b670efe3794e2454a0af71c3c2c43638885f3434eab94`|
|`ED_Table_2.tex`|`1f7432dca2325407d6c348e2ea00368c1f170dc4d0a1aa1e0e9c13b7955454df`|
|`ED_Table_2_compile.txt`|`7dc4c53c019b7bbe574313fd33b4ecc78a84afa3d102a5f2c9423c0b0034ed60`|
|`build_ed_tables.py`|`24896514ef73272286f6db1f3dcbc461cfa3215ff97c9a9f89078708a1ed2126`|
|`verify_ed_tables.py`|`0858cbfd9f7b0f8c1a31c4dbc693a37840e778ff8039330803af2824bf0aea76`|
|`tables_header.tex`|`83607dde60232886da76ca76996b8fbdba914f37ab365cd8d801854d8286f069`|
|`table_width_1.lua`|`f11c1ac1a9b610ac27a916598c681fe97a320ae8b6ca44c593f0bd896ede9a84`|
|`table_width_2.lua`|`438767fd8af9e8be3d0370e193f4b90d7f488fccb5eaf9dfeee45962a6000773`|
|`TABLE_SOURCE_CELL_MAP.json`|`41c7db0e03ad07266fd6fb875e86df6240cf44ab1705345997bfca268558151b`|
|`TABLE_RENDER_CHECKS.json`|`330f24b5d064748a094e773b183cc9762a85fdc9d0752d7157652f23bcd19046`|
|`FROZEN_INPUT_REBUILD_CHECK.json`|`28303eb3637891bc9da8c419e6bf6c669b18788f029ca737c6cf742b6fab1641`|
|`ED_TABLE_LEGENDS_DRAFT.md`|`c9391dab613fb52bdb48ae77a828aeed05b1acb23e0e0ccbca44433180cd5871`|
|`ED_TABLES_IMPLEMENTATION_ZH.md`|`37294cfeaa7b5ae37160e4e118808c8f83ac379344646cfc3ff1c6227c5597f4`|
|`ED_ALLOCATION_PLAN.md`|`e058401f6f3dc735f2d57deb08a3e300fd3af1d4467bc18b68a5b25212f208aa`|
|`inputs/CITATION_ORDER.json`|`cac67c7bb3aec9f3a2f6210081587cb07fbda51a9fef35fc010fb544cbec998b`|
|`inputs/sections/extended_data.md`|`2124a123a38d09c426c953a4445518e7a1391afe4c31cf18a2dc52ea0cb6dbf7`|
|`inputs/sections/supplementary_methods.md`|`a801d4840d1db217c1b0f5518aca87c6654bd2e952e44d341303933e0ac11398`|
|`BOTTOM_CROP_CHECK.json`|`b8b8942428942fd62886d18172a5068464b9dc486485e6dc65f07db8cf3000c1`|
