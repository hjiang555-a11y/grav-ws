**a | Main and filtered validation analyses.**

| | Filtered validation (primary) | Main analysis (auxiliary) |
|:--|:--|:--|
| Data | 1-s samples after transient screening; 544 h | 3,299 non-overlapping 600-s means after segment-median counter-jump rejection and per-segment wall-clock binning (Methods), without the additional running-median transient screening; 545.9 h |
| Filtering | 1,200-s triangular window at 600-s steps, applied to data and model | None |
| Tidal template | IERS 2010 solid tide with constituent-dependent Love numbers; ocean-loading potential by Green's-function convolution of FES2022 (SM1) | IERS radial displacement converted with $h_2$ and $k_2$; effective-potential loading convolution with 18 constituents (Methods) |
| Weights | Equal | Observing-period noise for the full-template and three-group fits; equal for spectral scans, joint sinusoid fits and the solid-Earth/loading fit |
| Uncertainties | Residual resampling for the full template, semidiurnal band and lunar group; larger of scaled least squares and day-by-day jackknife otherwise | Larger of scaled least squares and UTC-day jackknife |
| Used in | Fig. 1b,d, Figs. 2 and 4, Extended Data Figs. 1–3 and 7, Extended Data Tables 1–3, Supplementary Figs. 1 and 3 | Fig. 3, Table 1, Extended Data Figs. 4–6, Supplementary Fig. 2, Supplementary Tables 1 and 2 |


**b | Injection tests of the primary estimator.**

| Disturbance | $A_{\mathrm{true}}$ | Bias | s.d. | Median error | 1σ coverage | 95% binomial interval | 1.96σ coverage | *A* > 3σ |
|:--|--:|--:|--:|--:|--:|:--|--:|--:|
| None | 0 | −0.026 | 0.134 | 0.135 | 0.70 | 0.645–0.751 | 0.94 | 0.003 |
| None | 1 | −0.003 | 0.135 | 0.137 | 0.71 | 0.659–0.764 | 0.94 | 1.000 |
| 24 h, air-temperature phase | 0 | −0.013 | 0.141 | 0.136 | 0.61 | 0.549–0.662 | 0.93 | 0.000 |
| 24 h, air-temperature phase | 1 | −0.007 | 0.145 | 0.138 | 0.64 | 0.579–0.691 | 0.94 | 1.000 |
| Common 24 h + 12 h | 0 | −0.013 | 0.148 | 0.140 | 0.63 | 0.573–0.685 | 0.90 | 0.000 |
| Common 24 h + 12 h | 1 | −0.024 | 0.148 | 0.139 | 0.60 | 0.546–0.659 | 0.92 | 1.000 |
| Summer 24 h + 12 h | 0 | −0.021 | 0.138 | 0.140 | 0.67 | 0.610–0.720 | 0.95 | 0.000 |
| Summer 24 h + 12 h | 1 | −0.016 | 0.150 | 0.137 | 0.59 | 0.529–0.643 | 0.92 | 1.000 |


**c | Noise-model simulations of the alternative processing.**

| Noise model | Bias (*T*) | Coverage (*T*), % | Bias (*L*) | Coverage (*L*), % |
|:--|--:|--:|--:|--:|
| White | −0.000 | 96.7 | −0.001 | 98.3 |
| White + OU, 1 h | −0.007 | 94.5 | −0.002 | 96.9 |
| White + OU, 12 h | −0.002 | 96.1 | +0.031 | 98.8 |
| White + OU, 3 d | +0.003 | 95.9 | +0.004 | 99.8 |
| White + period constants | +0.001 | 96.0 | +0.004 | 98.3 |
| Student-*t*₇ MA(1) | +0.002 | 98.3 | +0.004 | 98.2 |
| Student-*t*₅ MA(1) | +0.001 | 98.9 | +0.003 | 98.3 |
| Student-*t*₇ MA(1) + OU | +0.001 | 97.2 | +0.005 | 98.5 |
