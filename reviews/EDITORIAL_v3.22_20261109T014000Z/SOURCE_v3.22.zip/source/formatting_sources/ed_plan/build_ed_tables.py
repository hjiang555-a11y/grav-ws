"""Layout only: seven frozen manuscript tables into two ED items; no calculations."""
from pathlib import Path
import re, json, subprocess, hashlib, sys

O=Path(__file__).resolve().parent
R=Path(sys.argv[1]) if len(sys.argv)>1 else O/'inputs'
F=Path('/home/room115/.cache/camoufox/fonts/windows')
items={}
for filename,prefix in [('extended_data.md','ED'),('supplementary_methods.md','SI')]:
    source=R/'sections'/filename
    text=source.read_text()
    for m in re.finditer(r'\*\*(?:Extended Data|Supplementary) Table (\d+) \|([^*]+)\*\*(.*?)\n\n((?:\|[^\n]+\n)+)',text,re.S):
        rows=[[c.strip() for c in line.strip().strip('|').split('|')] for line in m[4].strip().splitlines()]
        rows.pop(1)
        items[prefix+m[1]]={'title':m[2].strip(),'legend':m[3].strip(),'rows':rows,'source':str(source),'source_line':text[:m.start()].count('\n')+1,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
groups=[['SI4','ED3','SI3'],['ED1','ED2','SI1','SI2']]
titles=['Analysis definitions and uncertainty checks.','Response estimates and related analyses.']
widths={'ED1':[.17,.05,.16,.17,.15,.15,.15],'ED2':[.18,.45,.11,.26],'ED3':[.20,.07,.07,.07,.08,.09,.19,.10,.13],'SI1':[.22,.13,.325,.325],'SI2':[.44,.2,.12,.12,.12],'SI3':[.40,.15,.15,.15,.15],'SI4':[.14,.40,.46]}
header=r'''\usepackage{fontspec}
\setmainfont{Arial}[Path=FONTDIR/,UprightFont=arial.ttf,BoldFont=arialbd.ttf,ItalicFont=ariali.ttf]
\newfontfamily\symbolfont{Symbol.ttf}[Path=/home/room115/.cache/camoufox/fonts/macos/,Scale=1]
\usepackage{newunicodechar}
\renewcommand{\textsubscript}[1]{\raisebox{-1.3bp}{\fontsize{5.5bp}{5.5bp}\selectfont #1}}
\renewcommand{\textsuperscript}[1]{\raisebox{2.2bp}{\fontsize{5.5bp}{5.5bp}\selectfont #1}}
\newunicodechar{ρ}{{\symbolfont ρ}}\newunicodechar{η}{{\symbolfont η}}\newunicodechar{σ}{{\symbolfont σ}}
\newunicodechar{₂}{\textsubscript{2}}\newunicodechar{₇}{\textsubscript{7}}\newunicodechar{₅}{\textsubscript{5}}
\pagestyle{empty}
\AtBeginDocument{\fontsize{7bp}{8.2bp}\selectfont}
\setlength{\tabcolsep}{2pt}\renewcommand{\arraystretch}{1}
\setlength{\parskip}{1pt}\setlength{\LTpre}{2pt}\setlength{\LTpost}{3pt}
'''.replace('FONTDIR',str(F)).replace('OUTDIR',str(O))
(O/'tables_header.tex').write_text(header)
math={r'A_{\mathrm{true}}':r'\textit{A}\textsubscript{true}',r'h_2':r'\textit{h}\textsubscript{2}',r'k_2':r'\textit{k}\textsubscript{2}',r'\hat A_i\pm u_i':r'\textit{\^{A}}\textsubscript{i} ± \textit{u}\textsubscript{i}',r'\rho_i':r'ρ\textsubscript{i}',r'\rho_{i,\mathrm{white}}':r'ρ\textsubscript{i,white}',r'\eta_i':r'η\textsubscript{i}'}
def typography(s):
    def convert(m):
        key=m[1]
        if key in math:return math[key]
        assert re.fullmatch(r'[\d.]+\\pm[\d.]+',key),key
        return key.replace(r'\pm',' ± ')
    s=re.sub(r'\$(.*?)\$',convert,s)
    return s.replace('*A*lunar',r'\textit{A}\textsubscript{lunar}')

# Explicit reference-only updates. These are audited separately from cells.
references={
('SI4',6,1):'Fig. 1b,d, Figs. 2 and 4, Extended Data Figs. 1, 2 and 7, Extended Data Tables 1a,b and 2a,b',
('SI4',6,2):'Fig. 3, Table 1, Extended Data Figs. 3–6, Extended Data Table 2c,d',
}
duration_updates={('SI4',1,1):'1-s samples retained after the filtered-validation selection and transient screening'}
citation_map=json.loads((O/'inputs/CITATION_ORDER.json').read_text())['source_to_compiled']
audit=[]; legend=[]
for n,group in enumerate(groups,1):
    chunks=[]
    legend.append(f'**Extended Data Table {n} | {titles[n-1]}**')
    for sub,key in enumerate(group):
        letter=chr(97+sub); item=items[key]
        rows=[]
        for row,cells in enumerate(item['rows']):
            display=[]
            for col,original in enumerate(cells):
                cell_key=(key,row,col)
                edited=duration_updates.get(cell_key,references.get(cell_key,original))
                citation_renumbered=bool(re.search(r'\^\d+\^',edited))
                edited=re.sub(r'\^(\d+)\^',lambda m:'^'+str(citation_map[m[1]])+'^',edited)
                rendered=typography(edited)
                display.append(rendered)
                audit.append({'source_item':key,'source_row':row,'source_col':col,'original':original,'content_updated':edited,'display_markup':rendered,'destination':f'ED Table {n}{letter}','change':'authorized-duration-label-removal' if cell_key in duration_updates else 'citation-renumbering' if citation_renumbered else 'reference-only' if edited!=original else 'typography-only' if rendered!=original else 'none'})
            rows.append('| '+' | '.join(display)+' |')
        rows.insert(1,'|'+'|'.join(':--' for _ in rows[0].strip('|').split('|'))+'|')
        chunks.append(f'**{letter} | {item["title"]}**\n\n'+'\n'.join(rows))
        caption=item['legend'].replace('Extended Data Fig. 2a','Extended Data Fig. 1a').replace('Extended Data Table 2','Extended Data Table 2b')
        legend.append(f'**{letter},** {item["title"]} {caption}')
    md='\n\n'.join(chunks)+'\n'
    (O/f'ED_Table_{n}.md').write_text(md)
    seq='{'+','.join('{'+','.join(map(str,widths[k]))+'}' for k in group)+'}'
    (O/f'table_width_{n}.lua').write_text('local n=0\nlocal widths='+seq+'\nfunction Table(t) n=n+1; for i=1,#t.colspecs do t.colspecs[i][2]=widths[n][i] end; return t end')
    subprocess.run(['pandoc',str(O/f'ED_Table_{n}.md'),'--standalone','--lua-filter='+str(O/f'table_width_{n}.lua'),'-H',str(O/'tables_header.tex'),'-V','geometry:paperwidth=179.99mm','-V','geometry:paperheight=169.99mm','-V','geometry:margin=2mm','-o',str(O/f'ED_Table_{n}.tex')],check=True)
    p=subprocess.run(['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error',f'ED_Table_{n}.tex'],cwd=O,capture_output=True,text=True)
    (O/f'ED_Table_{n}_compile.txt').write_text(p.stdout+p.stderr)
    assert p.returncode==0,p.stdout[-4000:]
    legend.append('')
(O/'ED_TABLE_LEGENDS_DRAFT.md').write_text('\n\n'.join(legend)+'\n')
(O/'TABLE_SOURCE_CELL_MAP.json').write_text(json.dumps({'sources':items,'groups':groups,'data_rows':sum(len(v['rows'])-1 for v in items.values()),'cells':audit,'symbol_font':'/home/room115/.cache/camoufox/fonts/macos/Symbol.ttf','notes':['No numerical calculations.','Beyond typography: two Used in reference cells updated; one filtered-validation Data cell revised by explicit user duration-consistency instruction.','Filtered 544 h label removed, never relabelled 545.9 h. Main-analysis 545.9 h retained. Original cell preserved verbatim in this provenance record.','Static table Hou citation source12 maps to compiled23 using frozen inputs/CITATION_ORDER.json. Legend Markdown retains source12 for normal manuscript compilation.']},ensure_ascii=False,indent=2))
print(json.dumps({'tables':2,'source_tables':len(items),'data_rows':sum(len(v['rows'])-1 for v in items.values()),'cells':len(audit)},indent=2))
