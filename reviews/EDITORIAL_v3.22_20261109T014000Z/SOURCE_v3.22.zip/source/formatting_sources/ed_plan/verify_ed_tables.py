"""Crop only bottom whitespace, then export and validate final ED tables."""
from pathlib import Path
from collections import Counter
import pymupdf as fitz
import json,subprocess,re,hashlib,sys
from PIL import Image
import math
O=Path(__file__).resolve().parent
data=json.loads((O/'TABLE_SOURCE_CELL_MAP.json').read_text())
for item in data['sources'].values():
    assert hashlib.sha256(Path(item['source']).read_bytes()).hexdigest()==item['source_sha256']
assert len(data['sources'])==7 and data['data_rows']==42 and len(data['cells'])==268
assert sum(c['change']=='reference-only' for c in data['cells'])==2
citations=[c for c in data['cells']if c['change']=='citation-renumbering']
assert len(citations)==1 and citations[0]['original']=='Hou et al.^12^' and citations[0]['content_updated']=='Hou et al.^23^'
duration=[c for c in data['cells'] if c['change']=='authorized-duration-label-removal']
assert len(duration)==1 and duration[0]['original']=='1-s samples after transient screening; 544 h'
assert duration[0]['content_updated']=='1-s samples retained after the filtered-validation selection and transient screening'
results=[]
for n,group in enumerate(data['groups'],1):
    pdf=O/f'ED_Table_{n}.pdf'; d=fitz.open(pdf); p=d[0]
    assert len(d)==1
    allspans=[s for b in p.get_text('dict')['blocks'] if 'lines'in b for l in b['lines'] for s in l['spans']]
    ink_bottom=max(max(s['bbox'][3]for s in allspans),max(path['rect'].y1 for path in p.get_drawings()))
    crop_height=ink_bottom+3*72/25.4
    assert crop_height<=p.rect.height+0.001
    p.set_cropbox(fitz.Rect(0,0,p.rect.width,crop_height))
    temp=pdf.with_suffix('.crop.pdf');d.save(temp,garbage=4,deflate=True);d.close();temp.replace(pdf)
    d=fitz.open(pdf);p=d[0]
    spans=[s for b in p.get_text('dict')['blocks'] if 'lines'in b for l in b['lines'] for s in l['spans']]
    fonts=sorted(set((s['font'],round(s['size'],4))for s in spans))
    assert all(size in [5.5,7] for font,size in fonts),fonts
    assert min(size for font,size in fonts)*166/(p.rect.width*25.4/72)>=5
    assert all(font.startswith('Arial')or font=='Symbol'for font,size in fonts)
    assert p.rect.width*25.4/72<=180 and p.rect.height*25.4/72<=170
    assert all(0<=s['bbox'][0]<s['bbox'][2]<=p.rect.width and 0<=s['bbox'][1]<s['bbox'][3]<=p.rect.height for s in spans)
    originals=' '.join(c['original'] for c in data['cells'] if c['source_item']in group)
    decimal=lambda t:Counter(re.findall(r'(?<![\d.])[+−-]?\d+\.\d+',t.replace('−','-')))
    missing=decimal(originals)-decimal(p.get_text())
    assert not missing,missing
    if n==1:
        assert not re.search(r'(?<![\d.])544\s+h',p.get_text())
        assert '545.9 h' in p.get_text()
    p.get_pixmap(dpi=180).save(O/f'ED_Table_{n}.png')
    p.get_pixmap(dpi=600).save(O/f'ED_Table_{n}_600dpi.png')
    raster=p.get_pixmap(dpi=450,alpha=False)
    im=Image.frombytes('RGB',[raster.width,raster.height],raster.samples)
    # Remove at most a subpixel-rounded blank right/bottom edge so physical
    # size at exactly 450 dpi never exceeds the source PDF or 180 x 170 mm.
    size=(math.floor(p.rect.width*450/72),math.floor(p.rect.height*450/72))
    assert raster.width-size[0]<=1 and raster.height-size[1]<=1
    tif=O/f'ED_Table_{n}_450dpi_LZW.tiff'
    im.crop((0,0,*size)).save(tif,compression='tiff_lzw',dpi=(450,450))
    assert tif.stat().st_size<10_000_000
    (O/f'ED_Table_{n}.svg').write_text(p.get_svg_image())
    proc=subprocess.run(['pdftoppm','-cropbox','-r','150','-singlefile','-png',str(pdf),str(O/f'ED_Table_{n}_poppler')],capture_output=True,text=True)
    assert proc.returncode==0 and not proc.stderr
    log=(O/f'ED_Table_{n}_compile.txt').read_text()
    assert 'Missing character'not in log and 'Overfull'not in log
    results.append({'table':n,'source_items':group,'pages':len(d),'width_mm':p.rect.width*25.4/72,'height_mm':p.rect.height*25.4/72,'text_bottom_mm':max(s['bbox'][3]for s in spans)*25.4/72,'fonts':fonts,'decimal_token_missing':dict(missing),'poppler_stderr':proc.stderr,'source_unchanged':True,'sha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'tiff':{'filename':tif.name,'bytes':tif.stat().st_size,'compression':'LZW','dpi':450,'pixels':size,'width_mm':size[0]*25.4/450,'height_mm':size[1]*25.4/450,'edge_rounding_crop_pixels':[raster.width-size[0],raster.height-size[1]],'sha256':hashlib.sha256(tif.read_bytes()).hexdigest()}})
(O/'TABLE_RENDER_CHECKS.json').write_text(json.dumps({'python':sys.version,'pymupdf':fitz.VersionBind,'source_tables':7,'data_rows':42,'source_cells_including_headers':268,'authorized_numeric_label_change':{'cell':'ED Table 1a / Data / Filtered validation (primary)','removed':'544 h','retained_in_main_analysis':'545.9 h','original_cell_retained_in_provenance':True},'results':results},indent=2))
print(json.dumps(results,indent=2))
