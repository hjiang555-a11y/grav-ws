**Extended Data Table 1 | Analysis definitions and uncertainty checks.**

**a,** Main and filtered validation analyses. Both reductions use the same 54 observing segments, each with its own offset. They differ in selection, filtering, tidal-template realization and weighting, so their estimates are related but are not independent measurements.

**b,** Injection tests of the primary estimator. Lunar amplitudes fitted with segment offsets and no empirical daily terms to resampled residuals plus either the full tidal model ($A_{\mathrm{true}}$ = 1) or the model without the lunar group ($A_{\mathrm{true}}$ = 0). The four daily-disturbance scenarios are defined in Methods, with 300 realizations per row. Bias and standard deviation describe the fitted amplitude. The median standard error is that computed within each realization, before the final residual-based calibration. Coverage is the fraction of intervals, formed with these uncalibrated standard errors, containing the injected amplitude; with the calibrated uncertainty of 0.14 the one-standard-error coverage is 0.67–0.68 (Supplementary Methods SM3); the accompanying 95% binomial interval refers to one-standard-error coverage. The last column gives the fraction with *A* > 3σ.

**c,** Noise-model simulations of the alternative processing. Bias and coverage of nominal 95% intervals based on the largest of the least-squares, delete-day and delete-period standard errors. *T* denotes the full template without daily terms, and *L* the lunar group with daily terms, using the ten-day calendar-baseline design in Extended Data Table 2b and the actual observation times. Gaussian scenarios contain 1,024 simulations; Student-*t* and moving-average scenarios contain 4,096. OU denotes Ornstein–Uhlenbeck noise and MA(1) a first-order moving-average process.



**Extended Data Table 2 | Response estimates and related analyses.**

**a,** Daily terms and campaign-specific tidal amplitudes. Amplitude and local time of maximum of the 24-h term, and amplitude of the 12-h term, fitted jointly with the full tidal model within each campaign. Days are local calendar days with data. Daily amplitudes are expressed in 10⁻¹⁸. Their uncertainties are the larger of the scaled least-squares and day-by-day jackknife values; uncertainties in the time of maximum are jackknife estimates. Weak sinusoidal amplitudes are biased positive. The full-template amplitude *A*, fitted without daily terms, and its residual-calibrated uncertainty are those in Extended Data Fig. 1a. The last column gives the lunar amplitude fitted independently to each campaign with the primary estimator.

**b,** Related tidal estimates. These estimates share observations and are not combined. The last column specifies each uncertainty definition. Applying the segment-wise estimator of Hou et al.^12^ to the summer record with the tidal model used here gives 0.78 ± 0.19.

**c,** Free sinusoidal coefficients in the auxiliary reduction. Joint M₂ and S₂ cosine–sine coefficients, after controlling 54 segment constants and freely phased N₂ and K₂ terms. Coefficients and standard errors are in units of $10^{-18}$. Phases refer to 6 September 2025, 16:05 UTC. Scaled least-squares errors use the residual variance; UTC-day jackknife errors delete each of the 43 observed dates and refit all coefficients.

**d,** Template-response signal-to-noise ratios. The first four rows use the non-overlapping full-template or three-group fits; their empirical errors are the larger of scaled-least-squares and UTC-day-jackknife errors. The final two rows use the equal-weight complete solid-Earth/loading fit with UTC-day-jackknife errors. The common-white-noise calculation retains each estimator and uses $\alpha=5.4\times10^{-16}\sqrt{\mathrm{s}}$. The dimensionless factor $\eta_i$ is defined in Methods.


