**a | Daily terms and campaign-specific tidal amplitudes.**

| Campaign | Days | 24-h amplitude | 24-h maximum, h | 12-h amplitude | *A* | *A*lunar |
|:--|--:|:--|:--|:--|:--|:--|
| Sep–Oct 2025 | 4 | 5.1 ± 2.7 | 20.7 ± 5.6 | 5.0 ± 9.7 | 1.28 ± 0.31 | 0.04 ± 0.74 |
| Jan 2026 | 4 | 2.1 ± 3.0 | 17.2 ± 3.9 | 4.1 ± 1.8 | 1.27 ± 0.30 | 1.36 ± 0.37 |
| Apr 2026 | 5 | 2.9 ± 2.2 | 1.9 ± 1.4 | 1.0 ± 3.9 | 0.91 ± 0.13 | 0.66 ± 0.42 |
| May 2026 | 4 | 5.2 ± 3.3 | 3.8 ± 2.4 | 3.1 ± 2.6 | 0.97 ± 0.18 | 0.28 ± 0.68 |
| Jun–Aug 2026 | 22 | 2.8 ± 1.3 | 15.8 ± 1.5 | 0.6 ± 0.7 | 0.67 ± 0.18 | 0.87 ± 0.18 |


**b | Free sinusoidal coefficients in the auxiliary reduction.**

| Coefficient | Estimate | Scaled least-squares standard error | UTC-day jackknife standard error |
|:--|--:|--:|--:|
| M₂ cosine | -1.667 | 0.688 | 0.880 |
| M₂ sine | -4.185 | 0.679 | 0.635 |
| S₂ cosine | -0.460 | 0.738 | 0.701 |
| S₂ sine | -1.866 | 0.750 | 1.043 |


**c | Template-response signal-to-noise ratios.**

| Fit and coefficient | $\hat A_i\pm u_i$ | $\rho_i$ | $\rho_{i,\mathrm{white}}$ | $\eta_i$ |
|:--|:--|--:|--:|--:|
| Full tide, one template | $0.955\pm0.108$ | 8.83 | 9.79 | 0.865 |
| Lunar group, three-group fit | $1.000\pm0.132$ | 7.58 | 7.50 | 0.840 |
| Near-12-h group (S₂, K₂) | $0.925\pm0.365$ | 2.54 | 3.14 | 0.856 |
| Diurnal group, three-group fit | $0.579\pm0.538$ | 1.08 | 1.55 | 0.740 |
| Solid Earth, two-template fit | $1.082\pm0.322$ | 3.36 | 5.81 | 0.611 |
| Ocean loading, two-template fit | $0.486\pm0.544$ | 0.89 | 1.17 | 0.612 |


**d | Related tidal estimates.**

| Analysis | Data and model | Amplitude factor *A* | Uncertainty |
|:--|:--|:--|:--|
| Hou et al.^12^ | Summer; 16 segments; their tidal model and segment-wise correlation | 0.87(15) | Reported weighted statistical error |
| Primary reduction, lunar group | 54 segments; lunar group; segment offsets; astronomical ephemerides | 0.97 ± 0.14 | Calibrated by residual resampling |
| Primary reduction, full template | Same observations; full template; segment offsets | 0.90 ± 0.12 | Calibrated by residual resampling |
| Alternative processing | 2026 observations; 600-s means; ten-day calendar baselines; full template | 0.88 ± 0.10 | Largest of least-squares, delete-day and delete-period standard errors |
| Alternative processing | Same observations and baselines; lunar group; daily terms in each ten-day block | 0.89 ± 0.28 | Largest of least-squares, delete-day and delete-period standard errors |
