# A03：完整内容保留的ED配置方案

推荐 **8张ED图＋2张ED表＝10项，SI仅保留说明文字**。不删除任一原图panel、表格数据行或单元格，不重算科学结果。A04通讯占位与A05贡献缺省不改。

## 图件：仅三组合并，全部可在180×170 mm内

下列旧图原宽均为183 mm；给出的高度是按180/183缩放后的实际几何预算，合并项另留3 mm间隔。普通字号最终应5–7 pt、panel字母8 pt，须按最终180 mm成品检查，不直接把缩放后的7.87 pt字母称为8 pt。

| 建议新编号（待root核定引用映射） | 旧内容 | 实际高度预算/mm | panel安排 |
|:--|:--|--:|:--|
| ED Fig. 1 | 旧ED Fig. 2＋旧ED Fig. 7 | 145.82 | 原campaign响应a,b置上；相位/当地时刻a,b改为c,d置下 |
| ED Fig. 2 | 旧ED Fig. 3＋旧SI Fig. 1 | 155.46 | 上方五campaign记录统一a；下方April时序/谱为b,c |
| ED Fig. 3 | 旧ED Fig. 4 | 167.21 | 原a–d及zoom全部保留 |
| ED Fig. 4 | 旧ED Fig. 5 | 113.11 | 原a–d保留 |
| ED Fig. 5 | 旧ED Fig. 6 | 147.54 | 原a–d保留 |
| ED Fig. 6 | 旧SI Fig. 2 | 157.38 | 原a–d及zoom全部保留 |
| ED Fig. 7 | 旧ED Fig. 1＋旧SI Fig. 3 | 160.38 | 原响应/相位/全谱a–c在上；原瞬态/阈值/剔除时长a–c改为d–f在下 |
| ED Fig. 8 | 旧SI Fig. 4 | 54.10 | 原a,b保留 |

上述顺序依正文既有首次引用自然得到1–6；Methods中的筛选/加载核查随后引用7/8。最终顺序须由root按改完的全文自动检查，不能只按旧文件编号排序。

合并主题分别为campaign一致性与相位/当地时刻检查、全记录与April日历实例、滤波响应与数据筛选诊断，避免仅为凑项将不相关图拼接。旧图11张变8张，全部内容仍在。ED3/ED6较满，不宜再叠加额外图；不推荐7图＋3表方案，因为它还需第四次图件合并，而两组表的实际试排已足够宽松。

## 表格：真实试排支持两项，所有42行保留

使用现有Markdown表格，Arial 7 pt普通文字、7 pt/8.2 pt行距、180×170 mm页面、2 mm边距；标题/完整说明另放稿件legend，不挤入图像。实际运行Pandoc＋XeLaTeX，试件如下：

| 建议新表号 | 原表与子表映射 | 数据行 | 试件文字底边/mm |
|:--|:--|--:|--:|
| ED Table 1：Analysis definitions and uncertainty checks | a旧SI4；b旧EDT3；c旧SI3 | 6＋8＋8＝22 | 129.70 |
| ED Table 2：Response estimates and related analyses | a旧EDT1；b旧EDT2；c旧SI1；d旧SI2 | 5＋5＋4＋6＝20 | 122.62（旧试排顺序） |

试件：`table1_probe.pdf/png`、`table2_probe.pdf/png`；源表由 `table_probe.py` 直接提取，原图注/表注未用于数据表图片。每组均为一页，剩余约40 mm高余量。原数字未改；EDT2长方法说明能自然换行，数值不被挤成多个碎片。probe尚非最终制作物：数学字体被默认相对缩放，正式版本须明确7 pt数学/符号处理；原表“Used in”交叉引用也必须按最终图表映射更新。

Methods比较表原SI4在Results段最先引用，因此把这组作新EDTable1；campaign结果表下一处出现，作新EDTable2。旧七个表不是仅换成两个文件名：应在两个成品中明确a–c/a–d子表分组及图注映射，保留完整列名、数据、注释和误差定义。

## 交接约束

- root统一正文、Methods、SI文字、图注、表内Used in与引用编号；同一旧项的全部引用必须随映射变更。
- 重排后SI仅文字SM1–SM7，原独有说明移为新ED图表legend/footnotes，不能静默删去。
- 用来源单元格映射核对所有42行及原列名；显式允许的差别仅为交叉引用、子表标记、数学排版和不会改变含义的标题整合。
- 全部输出在新工作目录准备；旧R、A04、A05保持只读。正式表格已完成，见 `ED_TABLES_IMPLEMENTATION_ZH.md`；表2顺序按root确认的首次引用顺序更新为campaign、related estimates、free coefficients、SNR。最终正文底边129.79/121.64 mm。
