# A03 两张 Extended Data 表：完成交接

最终采用8图＋2表，总计10项ED。此交接实施表格合并、排版及对应图注草稿，并按用户最新时长一致性指令删除一处筛选子集的544 h标注；图件由其他worker按共同映射合并。R稿件源文件全程只读，没有统计重算。A04通讯占位和A05贡献缺省均未触及。

## 交付与映射

| 新表 | 子表 | 原表 | 原数据行数 |
|:--|:--|:--|--:|
| ED Table 1 | a | SI Table 4 | 6 |
| ED Table 1 | b | ED Table 3 | 8 |
| ED Table 1 | c | SI Table 3 | 8 |
| ED Table 2 | a | ED Table 1 | 5 |
| ED Table 2 | b | ED Table 2 | 5 |
| ED Table 2 | c | SI Table 1 | 4 |
| ED Table 2 | d | SI Table 2 | 6 |

- 正式件：`ED_Table_1.pdf`、`ED_Table_2.pdf`；同名SVG、180dpi PNG和`*_600dpi.png`；可编辑源为同名Markdown/LaTeX及`build_ed_tables.py`。
- 完整说明：`ED_TABLE_LEGENDS_DRAFT.md`。保留所有原caption的科学解释、误差定义、模拟次数、单位、比较限制；只整合标题、增加子项标记和更新两处引用。
- 可核查溯源：`TABLE_SOURCE_CELL_MAP.json`含7个原表、42数据行、268个含表头单元格、原文件SHA256、起始行、每格原文及排版后内容。
- 渲染/字体证据：`TABLE_RENDER_CHECKS.json`；独立Poppler预览`ED_Table_1_poppler.png`、`ED_Table_2_poppler.png`。

## 实际检查结果

两张PDF各一页，最终CropBox可见尺寸分别179.990747×133.393010 mm和179.990747×125.828043 mm，小于180×170 mm；原MediaBox画布保持169.989495 mm高，仅裁底部空白。普通文字和Greek均7.000 pt，正文Arial、Greek使用原生Unicode的macOS Symbol；真正的上下标5.500 pt（166 mm宽嵌入时约5.073 pt）。没有Latin Modern混入，也没有自动放大的数学字体。子表标题是表格文本7pt加粗，并非图件panel标记。

正文最下边界分别129.7902和121.7666 mm，原始画布约40/48 mm的底部余量现已裁去，最后横线下仅保留3 mm。逐span检查全部在页内；LaTeX无Overfull和缺字警告。MuPDF和Poppler均成功渲染，Poppler stderr为空；两种渲染预览检查无文字遮挡、裁切、异常空白或数值折断。原表所有小数数值的逐值出现次数已与PDF文本核对，无缺失。该检查不声称重新验证科学正确性。

原表七组结果数据完整保留，来源文件SHA256不变。超出排版的表内变更包括原SI4“Used in”行的两格交叉引用（JSON标为`reference-only`），以及用户最新明确授权的一个时长标注调整：新ED Table 1a的Data/Filtered validation单元格由`1-s samples after transient screening; 544 h`改为`1-s samples retained after the filtered-validation selection and transient screening`，JSON标为`authorized-duration-label-removal`。原544 h单元格原文保留于溯源及`archive_before_effective_duration_update/`，未将544 h改标为545.9 h；主分析单元格的545.9 h保持不变。这是一处标签删除，不能再声称所有数值标签逐字保留。其余差别仅为数学字符的Arial/Symbol排版、上下标、A_lunar显示。结果数值没有换算、舍入或重估。

## 运行与集成

```bash
/data/AI_Research/environments/python/sci/bin/python build_ed_tables.py
/data/AI_Research/environments/python/tide-review-20261108T121212Z/bin/python verify_ed_tables.py
```

依赖：Python3.12、Pandoc、XeLaTeX、fontspec/newunicodechar、PyMuPDF（环境实际返回VersionBind为2.1，完整记录见`TABLE_RENDER_CHECKS.json`）、Pillow及Poppler pdftoppm。Arial字体路径为`/home/room115/.cache/camoufox/fonts/windows/`；Symbol为`/home/room115/.cache/camoufox/fonts/macos/Symbol.ttf`。字体不会上传；源脚本记录所需路径。`SymbolUnicode.ttf`是前期试验遗留文件，正式脚本和成品不使用它，打包无需包含。

root集成时请使用最终两张ED表，按上表精确到子项统一全部引用；旧7张Markdown表及其旧legend应由新两项替代，防止重复显示。新legend草稿已使用最终ED Fig. 1a、ED Table 2b；不应再对这些已经改好的文字盲目应用旧号全局替换。Hou引用在legend源稿保持ref.12，静态表2b依据冻结CITATION_ORDER映射显示compiled23；如文献次序改变须更新该冻结映射后重新生成。仅当上游科学表格内容、文献序号或最终引用映射变化时才重新生成。

当前样本量、观察段数与模拟次数完全沿用稿件原文；本任务是图表整理，没有新的实验设计、重复单位或统计参数。最终稿件整体分页、首次引用顺序、legend长度和8图实际合成效果由root集成后检查；这里不代替最终全稿门禁。

## 输入冻结与最终字号更新

原表输入已从本轮baseline复制到`inputs/sections/extended_data.md`和`inputs/sections/supplementary_methods.md`，构建脚本默认读取这两个冻结文件，不再读取活动R稿件。仅改输入来源后先完整重建，两张PNG像素文件与旧成品字节一致，268个单元格映射完全一致，证据见`FROZEN_INPUT_REBUILD_CHECK.json`。随后仅把上下标从5改为5.5 pt，使166 mm审稿页上的最小字号高于5 pt；普通Arial及Symbol仍7 pt。最终所有单元格文本与冻结前保持一致，PDF文字越界、缺字、decimal缺失及双渲染错误均为零。更新前成品归档于`archive_before_frozen_inputs_and_5p5/`。

## 静态引用与TIFF最终更新

表2b的Hou上标现按`inputs/CITATION_ORDER.json`由source12映射为compiled23，JSON标记`citation-renumbering`；这是引用编号变化，不是数据变化。源单元格与legend保留source12。独立PDF提取确认显示`Hou et al.23`。最终两张450dpi LZW TIFF分别3188×2363和3188×2229像素，尺寸179.9449×133.3782 mm和179.9449×125.8147 mm，分别822690与695710字节，均低于10MB。为避免像素取整使纸面超180×170mm，仅去掉右边/底边各1个纯空白像素；无缩放，字体仍7/5.5pt，表注仍单独保留。最终全部文件SHA256见`ED_TABLES_FINAL_HANDOFF.md`及`FINAL_OUTPUT_HASHES.json`。

## 最终底部空白裁切

按root授权，使用PDF CropBox仅裁掉底部空白，保留最后横线后3 mm；顶边、左右边、文字坐标、字号与全部矢量绘图对象均不变（逐项相等证据`BOTTOM_CROP_CHECK.json`）。`verify_ed_tables.py`现在按此规则完成裁切后统一导出PDF、SVG、PNG和TIFF；重复执行不继续侵入内容。Poppler以`-cropbox`核对可见页面。旧未裁版本保存在`archive_before_bottom_crop/`。最终PDF SHA及其他所有交付文件SHA以`FINAL_OUTPUT_HASHES.json`和`ED_TABLES_FINAL_HANDOFF.md`为准。
