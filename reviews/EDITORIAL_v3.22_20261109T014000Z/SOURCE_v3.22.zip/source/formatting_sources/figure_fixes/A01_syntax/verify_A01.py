from pathlib import Path
import hashlib,json,re,subprocess
import pymupdf as f
R=Path(__file__).resolve().parent
OLD=Path('/data/AI_Research/projects/grav-ws/manuscript_48h/editorial_v322_20261109T014000Z/figures/figure4.pdf')
NEW=R/'figure4.pdf'
old=f.open(OLD);new=f.open(NEW);a=old[0];b=new[0]
assert a.get_text('dict')==b.get_text('dict'),'Text/font geometry changed'
assert a.get_drawings()==b.get_drawings(),'Vector drawing geometry/style changed'
ap=a.get_pixmap(matrix=f.Matrix(3,3),alpha=False);bp=b.get_pixmap(matrix=f.Matrix(3,3),alpha=False)
assert ap.samples==bp.samples,'MuPDF rendered pixels changed'
bad=[]
for x in range(1,new.xref_length()):
 if new.xref_is_stream(x):
  for m in re.finditer(rb'\[[^\]]*\]\s+d\b',new.xref_stream(x)):bad.append({'xref':x,'operator':m[0].decode()})
assert not bad
runs=[]
for cmd in [['pdftotext','-layout',str(NEW),'-'],['pdftoppm','-f','1','-singlefile','-r','150','-png',str(NEW),str(R/'figure4_poppler')]]:
 p=subprocess.run(cmd,capture_output=True);assert p.returncode==0 and not p.stderr,(p.returncode,p.stderr)
 runs.append({'command':cmd,'exit_code':p.returncode,'stderr':p.stderr.decode(),'stdout_bytes':len(p.stdout)})
 if cmd[0]=='pdftotext':
  assert b'Main result' in p.stdout and b'Independent phase' in p.stdout
  (R/'figure4_poppler_text.txt').write_bytes(p.stdout)
checks=json.loads((R/'REVIEW_CHECKS.json').read_text())
result={'scope':'A01 only: supply missing PDF dash phase; no font, geometry, values or layout change','old_sha256':hashlib.sha256(OLD.read_bytes()).hexdigest(),'new_sha256':hashlib.sha256(NEW.read_bytes()).hexdigest(),'text_font_and_position_dict_exact':True,'all_vector_drawings_exact':True,'mupdf_rendered_pixels_exact':True,'malformed_dash_operators':bad,'poppler_text_and_render_no_stderr':True,'runs':runs,'rows':checks['rows'],'intervals':checks['intervals'],'panel_b_bars':checks['panel_b_bars'],'python_mupdf':f.VersionBind}
(R/'A01_CHECKS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,ensure_ascii=False,indent=2))
