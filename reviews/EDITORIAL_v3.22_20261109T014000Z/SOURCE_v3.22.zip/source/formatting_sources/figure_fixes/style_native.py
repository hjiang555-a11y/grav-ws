"""Native editable figure typography; explicit decorative-grid and palette changes only."""
from pathlib import Path
from collections import Counter
import argparse,copy,hashlib,json,re,shutil,subprocess,unicodedata
import pymupdf as f
BASE=Path(__file__).resolve().parent
SOURCE=BASE.parent/'baseline'
OUT=BASE/'A10_native_v2';OUT.mkdir(exist_ok=True)
ARIAL=Path('/home/room115/.cache/camoufox/fonts/windows')
FILES={'regular':ARIAL/'arial.ttf','bold':ARIAL/'arialbd.ttf','italic':ARIAL/'ariali.ttf','bolditalic':ARIAL/'arialbi.ttf','symbol':Path('/home/room115/.cache/camoufox/fonts/macos/Symbol.ttf')}
FONTS={k:f.Font(fontfile=str(p))for k,p in FILES.items()}
IDS={k:'Native'+k for k in FILES}
MAIN={'figures/figure1_v319.pdf','figures/figure2_v1.pdf','figures/amplitude/figure3.pdf','figures/figure4.pdf'}
REMAP={'figures/ed2.pdf':{'a':'c','b':'d'},'figures/ed4.pdf':{'a':'b','b':'c'},'figures/ed5.pdf':{'a':'d','b':'e','c':'f'}}
GRIDS={'figures/figure1_v319.pdf','figures/ED_Figure_5_v35.pdf','figures/ED_Figure_6_v35.pdf','figures/SI_Figure_2_v35.pdf'}
NUM=r'[-+]?(?:\d*\.\d+|\d+)'
GRID=re.compile(r'(?P<head>(?:0?\.690196\d*)\s+G\s+(?:(?:/DeviceRGB\s+cs|[0-9.]+\s+[Jwj])\s+)*)(?P<path>(?P<x0>'+NUM+r')\s+(?P<y0>'+NUM+r')\s+m\s+(?P<x1>'+NUM+r')\s+(?P<y1>'+NUM+r')\s+l\s+)S\b')
COLORS={'figures/figure4.pdf':[((.7529411765,.2235294118,.168627451),(213/255,94/255,0.))],
 'figures/SI_Figure_2_v35.pdf':[((1.,.4980392157,.0549019608),(230/255,159/255,0.)),((.1725490196,.6274509804,.1725490196),(0.,114/255,178/255)),((.8392156863,.1529411765,.1568627451),(204/255,121/255,167/255))]}
RGB=re.compile(r'(?<![\w.])('+NUM+r')\s+('+NUM+r')\s+('+NUM+r')\s+(RG|rg)\b')
canon=lambda s:unicodedata.normalize('NFC',s).replace('\u00b5','μ').replace('\u00ad','-')
isgreek=lambda c:c=='μ'or ('\u0370'<=c<='\u03ff'and unicodedata.category(c).startswith('L'))
def kind(s):
 t=s['font'].lower();bold='bold'in t;italic='italic'in t or'oblique'in t
 return 'bolditalic'if bold and italic else'bold'if bold else'italic'if italic else'regular'
def spans(p):return[s for b in p.get_text('dict')['blocks']for l in b.get('lines',[])for s in l['spans']if s['text'].strip()]
def clear_text(doc,page):
 # Current inputs use separate native PDF text objects. Remove only those bytes;
 # MuPDF redaction can rewrite inherited line widths even with graphics=0.
 page_streams=set(page.get_contents())
 for x in range(1,doc.xref_length()):
  if not doc.xref_is_stream(x)or not('/Subtype /Form'in doc.xref_object(x)or x in page_streams):continue
  old=doc.xref_stream(x)
  def remove(m):
   assert not re.search(rb'(?<!\S)(?:m|l|c|S|f|re)\s',m[0]),'Graphics inside text object'
   return b''
  new=re.sub(rb'(?<!\w)BT\b.*?\bET(?!\w)',remove,old,flags=re.S)
  if new!=old:doc.update_stream(x,new)
def chars(ss):return Counter(c for s in ss for c in canon(s['text'])if not c.isspace())
def project(p,d):return p[0]*d[0]+p[1]*d[1]
def grid_path(d,rel):
 c=d.get('color');r=d['rect']
 return rel in GRIDS and c is not None and max(abs(x-.69015)for x in c)<.0003 and d['type']=='s'and len(d['items'])==1 and (r.width<.001 or r.height<.001)and .29<d['width']<.31
def clean(v):
 if isinstance(v,(f.Point,f.Rect,f.Quad)):return[clean(x)for x in v]
 if isinstance(v,(list,tuple)):return[clean(x)for x in v]
 if isinstance(v,dict):return{k:clean(x)for k,x in v.items()}
 return v
def equal(a,b,tol=.008):
 if isinstance(a,(int,float))and isinstance(b,(int,float)):return abs(a-b)<=tol
 if isinstance(a,dict)and isinstance(b,dict):return a.keys()==b.keys()and all(equal(a[k],b[k],tol)for k in a)
 if isinstance(a,list)and isinstance(b,list):return len(a)==len(b)and all(equal(x,y,tol)for x,y in zip(a,b))
 return a==b
def geometry(ds,exclude_color=False,exclude_width=False):
 keys=['items','width','dashes','lineCap','lineJoin','closePath','fill_opacity','stroke_opacity','even_odd']
 if not exclude_color:keys+=['color','fill']
 if exclude_width:keys.remove('width')
 return[{k:clean(d.get(k))for k in keys}for d in ds]
def patch_vectors(doc,rel):
 before=doc[0].get_drawings();logs=[]
 pages=set(doc[0].get_contents())
 for x in range(1,doc.xref_length()):
  if not doc.xref_is_stream(x)or not('/Subtype /Form'in doc.xref_object(x)or x in pages):continue
  old=doc.xref_stream(x);s=old.decode('latin1')
  if rel in GRIDS:
   def strip(m):
    assert abs(float(m['x0'])-float(m['x1']))<.0001 or abs(float(m['y0'])-float(m['y1']))<.0001
    logs.append({'operation':'remove_decorative_grid_stroke','xref':x,'path':m['path'].strip()})
    return m['head']+m['path']+'n'
   s=GRID.sub(strip,s)
  if rel in COLORS:
   def recolor(m):
    rgb=tuple(float(m[i])for i in [1,2,3])
    for oldrgb,newrgb in COLORS[rel]:
     if max(abs(a-b)for a,b in zip(rgb,oldrgb))<.000002:
      logs.append({'operation':'accessible_palette','xref':x,'old_rgb':rgb,'new_rgb':newrgb})
      return' '.join(f'{v:.10f}'for v in newrgb)+' '+m[4]
    return m[0]
   s=RGB.sub(recolor,s)
  if rel in {'figures/ed2.pdf','figures/ed4.pdf'}:
   # Verified raw-to-native180 stroke scales: ed2 originally 150mm, ed4 183mm.
   raw_to_final=1.2 if rel=='figures/ed2.pdf'else 180/183
   def weight(m):
    oldw=float(m[1]);neww=min(1.,max(.25,oldw*raw_to_final))/raw_to_final
    if abs(neww-oldw)>.000001:
     logs.append({'operation':'ED_stroke_weight','xref':x,'old_raw_width':oldw,'new_raw_width':neww,'raw_to_final_scale':raw_to_final})
     return f'{neww:.10f} w'
    return m[0]
   s=re.sub(r'(?<![\w.])('+NUM+r')\s+w\b',weight,s)
  if s.encode('latin1')!=old:doc.update_stream(x,s.encode('latin1'))
 after=doc[0].get_drawings();kept=[d for d in before if not grid_path(d,rel)]
 assert len(after)==len(kept),(rel,'grid count',len(before),len(after),len(kept))
 weight_change=rel in {'figures/ed2.pdf','figures/ed4.pdf'}
 assert equal(geometry(kept,True,weight_change),geometry(after,True,weight_change)),(rel,'scientific geometry changed')
 if rel not in COLORS:assert equal(geometry(kept,False,weight_change),geometry(after,False,weight_change)),(rel,'unexpected style change')
 else:
  for a,b in zip(kept,after):
   for key in ['color','fill']:
    v=a.get(key);w=b.get(key)
    if v is None:assert w is None;continue
    mapped=next((dst for src,dst in COLORS[rel]if max(abs(x-y)for x,y in zip(v,src))<.001),v)
    assert equal(list(mapped),list(w),.001),(rel,key,v,w,mapped)
 return logs,len(before)-len(kept),len(after)
def style(rel):
 source=BASE/'A01_syntax/figure4.pdf'if rel=='figures/figure4.pdf'else SOURCE/rel
 inp=OUT/'inputs'/rel;inp.parent.mkdir(parents=True,exist_ok=True)
 if not inp.exists():shutil.copy2(source,inp)
 original=f.open(inp);before_spans=spans(original[0]);vlog,removed,paths=patch_vectors(original,rel)
 width=(183 if rel in MAIN else 180)/25.4*72;scale=width/original[0].rect.width
 doc=f.open();p=doc.new_page(width=width,height=original[0].rect.height*scale);p.show_pdf_page(p.rect,original,0)
 lines=[l for b in p.get_text('dict')['blocks']for l in b.get('lines',[])]
 before=p.get_drawings();images=sorted(i['digest'].hex()for i in p.get_image_info(hashes=True))
 clear_text(doc,p);assert not spans(p)
 for k,path in FILES.items():p.insert_font(fontname=IDS[k],fontfile=str(path))
 removed_hours=[];remaps=[];expected=[];textlog=[];greek_log=[]
 for line in lines:
  d=line['dir'];ss=[s for s in line['spans']if s['text']]
  if not ss:continue
  prepared=[];right_anchor=False
  for s in ss:
   text=canon(s['text']);newtext=text;panel=s['text'].strip()in list('abcdefgh')and'bold'in kind(s)and s['size']/scale>7.5
   size=8. if panel else min(7.,max(5.6,s['size']/scale))
   if rel=='figures/figure1_v319.pdf':
    if re.fullmatch(r'\s*(?:60|68|73|70|274)\s+h\s*',newtext):newtext=''
    else:newtext=re.sub(r'\s*\((?:60|68|73|70|274)\s+h\)','',newtext)
    if newtext!=text:
     removed_hours.append({'before':text,'after':newtext,'source_origin':s['origin'],'preserve_right_anchor':bool(newtext)})
     if newtext:right_anchor=True
   if panel and rel in REMAP:
    assert text in REMAP[rel];newtext=REMAP[rel][text];remaps.append({'before':text,'after':newtext})
   expected.append({'text':newtext})
   parts=[]
   for token in re.findall(r'[μ\u0391-\u03c9]+|[^μ\u0391-\u03c9]+',newtext):
    k='symbol'if all(isgreek(c)for c in token)else kind(s)
    assert all(FONTS[k].has_glyph(ord(c))for c in token if not c.isspace()),(rel,k,token)
    parts.append((token,k))
   oldwidth=FONTS[kind(s)].text_length(s['text'],fontsize=s['size'])
   newwidth=sum(FONTS[k].text_length(t,fontsize=size)for t,k in parts)
   prepared.append({'source':s,'text':newtext,'parts':parts,'size':size,'oldwidth':oldwidth,'newwidth':newwidth})
  if not prepared:continue
  shifts=[0.]
  for i in range(1,len(prepared)):shifts.append(shifts[-1]+prepared[i-1]['newwidth']-prepared[i-1]['oldwidth'])
  delta=shifts[-1]+prepared[-1]['newwidth']-prepared[-1]['oldwidth'];anchor=-delta if right_anchor else-delta/2
  for i,item in enumerate(prepared):
   s=item['source'];origin=f.Point(s['origin'])+f.Point(d)*(shifts[i]+anchor)
   mat=f.Matrix(d[0],-d[1],d[1],d[0],0,0);advance=0.
   for text,k in item['parts']:
    pt=origin+f.Point(d)*advance
    p.insert_text(pt,text,fontname=IDS[k],fontsize=item['size'],color=f.sRGB_to_pdf(s['color']),morph=(pt,mat))
    if k=='symbol':greek_log.append({'text':text,'font':'Symbol','size':item['size'],'origin':list(pt)})
    advance+=FONTS[k].text_length(text,fontsize=item['size'])
   if item['text']!=canon(s['text'])or abs(item['size']-s['size'])>.001:textlog.append({'before':s['text'],'after':item['text'],'old_size':s['size'],'new_size':item['size'],'new_origin':list(origin)})
 if rel=='figures/ed1.pdf':
  p.insert_text((2,8), 'a',fontname=IDS['bold'],fontsize=8,color=(0,0,0));expected.append({'text':'a'});remaps.append({'before':None,'after':'a'})
 assert equal(geometry(before),geometry(p.get_drawings())),(rel,'graphics changed during text-only pass')
 assert images==sorted(i['digest'].hex()for i in p.get_image_info(hashes=True)),(rel,'image bytes changed')
 out=OUT/'outputs'/rel;out.parent.mkdir(parents=True,exist_ok=True)
 doc.subset_fonts();doc.save(out,garbage=4,deflate=True);doc.close()
 final=f.open(out);q=final[0];ss=spans(q)
 assert chars(ss)==chars(expected),(rel,'character change',chars(expected)-chars(ss),chars(ss)-chars(expected))
 issues=[{'text':s['text'],'bbox':s['bbox']}for s in ss if not q.rect.contains(f.Rect(s['bbox']))]
 assert not issues,(rel,'text out of page',issues)
 assert all(all(not isgreek(c)or'Symbol'in s['font']for c in canon(s['text']))for s in ss),(rel,'Greek not Symbol')
 assert all(s['size']>=5.59 for s in ss),(rel,'small font')
 weights=[d['width']for d in q.get_drawings()if d.get('color')is not None]
 if rel not in MAIN:assert min(weights)>=.2499 and max(weights)<=1.0001,(rel,'ED stroke range',min(weights),max(weights))
 if rel=='figures/figure1_v319.pdf':assert len(removed_hours)==10,removed_hours
 if rel in REMAP:assert len(remaps)==len(REMAP[rel]),remaps
 q.get_pixmap(matrix=f.Matrix(2.5,2.5),alpha=False).save(out.with_suffix('.png'));out.with_suffix('.svg').write_text(q.get_svg_image(text_as_path=False))
 cmd=['pdftotext','-layout',str(out),'-'];pop=subprocess.run(cmd,capture_output=True);assert pop.returncode==0 and not pop.stderr,(rel,pop.stderr)
 preview=OUT/'poppler'/Path(rel).with_suffix('');preview.parent.mkdir(parents=True,exist_ok=True)
 cmd2=['pdftoppm','-f','1','-singlefile','-r','120','-png',str(out),str(preview)];pp=subprocess.run(cmd2,capture_output=True);assert pp.returncode==0 and not pp.stderr,(rel,pp.stderr)
 return{'path':rel,'source_sha256':hashlib.sha256(inp.read_bytes()).hexdigest(),'pdf':str(out),'png':str(out.with_suffix('.png')),'svg':str(out.with_suffix('.svg')),'output_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'width_mm':q.rect.width/72*25.4,'height_mm':q.rect.height/72*25.4,'native_fonts':sorted({s['font']for s in ss}),'size_range_pt':[min(s['size']for s in ss),max(s['size']for s in ss)],'stroke_width_range_pt':[min(weights),max(weights)],'greek':greek_log,'panel_remaps':remaps,'removed_hour_annotations':removed_hours,'removed_decorative_path_instances':removed,'vector_operations':vlog,'scientific_vector_geometry_preserved':True,'scientific_raster_bytes_preserved':True,'text_characters_preserved_except_declared_changes':True,'all_text_in_page':True,'Poppler_text_and_render_no_stderr':True,'mupdf_visible_text_spans':len(ss),'poppler_text_bytes':len(pop.stdout)}
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--only',nargs='*');a=ap.parse_args()
 active=sorted({m[1]for p in(SOURCE/'sections').glob('*.md')for m in re.finditer(r'!\[[^\]]*\]\(([^)]+)\)',p.read_text())})
 if not active:
  active=sorted(p.relative_to(OUT/'inputs').as_posix()for p in(OUT/'inputs').rglob('*.pdf'))
 assert len(active)==15,'Expected all 15 frozen component inputs; do not infer a new inventory'
 chosen=a.only or active;records=[]
 for rel in chosen:
  assert rel in active;print('STYLING',rel,flush=True);result=style(rel);records.append(result)
  (OUT/(Path(rel).stem+'_CHECKS.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2))
 (OUT/'A10_CHECKS.json').write_text(json.dumps({'scope':'A01/A08/A10 native formatting only; frozen observations and result geometry preserved','encoding_equivalence':'micro sign U+00B5 mapped to Greek mu U+03BC for editable Symbol glyph; soft hyphen/NFC canonically compared','font_files':{k:{'path':str(v),'sha256':hashlib.sha256(v.read_bytes()).hexdigest()}for k,v in FILES.items()},'files':records},ensure_ascii=False,indent=2))
 (OUT/'FIGURE_MAPPING.json').write_text(json.dumps({x['path']:{e:x[e]for e in ['pdf','png','svg']}for x in records},indent=2))
 print('COMPLETE',len(records),flush=True)
