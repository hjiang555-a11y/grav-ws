#!/usr/bin/env python3
"""Compose approved Extended Data figure sets from frozen, styled 180-mm PDFs.
No scientific recalculation, raster interpolation, panel deletion, or font scaling.
"""
from pathlib import Path
import argparse,collections,hashlib,json,math,os,shutil,subprocess,sys,unicodedata
import pymupdf as fitz
from PIL import Image
ROOT=Path(__file__).resolve().parent
WIDTH_MM=180;MAX_HEIGHT_MM=170;GAP_MM=3;PT_PER_MM=72/25.4
PLAN=[
 ('ED_Figure_1',['ed3.pdf','ed2.pdf'],'Original ED 2 panels a,b + original ED 7 panels c,d'),
 ('ED_Figure_2',['ed1.pdf','ed4.pdf'],'Original ED 3 panel a + original SI 1 panels b,c'),
 ('ED_Figure_3',['ED_Figure_4_v35.pdf'],'Original ED 4 panels a–d'),
 ('ED_Figure_4',['ED_Figure_5_v35.pdf'],'Original ED 5 panels a–d'),
 ('ED_Figure_5',['ED_Figure_6_v35.pdf'],'Original ED 6 panels a–d'),
 ('ED_Figure_6',['SI_Figure_2_v35.pdf'],'Original SI 2 panels a–d'),
 ('ED_Figure_7',['primary_response_methods.pdf','ed5.pdf'],'Original ED 1 panels a–c + original SI 3 panels d–f'),
 ('ED_Figure_8',['SI_Figure_4_v36.pdf'],'Original SI 4 panels a,b'),
]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def canonical(s):return unicodedata.normalize('NFC',s).replace('\xad','-').replace('ꞏ','·')
def text(p):return ''.join(c for b in p.get_text('dict')['blocks']for l in b.get('lines',[])for s in l['spans']for c in canonical(s['text'])if not c.isspace())
def translate(x,dx,dy):
 if isinstance(x,fitz.Point):return [x.x+dx,x.y+dy]
 if isinstance(x,fitz.Rect):return [x.x0+dx,x.y0+dy,x.x1+dx,x.y1+dy]
 if isinstance(x,fitz.Quad):return [translate(p,dx,dy)for p in x]
 if isinstance(x,(tuple,list)):return [translate(v,dx,dy)for v in x]
 return x
def geometry(page,dx=0,dy=0):
 keys=['type','color','fill','width','dashes','fill_opacity','stroke_opacity','closePath','even_odd','lineCap','lineJoin']
 return [dict(items=translate(d['items'],dx,dy),**{k:translate(d.get(k),0,0)for k in keys})for d in page.get_drawings()]
def close(a,b,tol=.01):
 if isinstance(a,(float,int))and isinstance(b,(float,int)):return abs(a-b)<tol
 if isinstance(a,dict)and isinstance(b,dict):return a.keys()==b.keys()and all(close(a[k],b[k],tol)for k in a)
 if isinstance(a,list)and isinstance(b,list):return len(a)==len(b)and all(close(x,y,tol)for x,y in zip(a,b))
 return a==b

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--input-dir',type=Path,required=True);ap.add_argument('--approved-manifest',type=Path);args=ap.parse_args()
 names=sorted({p for _,ns,_ in PLAN for p in ns});inputs=ROOT/'inputs';outputs=ROOT/'outputs';previews=ROOT/'poppler';inputs.mkdir(exist_ok=True);outputs.mkdir(exist_ok=True);previews.mkdir(exist_ok=True)
 # First run freezes inputs; subsequent runs require the exact same bytes.
 for name in names:
  src=args.input_dir/name;dest=inputs/name
  assert src.is_file(),src
  if dest.exists():assert sha(dest)==sha(src),f'Frozen input differs: {name}'
  else:shutil.copy2(src,dest)
 if args.approved_manifest:
  frozen=ROOT/'INPUT_APPROVAL_MANIFEST.json'
  if frozen.exists():assert sha(frozen)==sha(args.approved_manifest),'Approval manifest differs'
  else:shutil.copy2(args.approved_manifest,frozen)
 report={'scope':'Approved 1:1 composition only; no scientific computation.','python':sys.version,'pymupdf':fitz.VersionBind,'pillow':Image.__version__,'native_width_mm':WIDTH_MM,'maximum_height_mm':MAX_HEIGHT_MM,'vertical_gap_mm':GAP_MM,'tiff_dpi':450,'source_figure_count':len(names),'sources':{n:{'path':str(inputs/n),'sha256':sha(inputs/n)}for n in names},'figures':[]}
 for label,ns,meaning in PLAN:
  docs=[fitz.open(inputs/n)for n in ns];pages=[d[0]for d in docs]
  assert all(len(d)==1 for d in docs),ns
  assert all(abs(p.rect.width/PT_PER_MM-WIDTH_MM)<.015 for p in pages),[(n,p.rect.width/PT_PER_MM)for n,p in zip(ns,pages)]
  height=sum(p.rect.height for p in pages)+(len(pages)-1)*GAP_MM*PT_PER_MM
  assert height/PT_PER_MM<=MAX_HEIGHT_MM+.001,(label,height/PT_PER_MM)
  out=fitz.open();page=out.new_page(width=WIDTH_MM*PT_PER_MM,height=height);y=0;expected='';expected_geom=[];expected_images=[];placements=[]
  for n,d,p in zip(ns,docs,pages):
   # Destination retains the input's exact native dimensions: no font scaling.
   rect=fitz.Rect(0,y,p.rect.width,y+p.rect.height);page.show_pdf_page(rect,d,0,keep_proportion=True)
   expected+=text(p);expected_geom.extend(geometry(p,0,y))
   for image in p.get_image_info(hashes=True):
    transform=list(image['transform']);transform[5]+=y;expected_images.append({'digest':image['digest'].hex(),'transform':transform})
   placements.append({'source':n,'x_pt':0,'y_pt':y,'width_pt':p.rect.width,'height_pt':p.rect.height,'scale':1.0});y+=p.rect.height+GAP_MM*PT_PER_MM
  pdf=outputs/(label+'.pdf');out.save(pdf,garbage=4,deflate=True);out.close();final=fitz.open(pdf);page=final[0]
  assert text(page)==expected,(label,'ordered scientific labels changed')
  assert close(expected_geom,geometry(page)),(label,'vector geometry or style changed')
  actual_images=[{'digest':image['digest'].hex(),'transform':list(image['transform'])}for image in page.get_image_info(hashes=True)]
  assert close(expected_images,actual_images),(label,'image pixels or placements changed')
  spans=[s for b in page.get_text('dict')['blocks']for l in b.get('lines',[])for s in l['spans']]
  assert all(5.59<=s['size']<=8.01 for s in spans),(label,'font size')
  boundary=[{'text':s['text'],'bbox':s['bbox']}for s in spans if fitz.Rect(s['bbox']).x0<-.1 or fitz.Rect(s['bbox']).y0<-.1 or fitz.Rect(s['bbox']).x1>page.rect.width+.1 or fitz.Rect(s['bbox']).y1>page.rect.height+.1]
  assert not boundary,(label,'text outside page',boundary)
  panel_letters=sorted(s['text']for s in spans if abs(s['size']-8)<.01 and s['text']in 'abcdefg')
  expected_panel_letters={'ED_Figure_1':'abcd','ED_Figure_2':'abc','ED_Figure_3':'abcd','ED_Figure_4':'abcd','ED_Figure_5':'abcd','ED_Figure_6':'abcd','ED_Figure_7':'abcdef','ED_Figure_8':'ab'}
  assert ''.join(panel_letters)==expected_panel_letters[label],(label,'panel letters')
  pix=page.get_pixmap(dpi=180,alpha=False);pix.save(outputs/(label+'.png'))
  (outputs/(label+'.svg')).write_text(page.get_svg_image(text_as_path=False))
  tif_pix=page.get_pixmap(dpi=450,alpha=False);tiff=outputs/(label+'.tiff');im=Image.frombytes('RGB',(tif_pix.width,tif_pix.height),tif_pix.samples);im.save(tiff,compression='tiff_lzw',dpi=(450,450));assert tiff.stat().st_size<10_000_000,(label,'TIFF exceeds 10 MB')
  ti=Image.open(tiff);assert ti.tag_v2[259]==5 and ti.info['dpi']==(450.,450.),(label,'TIFF metadata')
  subprocess.run(['pdftoppm','-png','-r','180','-singlefile',str(pdf),str(previews/label)],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
  pp=Image.open(previews/(label+'.png'));assert pp.width>=1275 and pp.height>0
  record={'name':label,'meaning':meaning,'sources':ns,'placements':placements,'width_mm':page.rect.width/PT_PER_MM,'height_mm':page.rect.height/PT_PER_MM,'visible_font_sizes_pt':sorted({round(s['size'],3)for s in spans}),'ordered_scientific_text_preserved':True,'vector_geometry_and_styles_preserved':True,'source_images_preserved':True,'boundary_check_passed':True,'panel_letters':panel_letters,'tiff_lzw_and_dpi_verified':True,'mupdf_and_poppler_rendered':True,'tiff_bytes':tiff.stat().st_size,'tiff_pixels':[im.width,im.height],'assets':{ext:{'path':str(outputs/(label+ext)),'sha256':sha(outputs/(label+ext))}for ext in ['.pdf','.png','.svg','.tiff']}}
  report['figures'].append(record);print(label,round(record['height_mm'],2),'mm',record['tiff_bytes'],'bytes',flush=True)
 (ROOT/'ED_COMPOSITION_AUDIT.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n')
 (ROOT/'ED_FIGURE_MAPPING.json').write_text(json.dumps({r['name']:r['assets']['.pdf']['path']for r in report['figures']},indent=2)+'\n')
if __name__=='__main__':main()
