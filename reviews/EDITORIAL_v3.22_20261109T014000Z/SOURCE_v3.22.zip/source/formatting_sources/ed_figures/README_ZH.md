# Extended Data 合图与投稿图件输出

本轮依据作者批准的A03/A09及主代理映射，将已有11幅扩展数据/SI图组织为8幅Extended Data图。只组合已完成A10样式修复和分图字母重编号的最终矢量PDF，不运行科学计算，不删数据面板，不修改任何数值、误差线、坐标范围或拟合。

| 新图 | 来源及分图 |
|---|---|
| ED Figure 1 | 原ED2（ed3.pdf）a,b；原ED7（ed2.pdf）c,d |
| ED Figure 2 | 原ED3（ed1.pdf）a；原SI1（ed4.pdf）b,c |
| ED Figure 3 | 原ED4（ED_Figure_4_v35.pdf），全部分图 |
| ED Figure 4 | 原ED5（ED_Figure_5_v35.pdf），全部分图 |
| ED Figure 5 | 原ED6（ED_Figure_6_v35.pdf），全部分图 |
| ED Figure 6 | 原SI2（SI_Figure_2_v35.pdf），全部分图 |
| ED Figure 7 | 原ED1（primary_response_methods.pdf）a,b,c；原SI3（ed5.pdf）d,e,f |
| ED Figure 8 | 原SI4（SI_Figure_4_v36.pdf）a,b |

固定图宽180 mm；成对图上下排列，中间3 mm间隔。源图以1:1尺寸嵌入，不缩小字体，每张总高不超过170 mm。分图字母及图内普通文字的样式由上游A10修复脚本负责；本脚本核对文字未丢失、字框未越界、字体未缩放。

`compose_ed.py` 从经批准的输入文件夹读取源图，首次运行冻结到 `inputs/`。再次运行时输入SHA256必须与冻结副本相同。PDF保留矢量和可编辑文字，SVG保持文字对象，PNG用于预览；TIFF以450 dpi、RGB、LZW压缩输出，每张文件小于10 MB。`poppler/`为独立Poppler渲染，`outputs/*.png`为MuPDF渲染，以便交叉视觉检查。

执行：

```
/data/AI_Research/environments/python/tide-review-20261108T121212Z/bin/python compose_ed.py --input-dir /path/to/approved180mmFigures --approved-manifest /path/to/approval.json
```

实际软件版本、输入及输出SHA256、尺寸、字体大小、TIFF体积、各图面板放置坐标、文字顺序与矢量几何/样式核对结果记录在运行生成的 `ED_COMPOSITION_AUDIT.json`。`ED_FIGURE_MAPPING.json`给出稿件整合使用的PDF路径。图注和论文引用编号由主代理同步调整，不属于本脚本写入范围。

本任务是科研图件组稿，不产生新统计估计、样本量或不确定度；实验设计及科学解释沿用源图和原图注。所有输入均为已生成的派生图件，原始实验数据没有读取或变动。最终审阅前，不把输出称为已批准投稿。

## 本轮执行结果

8图均已生成并核查；高度依次为145.82、155.46、167.21、113.11、147.54、157.38、160.38、54.10 mm，均满足上限。8张450 dpi LZW TIFF分别约0.53、1.18、1.09、0.42、0.99、1.18、0.95、0.13 MB（十进制），全部低于10 MB。各图分图字母分别为abcd、abc、abcd、abcd、abcd、abcd、abcdef、ab，与既有面板映射相符。两套渲染引擎的8张完整图均已逐图目视核对；主代理另行独立复核三张新合图ED1/2/7通过。未发现组合造成的新重叠或裁切。
