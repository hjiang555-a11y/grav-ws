"""Extract the delivered source ZIP and rebuild layout only in a fresh directory."""
from pathlib import Path
import zipfile,subprocess,json,hashlib,sys
import pymupdf as fitz
R=Path(__file__).resolve().parents[1]
H=Path(json.loads((R/'evidence/BRANCH_METADATA.json').read_text())['handoff'])
O=R/'evidence/source_rebuild_01';O.mkdir(exist_ok=False)
with zipfile.ZipFile(H/'SOURCE_v3.22.zip') as z:
 assert z.testzip() is None
 assert not any(n.startswith('/') or '..' in Path(n).parts for n in z.namelist())
 z.extractall(O)
S=O/'source'
p=subprocess.run([sys.executable,str(S/'scripts/build_formal.py'),'--out',str(S/'formal_build_01'),'--include-author-contributions'],cwd=S,capture_output=True,text=True)
(O/'rebuild.log').write_text(p.stdout+p.stderr)
assert p.returncode==0,p.stdout+p.stderr
checks={}
for name in ['NATURE_ARTICLE_v3.22.pdf','NATURE_ARTICLE_MAIN_v3.22.pdf','SUPPLEMENTARY_INFORMATION_v3.22.pdf']:
 a=fitz.open(H/name);b=fitz.open(S/'formal_build_01'/name)
 ta='\n'.join(p.get_text() for p in a);tb='\n'.join(p.get_text() for p in b)
 assert len(a)==len(b),(name,len(a),len(b))
 assert ta==tb,name
 checks[name]={'pages':len(a),'extracted_text_exact':True,'text_sha256':hashlib.sha256(ta.encode()).hexdigest()}
result={'scope':'Manuscript layout rebuild only; no scientific analysis','source_zip_sha256':hashlib.sha256((H/'SOURCE_v3.22.zip').read_bytes()).hexdigest(),'checks':checks}
(H/'SOURCE_REBUILD_CHECKS.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
