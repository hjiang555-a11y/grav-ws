"""Export an explicitly provisional cover letter; no scientific analysis."""
from pathlib import Path
import subprocess,json
from docx import Document
from docx.shared import Pt,Mm,RGBColor
R=Path(__file__).resolve().parents[1]
S=R/'submission';source=S/'COVER_LETTER_v3.22.md'
for suffix in ['pdf','docx']:
 target=S/f'COVER_LETTER_v3.22.{suffix}'
 assert not target.exists(),target
 cmd=['pandoc',str(source),'--standalone','-o',str(target)]
 if suffix=='pdf':cmd+=['--pdf-engine=xelatex','-V','mainfont=Liberation Serif','-V','papersize=a4','-V','geometry:margin=23mm','-V','fontsize=11pt','-V','linestretch=1.05','-V','colorlinks=true']
 p=subprocess.run(cmd,cwd=R,capture_output=True,text=True)
 (S/f'COVER_LETTER_{suffix}.log').write_text(p.stdout+p.stderr)
 assert p.returncode==0,p.stderr
 assert 'WARNING' not in p.stderr,p.stderr
 if suffix=='docx':
  doc=Document(target)
  for sty in doc.styles:
   if sty.type==1:
    sty.font.name='Times New Roman';sty.font.size=Pt(11);sty.font.color.rgb=RGBColor(0,0,0)
    sty.paragraph_format.line_spacing=1.05;sty.paragraph_format.space_after=Pt(7)
  for sec in doc.sections:
   sec.page_width,sec.page_height=Mm(210),Mm(297)
   sec.top_margin=sec.bottom_margin=sec.left_margin=sec.right_margin=Mm(23)
  doc.save(target)
print(json.dumps({'source':str(source),'outputs':['COVER_LETTER_v3.22.pdf','COVER_LETTER_v3.22.docx']}))
