"""Render final PDF contact sheets and record text/layout checks, without edits."""
from pathlib import Path
import json, re, hashlib
import pymupdf as fitz
from PIL import Image, ImageDraw

R=Path(__file__).resolve().parents[1]
B=R/'formal_build_01'
O=R/'visual_check_01';O.mkdir(exist_ok=True)
checks={}
for pdf in B.glob('*.pdf'):
    doc=fitz.open(pdf)
    pages=[];issues=[]
    for i,p in enumerate(doc):
        text=p.get_text()
        pages.append({'page':i+1,'characters':len(text),'first_text':text[:150]})
        for block in p.get_text('dict')['blocks']:
            for line in block.get('lines',[]):
                for span in line['spans']:
                    rect=fitz.Rect(span['bbox'])
                    if rect.x0 < 0 or rect.y0 < 0 or rect.x1 > p.rect.width+1 or rect.y1 > p.rect.height+1:
                        issues.append({'page':i+1,'text':span['text'],'bbox':span['bbox']})
        if len(text.strip())<20:issues.append({'page':i+1,'possibly_blank':True})
    checks[pdf.name]={'pages':len(doc),'layout_issues':issues,'page_inventory':pages,'sha256':hashlib.sha256(pdf.read_bytes()).hexdigest()}
    (O/(pdf.stem+'.txt')).write_text('\n\f\n'.join(p.get_text() for p in doc))
    if pdf.stem=='NATURE_ARTICLE_v3.22':
        for start in range(0,len(doc),12):
            sheet=Image.new('RGB',(1600,2400),'#d0d0d0');draw=ImageDraw.Draw(sheet)
            for j in range(start,min(start+12,len(doc))):
                pix=doc[j].get_pixmap(matrix=fitz.Matrix(.64,.64),alpha=False)
                im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
                x=(j-start)%4*400;y=(j-start)//4*800
                draw.text((x+10,y+8),f'PAGE {j+1}',fill='black')
                sheet.paste(im,(x+8,y+28))
            sheet.save(O/f'contact_{start+1:02d}.jpg')
        for i,p in enumerate(doc):
            if i==0 or re.search(r'(?:Fig\. 1 \||Extended Data Table [123] \||Fig\. 3 \|)',p.get_text()):
                p.get_pixmap(matrix=fitz.Matrix(1.6,1.6),alpha=False).save(O/f'page_{i+1:02d}.png')
(O/'PDF_CHECKS.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
print(json.dumps({k:{a:b for a,b in v.items() if a!='page_inventory'} for k,v in checks.items()},indent=2))
