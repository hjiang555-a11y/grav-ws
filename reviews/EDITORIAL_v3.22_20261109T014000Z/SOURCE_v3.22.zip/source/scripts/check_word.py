"""Check editable artifacts and their existing LibreOffice previews."""
from pathlib import Path
import zipfile,json,xml.etree.ElementTree as E
import pymupdf as fitz
R=Path(__file__).resolve().parents[1]
NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main','m':'http://schemas.openxmlformats.org/officeDocument/2006/math'}
result={}
for p in [R/'formal_build_01/NATURE_ARTICLE_MAIN_v3.22.docx',R/'submission/COVER_LETTER_v3.22.docx']:
 with zipfile.ZipFile(p) as z:
  assert z.testzip() is None
  root=E.fromstring(z.read('word/document.xml'))
  txt=' '.join(n.text or '' for n in root.findall('.//w:t',NS))
  math=len(root.findall('.//m:oMath',NS));tables=len(root.findall('.//w:tbl',NS))
  assert 'Corresponding author name to be confirmed' in txt
  assert '0.96' in txt and '0.11' in txt
  if p.name.startswith('NATURE'):
   assert math>100 and tables==1,(math,tables)
   assert 'Provisional contribution statement' in txt
   assert root.find('.//w:lnNumType',NS) is not None
  preview=R/'evidence/word_preview_01'/p.with_suffix('.pdf').name
  doc=fitz.open(preview);issues=[]
  for i,page in enumerate(doc):
   for b in page.get_text('dict')['blocks']:
    for line in b.get('lines',[]):
     for s in line['spans']:
      q=fitz.Rect(s['bbox'])
      if q.x0<0 or q.y0<0 or q.x1>page.rect.width+1 or q.y1>page.rect.height+1:issues.append({'page':i+1,'text':s['text']})
  assert not issues,issues
  result[p.name]={'math_objects':math,'editable_tables':tables,'preview_pages':len(doc),'preview_out_of_page_text':issues,'provisional_correspondence_present':True}
(R/'evidence/WORD_CHECKS_FINAL.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result,indent=2))
