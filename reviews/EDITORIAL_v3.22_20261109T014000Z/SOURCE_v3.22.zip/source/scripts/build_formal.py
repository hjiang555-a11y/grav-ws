"""Build a versioned reading manuscript and Nature-organized editable source.

Editorial v3.22 uses the selected existing v3.21 scientific results and unchanged figures.
Reference numbering is derived from first citation, with author affiliations excluded.
"""
from pathlib import Path
import re, json, subprocess, argparse, sys

R=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser()
ap.add_argument('--out',type=Path,required=True)
ap.add_argument('--include-author-contributions',action='store_true')
args=ap.parse_args();O=args.out.resolve();O.mkdir(parents=True,exist_ok=False)
def read(name):return (R/'sections'/f'{name}.md').read_text().strip()
def prep(s):
    s=re.sub(r'\bref\.\s+(\d+)(?![\d^])',r'ref. ^\1^',s)
    return s
opening=prep(read('opening'))
title,rest=opening.split('\n',1)
body=prep(read('results_discussion'))
methods=prep(re.sub(r'\[([\d,– -]+)\]',r'^\1^',read('methods')))+'\n\n'+prep(read('auxiliary_methods'))
figures=re.sub(r'^# Figures and Table\s*','',prep(read('figures_tables')))
ed=re.sub(r'^# Extended Data\s*','',prep(read('extended_data')))
si=prep(read('supplementary_methods'))
availability,funding=prep(read('declarations_pre')).split('## Funding',1)
decl='## Funding'+funding+'\n\n'+(prep(read('author_contributions'))+'\n\n' if args.include_author_contributions else '')+prep(read('declarations_post'))
refs={int(m[1]):m[2] for m in re.finditer(r'(?m)^(\d+)\. (.+)$',read('references'))}
def expand(s):
    vals=[]
    for part in s.split(','):
        bounds=re.split('[–-]',part.strip())
        vals.extend(range(int(bounds[0]),int(bounds[-1])+1))
    return vals
order=[];origins={}
for name,text in [('main',rest+'\n'+body+'\n'+figures),('methods',methods+'\n'+availability),('declarations',decl),('extended_data',ed),('supplement',si)]:
    for m in re.finditer(r'\^([\d,– -]+)\^',text):
        for n in expand(m[1]):
            assert n in refs,(name,n)
            if n not in order:order.append(n);origins[n]=name
mapping={n:i+1 for i,n in enumerate(order)}
assert len(order)==35,len(order)
assert all(n in mapping for n in (63,64,65)),mapping
def cite(m):
    vals=sorted({mapping[n] for n in expand(m[1])});parts=[];i=0
    while i<len(vals):
        j=i
        while j+1<len(vals) and vals[j+1]==vals[j]+1:j+=1
        if j-i>=2:parts.append(f'{vals[i]}–{vals[j]}')
        else:parts.extend(map(str,vals[i:j+1]))
        i=j+1
    return '^'+','.join(parts)+'^'
def renumber(s):
    s=re.sub(r'\^([\d,– -]+)\^',cite,s)
    return re.sub(r'\bref\. \^(\d+)\^','ref.\u00a0'+r'\1',s)
rest,body,methods,figures,ed,si,decl=map(renumber,[rest,body,methods,figures,ed,si,decl])
availability=renumber(availability)
main_ids=[n for n in order if origins[n]=='main']
other_ids=[n for n in order if origins[n]!='main']
assert len(main_ids)==29 and len(other_ids)==6,(len(main_ids),len(other_ids))
def reference_list(ids,heading):
    return '\n\n'+heading+'\n\n'+'\n\n'.join(f'{mapping[n]}. {refs[n]}' for n in ids)+'\n'
mainrefs=reference_list(main_ids,'## References')
methodrefs=reference_list(other_ids,'## Methods references')
authors='\n\n::: authors\n'+read('author_block')+'\n:::\n\n'
# Keep exact approved wording; only the reference markers differ from the accepted draft.
abstract=rest.strip().split('\n\n')[0].strip('*')
approved=(R/'evidence/APPROVED_ABSTRACT_SOURCE.md').read_text().strip()
strip_cites=lambda t:re.sub(r'\^[\d,– -]+\^','',t)
assert strip_cites(abstract)==strip_cites(approved)
count=len(strip_cites(abstract).split());assert count<=200

def displays(text):
    # Attach category headings to their first display, not to the preceding page.
    text=re.sub(r'(?m)^### Supplementary (Tables|Figures)\s*',r'\\clearpage\n\n### Supplementary \1\n\n',text)
    text=re.sub(r'(?m)(^!\[|^\*\*(?:Extended Data Table|Supplementary Table))',r'\\clearpage\n\n\1',text)
    text=re.sub(r'(### Supplementary (?:Tables|Figures)\s*)\\clearpage\s*',r'\1',text)
    chunks=text.split('\\clearpage')
    out=[]
    for c in chunks:
        c=c.strip()
        if not c:continue
        if '![' in c or c.startswith('**Extended Data Table'):
            c='::: display\n'+c+'\n:::'
        elif c.startswith('**Supplementary Table') or c.startswith('### Supplementary Tables'):
            c='::: supplementarytable\n'+c+'\n:::'
        out.append(c)
    result='\n\n\\clearpage\n\n'.join(out)
    # The first SI table can share the final methods page, avoiding a two-line page.
    result=result.replace('\\clearpage\n\n::: supplementarytable\n### Supplementary Tables',
                          '::: supplementarytable\n### Supplementary Tables')
    return result

# Main table remains editable and attached to the scientific argument.
table_pattern=r'(\*\*Table 1 \|.*?)(?=\n\nAs shown in Table 1)'
body=re.sub(table_pattern,r'::: maintable\n\1\n:::\n',body,flags=re.S)
preface=title+authors+rest+'\n\n'+body
legends=re.sub(r'!\[[^\]]*\]\([^\n]+\)\{[^\n]+\}\s*','',figures)
ed_legends=re.sub(r'!\[[^\]]*\]\([^\n]+\)\{[^\n]+\}\s*','',ed)
# Remove ED table grids from the submission text; captions stay, image files supplied separately.
ed_legends=re.sub(r'(?m)^\|.*\n?', '',ed_legends)
reading=preface+mainrefs+'\n\n\\clearpage\n\n'+displays(figures)+'\n\n\\clearpage\n\n'+methods+'\n\n'+availability+methodrefs+'\n\n'+decl+'\n\n\\clearpage\n\n'+displays(ed)
table_block=re.search(r'::: display\s*::: maintable\s*.*?\n:::\s*\n:::',preface,re.S)
assert table_block is not None
submission_preface=preface[:table_block.start()]+preface[table_block.end():]
submission=submission_preface+mainrefs+'\n\n'+table_block[0]+'\n\n## Main figure legends\n\n'+legends+'\n\n'+methods+'\n\n'+availability+methodrefs+'\n\n'+decl+'\n\n## Extended Data legends\n\n'+ed_legends
si_title=r'''\thispagestyle{empty}
\nolinenumbers
\begin{center}
\vspace*{35mm}
{\Large\bfseries Supplementary Information\par}
\vspace{12mm}
{\large Tidal potential measured with distant optical clocks\par}
\vspace{8mm}
Lei Hou et al.
\vspace{10mm}

{\small Reference numbers follow the main manuscript.\par}
\end{center}
\clearpage
\linenumbers
'''
supplement=si_title+displays(si)
reading+='\n\n\\clearpage\n\n'+supplement
layout=r'''function Table(el)
 if FORMAT:match('latex') and #el.colspecs==9 then
  local widths={0.22,0.07,0.09,0.08,0.10,0.09,0.15,0.11,0.09}
  for i=1,9 do el.colspecs[i][2]=widths[i] end
  return {pandoc.RawBlock('latex','\\begingroup\\fontsize{9.5}{11.5}\\selectfont'),el,pandoc.RawBlock('latex','\\endgroup')}
 end
end
function Div(el)
 if not FORMAT:match('latex') then return end
 local begin=nil; local ending=nil
 if el.classes:includes('authors') then
  begin='\\begingroup\\singlespacing\\fontsize{10}{12}\\selectfont\\setlength{\\parskip}{3pt}\\nolinenumbers'; ending='\\par\\endgroup'
 elseif el.classes:includes('display') then
  begin='\\par\\begingroup\\singlespacing\\small'; ending='\\par\\endgroup'
 elseif el.classes:includes('maintable') then
  begin='\\begingroup\\singlespacing\\small';ending='\\par\\endgroup'
 elseif el.classes:includes('supplementarytable') then
  begin='\\begingroup\\singlespacing\\small';ending='\\par\\endgroup'
 end
 if begin then
  local out={pandoc.RawBlock('latex',begin)}
  for _,v in ipairs(el.content) do table.insert(out,v) end
  table.insert(out,pandoc.RawBlock('latex',ending));return out
 end
end
'''
(O/'layout.lua').write_text(layout)
header=r'''\usepackage{setspace}
\usepackage{lineno}
\usepackage{fancyhdr}
\usepackage{titlesec}
\usepackage{float}
\floatplacement{figure}{H}
\titleformat{\section}{\normalfont\Large\bfseries\raggedright}{}{0pt}{}
\titleformat{\subsection}{\normalfont\large\bfseries\raggedright}{}{0pt}{}
\titleformat{\subsubsection}{\normalfont\normalsize\bfseries\raggedright}{}{0pt}{}
\setlength{\emergencystretch}{3em}
\widowpenalty=10000
\clubpenalty=10000
\setlength{\tabcolsep}{3pt}
\setlength{\headheight}{15pt}
\pagestyle{fancy}\fancyhf{}
\fancyhead[L]{\footnotesize Tidal potential measured with distant optical clocks}
\fancyfoot[C]{\thepage}
\renewcommand{\linenumberfont}{\normalfont\tiny\sffamily}
\modulolinenumbers[1]
\doublespacing
\linenumbers
\newfontfamily\fallbackfont{DejaVu Serif}
\usepackage{newunicodechar}
\newunicodechar{₀}{\textsubscript{0}}
\newunicodechar{₁}{\textsubscript{1}}
\newunicodechar{₂}{\textsubscript{2}}
\newunicodechar{₅}{\textsubscript{5}}
\newunicodechar{₇}{\textsubscript{7}}
\newunicodechar{⁻}{\textsuperscript{−}}
\newunicodechar{¹}{\textsuperscript{1}}
\newunicodechar{⁸}{\textsuperscript{8}}
'''
(O/'header.tex').write_text(header)
records=[]
for stem,text in [('NATURE_ARTICLE_v3.22',reading),('NATURE_ARTICLE_MAIN_v3.22',submission),('SUPPLEMENTARY_INFORMATION_v3.22',supplement)]:
    inp=O/(stem+'.md');inp.write_text(text)
    tex=O/(stem+'.tex')
    cmd=['pandoc',str(inp),'--standalone','--from=markdown-implicit_figures','--resource-path='+str(R),
         '--lua-filter='+str(O/'layout.lua'),'-V','mainfont=Liberation Serif','-V','sansfont=Liberation Sans',
         '-V','mathfont=Latin Modern Math','-V','papersize=a4','-V','geometry:margin=22mm','-V','fontsize=12pt',
         '-H',str(O/'header.tex'),'-o',str(tex)]
    p=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/(stem+'.pandoc.log')).write_text(p.stderr)
    assert p.returncode==0,p.stderr
    # Expand the inline image links to absolute paths for the build; later make portable.
    s=tex.read_text();s=s.replace('{figures/', '{'+str(R/'figures')+'/')
    s=s.replace(r'\boldsymbol\beta',r'\symbf{\beta}')
    # Avoid rounding overflow in the seven equal-width table columns.
    s=s.replace(r'\real{0.1429}',r'\real{0.142857}')
    tex.write_text(s)
    for iteration in range(2):
        p=subprocess.run(['xelatex','-no-shell-escape','-interaction=nonstopmode','-halt-on-error','-output-directory',str(O),str(tex)],cwd=R,capture_output=True,text=True)
        (O/f'{stem}.pass{iteration+1}.stdout').write_text(p.stdout+p.stderr)
        if p.returncode:raise RuntimeError(p.stdout[-4000:])
    records.append({'stem':stem,'pdf':str(O/(stem+'.pdf'))})
(O/'CITATION_ORDER.json').write_text(json.dumps({'source_to_compiled':mapping,'origins':origins,'main_count':len(main_ids),'methods_count':len(other_ids),'total':len(order)},indent=2))
(O/'BUILD_CHECKS.json').write_text(json.dumps({'abstract_whitespace_tokens':count,'abstract_words_excluding_operators':len([w for w in strip_cites(abstract).split() if w!='±']),'approved_abstract_exact_text':True,'author_contributions_included':args.include_author_contributions,'records':records,'python':sys.version,'body_font':'Liberation Serif, 12pt (Times-compatible substitute)','body_line_spacing':'double'},indent=2))
print(json.dumps(records,indent=2))
