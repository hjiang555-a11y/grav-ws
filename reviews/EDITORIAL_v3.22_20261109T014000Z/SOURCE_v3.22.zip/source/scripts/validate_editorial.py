"""Verify manuscript/editorial invariants; never load or recalculate observations."""
from pathlib import Path
from collections import Counter
import hashlib,json,re
R=Path(__file__).resolve().parents[1]
OLD=R.parent/'editorial_v321_20261109T010919Z'
B=R/'formal_build_01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
baseline=json.loads((R/'evidence/BASELINE_V321_HASHES.json').read_text())
for name,digest in baseline.items(): assert sha(Path(name))==digest,name
changed=[p.name for p in sorted((R/'sections').glob('*.md')) if p.read_bytes()!=(OLD/'sections'/p.name).read_bytes()]
assert set(changed)=={'opening.md','results_discussion.md','methods.md','auxiliary_methods.md','figures_tables.md','supplementary_methods.md','author_block.md','author_contributions.md'},changed
assert (OLD/'sections/opening.md').read_text().split('## Introduction')[0]==(R/'sections/opening.md').read_text().split('## Introduction')[0]
oldtext='\n'.join(p.read_text() for p in sorted((OLD/'sections').glob('*.md')))
newtext='\n'.join(p.read_text() for p in sorted((R/'sections').glob('*.md')))
assert Counter(re.findall(r'\$\$.*?\$\$',oldtext,re.S))==Counter(re.findall(r'\$\$.*?\$\$',newtext,re.S))
body=(R/'sections/results_discussion.md').read_text()
oldbody=(OLD/'sections/results_discussion.md').read_text()
table=lambda s:re.search(r'\*\*Table 1 \|.*?(?=\n:::) ',s,re.S)
start='**Table 1 |'
assert body.split(start,1)[1].split('\n:::',1)[0]==oldbody.split(start,1)[1].split('\n:::',1)[0]
for x in ['0.97\\pm0.14','0.90\\pm0.29','0.98\\pm0.11','0.89\\pm0.55','0.36\\pm0.50']:
 assert x not in body,x
for x in ['0.96\\pm0.11','1.00\\pm0.13']: assert x in body,x
figures=[p for p in (R/'figures').rglob('*') if p.is_file()]
for p in figures: assert p.read_bytes()==(OLD/p.relative_to(R)).read_bytes(),p
links=lambda s:re.findall(r'!\[[^\]]*\]\([^\n]+\)\{[^\n]+\}',s)
assert links((R/'sections/figures_tables.md').read_text())==links((OLD/'sections/figures_tables.md').read_text())
oldauthors=(OLD/'sections/author_block.md').read_text().strip()
assert (R/'sections/author_block.md').read_text().startswith(oldauthors)
assert re.search(r'provisional|confirmation', (R/'sections/author_contributions.md').read_text(),re.I)
assert 'Correspond' in (R/'sections/author_block.md').read_text()
def expand(s):
 out=[]
 for part in s.split(','):
  bounds=re.split('[–-]',part.strip());out.extend(range(int(bounds[0]),int(bounds[-1])+1))
 return out
compiled=(B/'NATURE_ARTICLE_v3.22.md').read_text()
without_authors=re.sub(r'::: authors.*?:::', '',compiled,flags=re.S)
first=[]
for match in re.finditer(r'\^([\d,– -]+)\^|\bref\.\s+(\d+)',without_authors):
 for n in expand(match[1] or match[2]):
  if n not in first:first.append(n)
assert first==list(range(1,36)),first
mapping=json.loads((B/'CITATION_ORDER.json').read_text())
oldmap=json.loads((OLD/'formal_build_01/CITATION_ORDER.json').read_text())
assert set(mapping['source_to_compiled'])==set(oldmap['source_to_compiled'])
mainfigs=[]
for m in re.finditer(r'(?<!Data )(?<!Supplementary )Fig\. ([1-4])',body):
 if int(m[1]) not in mainfigs:mainfigs.append(int(m[1]))
assert mainfigs==[1,2,3,4],mainfigs
issues={}
for p in B.glob('*.log'):
 found=[s for s in p.read_text().splitlines() if re.search(r'Overfull|Missing character|LaTeX Warning|Font Warning|^!',s)]
 if found:issues[p.name]=found
assert not issues,issues
build=json.loads((B/'BUILD_CHECKS.json').read_text())
assert build['author_contributions_included']
result={'scope':'Editorial/layout verification only; no scientific recalculation or raw-data reproduction',
'changed_sections':changed,'frozen_baseline_files_verified':len(baseline),'approved_title_abstract_exact':True,
'abstract_words_excluding_operators':build['abstract_words_excluding_operators'],'display_equations_unchanged':True,
'Table1_exact':True,'all_figure_files_byte_identical':len(figures),'main_figure_links_sizes_order_unchanged':True,
'main_selected_result_series_only':True,'removed_alternative_numbers_recorded_in':'agents/task1/CHANGE_MAP.md',
'numeric_multiset_unchanged':False,'numeric_changes':'Author-authorized redundant-result deletions; existing selection rules disclosed with frozen-source provenance',
'citation_sources_unchanged':True,'citation_first_appearance':first,'main_figure_first_appearance':mainfigs,
'author_order_affiliations_unchanged':True,'provisional_author_contributions_included':True,'compiler_serious_warnings':issues,
'pending_author_items':['Corresponding author identity and email','Approval of provisional contributions and submission declarations','Original segment-window selection rationale','Existing S2 detection/attribution claim boundary','Fig1 campaign-hour aggregation','Data/code access arrangements'], 'build':build}
(B/'FINAL_VALIDATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='build'},ensure_ascii=False,indent=2))
