"""Export an editable text-and-legends companion; the combined PDF carries figures."""
from pathlib import Path
import subprocess, re
from docx import Document
from docx.shared import Pt, Mm, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

R = Path(__file__).resolve().parents[1]
B = R / 'formal_build_01'
target = B / 'NATURE_ARTICLE_MAIN_v3.22.docx'
assert not target.exists()
source = (B/'NATURE_ARTICLE_MAIN_v3.22.md').read_text()
# Pandoc's Word math reader needs a braced font command, unlike XeLaTeX.
# This syntax-only adaptation leaves the canonical manuscript untouched.
source = re.sub(r'\{\\rm\s+([^{}]*)\}', lambda m: r'{\mathrm{' + m[1] + '}}', source)
adapted = B/'WORD_COMPATIBLE_SOURCE.md'
adapted.write_text(source)
result = subprocess.run(['pandoc', str(adapted),
                '--from=markdown-implicit_figures', '-o', str(target)],
                capture_output=True, text=True, check=True)
(B/'WORD_EXPORT.log').write_text(result.stderr)
assert 'WARNING' not in result.stderr, result.stderr
doc = Document(target)
normal = doc.styles['Normal']
normal.font.name = 'Times New Roman'
normal.font.size = Pt(12)
normal.paragraph_format.line_spacing = 2
normal.paragraph_format.space_after = Pt(0)
for name, size in [('Heading 1', 16), ('Heading 2', 14), ('Heading 3', 12)]:
    style = next(s for s in doc.styles if s.name.lower() == name.lower())
    style.font.name = 'Times New Roman'
    style.font.size = Pt(size)
    style.font.color.rgb = RGBColor(0, 0, 0)
# Keep the approved author block compact, as in the authoritative PDF.
for para in doc.paragraphs[1:]:
    if para.text.startswith('The Moon and the Sun'):
        break
    para.paragraph_format.line_spacing = 1
    for run in para.runs:
        run.font.size = Pt(10)
    para._p.get_or_add_pPr().append(OxmlElement('w:suppressLineNumbers'))
for sec in doc.sections:
    sec.page_width, sec.page_height = Mm(210), Mm(297)
    sec.top_margin = sec.bottom_margin = sec.left_margin = sec.right_margin = Mm(22)
    numbering = OxmlElement('w:lnNumType')
    numbering.set(qn('w:countBy'), '1')
    numbering.set(qn('w:restart'), 'continuous')
    sec._sectPr.append(numbering)
    p = sec.footer.paragraphs[0]
    p.clear()
    p.alignment = 1
    p._p.get_or_add_pPr().append(OxmlElement('w:suppressLineNumbers'))
    field = OxmlElement('w:fldSimple')
    field.set(qn('w:instr'), 'PAGE')
    p._p.append(field)
for table in doc.tables:
    for row in table.rows:
        for cell in row.cells:
            for para in cell.paragraphs:
                para.paragraph_format.line_spacing = 1
                for run in para.runs:
                    run.font.size = Pt(10)
doc.save(target)
print(target)
