## Supplementary Methods

SM1–SM5 describe the filtered validation analysis, also labelled the primary reduction. SM6 and SM7 describe the main analysis, also labelled the auxiliary reduction, unless a filtered-data comparison is explicitly identified. Extended Data Table 1a summarizes their methodological differences.

### SM1. Physical model

We use $k_{20}=0.29525$, $k_{22}=0.29801$ and $k_3=0.093$. The IERS 2010 resonance formula, applied constituent by constituent for $k_{21}$, gives 0.2588 for K₁, 0.2873 for P₁ and 0.2975 for O₁. The radial displacement is computed with the IERS algorithm, including the frequency and latitude dependence of the Love number $h$ ^16^.

PREM load Love numbers are used through degree $n=696$ ^27^, from the gravity-toolkit distribution ^28^. Above this degree, $h'_n$ is joined smoothly to its Boussinesq limit of −6.22, and the series is summed with a Kummer transformation through $n=40,000$. The convolution uses full grid resolution within 3° of each station and sums blocks of $8\times8$ cells farther away, which changes the differential M₂ and K₁ loading by at most 0.05%.

The full loading potential exceeds the vertical-displacement contribution $-g\delta h$ by factors of approximately 1.4 for the semidiurnal and 1.8 for the diurnal constituents. The radial displacement from the same convolution agrees with the FES2022 load-tide grid to within 2.2% in amplitude and 1.2° in phase for seven of the eight constituents (Extended Data Fig. 8); the attraction and induced-potential terms use the same PREM load Love numbers. For S₂, whose load-tide grid derives from a different ocean-model release, the amplitude differs by about 18% and the phase at Wuhan by 54°. The S₂ loading is $0.62\times10^{-18}$ in Shanghai and $0.18\times10^{-18}$ in Wuhan, a differential amplitude of $0.63\times10^{-18}$ compared with $1.42\times10^{-18}$ for M₂. Substituting the S₂ loading inferred from the load-tide grid changes the full-template amplitude by 0.001 and the semidiurnal amplitude by 0.000, and leaves the lunar amplitude unchanged.

The Shanghai clock is 22 km from the nearest ocean cell. Filling land cells within 0.3° or 0.6° of the coastline in a $4^\circ\times5^\circ$ box centred on Shanghai with the nearest ocean values, strips approximately 33–66 km wide, increases the Shanghai M₂ loading potential expressed as $\delta W/g$ from 15.3 mm to 17.0 or 18.5 mm and decreases the lunar response by 0.05 or 0.08, respectively.

Setting the remainder of the eight-constituent model to zero or doubling it gives semidiurnal amplitudes of 0.95–0.96 and lunar amplitudes of 0.95–0.99.

### SM2. Selection and timing

Adding the tidal model with factors of −1, 1 or 3 leaves the removed samples unchanged; six robust standard deviations is the lowest tested threshold with this invariance up to three times the model. Block lengths of 60 or 300 s and thresholds from four to eight standard deviations give lunar amplitudes from 0.93 to 1.02. Retaining the excursions gives $0.96\pm0.14$, and the full-template and semidiurnal amplitudes change by less than 0.04. Before transient removal, the procedure reproduces the summer sample set of ref. ^12^; after removal, the campaign diurnal amplitudes are mutually consistent ($p=0.21$). Three of the nine identified excursions coincide with approximately equal and opposite link-monitor excursions.

Omitting endpoint trimming changes the lunar amplitude by −0.009 and the full-template amplitude by 0.008. Shifting the model by ±10 min changes $A$ by less than 0.02. Long-period tides are not fitted: the similar site latitudes make the predicted differential semiannual tide only about $2\times10^{-20}$. Durations refer to retained 1-s samples; the exposure of the filtered data at 600-s steps is slightly shorter.

### SM3. Uncertainty calibration and campaign consistency

For the lunar group, two independent sets of 200 realizations give standard deviations of 0.13 and 0.14, compared with 0.13 for the larger of the scaled least-squares and jackknife errors; we quote 0.14, with a resampling bias of +0.01. With the daily disturbances of Methods, which have r.m.s. values up to $1.9\times10^{-18}$, 5,000 realizations per scenario give standard deviations rounding to 0.14 (0.13–0.15 for the 300 realizations of Extended Data Table 1b) and coverage of 0.67–0.68 for ±0.14 and 0.945–0.952 for ±1.96 × 0.14.

For the semidiurnal response, the group-bootstrap standard deviation of 0.08 is smaller than the calibrated value of 0.12, which is quoted. The segment bootstrap gives a lunar amplitude of $0.98\pm0.11$ and phase of $-6^\circ\pm8^\circ$. The correlation between the lunar and neighbouring semidiurnal coefficients is −0.32.

Summer supplies 61% of the conditional information on the lunar response and gives $0.87\pm0.18$, compared with $1.05\pm0.31$ for the earlier campaigns together. The five lunar estimates are consistent ($\chi^2=4.1$, four degrees of freedom, $p=0.40$; Extended Data Table 2a), as are the semidiurnal estimates ($\chi^2=3.2$, $p=0.52$; Extended Data Fig. 1a,b). Resampling the operating groups gives a 95% lunar interval of [0.76, 1.18].

### SM4. Prediction, environmental and daily-term checks

The whole-template prediction reduces residual sums of squares in seven of eight held-out periods, by 4.9% when pooled; the lunar prediction improves six of eight periods, by 1.7% when pooled.

Over the 98-h overlap, the blackbody shift calculated from chamber temperature and filtered like the ratio has an r.m.s. of $2.8\times10^{-18}$. As a free regressor it gives $0.92\pm0.74$, or $0.72\pm0.74$ after excluding the chamber-temperature transient on 30 June (day-by-day jackknife errors), consistent with zero. Without real-time correction, the shift would contain a daily component of $2.0\times10^{-18}$ peaking at 12:13 local time, with a peak-to-peak daily range of $4\times10^{-18}$; the fitted 24-h ratio term in the same overlap is $(0.9\pm1.1)\times10^{-18}$ with maximum at 10:54 ± 5.0 h.

On the primary sampling after segment-mean removal, the predicted solid-tide and loading r.m.s. fractional frequencies are $3.02\times10^{-18}$ and $1.35\times10^{-18}$, and that of their sum is $4.09\times10^{-18}$. The response fitted to the solid-Earth tide alone is $1.19\pm0.20$, compared with 1.32 expected on this sampling for the combined model, and the separately fitted loading coefficient is $0.89\pm0.55$. This coefficient comes from a fit of the solid-Earth and loading templates with two free coefficients and segment offsets to the filtered primary data with equal weights; its uncertainty is the larger of the scaled least-squares and day-by-day jackknife errors.

The summer 24-h term has amplitude $(2.8\pm1.3)\times10^{-18}$ and peaks at 15:48 local time with a 1.5-h uncertainty; the 12-h term is $(0.6\pm0.7)\times10^{-18}$. With summer projection coefficients of 0.016 and 0.043 per $10^{-18}$, they shift the lunar response by at most 0.045 and 0.024 (Extended Data Table 2a). For the full record, a common-phase 12-h perturbation of $10^{-18}$ changes the whole-template response by at most 0.087.

The lunar responses for alternative daily models (Fig. 4a) are: campaign-specific 24-h terms with air-temperature phases, $0.99\pm0.14$; free-phase campaign-specific 24-h terms, $0.97\pm0.15$; air-temperature anomalies at both sites, $0.98\pm0.13$; common 24-h and 12-h terms, $1.00\pm0.13$; campaign-specific free-phase 12-h terms, $0.82\pm0.17$, or $0.86\pm0.18$ with 24-h terms also included. Operating-group or period offsets in place of segment offsets give $0.97\pm0.11$ and $0.99\pm0.11$, and omitting each earlier campaign in turn gives 0.89–0.99.

### SM5. Alternative processing and spectra

The segment-wise estimator of ref. ^12^ demeans filtered data and model within each segment, fits the amplitude through the origin using non-overlapping 1,200-s windows, and combines segments with inverse-variance weights. For the summer record it gives $A=0.78\pm0.19$ with the present physical model and 0.87(15) with the model of ref. ^12^; the joint lunar fit gives $0.87\pm0.18$.

Independent processing of the 2026 records uses non-overlapping 600-s means, corrected clock systematic shifts and fixed ten-day calendar baselines. It gives a whole-template response of $0.88\pm0.10$ without empirical daily terms and a lunar response of $0.89\pm0.28$ with daily terms in each ten-day block, and its whole-template prediction improves all six held-out 2026 periods. Simulations with white, Ornstein–Uhlenbeck (correlation times of 1 h to 3 d), Student-$t$ and moving-average noise give biases below 0.04 and 95%-interval coverage of 94.5–99.8% (Extended Data Table 1c). Simpler solid-tide approximations change its whole-template scale by less than 0.01.

At M₂, the harmonic power of the full record after projection of segment offsets decreases by 99% after subtraction of the fitted whole template (Extended Data Fig. 7c). In the three-group fit the diurnal coefficient is $0.35\pm0.51$; the two-band estimate is $0.36\pm0.50$ (Extended Data Fig. 1b).

### SM6. Auxiliary response and uncertainty details

Extended Data Table 1a compares the main and filtered validation analyses; Extended Data Table 2d gives the main response estimates and their uncertainties. In the phase-relaxed fit, the lunar in-phase and quadrature estimates are $1.0007\pm0.1320$ and $-0.0969\pm0.1989$; the scaled least-squares quadrature error is 0.1273.

The projected solid-Earth/loading template correlation is 0.725 and the coefficient correlation under day deletion is −0.888. For M₂ and S₂, at the measured amplitudes $4.5047\times10^{-18}$ and $1.9214\times10^{-18}$, observing-period noise propagation gives standard errors of $0.6153\times10^{-18}$ and $0.6788\times10^{-18}$. For the diurnal-group and loading coefficients, the period-noise standard errors are 0.3631 and 0.4337 and the UTC-day-jackknife errors 0.5381 and 0.5438.

Propagating the observing-period noise coefficients, $\Sigma_{kk}=\alpha_{p(k)}^2/\Delta t_k$, through the unchanged estimators gives $S/R$ values of 7.32, 2.83, 1.59 and 1.12 for M₂, S₂, the diurnal group and ocean loading. In the triangular-filter reduction, the corresponding ratios are 6.93 for the lunar group, 3.10 for the neighbouring semidiurnal group and 0.72 for the two-band diurnal estimate.

### SM7. Compensation, alias and correlation diagnostics

For donor $D$ and target $T$, the joint fit supplies the fixed donor coefficient vector $\hat\beta_D$. For 61 values of λ from 0 to 1.5, we form $y_\lambda=y-\lambda X_D\hat\beta_D$ and fit only the target pair together with $N$. With $P_T=R_NX_T$ and $P_D=R_NX_D$,

$$
\hat\beta_T(\lambda)=\hat\beta_{T,\mathrm{single}}-\lambda P_T^+P_D\hat\beta_D,
$$

where $P_T^+$ is the Moore–Penrose pseudoinverse. We repeat the sweep with the donor's single-frequency estimate. A fit retaining both pairs after subtraction leaves the target unchanged by construction and is an algebraic control. Amplitude is the norm of the two coefficients and phase is $\operatorname{atan2}(\beta_{\sin},\beta_{\cos})$, corresponding to $A\cos(2\pi f(t-t_0)-\phi)$. Amplitudes are converted to equivalent height as in Methods.

Template lag correlations evaluate the fitted donor waveform at $t-\ell$ and the target at $t$, residualize both on the observation support and normalize their inner product, for lags within ±24 h in 5-min steps. The zero-lag correlation is 0.1955, and the maximum absolute lag correlations are 0.2413 for shifted M₂ against S₂ and 0.2113 in the reverse direction. The largest cross-component coefficient correlations between the joint M₂ and S₂ estimates, $R_{ij}=C_{ij}/\sqrt{C_{ii}C_{jj}}$, are 0.248 under scaled least squares and 0.261 under UTC-day deletion (Extended Data Fig. 5).

For alias diagnostics, we scan 20–25 μHz with spacing $1/(12T_{\rm span})$ and, for each donor, select the three strongest local maxima of its pure-injection least-squares power at least $2/T_{\rm span}$ from its own frequency. At each selected frequency, the fitted coefficient vector follows $\hat b_f(\lambda)=\hat b_f(0)-\lambda\hat b_{f,D}$, and the equivalent-height amplitude is $K\|\hat b_f(0)-\lambda\hat b_{f,D}\|$ with $K=(c^2/g_0)\,10^{-16}$ cm. At 22.1016 and 22.6283 μHz, subtraction of the jointly fitted lunar waveform reduces the amplitudes from 3.149 to 0.204 cm and from 3.307 to 0.266 cm, reductions of 93.51% and 91.97%, with minima at compensation factors 0.9974 and 1.0490 (Extended Data Fig. 6).
