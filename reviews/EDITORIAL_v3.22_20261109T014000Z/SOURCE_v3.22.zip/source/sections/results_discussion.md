## Results

### A coastal–inland clock baseline

As shown in Fig. 1a, the Shanghai Sr clock and the Wuhan Yb clock lie on a 692-km coastal–inland baseline and are connected through Hefei by a 1,350-km phase-stabilized fibre link.^24^ The comparison instability is approximately $5.4\times10^{-16}/\sqrt{\tau/\mathrm{s}}$ at averaging time $\tau$ for the spliced summer record (ref. 12) and is dominated by the clocks. Changes in the frequency ratio follow the changing potential difference, and a fitted offset for each observing segment absorbs the static part.

On this baseline, ocean loading contributes appreciably. We compute the solid-Earth tide following the IERS conventions^16^ and the loading potential from FES2022,^17,18^ including water attraction, induced Earth potential and clock displacement.^19^ For the principal lunar semidiurnal tide, M₂, the differential solid-tide and loading amplitudes are $3.41\times10^{-18}$ and $1.42\times10^{-18}$ in fractional frequency, and their 20° phase difference gives a combined amplitude of $4.76\times10^{-18}$ (Fig. 1c).

The observations span five campaigns and 54 observing segments over 353 days (Fig. 1b). The main analysis uses 545.9 h of retained samples to estimate template responses, spectra and signal-to-noise ratios. A filtered analysis of the same observations provides the time-domain displays (Fig. 2) and validation tests. Both analyses fit segment offsets; their selection, weights and template realizations are described in Methods and Extended Data Table 1a.

### Amplitude, phase and coverage

The full-template response is $0.96\pm0.11$, where a response of one denotes agreement with the predicted change in frequency ratio (Fig. 3a). To separate the semidiurnal contributions, we group M₂ with the larger lunar elliptic semidiurnal tide, N₂, and the principal solar semidiurnal tide, S₂, with the lunisolar semidiurnal tide, K₂. Within each group, relative amplitudes and phases follow the physical model. The lunar-group response is $1.00\pm0.13$ (Fig. 3a), and allowing its phase to vary gives timing consistent with the prediction (Fig. 3b).

The lunar and solar semidiurnal periods are approximately 12.42 h and 12 h, and their changing relative phase allows the observations to distinguish them. The two-month summer campaign covers the full relative-phase cycle, whereas the shorter campaigns cover narrower intervals (Fig. 1d). The five filtered-analysis campaign estimates are mutually consistent (Extended Data Fig. 1a,b and Extended Data Table 2a). As shown in Fig. 2, the summer time series and its dependence on lunar phase, after removal of the fitted offsets and non-lunar groups, agree well with the predicted lunar variation. Gaps are compressed on the time axis; Extended Data Fig. 2a shows the records of all campaigns, and Extended Data Fig. 2b,c shows the April campaign in calendar time.

The 274-h summer record was also used in the absolute frequency-ratio measurement of Hou et al.;^12^ Extended Data Table 2b relates those estimates to the present analysis.

### Separate semidiurnal detections

The equivalent-height amplitude spectrum (Fig. 3c) has lunar and solar-frequency peaks of 4.87 and 2.87 cm at 22.361 and 23.148 μHz. Subtracting the fixed unit-amplitude physical prediction reduces the amplitudes at these frequencies to 0.71 and 1.02 cm. Each principal frequency retains its peak when the other is controlled by a freely phased sinusoid, with N₂ and K₂ also controlled (Extended Data Fig. 3). A joint fit gives M₂ and S₂ amplitudes of 4.13 and 1.76 cm ($4.50\times10^{-18}$ and $1.92\times10^{-18}$; Extended Data Table 2c). These differ from the scan peaks because neighbouring frequencies are fitted simultaneously. The conditional spectra thus separate the M₂ and S₂-frequency contributions without imposing their astronomical phase relation. The predicted-phase group responses in Fig. 3a instead test agreement with the physical waveforms, keeping the relative phases of S₂ and K₂ fixed within their group (Methods).

### Reliability of the separated signals

Reciprocal subtraction tests the coupling introduced by the sampling (Extended Data Fig. 4). Removing the jointly fitted lunar waveform changes the solar-frequency amplitude from 2.67 to 1.76 cm ($2.918$ to $1.921\times10^{-18}$). Removing the solar-frequency waveform changes the lunar amplitude from 4.45 to 4.13 cm ($4.857$ to $4.505\times10^{-18}$). Both remain identifiable. The maximum canonical correlation between the projected sine–cosine pairs is 0.290 (Extended Data Fig. 5), and the strongest sampling sidelobes respond to lunar-waveform subtraction as predicted (Extended Data Fig. 6).

The lunar estimate is also stable against specified daily disturbances. A $10^{-18}$ fractional-frequency sinusoid at 24 h or 12 h changes the main lunar response by at most 0.023 with a phase fixed across the record; with independent phases in each campaign, the bounds are 0.030 and 0.12, respectively. The filtered analysis provides complementary checks of daily terms, sampling and data selection (Fig. 4). Both clocks correct blackbody shifts in real time, and temperature regressions test residual correction errors (Methods and Extended Data Fig. 1d). In the filtered analysis, adding the fibre-link monitor as a regressor changes the lunar and full-template responses by less than 0.005. Retaining the screened transients leaves the lunar result consistent, and the fits improve predictions for most withheld observation periods (Methods). Extending the ocean mask near Shanghai by 0.3° or 0.6° changes the filtered lunar response by −0.05 or −0.08, respectively, about half of its statistical uncertainty.

### Ocean loading and diurnal response

The separate ocean-loading and diurnal responses are constrained less precisely, with signal-to-noise ratios near unity (Table 1). The corresponding filtered-data fits are consistent with the prediction (Extended Data Fig. 1b; Supplementary Methods SM4 and SM5). Refined coastal loading models and longer continuous runs are expected to sharpen these comparisons.^15^ These weaker constraints, compared with the lunar response, motivate a quantitative account of component precision.

## Discussion

We develop a signal-to-noise model that relates component precision to signal strength, noise and phase coverage. The observation schedule enters through the sampling window and coupling between fitted components; within short segments, a slowly varying tide is partly absorbed by the fitted offset. For a specified estimator, the amplitude signal-to-noise ratio scales locally as

$$
\rho_i(T)\simeq\rho_i(T_0)
\frac{\eta_i(T)}{\eta_i(T_0)}
\left(\frac{T}{T_0}\right)^{a_i-b_i}.\tag{1}
$$

Here $T$ is the retained exposure and $\rho_i=S/R$. The exponents $a_i$ and $b_i$ describe how the phase-aligned signal and the noise standard deviation accumulate, and $\eta_i$ accounts for the sampling window, weights and parameter coupling. For a coherent signal in white noise, $a_i=1$ and $b_i=1/2$, giving $\rho_i\propto\sqrt{T}$ at fixed $\eta_i$. We evaluate this white-noise case on the actual sampling with the measured amplitudes and a common clock-noise coefficient (Methods). Table 1 compares the resulting precision with the empirical errors of the same estimators.

::: display
**Table 1 | Calculated and measured signal-to-noise ratios.**

| Evaluation | Lunar M₂ | Solar S₂ | Diurnal group | Ocean loading |
|:--|--:|--:|--:|--:|
| $S/R$ (white noise) | 7.17 | 2.78 | 1.55 | 1.17 |
| $S/R$ (measured) | 7.02 | 1.96 | 1.08 | 0.89 |

$S=|\hat A|$ is the measured amplitude or template-response magnitude and $R=u(\hat A)$ its standard error. The white-noise row uses the common noise coefficient and the actual sampling; the measured row uses UTC-day-jackknife covariance. All entries use the auxiliary reduction: M₂ and S₂ from their joint sine–cosine fit, the diurnal group from the three-group fit and ocean loading from the two-template solid-Earth/loading fit (Methods).
:::

As shown in Table 1, the lunar precision agrees well with the white-noise expectation, whereas the solar-frequency, diurnal and loading estimates have larger empirical uncertainties. Short segments constrain diurnal cycles weakly after offset removal, and the smaller loading signal overlaps the solid-Earth waveform. The signal-to-noise model thus accounts for most of the differences in precision between components. This comparison evaluates precision at the measured amplitudes; the exposure scaling in equation (1) remains conditional on the noise and sampling efficiency of future observations.

The model identifies distinct ways to improve future observations. Better clock stability lowers noise for a given retained exposure, whereas sustained network operation improves phase coverage and reduces component coupling. Continuous runs of at least two days with maintained phase lock cover successive diurnal cycles; a longer calendar span separates neighbouring frequencies, while gaps create sidelobes (Extended Data Fig. 6). Increasing retained exposure accumulates signal according to equation (1), with the applicable noise and sampling efficiency. Together with additional sites and local environmental records, these improvements would allow weaker potential changes to be identified after subtraction of the tidal background.

The measurement and separation of the lunar and solar-frequency semidiurnal contributions extend demonstrated sub-centimetre-equivalent clock performance^29^ to time-varying geophysical signals. Together with the signal-to-noise model, they support the development of clock networks for geodesy, ultralight-dark-matter searches^38^ and future clock-based gravitational-wave detectors.^62^ Characterizing the tidal background has potential applications to the redefinition of the second^63^ and the unification of height systems at the centimetre level.^64^

**Note added.** During the preparation of this manuscript, a related observation of tidal variations of the gravity potential in a European optical-clock network was reported;^20^ the present work is complementary in separating the lunar and solar semidiurnal contributions on a coastal–inland baseline.
