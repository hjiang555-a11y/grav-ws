## Methods

### Clocks, link and data

The Sr optical lattice clock is in Shanghai (31.130° N, 121.570° E, height approximately 5 m) and the Yb optical lattice clock in Wuhan (30.529° N, 114.357° E, approximately 30 m); changing the Shanghai height by 5 m changes the differential tidal model by only $4\times10^{-23}$. The static geopotential difference, $280.042\pm0.085\ \mathrm{m^2\,s^{-2}}$ from first-order levelling [12], enters the frequency ratio as a constant absorbed by the fitted offsets. The evaluated systematic uncertainties of the Sr and Yb clocks are $9.2\times10^{-19}$ and $1.3\times10^{-18}$ [21,22]; the clocks, fibre link and frequency chain are described in ref. [12], and optical frequency dissemination [23,24] over field fibres of comparable length has been demonstrated.

A 1,550-nm carrier referenced to the Sr clock through a frequency comb in Shanghai is transmitted to Wuhan, where its beat against the Yb-referenced comb is counted at 1-s intervals. In 2026 the beat frequency is 33.6 MHz, and a deviation of 1 Hz corresponds to $5.17\times10^{-15}$ in Yb/Sr; in 2025 the counter recorded the beat after division by two, which is accounted for. The white-frequency-noise level of the tide-corrected ratio, $\sigma_y\sqrt{\tau}$, from the overlapping Allan deviation [26] at 256–4,096 s, is $7.9\times10^{-16}$ in September–October 2025 and $4.2$–$5.3\times10^{-16}$ in the 2026 campaigns, evaluated for each campaign in the primary reduction.

The 1,350-km link extends a 2,067-km dissemination system with bias-free noise compensation based on digital radio-frequency phase recording [12,24]. The out-of-loop round-trip signal and the optical phase-locked loops of the frequency chain are monitored continuously [12]; maintaining lock preserves the phase connection needed for coherent accumulation.

The filtered validation record contains five campaigns (September–October 2025, January 2026, April 2026, May 2026 and June–August 2026) and 54 segments defined by the experiment team; the summer segments are those of ref. [12]. There are 270 h in 38 segments before June and 274 h in 16 segments in June–August, 544 h in total. Campaigns define the seasonal subsets and campaign-specific daily terms, the eight observation periods are the units of held-out prediction, the 29 operating groups are the units of group-bootstrap resampling, and segments carry the fitted offsets. Time stamps are in local time (UTC+8).

### Main analysis: grouped responses

The main analysis (labelled the auxiliary reduction in the supplementary material) provides the summary responses, spectra and signal-to-noise ratios. The filtered validation analysis (labelled the primary reduction in the figure and supplementary labels) provides the time-domain displays and robustness checks. These analyses share observations and are not independent measurements (Supplementary Table 4).

Figure 3, Extended Data Figs. 4–6 and Supplementary Fig. 2 use $N_{\rm b}=3,299$ non-overlapping 600-s means over 353.39 days and 54 segment constants. Within each predefined observing segment, beat-frequency records differing by more than 10 Hz from the segment median were excluded. Retained records were averaged separately within each segment on a 600-s wall-clock grid in Beijing time (UTC+8), retaining bins with at least 180 nominal one-second members. Bin timestamps denote the nominal grid centres. This reduction applies neither the triangular filter nor the additional running-median transient screening used in the filtered validation analysis. Its solid-Earth template converts the IERS radial displacements into fractional frequency,

$$
y_{\rm solid}=-\frac{1+k_2-h_2}{h_2}\frac{g(u_{\rm Wuhan}-u_{\rm Shanghai})}{c^2},
$$

with $h_2=0.6078$, $k_2=0.3010$ and $g=9.794\ \mathrm{m/s^2}$, which differ from the IERS values of the filtered-validation model ($k_{22}=0.29801$) by 0.4% in $1+k_2-h_2$; its loading template uses the effective-potential convolution with 18 constituents. The lunar (M₂, N₂), near-12-h (S₂, K₂) and diurnal (K₁, O₁, P₁, Q₁) groups comprise eight constituents; the remaining terms form a fixed remainder $r_0$. The complete-template and grouped models are $y_i=c_{s(i)}+A_T(s_{L,i}+s_{S,i}+s_{D,i}+r_{0,i})+\epsilon_i$ and $y_i-r_{0,i}=c_{s(i)}+A_Ls_{L,i}+A_Ss_{S,i}+A_Ds_{D,i}+\epsilon_i$. The phase-relaxed model adds a quarter-cycle-shifted lunar template while keeping the M₂/N₂ relation.

The weights are $W_{ii}=1/\sigma_i^2$ with $\sigma_i=\alpha_{p(i)}/\sqrt{\Delta t_i}$, where $\Delta t_i=n_i\delta t$ is the retained exposure of bin $i$ ($n_i$ one-second members, $\delta t=1$ s) and $\alpha_p$ is the white-frequency-noise coefficient of observing period $p$ from overlapping Allan deviations at 256–4,096 s: 9.70 and $5.70\times10^{-16}$ for September and October 2025, and $4.30$–$5.76\times10^{-16}$ for the six 2026 periods. Errors are the larger of the residual-scaled least-squares and UTC-day-deletion jackknife errors, each deletion refitting all coefficients. The contours in Fig. 3b show the scaled least-squares covariance at radii one and two.

### Spectra and constituent separation

For Fig. 3c, at each trial frequency we fit a freely phased sinusoid and the 54 segment constants to the auxiliary means with equal weights,

$$
y_i=c_{s(i)}+a_f\cos[2\pi f(t_i-t_0)]+b_f\sin[2\pi f(t_i-t_0)]+\epsilon_i,
$$

and plot the peak amplitude $A_y(f)=\sqrt{a_f^2+b_f^2}$; for the residual curve, the fixed unit-amplitude physical prediction is subtracted first. The equivalent height is $A_{h,\mathrm{cm}}=100c^2A_y/g_0$ with $g_0=9.80665\ \mathrm{m/s^2}$. The span $T_{\rm span}=353.3889$ d sets the nominal Rayleigh scale $1/T_{\rm span}=0.03275$ μHz. The scan spacing is $1/(12T_{\rm span})=0.002729$ μHz, with the astronomical frequencies added, and the peaks are local maxima within one Rayleigh scale of each prescribed frequency.

For Extended Data Figs. 4–6 and Supplementary Fig. 2, a nuisance matrix $N$ (segment constants, and free N₂ and K₂ pairs where stated) is projected out of the data and of each trial cosine–sine pair $X_f$ with $R_N=I-QQ^{\mathsf T}$, where $Q$ is an orthonormal basis of $N$. The fitted coefficients $\hat{\boldsymbol\beta}_f=(R_NX_f)^+R_Ny$, with $y$ in units of $10^{-18}$, give the equivalent-height peak amplitude $A_{h,\mathrm{cm}}(f)=(c^2/g_0)\,10^{-16}\,\|\hat{\boldsymbol\beta}_f\|$, as in Fig. 3c. At a frequency coinciding with a controlled constituent, the trial pair lies in the nuisance space and its amplitude is undefined; these entries are not plotted. Phases refer to 6 September 2025, 16:05 UTC. The M₂ and S₂ waveforms come from a simultaneous four-coefficient fit with no amplitude or phase constraint between them; without N₂/K₂ control their amplitudes are 4.63 and $1.82\times10^{-18}$. Conditional scans add the other principal pair to $N$ and scan within ±0.16 μHz of the target. Compensation tests subtract a scaled donor waveform and re-estimate the target with the same nuisance terms, and canonical correlations are the singular values of $Q_M^{\mathsf T}Q_S$ for the residualized pairs (Supplementary Methods SM7).

### Signal-to-noise ratios

We define $\rho_i=|\hat A_i|/u(\hat A_i)$. For the white-noise case of equation (1), $H=(X^{\mathsf T}WX)^{-1}X^{\mathsf T}W$ maps the observations to the fitted coefficients for design matrix $X$ and weights $W$. For white frequency noise with $\alpha=5.4\times10^{-16}\sqrt{\mathrm{s}}$, the bin variance is $\alpha^2/\Delta t_k$, giving

$$
u_{i,\mathrm{white}}^2=\alpha^2\sum_k\frac{H_{ik}^2}{\Delta t_k},
\qquad
\rho_{i,\mathrm{white}}=\frac{|\hat A_i|}{u_{i,\mathrm{white}}}.\tag{2}
$$

With the retained exposure $T=\sum_{k=1}^{N_{\rm b}}\Delta t_k$ of the $N_{\rm b}$ means, $s_{i,\mathrm{rms}}^2=\sum_k\Delta t_k\,s_i(t_k)^2/T$ for template $s_i$ per unit response and $\eta_i=\alpha/(s_{i,\mathrm{rms}}\sqrt{T}\,u_{i,\mathrm{white}})$,

$$
\rho_{i,\mathrm{white}}=
\frac{|\hat A_i|s_{i,\mathrm{rms}}}{\alpha}\,\eta_i\sqrt{T}.\tag{3}
$$

The sampling window, offsets, template coupling and weights enter $\eta_i$, and equation (3) gives the $a_i=1$, $b_i=1/2$ sensitivity at the measured amplitude (Supplementary Table 2). For M₂ and S₂ in Table 1, $\hat A=(\beta_c^2+\beta_s^2)^{1/2}$ from the equal-weight joint fit of M₂, S₂, N₂ and K₂ pairs with 54 segment offsets, and $u^2(\hat A)=JC_iJ^{\mathsf T}$ with $J=(\beta_c,\beta_s)/\hat A$; $C_\beta=H\Sigma H^{\mathsf T}$ with $\Sigma_{kk}=\alpha^2/\Delta t_k$ for the white-noise row, and the covariance of 43 UTC-day deletion fits for the measured row. The diurnal column uses the three-group fit. The loading column uses a fit of the complete solid-Earth and loading templates with two free coefficients, 54 segment offsets and equal weights, with UTC-day-deletion errors (Supplementary Table 2 and Supplementary Methods SM6).
