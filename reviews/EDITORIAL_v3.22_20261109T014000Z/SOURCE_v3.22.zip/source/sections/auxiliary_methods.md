### Filtered validation: data selection

Every segment is processed identically. The time axis is reconstructed from the first time stamp and the sample index. Samples more than 10 Hz (approximately $5\times10^{-14}$ in Yb/Sr) from the segment median are removed, the longest uninterrupted run is retained, and leading and trailing samples deviating from the median by more than 1% of the peak-to-peak range are trimmed. To remove smaller transient excursions, 300-s averages are compared with a running median over ±30 min, and averages deviating by more than six robust standard deviations are removed together with their neighbours. This step removes 0.4% of the samples, or 2.2 h (Extended Data Fig. 7d–f). The criterion uses no tidal model, and adding the model to the data leaves the selection unchanged; because the subsequent filter is linear, injection tests use the selected data. Screening variants are given in Supplementary Methods SM2.

### Filtered validation: tidal model

The solid Earth contribution at each clock is

$$
\delta W=\sum_m(1+k_{2m})V_{2m}+(1+k_3)V_3-g u_r,
$$

where $V_{2m}$ are the degree-2 tide-generating potentials of the Moon and Sun of order $m$, $V_3$ is the lunar degree-3 potential and $u_r$ is the radial displacement. Love numbers and displacements follow the IERS 2010 conventions ^16^ (Supplementary Methods SM1). The ocean-loading potential is computed by grid convolution,

$$
\delta W_{\rm ocean}(t)=\sum_{\rm ocean}\rho_w\zeta(\mathbf r',t)G_W(\psi)\,\mathrm dA,
\qquad
G_W(\psi)=\frac{ga}{M_E}\sum_n(1+k'_n-h'_n)P_n(\cos\psi),
$$

with the FES2022 ocean elevation $\zeta$ on a $1/30^\circ$ grid ^17,18^, $\rho_w=1,025\ \mathrm{kg\,m^{-3}}$, Earth's radius $a$ and mass $M_E$, and angular distance $\psi$. The Green's function ^19^ uses PREM load Love numbers ^27,28^. After removal of the ocean mean, eight constituents (M₂, S₂, N₂, K₂ and the diurnal K₁, O₁, P₁, Q₁) are synthesized with astronomical arguments and nodal corrections. They explain 99.84% of the model variance; the remainder, with an r.m.s. of $0.18\times10^{-18}$, is held at its predicted value. The radial displacement from the same convolution agrees with the FES2022 load-tide grid to within 2.2% in amplitude and 1.2° in phase for seven of the eight constituents; for S₂ the grid derives from a different ocean-model release, and substituting it changes the full-template response by 0.001 (Extended Data Fig. 8; Supplementary Methods SM1). Extending the ocean mask near Shanghai by 0.3° or 0.6° changes the lunar response by −0.05 or −0.08, respectively, about half of its statistical uncertainty of 0.14.

### Filtered validation: uncertainties

The 1-s observations and model are filtered identically with a 1,200-s triangular window stepped by 600 s and fitted by least squares as $y(t)=c_i+A s(t)$, with an offset $c_i$ for segment $i$. For band analyses, the eight-constituent model is divided into semidiurnal (M₂, S₂, N₂, K₂) and diurnal (K₁, O₁, P₁, Q₁) bands, or into lunar (M₂, N₂), near-12-h (S₂, K₂) and diurnal groups with separate amplitudes. The primary grouped fit contains no empirical daily terms. Separate fits of the solid-Earth and loading templates assess their coupling (Supplementary Methods SM4).

For the full template, the semidiurnal band and the lunar group, uncertainties are calibrated by residual resampling. The fitted residuals are shifted circularly within each continuous run of the filtered record, added to the model with $A=1$ and refitted; the standard deviation over 200 realizations gives the error, retaining the within-run residual structure. For the diurnal and near-12-h groups, fits with empirical daily terms and fitted daily amplitudes, we quote the larger of the scaled least-squares standard error^52^ and the day-by-day jackknife error; in the resampled data these differ from the calibrated uncertainty by factors of 0.8–1.3. Group-bootstrap intervals draw the 29 operating groups with replacement in 1,000 refits; the segment bootstrap draws the 54 segments. In the phase test, each band has in-phase and quadrature templates, the latter shifting every constituent by 90°, with segment-bootstrap uncertainties. Quoted uncertainties are one standard deviation (Supplementary Methods SM3).

The phase-folded summer display (Fig. 2b) subtracts the fitted offsets and non-lunar groups and averages in 30° M₂-phase bins; the M₂+N₂ model is folded with the same sampling, and the day-by-day jackknife error bars hold the fitted non-lunar terms fixed. The time-series display uses 3-h averages, with gaps longer than 6 h removed from the horizontal axis and marked.

The full-record and April spectra (Extended Data Fig. 7c and Extended Data Fig. 2c) show sinusoidal power, the squared amplitude divided by two, after projection of segment offsets and before and after subtraction of the fitted whole template. Their thresholds are 99% quantiles of the maximum over 5–40 μHz from 200 resampled residual series (full record) and over 15–50 μHz from 1,000 series (April, together with pointwise 99% levels). No April frequency exceeds the latter threshold after tidal correction.

### Daily terms, environment and prediction

In the filtered validation analysis, daily sensitivity fits add $a_1\cos\omega t+b_1\sin\omega t+a_2\cos2\omega t+b_2\sin2\omega t$, where $\omega=2\pi/(1\ \mathrm{day})$ and $t$ is local time, with common or campaign-specific coefficients. Alternatives use, in each campaign, a free-amplitude 24-h term with the phase of the 24-h harmonic of hourly ERA5 2-m air temperature at the two sites ^25^, or the air-temperature anomalies at both sites relative to a 24-h running mean as two regressors.

The response of the lunar estimate to a disturbance $B\cos(\omega t-\varphi)$ follows from the lunar row $h$ of the estimator $H$ (defined in the signal-to-noise calculation) for the specified fit. For a common phase, the maximum amplitude change is

$$
B\sqrt{(h\cdot\cos\omega t)^2+(h\cdot\sin\omega t)^2};
$$

for phases independent between campaigns, it is the sum of the corresponding campaign norms. The main-analysis bounds reported in Results use the three-group design, with the main sample times, lunar, near-12-h and diurnal templates, segment offsets and observing-period-noise weights defined in Methods. Figure 4 uses the corresponding operator for the equal-weight filtered validation fit. The following injection, environmental and held-out prediction checks use the filtered record.

Injection tests add either the full tidal model ($A=1$) or the model without its lunar group ($A=0$) to circularly shifted residuals of the full-template fit, under four daily-disturbance scenarios: none; campaign-specific 24-h terms with air-temperature phases and fitted amplitudes; common 24-h and 12-h terms with fitted amplitudes and phases; and the fitted summer 24-h and 12-h terms. With 300 realizations per scenario and injected amplitude, the lunar-amplitude biases lie between −0.03 and 0.00, and for $A=1$ the fitted amplitude exceeds three standard errors in every realization (Extended Data Table 1b).

Campaign information shares project the lunar template onto the complement of the near-12-h and diurnal templates and segment offsets, and sum the squared projection within each campaign. Held-out prediction fits the amplitude to all but one observation period and applies it to the excluded period, refitting only that period's offsets (Supplementary Methods SM4).

The round-trip beat of the fibre link, recorded in Shanghai near 10 MHz at 1-s resolution, is normalized by the optical carrier frequency and filtered like the clock ratio. It covers 474 h of the analysed data. Including it as an additional regressor, or excluding 300-s blocks in which it deviates by more than $5\times10^{-16}$, changes the lunar and whole-template responses by less than 0.005.

The Sr vacuum-chamber temperature, the mean of 20 PT100 sensors sampled every 20 s, is available from 28 June to 7 July 2026 and overlaps 98 h of the filtered summer record. The blackbody sensitivity is $6.26\times10^{-17}\ \mathrm{K^{-1}}$ at 294.3 K. Because both clocks correct blackbody shifts in real time, a regression of the ratio on the chamber-temperature shift tests residual correction errors and has an expected coefficient of zero; it gives $0.92\pm0.74$ (Supplementary Methods SM4).
### Use of large language models

Large language models were used to assist with code writing, manuscript drafting and editing. All scientific content, analyses and conclusions are those of the authors, who independently verified all numerical results and take full responsibility for the manuscript.
