**Table 1 | Model-estimated and measured signal-to-noise ratios.**

| Evaluation | Lunar M₂ | Solar S₂ | Diurnal group | Ocean loading |
|:--|--:|--:|--:|--:|
| $S/R$ (model estimated) | 7.17 | 2.78 | 1.55 | 1.17 |
| $S/R$ (measured) | 7.02 | 1.96 | 1.08 | 0.89 |

$S=|\hat A|$ is the measured amplitude or template-response magnitude and $R=u(\hat A)$ its standard error. The model-estimated row assumes white frequency noise and uses the common noise coefficient and the actual sampling; the measured row uses UTC-day-jackknife covariance. All entries use the auxiliary reduction: M₂ and S₂ from their joint sine–cosine fit, the diurnal group from the three-group fit and ocean loading from the two-template solid-Earth/loading fit (Methods).
