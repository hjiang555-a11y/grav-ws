# v3.20-P1：统一处理迁移工作稿，尚未完成

此目录含明确的 PRIMARY-PENDING / PRIMARY RECOMPUTATION REQUIRED 标记。既有 Primary 数值仅来自原文，未在本轮重算。不得当作正式稿、完整Primary复现或已完成数值迁移。主要推断和图表等待Primary原始计算包；v3.20暂定稿未修改。
