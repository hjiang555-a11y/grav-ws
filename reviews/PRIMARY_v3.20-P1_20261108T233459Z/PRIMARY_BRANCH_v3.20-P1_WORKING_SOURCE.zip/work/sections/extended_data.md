# Extended Data

![Extended Data Figure 1](figures/primary_response_methods.pdf){width=100%}

**Extended Data Fig. 1 | Primary grouped responses and full-record sinusoidal power.** **a,** Amplitude factors for the full model and the semidiurnal band, each fitted with one amplitude, and for the lunar (M₂, N₂), near-12-h (S₂, K₂) and diurnal groups fitted jointly. All fits include segment offsets and omit empirical daily terms. Error bars are one standard deviation, calibrated by residual resampling for the full model, semidiurnal band and lunar group; for the near-12-h and diurnal groups, the larger of the scaled least-squares and day-by-day jackknife uncertainties is used. The dashed line denotes the prediction, *A* = 1. **b,** Covariance contours at radii one and two for the lunar and near-12-h amplitudes, using the least-squares correlation scaled to the quoted marginal uncertainties; the cross denotes the model prediction. **c,** Sinusoidal power of the full record after projection of segment offsets, before and after subtracting the fitted full model. Power is the squared sinusoidal amplitude divided by two, on a linear axis in units of 10⁻³⁶. The dotted line is the 99% quantile of the maximum power over 5–40 μHz from 200 resampled residual series.

![Extended Data Figure 2](figures/ed3.pdf){width=100%}

**Extended Data Fig. 2 | Campaign-resolved tidal amplitudes.** **a,** Full-model and semidiurnal amplitude factors for each campaign and the combined observations, fitted with segment offsets. Combined-data estimates also include the lunar group and the solid Earth tide alone. **b,** Diurnal amplitude fitted jointly with the semidiurnal band in a two-band fit; the combined estimate is 0.36 ± 0.50. The arrow marks an uncertainty extending beyond the plotted range. Error bars represent one standard deviation, calibrated by residual resampling for the full model, semidiurnal band and lunar group; for the diurnal band and solid Earth tide alone they are the larger of the scaled least-squares and day-by-day jackknife uncertainties. Thin lines in the combined-data rows show 95% intervals from resampling operating groups, or segments for the lunar group.

![Extended Data Figure 3](figures/ed1.pdf){width=100%}

**Extended Data Fig. 3 | Tidal records in all campaigns.** Three-hour averages of the filtered frequency ratio after subtraction of fitted segment offsets (blue), with the tidal model (red). Measurement-time axes compress gaps longer than 6 h, marked by vertical lines; gaps longer than 5 days are labelled. The vertical range is ±15 × 10⁻¹⁸; triangles mark values outside this range.

**Extended Data Fig. 4 | Unified-reduction analysis pending.**

**[PRIMARY RECOMPUTATION REQUIRED: P03]** Primary amplitude spectra and freely phased joint M2/S2 coefficients must be computed on the same selected and triangular-filtered record. Peak frequencies, amplitudes and conditional-separation statements are not yet available.

**Extended Data Fig. 5 | Unified-reduction analysis pending.**

**[PRIMARY RECOMPUTATION REQUIRED: P04]** Primary compensation sweeps, canonical correlations and sampling-alias diagnostics must be computed from the same filtered design and nuisance projection.

**Extended Data Fig. 6 | Unified-reduction analysis pending.**

**[PRIMARY RECOMPUTATION REQUIRED: P04]** Primary compensation sweeps, canonical correlations and sampling-alias diagnostics must be computed from the same filtered design and nuisance projection.

![Extended Data Figure 7](figures/ed2.pdf){width=100%}

**Extended Data Fig. 7 | Folds by tidal phase and local time.** **a,** All observations folded at the astronomical M₂ phase after subtracting fitted segment offsets and all tidal constituents except M₂ from the full-model fit. Points are means in 30° bins with day-by-day jackknife uncertainties, with the removed terms held fixed; the curve is the M₂ model. **b,** Tidally corrected residuals folded by local time in 2-h bins for summer, May (light symbols), the other three campaigns, and summer observations overlapping the temperature record from 28 June to 7 July (open circles). Error bars are day-by-day jackknife uncertainties; bins covering fewer than three days are omitted. The dashed curve is the mean daily blackbody-radiation (BBR) shift computed from the Sr chamber temperature over the same interval, after removing a 24-h running mean and excluding the temperature transient on 30 June; the real-time correction removes this shift from the recorded frequency ratio.

\clearpage

**Extended Data Table 1 | Daily terms and campaign-specific tidal amplitudes.** Amplitude and local time of maximum of the 24-h term, and amplitude of the 12-h term, fitted jointly with the full tidal model within each campaign. Days are local calendar days with data. Daily amplitudes are expressed in 10⁻¹⁸. Their uncertainties are the larger of the scaled least-squares and day-by-day jackknife values; uncertainties in the time of maximum are jackknife estimates. Weak sinusoidal amplitudes are biased positive. The full-template amplitude *A*, fitted without daily terms, and its residual-calibrated uncertainty are those in Extended Data Fig. 2a. The last column gives the lunar amplitude fitted independently to each campaign with the primary estimator.

| Campaign | Days | 24-h amplitude | 24-h maximum, h | 12-h amplitude | *A* | *A*lunar |
|:--|--:|:--|:--|:--|:--|:--|
| Sep–Oct 2025 | 4 | 5.1 ± 2.7 | 20.7 ± 5.6 | 5.0 ± 9.7 | 1.28 ± 0.31 | 0.04 ± 0.74 |
| Jan 2026 | 4 | 2.1 ± 3.0 | 17.2 ± 3.9 | 4.1 ± 1.8 | 1.27 ± 0.30 | 1.36 ± 0.37 |
| Apr 2026 | 5 | 2.9 ± 2.2 | 1.9 ± 1.4 | 1.0 ± 3.9 | 0.91 ± 0.13 | 0.66 ± 0.42 |
| May 2026 | 4 | 5.2 ± 3.3 | 3.8 ± 2.4 | 3.1 ± 2.6 | 0.97 ± 0.18 | 0.28 ± 0.68 |
| Jun–Aug 2026 | 22 | 2.8 ± 1.3 | 15.8 ± 1.5 | 0.6 ± 0.7 | 0.67 ± 0.18 | 0.87 ± 0.18 |

**Extended Data Table 2 | Related tidal estimates.** These estimates share observations and are not combined. The last column specifies each uncertainty definition.

| Analysis | Data and model | Amplitude factor *A* | Uncertainty |
|:--|:--|:--|:--|
| Hou et al.^12^ | Summer; 16 segments; their tidal model and segment-wise correlation | 0.87(15) | Reported weighted statistical error |
| Primary reduction, lunar group | 54 segments; lunar group; segment offsets; astronomical ephemerides | 0.97 ± 0.14 | Calibrated by residual resampling |
| Primary reduction, full template | Same observations; full template; segment offsets | 0.90 ± 0.12 | Calibrated by residual resampling |

**Extended Data Table 3 | Injection tests of the primary estimator.** Lunar amplitudes fitted with segment offsets and no empirical daily terms to resampled residuals plus either the full tidal model ($A_{\mathrm{true}}$ = 1) or the model without the lunar group ($A_{\mathrm{true}}$ = 0). The four daily-disturbance scenarios are defined in Methods, with 300 realizations per row. Bias and standard deviation describe the fitted amplitude. The median standard error is that computed within each realization, before the final residual-based calibration. Coverage is the fraction of intervals, formed with these uncalibrated standard errors, containing the injected amplitude; with the calibrated uncertainty of 0.14 the one-standard-error coverage is 0.67–0.68 (Supplementary Methods SM3); the accompanying 95% binomial interval refers to one-standard-error coverage. The last column gives the fraction with *A* > 3σ.

| Disturbance | $A_{\mathrm{true}}$ | Bias | s.d. | Median error | 1σ coverage | 95% binomial interval | 1.96σ coverage | *A* > 3σ |
|:--|--:|--:|--:|--:|--:|:--|--:|--:|
| None | 0 | −0.026 | 0.134 | 0.135 | 0.70 | 0.645–0.751 | 0.94 | 0.003 |
| None | 1 | −0.003 | 0.135 | 0.137 | 0.71 | 0.659–0.764 | 0.94 | 1.000 |
| 24 h, air-temperature phase | 0 | −0.013 | 0.141 | 0.136 | 0.61 | 0.549–0.662 | 0.93 | 0.000 |
| 24 h, air-temperature phase | 1 | −0.007 | 0.145 | 0.138 | 0.64 | 0.579–0.691 | 0.94 | 1.000 |
| Common 24 h + 12 h | 0 | −0.013 | 0.148 | 0.140 | 0.63 | 0.573–0.685 | 0.90 | 0.000 |
| Common 24 h + 12 h | 1 | −0.024 | 0.148 | 0.139 | 0.60 | 0.546–0.659 | 0.92 | 1.000 |
| Summer 24 h + 12 h | 0 | −0.021 | 0.138 | 0.140 | 0.67 | 0.610–0.720 | 0.95 | 0.000 |
| Summer 24 h + 12 h | 1 | −0.016 | 0.150 | 0.137 | 0.59 | 0.529–0.643 | 0.92 | 1.000 |
