## Results

### A coastal–inland clock baseline

As shown in Fig. 1a, the Shanghai Sr clock and the Wuhan Yb clock lie on a 692-km coastal–inland baseline and are connected through Hefei by a 1,350-km phase-stabilized fibre link.^24^ The comparison instability is approximately $5.4\times10^{-16}/\sqrt{\tau/\mathrm{s}}$ at averaging time $\tau$ for the spliced summer record (ref. 12) and is dominated by the clocks. Changes in the frequency ratio follow the changing potential difference, and a fitted offset for each observing segment absorbs the static part.

On this baseline, ocean loading contributes appreciably. We compute the solid-Earth tide following the IERS conventions^16^ and the loading potential from FES2022,^17,18^ including water attraction, induced Earth potential and clock displacement.^19^ For the principal lunar semidiurnal tide, M₂, the differential solid-tide and loading amplitudes are $3.41\times10^{-18}$ and $1.42\times10^{-18}$ in fractional frequency, and their 20° phase difference gives a combined amplitude of $4.76\times10^{-18}$ (Fig. 1c).

The record comprises 544 h of retained data in five campaigns and 54 observing segments over 353 days (Fig. 1b). A single reduction is used throughout: the observations undergo transient screening and a 1,200-s triangular filter stepped by 600 s; the same filter is applied to the model. All response estimates, spectra and signal-to-noise calculations use this selected record and its segment offsets. **[PRIMARY RECOMPUTATION REQUIRED: P11]** Confirm the exact retained-member count, filtered-row count and time span from the Primary record; current 544 h and 353 d are source-reported rounded values.

### Tidal amplitude, phase and coverage

To separate the semidiurnal contributions, we group M₂ with the larger lunar elliptic semidiurnal tide, N₂, and the principal solar semidiurnal tide, S₂, with the lunisolar semidiurnal tide, K₂. Within each group, relative amplitudes and phases follow the physical model. With no empirical daily terms in the fit, the lunar and near-12-h group responses are $0.97\pm0.14$ and $0.90\pm0.29$ (Fig. 2 and Extended Data Fig. 1). The full-template response is $0.90\pm0.12$, where a response of one denotes agreement with the predicted change in frequency ratio. A free-phase lunar fit gives an amplitude of $0.98\pm0.11$ and a phase offset of $-6°\pm8°$ (segment-bootstrap uncertainties). **[PRIMARY RECOMPUTATION REQUIRED: P06]** Rebuild Fig. 3 from Primary response estimates, the appropriate Primary phase covariance and Primary amplitude spectra. The former figure is archived.

The lunar and solar semidiurnal periods are approximately 12.42 h and 12 h, and their changing relative phase allows the observations to distinguish them. The two-month summer campaign covers the full relative-phase cycle, whereas the shorter campaigns cover narrower intervals (Fig. 1d). The five campaign estimates are mutually consistent (Extended Data Fig. 2 and Extended Data Table 1). As shown in Fig. 2, the summer time series and its dependence on lunar phase, after removal of the fitted offsets and non-lunar groups, agree well with the predicted lunar variation. Gaps are compressed on the time axis; Extended Data Fig. 3 shows the records of all campaigns, and Supplementary Fig. 1 shows the April campaign in calendar time.

### Separate semidiurnal detections

**[PRIMARY RECOMPUTATION REQUIRED: P03]** Primary amplitude spectra and freely phased joint M2/S2 coefficients must be computed on the same selected and triangular-filtered record. Peak frequencies, amplitudes and conditional-separation statements are not yet available.

### Reliability of the separated signals

**[PRIMARY RECOMPUTATION REQUIRED: P04]** Primary compensation sweeps, canonical correlations and sampling-alias diagnostics must be computed from the same filtered design and nuisance projection.

The primary lunar estimate is also stable against daily disturbances (Fig. 4). A $10^{-18}$ fractional-frequency sinusoid at 24 h or 12 h with a phase fixed across the record changes the lunar response by at most 0.020, and with independent phases in each campaign the bounds are 0.032 and 0.12, respectively. Both clocks correct blackbody shifts in real time, and temperature regressions provide further checks (Methods and Extended Data Fig. 7). In addition, adding the fibre-link monitor as a regressor changes the lunar and full-template responses by less than 0.005, retaining the screened transients leaves the lunar result consistent, and the fits improve predictions for most withheld observation periods (Methods). Extending the ocean mask near Shanghai by 0.3° or 0.6° changes the lunar response by −0.05 or −0.08, respectively, about half of its statistical uncertainty.

### Ocean loading and diurnal response

The separate ocean-loading and diurnal responses are constrained less precisely. The loading coefficient is $0.89\pm0.55$ (Methods), and a joint diurnal–semidiurnal fit gives a diurnal response of $0.36\pm0.50$ (Extended Data Fig. 2b). Both are consistent with the prediction, and refined coastal loading models and longer continuous runs are expected to sharpen these comparisons.^15^

## Discussion

The different uncertainties of the measured components motivate a model of their signal-to-noise ratios. The precision of each tidal component is set by its signal strength, the noise and the phase coverage. Within short segments, a slowly varying tide is partly absorbed by the fitted offset. Continuous runs of at least two days with maintained phase lock cover successive diurnal cycles, a longer calendar span separates neighbouring frequencies, and gaps create sidelobes (Supplementary Fig. 2).

To relate component precision to observing conditions, we model the amplitude signal-to-noise ratio for a specified estimator as

$$
\rho_i(T)\simeq\rho_i(T_0)
\frac{\eta_i(T)}{\eta_i(T_0)}
\left(\frac{T}{T_0}\right)^{a_i-b_i}.\tag{1}
$$

Here $T$ is the retained exposure and $\rho_i=S/R$. The exponents $a_i$ and $b_i$ describe how the phase-aligned signal and the noise standard deviation accumulate, and $\eta_i$ accounts for the sampling window, weights and parameter coupling. For a coherent signal in white noise, $a_i=1$ and $b_i=1/2$, giving $\rho_i\propto\sqrt{T}$ at fixed $\eta_i$. Table 1 compares this white-noise expectation, evaluated on the actual sampling, with the measured ratios.

::: display
**Table 1 | Calculated and measured signal-to-noise ratios from the unified reduction.**

**[PRIMARY RECOMPUTATION REQUIRED: P05]** Recompute both rows of the signal-to-noise table with Primary estimators. Propagate white noise through the actual filter, including correlations from overlapping windows; empirical uncertainties must use the same fitted record.

| Evaluation | Lunar M₂ | Solar S₂ | Diurnal group | Ocean loading |
|:--|--:|--:|--:|--:|
| $S/R$ (white noise) | Pending | Pending | Pending | Pending |
| $S/R$ (measured) | Pending | Pending | Pending | Pending |
:::

**[PRIMARY RECOMPUTATION REQUIRED: P05]** Recompute both rows of the signal-to-noise table with Primary estimators. Propagate white noise through the actual filter, including correlations from overlapping windows; empirical uncertainties must use the same fitted record.

The 274-h summer record was also used in the absolute frequency-ratio measurement of Hou et al.;^12^ Extended Data Table 2 relates those estimates to the present analysis.

**[PRIMARY RECOMPUTATION REQUIRED: P12]** After Primary computations, determine whether the independent-component detection and model-versus-measured-precision conclusions remain supported. Any substantive conclusion change must be reported before finalizing.

Sustained network operation would extend phase coverage, and better clock stability would increase sensitivity for a given observing time. Together with additional sites and local environmental records, this would allow weaker potential changes to be identified after subtraction of the tidal background. These results extend demonstrated sub-centimetre-equivalent clock performance^29^ to time-varying geophysical signals, and represent a step toward clock networks for geodesy, ultralight-dark-matter searches^38^ and future clock-based gravitational-wave detectors.^62^

**Note added.** During the preparation of this manuscript, a related observation of tidal variations of the gravity potential in a European optical-clock network was reported;^20^ the present work is complementary in separating the lunar and solar semidiurnal contributions on a coastal–inland baseline.
