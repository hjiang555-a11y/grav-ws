## Supplementary Methods

### SM1. Physical model

We use $k_{20}=0.29525$, $k_{22}=0.29801$ and $k_3=0.093$. The IERS 2010 resonance formula, applied constituent by constituent for $k_{21}$, gives 0.2588 for K₁, 0.2873 for P₁ and 0.2975 for O₁. The radial displacement is computed with the IERS algorithm, including the frequency and latitude dependence of the Love number $h$ ^16^.

PREM load Love numbers are used through degree $n=696$ ^27^, from the gravity-toolkit distribution ^28^. Above this degree, $h'_n$ is joined smoothly to its Boussinesq limit of −6.22, and the series is summed with a Kummer transformation through $n=40,000$. The convolution uses full grid resolution within 3° of each station and sums blocks of $8\times8$ cells farther away, which changes the differential M₂ and K₁ loading by at most 0.05%.

The full loading potential exceeds the vertical-displacement contribution $-g\delta h$ by factors of approximately 1.4 for the semidiurnal and 1.8 for the diurnal constituents. The radial displacement from the same convolution agrees with the FES2022 load-tide grid to within 2.2% in amplitude and 1.2° in phase for seven of the eight constituents (Supplementary Fig. 4); the attraction and induced-potential terms use the same PREM load Love numbers. For S₂, whose load-tide grid derives from a different ocean-model release, the amplitude differs by about 18% and the phase at Wuhan by 54°. The S₂ loading is $0.62\times10^{-18}$ in Shanghai and $0.18\times10^{-18}$ in Wuhan, a differential amplitude of $0.63\times10^{-18}$ compared with $1.42\times10^{-18}$ for M₂. Substituting the S₂ loading inferred from the load-tide grid changes the full-template amplitude by 0.001 and the semidiurnal amplitude by 0.000, and leaves the lunar amplitude unchanged.

The Shanghai clock is 22 km from the nearest ocean cell. Filling land cells within 0.3° or 0.6° of the coastline in a $4^\circ\times5^\circ$ box centred on Shanghai with the nearest ocean values, strips approximately 33–66 km wide, increases the Shanghai M₂ loading potential expressed as $\delta W/g$ from 15.3 mm to 17.0 or 18.5 mm and decreases the lunar response by 0.05 or 0.08, respectively.

Setting the remainder of the eight-constituent model to zero or doubling it gives semidiurnal amplitudes of 0.95–0.96 and lunar amplitudes of 0.95–0.99.

### SM2. Selection and timing

Adding the tidal model with factors of −1, 1 or 3 leaves the removed samples unchanged; six robust standard deviations is the lowest tested threshold with this invariance up to three times the model. Block lengths of 60 or 300 s and thresholds from four to eight standard deviations give lunar amplitudes from 0.93 to 1.02. Retaining the excursions gives $0.96\pm0.14$, and the full-template and semidiurnal amplitudes change by less than 0.04. Before transient removal, the procedure reproduces the summer sample set of ref. ^12^; after removal, the campaign diurnal amplitudes are mutually consistent ($p=0.21$). Three of the nine identified excursions coincide with approximately equal and opposite link-monitor excursions.

Omitting endpoint trimming changes the lunar amplitude by −0.009 and the full-template amplitude by 0.008. Shifting the model by ±10 min changes $A$ by less than 0.02. Long-period tides are not fitted: the similar site latitudes make the predicted differential semiannual tide only about $2\times10^{-20}$. Durations refer to retained 1-s samples; the exposure of the filtered data at 600-s steps is slightly shorter.

### SM3. Uncertainty calibration and campaign consistency

For the lunar group, two independent sets of 200 realizations give standard deviations of 0.13 and 0.14, compared with 0.13 for the larger of the scaled least-squares and jackknife errors; we quote 0.14, with a resampling bias of +0.01. With the daily disturbances of Methods, which have r.m.s. values up to $1.9\times10^{-18}$, 5,000 realizations per scenario give standard deviations rounding to 0.14 (0.13–0.15 for the 300 realizations of Extended Data Table 3) and coverage of 0.67–0.68 for ±0.14 and 0.945–0.952 for ±1.96 × 0.14.

For the semidiurnal response, the group-bootstrap standard deviation of 0.08 is smaller than the calibrated value of 0.12, which is quoted. The segment bootstrap gives a lunar amplitude of $0.98\pm0.11$ and phase of $-6^\circ\pm8^\circ$. The correlation between the lunar and near-12-h group coefficients is −0.32. The full-template and semidiurnal responses are $0.90\pm0.12$ and $0.96\pm0.12$ (Extended Data Fig. 1).

Summer supplies 61% of the conditional information on the lunar response and gives $0.87\pm0.18$, compared with $1.05\pm0.31$ for the earlier campaigns together. The five lunar estimates are consistent ($\chi^2=4.1$, four degrees of freedom, $p=0.40$; Extended Data Table 1), as are the semidiurnal estimates ($\chi^2=3.2$, $p=0.52$; Extended Data Fig. 2). Resampling the operating groups gives a 95% lunar interval of [0.76, 1.18].

### SM4. Prediction, environmental and daily-term checks

The whole-template prediction reduces residual sums of squares in seven of eight held-out periods, by 4.9% when pooled; the lunar prediction improves six of eight periods, by 1.7% when pooled.

Over the 98-h overlap, the blackbody shift calculated from chamber temperature and filtered like the ratio has an r.m.s. of $2.8\times10^{-18}$. As a free regressor it gives $0.92\pm0.74$, or $0.72\pm0.74$ after excluding the chamber-temperature transient on 30 June (day-by-day jackknife errors), consistent with zero. Without real-time correction, the shift would contain a daily component of $2.0\times10^{-18}$ peaking at 12:13 local time, with a peak-to-peak daily range of $4\times10^{-18}$; the fitted 24-h ratio term in the same overlap is $(0.9\pm1.1)\times10^{-18}$ with maximum at 10:54 ± 5.0 h.

On the primary sampling after segment-mean removal, the predicted solid-tide and loading r.m.s. fractional frequencies are $3.02\times10^{-18}$ and $1.35\times10^{-18}$, and that of their sum is $4.09\times10^{-18}$. The response fitted to the solid-Earth tide alone is $1.19\pm0.20$, compared with 1.32 expected on this sampling for the combined model, and the separately fitted loading coefficient is $0.89\pm0.55$. This coefficient comes from a fit of the solid-Earth and loading templates with two free coefficients and segment offsets to the filtered primary data with equal weights; its uncertainty is the larger of the scaled least-squares and day-by-day jackknife errors.

The summer 24-h term has amplitude $(2.8\pm1.3)\times10^{-18}$ and peaks at 15:48 local time with a 1.5-h uncertainty; the 12-h term is $(0.6\pm0.7)\times10^{-18}$. With summer projection coefficients of 0.016 and 0.043 per $10^{-18}$, they shift the lunar response by at most 0.045 and 0.024 (Extended Data Table 1). For the full record, a common-phase 12-h perturbation of $10^{-18}$ changes the whole-template response by at most 0.087.

The lunar responses for alternative daily models (Fig. 4a) are: campaign-specific 24-h terms with air-temperature phases, $0.99\pm0.14$; free-phase campaign-specific 24-h terms, $0.97\pm0.15$; air-temperature anomalies at both sites, $0.98\pm0.13$; common 24-h and 12-h terms, $1.00\pm0.13$; campaign-specific free-phase 12-h terms, $0.82\pm0.17$, or $0.86\pm0.18$ with 24-h terms also included. Operating-group or period offsets in place of segment offsets give $0.97\pm0.11$ and $0.99\pm0.11$, and omitting each earlier campaign in turn gives 0.89–0.99.

### SM5. Primary spectra

At M₂, the harmonic power of the full record after projection of segment offsets decreases by 99% after subtraction of the fitted whole template (Extended Data Fig. 1c). In the three-group fit the diurnal coefficient is $0.35\pm0.51$; the two-band estimate is $0.36\pm0.50$ (Extended Data Fig. 2b).

**[PRIMARY RECOMPUTATION REQUIRED: P03]** Primary amplitude spectra and freely phased joint M2/S2 coefficients must be computed on the same selected and triangular-filtered record. Peak frequencies, amplitudes and conditional-separation statements are not yet available.

### SM6. Unified response and uncertainty details

**[PRIMARY RECOMPUTATION REQUIRED: P05]** Recompute both rows of the signal-to-noise table with Primary estimators. Propagate white noise through the actual filter, including correlations from overlapping windows; empirical uncertainties must use the same fitted record.

### SM7. Compensation, alias and correlation diagnostics

**[PRIMARY RECOMPUTATION REQUIRED: P04]** Primary compensation sweeps, canonical correlations and sampling-alias diagnostics must be computed from the same filtered design and nuisance projection.

### Supplementary Tables

**Supplementary Table 1 | Primary-only migration slot.**

**[PRIMARY RECOMPUTATION REQUIRED: P08]** Primary joint sine-cosine coefficient estimates and their uncertainties are pending computation.

**Supplementary Table 2 | Primary-only migration slot.**

**[PRIMARY RECOMPUTATION REQUIRED: P09]** Primary template-response SNR and sampling-efficiency estimates are pending computation.

**Supplementary Table 3 | Primary-only migration slot.**

**[PRIMARY RECOMPUTATION REQUIRED: P10]** This comparison table is removed from the single-method manuscript; the historical results are preserved in the sealed comparison archive. Final supplementary numbering is pending.

**Supplementary Table 4 | Unified data-reduction record.**

**[PRIMARY RECOMPUTATION REQUIRED: P11]** Confirm the exact retained-member count, filtered-row count and time span from the Primary record; current 544 h and 353 d are source-reported rounded values.

### Supplementary Figures

![Supplementary Figure 1](figures/ed4.pdf){width=100%}

**Supplementary Fig. 1 | April campaign in calendar time and frequency.** **a,** Frequency-ratio observations after the 1,200-s triangular filter and removal of fitted segment offsets, their 3-h averages, and predictions with and without ocean loading. The horizontal axis retains actual calendar dates and gaps (local time, UTC+8). **b,** Sinusoidal power before and after subtracting the model, expressed as amplitude squared divided by two on a linear vertical axis, in units of 10⁻³⁶. The dashed curve is the 99% level at each frequency; the dotted line is the 99% level for the maximum over 15–50 μHz, both obtained from 1,000 resampled residual series. In the April record, K₁, P₁ and O₁ merge into a diurnal band and M₂, S₂ and N₂ into a semidiurnal band. Power below 8 μHz exceeds the displayed range.

**Supplementary Fig. 2 | Sampling aliases and amplitude response to compensation.**

**[PRIMARY RECOMPUTATION REQUIRED: P04]** Primary compensation sweeps, canonical correlations and sampling-alias diagnostics must be computed from the same filtered design and nuisance projection.

![Supplementary Figure 3](figures/ed5.pdf){width=100%}

**Supplementary Fig. 3 | Transient excursions and sample exclusion.** **a,** Sixty-second averages around the excursion on 7 July 2026; red points mark averages consisting mainly of samples excluded by the criterion in Methods. **b,** Distribution of deviations of 300-s means from a running median over ±30 min, divided by the robust standard deviation within each segment. The dashed line marks the threshold of six. The count axis is logarithmic. **c,** Observation time excluded in each campaign (summer in red).

![Supplementary Figure 4](figures/SI_Figure_4_v36.pdf){width=100%}

**Supplementary Fig. 4 | Radial-displacement validation of the loading convolution.** **a,b,** Amplitude ratios (**a**) and phase differences (**b**) between radial displacements calculated with the loading Green's function and the FES2022 load-tide grid in the centre-of-mass frame, at Shanghai and Wuhan, for eight constituents. The S₂ difference is discussed in Supplementary Methods SM1.
