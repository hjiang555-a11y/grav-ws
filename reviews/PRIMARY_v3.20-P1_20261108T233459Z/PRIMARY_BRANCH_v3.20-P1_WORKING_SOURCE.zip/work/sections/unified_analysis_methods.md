### Spectra, constituent separation and signal-to-noise ratios

**[PRIMARY RECOMPUTATION REQUIRED: P07]** Primary spectrum/SNR implementation, exact support, weights, fit covariance and error propagation require the original Primary input package. No unverified implementation details are inserted here.

### Use of large language models

Large language models were used to assist with code writing, manuscript drafting and editing. All scientific content, analyses and conclusions are those of the authors, who independently verified all numerical results and take full responsibility for the manuscript.
