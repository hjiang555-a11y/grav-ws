from pathlib import Path
import re,json,difflib,shutil
R=Path('/data/AI_Research/projects/grav-ws/manuscript_48h/primary_branch_v320p1_20261108T233459Z');S=R/'work/sections';OLD=R.parent/'selected_v320_20261108T232133Z/sections'
P={
'P03':'Primary amplitude spectra and freely phased joint M2/S2 coefficients must be computed on the same selected and triangular-filtered record. Peak frequencies, amplitudes and conditional-separation statements are not yet available.',
'P04':'Primary compensation sweeps, canonical correlations and sampling-alias diagnostics must be computed from the same filtered design and nuisance projection.',
'P05':'Recompute both rows of the signal-to-noise table with Primary estimators. Propagate white noise through the actual filter, including correlations from overlapping windows; empirical uncertainties must use the same fitted record.',
'P06':'Rebuild Fig. 3 from Primary response estimates, the appropriate Primary phase covariance and Primary amplitude spectra. The former figure is archived.',
'P07':'Primary spectrum/SNR implementation, exact support, weights, fit covariance and error propagation require the original Primary input package. No unverified implementation details are inserted here.',
'P08':'Primary joint sine-cosine coefficient estimates and their uncertainties are pending computation.',
'P09':'Primary template-response SNR and sampling-efficiency estimates are pending computation.',
'P10':'This comparison table is removed from the single-method manuscript; the historical results are preserved in the sealed comparison archive. Final supplementary numbering is pending.',
'P11':'Confirm the exact retained-member count, filtered-row count and time span from the Primary record; current 544 h and 353 d are source-reported rounded values.',
'P12':'After Primary computations, determine whether the independent-component detection and model-versus-measured-precision conclusions remain supported. Any substantive conclusion change must be reported before finalizing.'}
def pending(k):return '**[PRIMARY RECOMPUTATION REQUIRED: '+k+']** '+P[k]
def save(name,s):(S/name).write_text(s)
s=(S/'opening.md').read_text();s=s.replace('Across 545.9 hours','Across 544 hours').replace('is 0.96 ± 0.11. The lunar semidiurnal group has a response of 1.00 ± 0.13.','is 0.90 ± 0.12. The lunar semidiurnal group has a response of 0.97 ± 0.14.')
s=s.replace('Spectral peaks near the M₂ and S₂ frequencies occur at 22.361 and 23.148 μHz, with equivalent-height amplitudes of 4.87 and 2.87 cm, respectively. Each contribution remains identifiable after controlling for the other.','[PRIMARY-PENDING P03: spectral peaks and conditional separation.]')
s=s.replace('We develop a signal-to-noise model that combines signal strength, clock noise and actual sampling, accounts for the lunar precision, and helps explain the weaker constraints on other components.','We develop a signal-to-noise model that combines signal strength, clock noise and actual sampling. [PRIMARY-PENDING P05: comparison with measured precision.]')
a='Over 545.9 hours of observations spanning 353 days, we measure the combined solid-Earth and ocean-loading tide and separately detect the principal lunar semidiurnal contribution (M₂) and the contribution at the principal solar semidiurnal frequency (S₂). The two contributions drift in relative phase and produce neighbouring spectral peaks, and each remains identifiable after the other is removed. Furthermore, we develop a signal-to-noise model that combines signal strength, noise and the actual sampling, and show that it accounts for most of the differences in precision between components.'
b='Over 544 hours of observations spanning 353 days, we measure the combined solid-Earth and ocean-loading tide and estimate the lunar and near-12-h group responses using one data reduction throughout. [PRIMARY-PENDING P03: independently phased constituent separation.] We develop a signal-to-noise model that combines signal strength, clock noise and actual sampling to relate component precision to observing conditions. [PRIMARY-PENDING P05: quantitative comparison.]'
assert a in s;s=s.replace(a,b);save('opening.md',s)
s=(S/'results_discussion.md').read_text()
a=re.search(r'The record comprises 544 h.*?(?=\n\n###)',s,re.S)[0]
b='The record comprises 544 h of retained data in five campaigns and 54 observing segments over 353 days (Fig. 1b). A single reduction is used throughout: the observations undergo transient screening and a 1,200-s triangular filter stepped by 600 s; the same filter is applied to the model. All response estimates, spectra and signal-to-noise calculations use this selected record and its segment offsets. '+pending('P11')
s=s.replace(a,b)
a=re.search(r'To separate the semidiurnal contributions,.*?(?=\n\n)',s,re.S)[0]
b='To separate the semidiurnal contributions, we group M₂ with the larger lunar elliptic semidiurnal tide, N₂, and the principal solar semidiurnal tide, S₂, with the lunisolar semidiurnal tide, K₂. Within each group, relative amplitudes and phases follow the physical model. With no empirical daily terms in the fit, the lunar and near-12-h group responses are $0.97\\pm0.14$ and $0.90\\pm0.29$ (Fig. 2 and Extended Data Fig. 1). The full-template response is $0.90\\pm0.12$, where a response of one denotes agreement with the predicted change in frequency ratio. A free-phase lunar fit gives an amplitude of $0.98\\pm0.11$ and a phase offset of $-6°\\pm8°$ (segment-bootstrap uncertainties). '+pending('P06')
s=s.replace(a,b)
a=re.search(r'As shown in Fig\. 3c,.*?(?=\n\n###)',s,re.S)[0];s=s.replace(a,pending('P03'))
a=re.search(r'Reciprocal subtraction tests.*?(?=\n\n)',s,re.S)[0];s=s.replace(a,pending('P04'))
s=s.replace('For the auxiliary lunar estimate, the same disturbances give at most 0.023 with a fixed phase, and 0.030 and 0.12 with independent campaign phases. ','')
a=re.search(r'::: display\n\*\*Table 1.*?\n:::',s,re.S)[0]
b='::: display\n**Table 1 | Calculated and measured signal-to-noise ratios from the unified reduction.**\n\n'+pending('P05')+'\n\n| Evaluation | Lunar M₂ | Solar S₂ | Diurnal group | Ocean loading |\n|:--|--:|--:|--:|--:|\n| $S/R$ (white noise) | Pending | Pending | Pending | Pending |\n| $S/R$ (measured) | Pending | Pending | Pending | Pending |\n:::'
s=s.replace(a,b)
a=re.search(r'As shown in Table 1,.*?(?=\n\n)',s,re.S)[0];s=s.replace(a,pending('P05'))
a=re.search(r'In summary, distant optical clocks.*?(?=\n\n)',s,re.S)[0];s=s.replace(a,pending('P12'))
# Link the already supported precision hierarchy to the model without claiming its pending numerical validation.
s=s.replace('## Discussion\n\nThe precision','## Discussion\n\nThe different uncertainties of the measured components motivate a model of their signal-to-noise ratios. The precision')
s=s.replace('### Amplitude, phase and coverage','### Tidal amplitude, phase and coverage')
s=s.replace('For a specified estimator, the amplitude signal-to-noise ratio scales locally as','To relate component precision to observing conditions, we model the amplitude signal-to-noise ratio for a specified estimator as')
save('results_discussion.md',s)
s=(S/'figures_tables.md').read_text();a=re.search(r'!\[Figure 3\].*?(?=\n\n!\[Figure 4)',s,re.S)[0];s=s.replace(a,'**Fig. 3 | Amplitude, phase and frequency of the tidal response.**\n\n'+pending('P06'));save('figures_tables.md',s)
s=(S/'extended_data.md').read_text()
for n,k in [(4,'P03'),(5,'P04'),(6,'P04')]:
 pattern=rf'!\[Extended Data Figure {n}\].*?(?=\n\n!\[Extended Data Figure {n+1}\])'
 a=re.search(pattern,s,re.S)[0];s=s.replace(a,f'**Extended Data Fig. {n} | Unified-reduction analysis pending.**\n\n'+pending(k))
s=s.replace(' Applying the segment-wise estimator of Hou et al.^12^ to the summer record with the tidal model used here gives 0.78 ± 0.19.','')
s='\n'.join(line for line in s.split('\n') if not line.startswith('| Alternative processing |'))
save('extended_data.md',s)
s=(S/'supplementary_methods.md').read_text()
a=re.search(r'### SM5\..*?(?=\n\n### SM6)',s,re.S)[0]
b='### SM5. Primary spectra\n\nAt M₂, the harmonic power of the full record after projection of segment offsets decreases by 99% after subtraction of the fitted whole template (Extended Data Fig. 1c). In the three-group fit the diurnal coefficient is $0.35\\pm0.51$; the two-band estimate is $0.36\\pm0.50$ (Extended Data Fig. 2b).\n\n'+pending('P03')
s=s.replace(a,b)
a=re.search(r'### SM6\..*?(?=\n\n### SM7)',s,re.S)[0];s=s.replace(a,'### SM6. Unified response and uncertainty details\n\n'+pending('P05'))
a=re.search(r'### SM7\..*?(?=\n\n### Supplementary Tables)',s,re.S)[0];s=s.replace(a,'### SM7. Compensation, alias and correlation diagnostics\n\n'+pending('P04'))
for n,k in [(1,'P08'),(2,'P09'),(3,'P10')]:
 a=re.search(rf'\*\*Supplementary Table {n} \|.*?(?=\n\n\*\*Supplementary Table {n+1} \|)',s,re.S)[0]
 s=s.replace(a,f'**Supplementary Table {n} | Primary-only migration slot.**\n\n'+pending(k))
a=re.search(r'\*\*Supplementary Table 4 \|.*?(?=\n\n### Supplementary Figures)',s,re.S)[0];s=s.replace(a,'**Supplementary Table 4 | Unified data-reduction record.**\n\n'+pending('P11'))
a=re.search(r'!\[Supplementary Figure 2\].*?(?=\n\n!\[Supplementary Figure 3)',s,re.S)[0];s=s.replace(a,'**Supplementary Fig. 2 | Sampling aliases and amplitude response to compensation.**\n\n'+pending('P04'))
s=s.replace('lunar and neighbouring semidiurnal coefficients','lunar and near-12-h group coefficients')
save('supplementary_methods.md',s)
# Keep the old file only in archive; avoid silently building the old Auxiliary method block.
old_analysis=(S/'auxiliary_methods.md').read_text()
(R/'archive/AUXILIARY_METHODS_v320.md').write_text(old_analysis)
llm=old_analysis.split('### Use of large language models')[1]
(S/'unified_analysis_methods.md').write_text('### Spectra, constituent separation and signal-to-noise ratios\n\n'+pending('P07')+'\n\n### Use of large language models'+llm)
(S/'auxiliary_methods.md').rename(R/'archive/WORK_COPY_auxiliary_methods.md')
# Only active Primary figure files remain under work/figures; all others stay archived.
used=set()
for p in S.glob('*.md'):
 used.update(re.findall(r'!\[[^\]]*\]\((figures/[^)]+)\)',p.read_text()))
for p in list((R/'work/figures').rglob('*')):
 if p.is_file() and p.relative_to(R/'work').as_posix() not in used:
  dest=R/'archive/unused_working_assets'/p.relative_to(R/'work/figures');dest.parent.mkdir(parents=True,exist_ok=True);p.rename(dest)
# A provisional work copy may not be compiled as a final manuscript while evidence is absent.
(R/'work/STATUS.md').write_text('# v3.20-P1：统一处理迁移工作稿，尚未完成\n\n此目录含明确的 PRIMARY-PENDING / PRIMARY RECOMPUTATION REQUIRED 标记。既有 Primary 数值仅来自原文，未在本轮重算。不得当作正式稿、完整Primary复现或已完成数值迁移。主要推断和图表等待Primary原始计算包；v3.20暂定稿未修改。\n')
changes=[]
for p in S.glob('*.md'):
 before=(OLD/p.name).read_text() if (OLD/p.name).exists() else ''
 if before!=p.read_text():changes.append(''.join(difflib.unified_diff(before.splitlines(True),p.read_text().splitlines(True),fromfile='v3.20/'+p.name,tofile='v3.20-P1-work/'+p.name)))
(R/'evidence/PRIMARY_MIGRATION_WORK.diff').write_text('\n'.join(changes))
(R/'evidence/PENDING_COMPUTATIONS.json').write_text(json.dumps(P,ensure_ascii=False,indent=2))
print('Work source staged with explicit pending fields. Active figure files:',len(used))
