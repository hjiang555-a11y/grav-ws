"""Check preservation and migration state. Never certify pending science as complete."""
from pathlib import Path
import hashlib,json,re,zipfile
R=Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((R/'evidence/V320_INPUT_HASHES.json').read_text())
for name,h in base.items():assert sha(Path(name))==h,name
assert sha(R/'baseline/NATURE_ARTICLE_v3.20.pdf')=='0a0ca15df1d0816a0e52f8c47b97523485f9f04d4f91c08cbf5bb4289f5ba08a'
archive=json.loads((R/'archive/ARCHIVE_MANIFEST.json').read_text())
for n,h in archive['archives'].items():assert sha(R/'archive'/n)==h
sections={p.name:p.read_text() for p in (R/'work/sections').glob('*.md')}
active='\n'.join(sections.values())
assert not (R/'work/sections/auxiliary_methods.md').exists()
# Explicit pending markers must remain until real numerical results are available.
pending=sorted(set(re.findall(r'(?:PRIMARY-PENDING |REQUIRED: )(P\d+)',active)))
assert pending
used=re.findall(r'!\[[^\]]*\]\((figures/[^)]+)\)',active)
for p in used:assert (R/'work'/p).exists(),p
for s in ['22.361','23.148','4.87','2.87','7.17','7.02','0.290','3,299','545.9']:
 assert s not in active,('Unmigrated auxiliary number',s)
result={'baseline_files_verified_unchanged':len(base),'baseline_pdf_unchanged':True,'sealed_archives_unchanged':True,'active_auxiliary_method_block_removed':True,'active_used_figures':sorted(set(used)),'pending_ids':pending,'new_scientific_calculations_run':False,'primary_only_final_manuscript_ready':False,'state':'INPUT_REQUIRED_PRIMARY_PIPELINE','reason':'No verified source package for the specified triangular-filter Primary reduction has been located.'}
(R/'evidence/MIGRATION_STATE_VALIDATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2));print(json.dumps(result,ensure_ascii=False,indent=2))
