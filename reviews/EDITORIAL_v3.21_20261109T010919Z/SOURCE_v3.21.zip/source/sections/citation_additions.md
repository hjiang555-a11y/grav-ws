# 引用扩充：稳定源编号29–52

以下源编号保持原1–28不变；最终首次引用顺序由主构建程序映射。所有24项已完成原论文摘要/正文与出版社元数据核对。

## Introduction：完整三段替换建议

Comparing two optical clocks measures the difference in gravitational potential at their locations, the basis of chronometric levelling.^1–4^ Improvements in optical lattice clocks^29–31^ and single-ion standards^32–34^ have reduced systematic uncertainties and improved comparison stability beyond established caesium-fountain references.^35,36^ Independent comparisons are essential for testing this performance and underpin proposals to redefine the SI second.^37,43^ Direct Yb/Sr measurements^39^ and multispecies optical-clock networks^38,40^ have advanced frequency-ratio metrology, while coordinated international campaigns have extended comparisons across laboratories and countries.^41,42^ Their reach is supported by stabilized fibre networks,^11,23,24^ intercontinental radio-astronomical comparisons,^49^ and terrestrial free-space transfer demonstrations designed to address the losses and distances relevant to future satellite links.^45–47^ Space-based optical-clock concepts^48^ and quantum-enhanced network proposals^44^ offer further possibilities, and distributed clock records have already been used to constrain dark-matter couplings following proposals to search for transient signatures.^50,51^ For geodesy, the observable remains the potential difference, complementing gravitational acceleration and displacement measured by gravimeters and satellite positioning. Static potential differences have been measured with laboratory and transportable clocks,^5–9^ down to the gradient across a millimetre-scale atomic sample,^10^ and remote comparisons have extended these measurements through fibre networks.^11,12^ Extending clock comparisons to time-varying potential would provide a means of observing the dynamics of the gravity field. Tides offer a predictable signal for this purpose, with spatially varying contributions from astronomical forcing, solid-Earth deformation and ocean loading.^13–15^

The difficulty is that some tidal constituents lie close to, or coincide with, solar-day harmonics also present in laboratory conditions. Such laboratory variations can include a 24-h cycle and its 12-h harmonic. The diurnal constituents K₁ and P₁ lie close to one cycle per solar day, while S₂ has exactly two cycles per solar day. During a short observing campaign, these signals can be difficult to distinguish from disturbances that repeat at the same local time. The principal lunar semidiurnal tide M₂ has a period of approximately 12.42 h; its corresponding daily maxima occur about 50 min later on successive solar days. Observations over a broad range of lunar–solar phases can therefore distinguish lunar variation from some solar-day disturbances. The strength of this distinction depends on the actual observation times, noise and stability of the disturbance phase.

Here we investigate the lunar tidal potential difference between Shanghai and Wuhan on a coastal–inland baseline. Ocean loading contributes to the predicted signal because the two stations respond differently to the redistribution of seawater. We analyse observations between September 2025 and August 2026, including the summer record used in an earlier absolute frequency-ratio measurement.^12^ We jointly estimate lunar semidiurnal, neighbouring semidiurnal and diurnal responses, with astronomical phases and relative constituent amplitudes fixed within each group. The lunar group is the primary target; the complete tidal waveform and other groups provide context and cross-checks. We quantify the estimator's response to solar-day disturbances, examine environmental and transmission records, and compare alternative processing of the shared observations.

## Methods：替换现有误差定义首句

Where indicated, uncertainty is the larger of the scaled least-squares standard error^52^ and the day-by-day jackknife error.

仅在现有scaled least-squares项后加Birge出处，不改变估计器或宣称其解决时序相关。其余重采样叙述保持。

## 新增参考文献

29. McGrew, W. F. et al. Atomic clock performance enabling geodesy below the centimetre level. *Nature* **564**, 87–90 (2018). <https://doi.org/10.1038/s41586-018-0738-2>
30. Aeppli, A., Kim, K., Warfield, W., Safronova, M. S. & Ye, J. Clock with $8\times10^{-19}$ systematic uncertainty. *Phys. Rev. Lett.* **133**, 023401 (2024). <https://doi.org/10.1103/PhysRevLett.133.023401>
31. Lu, X.-T. et al. NTSC SrII optical lattice clock with uncertainty of $2\times10^{-18}$. *Metrologia* **62**, 035007 (2025). <https://doi.org/10.1088/1681-7575/addc77>
32. Marshall, M. C. et al. High-stability single-ion clock with $5.5\times10^{-19}$ systematic uncertainty. *Phys. Rev. Lett.* **135**, 033201 (2025). <https://doi.org/10.1103/hb3c-dk28>
33. Arnold, K. J. et al. Lu$^+$ optical frequency references with accuracy verified at the 19th digit. *Nature* **658**, 60–64 (2026). <https://doi.org/10.1038/s41586-026-11072-8>
34. Zhang, B.-l. et al. Liquid-nitrogen-cooled $^{40}$Ca$^+$ ion optical clock with a systematic uncertainty of $4.4\times10^{-19}$. *Phys. Rev. Lett.* **136**, 053202 (2026). <https://doi.org/10.1103/vngc-c1xv>
35. Heavner, T. P. et al. First accuracy evaluation of NIST-F2. *Metrologia* **51**, 174–182 (2014). <https://doi.org/10.1088/0026-1394/51/3/174>
36. Weyers, S. et al. Advances in the accuracy, stability, and reliability of the PTB primary fountain clocks. *Metrologia* **55**, 789–805 (2018). <https://doi.org/10.1088/1681-7575/aae008>
37. Dimarcq, N. et al. Roadmap towards the redefinition of the second. *Metrologia* **61**, 012001 (2024). <https://doi.org/10.1088/1681-7575/ad17d2>
38. Boulder Atomic Clock Optical Network (BACON) Collaboration. Frequency ratio measurements at 18-digit accuracy using an optical clock network. *Nature* **591**, 564–569 (2021). <https://doi.org/10.1038/s41586-021-03253-4>
39. Nemitz, N. et al. Frequency ratio of Yb and Sr clocks with $5\times10^{-17}$ uncertainty at 150 seconds averaging time. *Nat. Photon.* **10**, 258–261 (2016). <https://doi.org/10.1038/nphoton.2016.20>
40. Aeppli, A. et al. Atomic clock frequency ratios with fractional uncertainty $\leq3.2\times10^{-18}$. *Phys. Rev. Lett.* **137**, 033201 (2026). <https://doi.org/10.1103/g865-9mk1>
41. Lindvall, T. et al. Coordinated international comparisons between optical clocks connected via fiber and satellite links. *Optica* **12**, 843–852 (2025). <https://doi.org/10.1364/optica.561754>
42. Pizzocaro, M. et al. International optical clock comparison using the European optical fiber network. *Phys. Rev. Research* **8**, 033250 (2026). <https://doi.org/10.1103/l4bh-ryxs>
43. Fortier, T. M., Luiten, A. N. & Margolis, H. S. Optical atomic clocks: defining the future of time and frequency metrology. *Optica* **13**, 143–163 (2026). <https://doi.org/10.1364/optica.575770>
44. Kómár, P. et al. A quantum network of clocks. *Nat. Phys.* **10**, 582–587 (2014). <https://doi.org/10.1038/nphys3000>
45. Shen, Q. et al. Experimental simulation of time and frequency transfer via an optical satellite–ground link at $10^{-18}$ instability. *Optica* **8**, 471–476 (2021). <https://doi.org/10.1364/optica.413114>
46. Shen, Q. et al. Free-space dissemination of time and frequency with $10^{-19}$ instability over 113 km. *Nature* **610**, 661–666 (2022). <https://doi.org/10.1038/s41586-022-05228-5>
47. Caldwell, E. D. et al. Quantum-limited optical time transfer for future geosynchronous links. *Nature* **618**, 721–726 (2023). <https://doi.org/10.1038/s41586-023-06032-5>
48. Derevianko, A. et al. Fundamental physics with a state-of-the-art optical clock in space. *Quantum Sci. Technol.* **7**, 044002 (2022). <https://doi.org/10.1088/2058-9565/ac7df9>
49. Pizzocaro, M. et al. Intercontinental comparison of optical atomic clocks through very long baseline interferometry. *Nat. Phys.* **17**, 223–227 (2021). <https://doi.org/10.1038/s41567-020-01038-6>
50. Derevianko, A. & Pospelov, M. Hunting for topological dark matter with atomic clocks. *Nat. Phys.* **10**, 933–936 (2014). <https://doi.org/10.1038/nphys3137>
51. Wcisło, P. et al. New bounds on dark matter coupling from a global network of optical atomic clocks. *Sci. Adv.* **4**, eaau4869 (2018). <https://doi.org/10.1126/sciadv.aau4869>
52. Birge, R. T. The calculation of errors by the method of least squares. *Phys. Rev.* **40**, 207–227 (1932). <https://doi.org/10.1103/PhysRev.40.207>
