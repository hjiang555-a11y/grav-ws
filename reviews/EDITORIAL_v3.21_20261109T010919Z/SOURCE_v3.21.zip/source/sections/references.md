## References

1. Ludlow, A. D., Boyd, M. M., Ye, J., Peik, E. & Schmidt, P. O. Optical atomic clocks. *Rev. Mod. Phys.* **87**, 637–701 (2015). <https://doi.org/10.1103/RevModPhys.87.637>
2. Vermeer, M. *Chronometric levelling*. Rep. Finn. Geod. Inst. **83:2** (1983). <https://hdl.handle.net/10138/353062>
3. Bjerhammar, A. On a relativistic geodesy. *Bull. Géod.* **59**, 207–220 (1985). <https://doi.org/10.1007/BF02520327>
4. Mehlstäubler, T. E., Grosche, G., Lisdat, C., Schmidt, P. O. & Denker, H. Atomic clocks for geodesy. *Rep. Prog. Phys.* **81**, 064401 (2018). <https://doi.org/10.1088/1361-6633/aab409>
5. Chou, C. W., Hume, D. B., Rosenband, T. & Wineland, D. J. Optical clocks and relativity. *Science* **329**, 1630–1633 (2010). <https://doi.org/10.1126/science.1192720>
6. Lisdat, C. et al. A clock network for geodesy and fundamental science. *Nat. Commun.* **7**, 12443 (2016). <https://doi.org/10.1038/ncomms12443>
7. Takano, T. et al. Geopotential measurements with synchronously linked optical lattice clocks. *Nat. Photon.* **10**, 662–666 (2016). <https://doi.org/10.1038/nphoton.2016.159>
8. Grotti, J. et al. Geodesy and metrology with a transportable optical clock. *Nat. Phys.* **14**, 437–441 (2018). <https://doi.org/10.1038/s41567-017-0042-3>
9. Takamoto, M. et al. Test of general relativity by a pair of transportable optical lattice clocks. *Nat. Photon.* **14**, 411–415 (2020). <https://doi.org/10.1038/s41566-020-0619-8>
10. Bothwell, T. et al. Resolving the gravitational redshift across a millimetre-scale atomic sample. *Nature* **602**, 420–424 (2022). <https://doi.org/10.1038/s41586-021-04349-7>
11. Riehle, F. Optical clock networks. *Nat. Photon.* **11**, 25–31 (2017). <https://doi.org/10.1038/nphoton.2016.235>
12. Hou, L. et al. Yb/Sr optical clock comparison at $2.2\times10^{-18}$ uncertainty over a 1350-km fiber link. Preprint at <https://arxiv.org/abs/2610.34250v1> (2026).
13. Voigt, C., Denker, H. & Timmen, L. Time-variable gravity potential components for optical clock comparisons and the definition of international time scales. *Metrologia* **53**, 1365–1383 (2016). <https://doi.org/10.1088/0026-1394/53/6/1365>
14. Denker, H. et al. Geodetic methods to determine the relativistic redshift at the level of $10^{-18}$ in the context of international timescales: a review and practical results. *J. Geod.* **92**, 487–516 (2018). <https://doi.org/10.1007/s00190-017-1075-1>
15. Schröder, S., Stellmer, S. & Kusche, J. Potential and scientific requirements of optical clock networks for validating satellite-derived time-variable gravity data. *Geophys. J. Int.* **226**, 764–779 (2021). <https://doi.org/10.1093/gji/ggab132>
16. Petit, G. & Luzum, B. (eds) *IERS Conventions (2010)*. IERS Technical Note **36** (2010). <https://iers-conventions.obspm.fr/content/tn36.pdf>
17. Lyard, F. H., Allain, D. J., Cancet, M., Carrère, L. & Picot, N. FES2014 global ocean tide atlas: design and performance. *Ocean Sci.* **17**, 615–649 (2021). <https://doi.org/10.5194/os-17-615-2021>
18. CNES. *FES2022 (Finite Element Solution) Tidal model (Version 2024)* [Data set] (2024). <https://doi.org/10.24400/527896/A01-2024.004>
19. Farrell, W. E. Deformation of the Earth by surface loads. *Rev. Geophys.* **10**, 761–797 (1972). <https://doi.org/10.1029/RG010i003p00761>
20. Stahl, K. et al. Optical clock network tracks tidal variations of the gravity potential. Preprint at <https://arxiv.org/abs/2610.39635v1> (2026).
21. Jia, Z.-P. et al. Improved systematic evaluation of a strontium optical clock with uncertainty below $1\times10^{-18}$. *Metrologia* **63**, 025002 (2026). <https://doi.org/10.1088/1681-7575/ae449e>
22. Zhu, Q. et al. Ytterbium lattice clock with systematic uncertainty of $1.3\times10^{-18}$ and instability at the $10^{-19}$ level. *Metrologia* **63**, 065002 (2026). <https://doi.org/10.1088/1681-7575/aeb809>
23. Schioppo, M. et al. Comparing ultrastable lasers at $7\times10^{-17}$ fractional frequency instability through a 2220 km optical fibre network. *Nat. Commun.* **13**, 212 (2022). <https://doi.org/10.1038/s41467-021-27884-3>
24. Chen, F.-X. et al. $10^{-21}$-Level optical frequency dissemination over 2067 km of noise-loaded field-deployed fiber network. *Light Sci. Appl.* **15**, 276 (2026). <https://doi.org/10.1038/s41377-026-02299-1>
25. Hersbach, H. et al. The ERA5 global reanalysis. *Q. J. R. Meteorol. Soc.* **146**, 1999–2049 (2020). <https://doi.org/10.1002/qj.3803>
26. Riley, W. J. *Handbook of Frequency Stability Analysis*. NIST Special Publication **1065** (2008). <https://doi.org/10.6028/NIST.SP.1065>
27. Han, D. & Wahr, J. The viscoelastic relaxation of a realistically stratified earth, and a further analysis of postglacial rebound. *Geophys. J. Int.* **120**, 287–311 (1995). <https://doi.org/10.1111/j.1365-246x.1995.tb01819.x>
28. Sutterley, T., Velicogna, I., Mohajerani, Y. & Lecomte, H. *gravity-toolkit*, version 1.2.8. Zenodo <https://doi.org/10.5281/zenodo.23107010> (2026).

29. McGrew, W. F. et al. Atomic clock performance enabling geodesy below the centimetre level. *Nature* **564**, 87–90 (2018). <https://doi.org/10.1038/s41586-018-0738-2>
30. Aeppli, A., Kim, K., Warfield, W., Safronova, M. S. & Ye, J. Clock with $8\times10^{-19}$ systematic uncertainty. *Phys. Rev. Lett.* **133**, 023401 (2024). <https://doi.org/10.1103/PhysRevLett.133.023401>
31. Lu, X.-T. et al. NTSC SrII optical lattice clock with uncertainty of $2\times10^{-18}$. *Metrologia* **62**, 035007 (2025). <https://doi.org/10.1088/1681-7575/addc77>
32. Marshall, M. C. et al. High-stability single-ion clock with $5.5\times10^{-19}$ systematic uncertainty. *Phys. Rev. Lett.* **135**, 033201 (2025). <https://doi.org/10.1103/hb3c-dk28>
33. Arnold, K. J. et al. Lu$^+$ optical frequency references with accuracy verified at the 19th digit. *Nature* **658**, 60–64 (2026). <https://doi.org/10.1038/s41586-026-11072-8>
34. Zhang, B.-l. et al. Liquid-nitrogen-cooled $^{40}$Ca$^+$ ion optical clock with a systematic uncertainty of $4.4\times10^{-19}$. *Phys. Rev. Lett.* **136**, 053202 (2026). <https://doi.org/10.1103/vngc-c1xv>
35. Heavner, T. P. et al. First accuracy evaluation of NIST-F2. *Metrologia* **51**, 174–182 (2014). <https://doi.org/10.1088/0026-1394/51/3/174>
36. Weyers, S. et al. Advances in the accuracy, stability, and reliability of the PTB primary fountain clocks. *Metrologia* **55**, 789–805 (2018). <https://doi.org/10.1088/1681-7575/aae008>
37. Dimarcq, N. et al. Roadmap towards the redefinition of the second. *Metrologia* **61**, 012001 (2024). <https://doi.org/10.1088/1681-7575/ad17d2>
38. Boulder Atomic Clock Optical Network (BACON) Collaboration. Frequency ratio measurements at 18-digit accuracy using an optical clock network. *Nature* **591**, 564–569 (2021). <https://doi.org/10.1038/s41586-021-03253-4>
39. Nemitz, N. et al. Frequency ratio of Yb and Sr clocks with $5\times10^{-17}$ uncertainty at 150 seconds averaging time. *Nat. Photon.* **10**, 258–261 (2016). <https://doi.org/10.1038/nphoton.2016.20>
40. Aeppli, A. et al. Atomic clock frequency ratios with fractional uncertainty $\leq3.2\times10^{-18}$. *Phys. Rev. Lett.* **137**, 033201 (2026). <https://doi.org/10.1103/g865-9mk1>
41. Lindvall, T. et al. Coordinated international comparisons between optical clocks connected via fiber and satellite links. *Optica* **12**, 843–852 (2025). <https://doi.org/10.1364/optica.561754>
42. Pizzocaro, M. et al. International optical clock comparison using the European optical fiber network. *Phys. Rev. Research* **8**, 033250 (2026). <https://doi.org/10.1103/l4bh-ryxs>
43. Fortier, T. M., Luiten, A. N. & Margolis, H. S. Optical atomic clocks: defining the future of time and frequency metrology. *Optica* **13**, 143–163 (2026). <https://doi.org/10.1364/optica.575770>
44. Kómár, P. et al. A quantum network of clocks. *Nat. Phys.* **10**, 582–587 (2014). <https://doi.org/10.1038/nphys3000>
45. Shen, Q. et al. Experimental simulation of time and frequency transfer via an optical satellite–ground link at $10^{-18}$ instability. *Optica* **8**, 471–476 (2021). <https://doi.org/10.1364/optica.413114>
46. Shen, Q. et al. Free-space dissemination of time and frequency with $10^{-19}$ instability over 113 km. *Nature* **610**, 661–666 (2022). <https://doi.org/10.1038/s41586-022-05228-5>
47. Caldwell, E. D. et al. Quantum-limited optical time transfer for future geosynchronous links. *Nature* **618**, 721–726 (2023). <https://doi.org/10.1038/s41586-023-06032-5>
48. Derevianko, A. et al. Fundamental physics with a state-of-the-art optical clock in space. *Quantum Sci. Technol.* **7**, 044002 (2022). <https://doi.org/10.1088/2058-9565/ac7df9>
49. Pizzocaro, M. et al. Intercontinental comparison of optical atomic clocks through very long baseline interferometry. *Nat. Phys.* **17**, 223–227 (2021). <https://doi.org/10.1038/s41567-020-01038-6>
50. Derevianko, A. & Pospelov, M. Hunting for topological dark matter with atomic clocks. *Nat. Phys.* **10**, 933–936 (2014). <https://doi.org/10.1038/nphys3137>
51. Wcisło, P. et al. New bounds on dark matter coupling from a global network of optical atomic clocks. *Sci. Adv.* **4**, eaau4869 (2018). <https://doi.org/10.1126/sciadv.aau4869>
52. Birge, R. T. The calculation of errors by the method of least squares. *Phys. Rev.* **40**, 207–227 (1932). <https://doi.org/10.1103/PhysRev.40.207>

53. Stray, B. et al. Quantum sensing for gravity cartography. *Nature* **602**, 590–594 (2022). <https://doi.org/10.1038/s41586-021-04315-3>
54. Tapley, B. D., Bettadpur, S., Ries, J. C., Thompson, P. F. & Watkins, M. M. GRACE measurements of mass variability in the Earth system. *Science* **305**, 503–505 (2004). <https://doi.org/10.1126/science.1099192>
55. Rodell, M. et al. Emerging trends in global freshwater availability. *Nature* **557**, 651–659 (2018). <https://doi.org/10.1038/s41586-018-0123-1>
56. Arbic, B. K. Atmospheric forcing of the oceanic semidiurnal tide. *Geophys. Res. Lett.* **32**, L02610 (2005). <https://doi.org/10.1029/2004GL021668>
57. Oelker, E. et al. Demonstration of $4.8\times10^{-17}$ stability at 1 s for two independent optical clocks. *Nat. Photon.* **13**, 714–719 (2019). <https://doi.org/10.1038/s41566-019-0493-4>

58. Zheng, X., Dolde, J., Lochab, V., Merriman, B. N., Li, H. & Kolkowitz, S. Differential clock comparisons with a multiplexed optical lattice clock. *Nature* **602**, 425–430 (2022). <https://doi.org/10.1038/s41586-021-04344-y>

59. Nichol, B. C. et al. An elementary quantum network of entangled optical atomic clocks. *Nature* **609**, 689–694 (2022). <https://doi.org/10.1038/s41586-022-05088-z>
60. Rymer, H. & Brown, G. Gravity changes as a precursor to volcanic eruption at Poás volcano, Costa Rica. *Nature* **342**, 902–905 (1989). <https://doi.org/10.1038/342902a0>
61. Lynett, P. et al. Diverse tsunamigenesis triggered by the Hunga Tonga-Hunga Ha’apai eruption. *Nature* **609**, 728–733 (2022). <https://doi.org/10.1038/s41586-022-05170-6>
62. Kolkowitz, S. et al. Gravitational wave detection with optical lattice atomic clocks. *Phys. Rev. D* **94**, 124043 (2016). <https://doi.org/10.1103/PhysRevD.94.124043>

63. Dimarcq, N. et al. Roadmap towards the redefinition of the second. *Metrologia* **61**, 012001 (2024). <https://doi.org/10.1088/1681-7575/ad17d2>
64. Wu, H., Müller, J. & Lämmerzahl, C. Clock networks for height system unification: a simulation study. *Geophys. J. Int.* **216**, 1594–1607 (2019). <https://doi.org/10.1093/gji/ggy508>
65. Gozzard, D. Clocks synchronized at the quantum limit. *Nature* **618**, 680–681 (2023). <https://doi.org/10.1038/d41586-023-01937-7>
