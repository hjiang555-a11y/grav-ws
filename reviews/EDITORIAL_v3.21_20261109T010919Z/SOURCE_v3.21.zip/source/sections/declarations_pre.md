## Data availability

The frequency-ratio records, the segment table with the retained samples and the tidal-model time series supporting the findings of this study are available from the authors upon reasonable request.

## Code availability

The analysis code for the primary and auxiliary reductions is available from the authors upon reasonable request.

## Funding

This work is supported by the National Natural Science Foundation of China (grant nos. T2125010, 92476001 and 12374467); the Quantum Science and Technology-National Science and Technology Major Project (grant nos. 2021ZD0300105, 2021ZD0300106, 2021ZD0300902, 2021ZD0300903 and 2021ZD0300904); the Strategic Priority Research Program of the Chinese Academy of Sciences (grant nos. XDA0520101, XDA0520102, XDA0520103 and XDB35000000); the Hefei National Facility for Quantum Precision Measurement (https://cstr.cn/31140.02.HQPM); the Independent Deployment Project of HFNL (grant nos. ZB2025010400 and ZB2025010100); the Anhui Initiative in Quantum Information Technologies (grant nos. AHY010100 and AHY040200); the Shanghai Municipal Science and Technology Major Project (grant no. 2019SHZDZX01); the Scientific Research Innovation Capability Support Project for Young Faculty (grant no. ZYGXQNJSKYCXNLZCXM-I26); the National Science and Technology Major Project (grant no. 2025ZD0300702); and the New Cornerstone Science Foundation.
