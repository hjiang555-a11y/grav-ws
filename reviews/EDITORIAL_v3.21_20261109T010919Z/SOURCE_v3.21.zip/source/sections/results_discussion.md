## Results

### A coastal–inland clock baseline

As shown in Fig. 1a, the Shanghai Sr clock and the Wuhan Yb clock lie on a 692-km coastal–inland baseline and are connected through Hefei by a 1,350-km phase-stabilized fibre link.^24^ The comparison instability is approximately $5.4\times10^{-16}/\sqrt{\tau/\mathrm{s}}$ at averaging time $\tau$ for the spliced summer record (ref. 12) and is dominated by the clocks. Changes in the frequency ratio follow the changing potential difference, and a fitted offset for each observing segment absorbs the static part.

On this baseline, ocean loading contributes appreciably. We compute the solid-Earth tide following the IERS conventions^16^ and the loading potential from FES2022,^17,18^ including water attraction, induced Earth potential and clock displacement.^19^ For the principal lunar semidiurnal tide, M₂, the differential solid-tide and loading amplitudes are $3.41\times10^{-18}$ and $1.42\times10^{-18}$ in fractional frequency, and their 20° phase difference gives a combined amplitude of $4.76\times10^{-18}$ (Fig. 1c).

The record comprises 544 h of retained data in five campaigns and 54 observing segments over 353 days (Fig. 1b). We analyse it in two reductions, both with segment offsets. The primary reduction uses the data after transient screening and applies a 1,200-s triangular filter at 600-s steps to observations and model alike. The auxiliary reduction consists of 3,299 non-overlapping 600-s means from the same 54 segments, with 545.9 h of retained samples, and is used without the triangular filter. The reductions share observations but differ in selection, weights and template realizations (Methods). The auxiliary reduction provides the summary responses, spectra and signal-to-noise ratios, and the primary reduction provides the time-domain displays (Fig. 2) and robustness tests (Supplementary Methods SM6).

### Amplitude, phase and coverage

The auxiliary full-template response is $0.96\pm0.11$, where a response of one denotes agreement with the predicted change in frequency ratio (Fig. 3a). To separate the semidiurnal contributions, we group M₂ with the larger lunar elliptic semidiurnal tide, N₂, and the principal solar semidiurnal tide, S₂, with the lunisolar semidiurnal tide, K₂. Within each group, relative amplitudes and phases follow the physical model. The auxiliary lunar-group response is $1.00\pm0.13$ (Fig. 3a). The primary reduction, with no empirical daily terms in the fit, gives lunar-group and near-12-h-group responses of $0.97\pm0.14$ and $0.90\pm0.29$ (Fig. 2 and Extended Data Fig. 1). A free-phase lunar fit in the primary reduction gives an amplitude of $0.98\pm0.11$ and a phase offset of $-6°\pm8°$ (segment-bootstrap uncertainties), and the auxiliary phase fit likewise agrees with the predicted timing (Fig. 3b).

The lunar and solar semidiurnal periods are approximately 12.42 h and 12 h, and their changing relative phase allows the observations to distinguish them. The two-month summer campaign covers the full relative-phase cycle, whereas the shorter campaigns cover narrower intervals (Fig. 1d). The five campaign estimates are mutually consistent (Extended Data Fig. 2 and Extended Data Table 1). As shown in Fig. 2, the summer time series and its dependence on lunar phase, after removal of the fitted offsets and non-lunar groups, agree well with the predicted lunar variation. Gaps are compressed on the time axis; Extended Data Fig. 3 shows the records of all campaigns, and Supplementary Fig. 1 shows the April campaign in calendar time.

The 274-h summer record was also used in the absolute frequency-ratio measurement of Hou et al.;^12^ Extended Data Table 2 relates those estimates to the present analysis.

### Separate semidiurnal detections

In the auxiliary reduction, the equivalent-height amplitude spectrum (Fig. 3c) has lunar and solar-frequency peaks of 4.87 and 2.87 cm at 22.361 and 23.148 μHz. Subtracting the fixed unit-amplitude physical prediction reduces the amplitudes at these frequencies to 0.71 and 1.02 cm. Each principal frequency retains its peak when the other is controlled by a freely phased sinusoid, with N₂ and K₂ also controlled (Extended Data Fig. 4). A joint fit gives M₂ and S₂ amplitudes of 4.13 and 1.76 cm ($4.50\times10^{-18}$ and $1.92\times10^{-18}$; Supplementary Table 1); these differ from the scan peaks because neighbouring frequencies are fitted simultaneously. The conditional spectra thus separate the M₂ and S₂-frequency contributions without imposing their astronomical phase relation. In the primary reduction, detection of the near-12-h contribution is quantified by the predicted-phase (S₂, K₂) group response of $0.90\pm0.29$ (Extended Data Fig. 1).

### Reliability of the separated signals

Reciprocal subtraction tests the coupling introduced by the sampling (Extended Data Fig. 5). Removing the jointly fitted lunar waveform changes the solar-frequency amplitude from 2.67 to 1.76 cm ($2.918$ to $1.921\times10^{-18}$), and removing the solar-frequency waveform changes the lunar amplitude from 4.45 to 4.13 cm ($4.857$ to $4.505\times10^{-18}$); both remain identifiable. The maximum canonical correlation between the projected sine–cosine pairs is 0.290 (Extended Data Fig. 6), and the strongest sampling sidelobes respond to lunar-waveform subtraction as predicted (Supplementary Fig. 2).

The primary lunar estimate is also stable against daily disturbances (Fig. 4). A $10^{-18}$ fractional-frequency sinusoid at 24 h or 12 h with a phase fixed across the record changes the lunar response by at most 0.020, and with independent phases in each campaign the bounds are 0.032 and 0.12, respectively. For the auxiliary lunar estimate, the same disturbances give at most 0.023 with a fixed phase, and 0.030 and 0.12 with independent campaign phases. Both clocks correct blackbody shifts in real time, and temperature regressions provide further checks (Methods and Extended Data Fig. 7). Adding the fibre-link monitor as a regressor changes the lunar and full-template responses by less than 0.005, retaining the screened transients leaves the lunar result consistent, and the fits improve predictions for most withheld observation periods (Methods). Extending the ocean mask near Shanghai by 0.3° or 0.6° changes the lunar response by −0.05 or −0.08, respectively, about half of its statistical uncertainty.

### Ocean loading and diurnal response

The separate ocean-loading and diurnal responses are constrained less precisely. The loading coefficient is $0.89\pm0.55$ (Methods), and a joint diurnal–semidiurnal fit gives a diurnal response of $0.36\pm0.50$ (Extended Data Fig. 2b). These primary-reduction responses differ from the auxiliary estimators used for the signal-to-noise comparison in Table 1 (Methods). Both are consistent with the prediction, and refined coastal loading models and longer continuous runs are expected to sharpen these comparisons.^15^

## Discussion

The differences in precision between tidal components reflect their signal strengths, the noise and the phase coverage. We develop a signal-to-noise model that combines these factors to account for component precision and guide future observations. Within short segments, a slowly varying tide is partly absorbed by the fitted offset. For a specified estimator, the amplitude signal-to-noise ratio scales locally as

$$
\rho_i(T)\simeq\rho_i(T_0)
\frac{\eta_i(T)}{\eta_i(T_0)}
\left(\frac{T}{T_0}\right)^{a_i-b_i}.\tag{1}
$$

Here $T$ is the retained exposure and $\rho_i=S/R$. The exponents $a_i$ and $b_i$ describe how the phase-aligned signal and the noise standard deviation accumulate, and $\eta_i$ accounts for the sampling window, weights and parameter coupling. For a coherent signal in white noise, $a_i=1$ and $b_i=1/2$, giving $\rho_i\propto\sqrt{T}$ at fixed $\eta_i$. Table 1 compares this white-noise expectation, evaluated on the actual sampling, with the measured ratios.

::: display
**Table 1 | Calculated and measured signal-to-noise ratios.**

| Evaluation | Lunar M₂ | Solar S₂ | Diurnal group | Ocean loading |
|:--|--:|--:|--:|--:|
| $S/R$ (white noise) | 7.17 | 2.78 | 1.55 | 1.17 |
| $S/R$ (measured) | 7.02 | 1.96 | 1.08 | 0.89 |

$S=|\hat A|$ is the measured amplitude or template-response magnitude and $R=u(\hat A)$ its standard error. The white-noise row uses the common noise coefficient and the actual sampling; the measured row uses UTC-day-jackknife covariance. All entries use the auxiliary reduction: M₂ and S₂ from their joint sine–cosine fit, the diurnal group from the three-group fit and ocean loading from the two-template solid-Earth/loading fit (Methods).
:::

As shown in Table 1, the lunar precision agrees well with the white-noise expectation, whereas the solar-frequency contribution has a larger empirical uncertainty. The diurnal group and the separate loading response have signal-to-noise ratios near unity, because short segments constrain diurnal cycles weakly after offset removal and the smaller loading signal overlaps the solid-Earth waveform. The signal-to-noise model thus accounts for most of the differences in precision between components.

Sustained network operation would extend phase coverage, and better clock stability would increase sensitivity for a given observing time. Continuous runs of at least two days with maintained phase lock cover successive diurnal cycles, a longer calendar span separates neighbouring frequencies, and gaps create sidelobes (Supplementary Fig. 2). Together with additional sites and local environmental records, improved coverage and stability would allow weaker potential changes to be identified after subtraction of the tidal background.

Distant optical clocks measured the tidal potential difference between Shanghai and Wuhan and separately detected the lunar semidiurnal and solar-frequency semidiurnal contributions, with equivalent-height spectral peaks of 4.87 and 2.87 cm. The signal-to-noise model, based on signal strength, noise and sampling, agrees broadly with the precision achieved. These results extend demonstrated sub-centimetre-equivalent clock performance^29^ to time-varying geophysical signals, and represent a step toward clock networks for geodesy, ultralight-dark-matter searches^38^ and future clock-based gravitational-wave detectors.^62^ They also help characterize the tidal background in optical-clock networks, with potential applications to the redefinition of the second^63^ and the unification of height systems at the centimetre level.^64^

**Note added.** During the preparation of this manuscript, a related observation of tidal variations of the gravity potential in a European optical-clock network was reported;^20^ the present work is complementary in separating the lunar and solar semidiurnal contributions on a coastal–inland baseline.
