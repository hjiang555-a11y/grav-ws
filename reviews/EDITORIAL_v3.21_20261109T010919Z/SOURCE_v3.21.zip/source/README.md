# v3.21 editorial source

This source rebuilds the editorial manuscript and layout, not the underlying scientific analysis.
Run from this directory with Python 3, pandoc, XeLaTeX, and the Liberation Serif/Sans,
Latin Modern Math and DejaVu Serif fonts installed:

    python scripts/build_formal.py --out formal_build_01

For the optional editable text-and-legends Word companion (requires python-docx):

    python scripts/export_editable.py

The combined PDF carries all figures. Only referenced figure PDFs and their available SVG
counterparts are packaged. Figure files are unchanged from v3.20. Generated standalone TeX
is also in compiled/, with figure paths made relative to this source directory.

The old author_contributions.md candidate is retained as source only. It is NOT part of
the default manuscript. Do not enable --include-author-contributions without author confirmation.
The corresponding-author marker is omitted under the author's existing decision.

Audit JSON and reviews record completed workstation checks. Baseline-hash comparisons
require the frozen v3.20 workspace and are not an independent scientific reproduction.
