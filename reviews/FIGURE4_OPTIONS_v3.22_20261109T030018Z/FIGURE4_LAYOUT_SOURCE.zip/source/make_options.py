"""Layout-only vector reflow of the frozen scientific plot; no fitting or data generation."""
from pathlib import Path
import pymupdf as f
import json,hashlib,textwrap
R=Path(__file__).resolve().parent
S=R.parent/'editorial_v322_20261109T014000Z/figures/figure4.pdf'
if (R/'inputs/figure4.pdf').exists():S=R/'inputs/figure4.pdf'
src=f.open(S);page=src[0]
# Original axis: 0 at177.56pt, .5 at217.46pt, 1 at257.37pt, 1.5 at297.27pt.
# Use a labelled .5–1.5 window containing all original intervals; no point digitization.
zero,unit=177.56874084472656,257.37493896484375
x0,x1=(zero+unit)/2,unit+(unit-zero)/2
labels=['Main result','Offsets per operating group','Offsets per observation period','24-h terms, phase of air temperature','Air-temperature regressors','Common 24-h and 12-h terms','24-h terms per campaign','12-h terms per campaign','24-h and 12-h terms per campaign','Summer only','Without Sep–Oct 2025','Without Jan 2026','Without Apr 2026','Without May 2026','Without Jun–Aug 2026','Without trimming of segment ends','Without removal of excursions']
short=['Main result','Operating-group offsets','Observation-period offsets','24 h: air-temperature phase','Air-temperature regressors','Common 24 h + 12 h','24 h per campaign','12 h per campaign','24 h + 12 h per campaign','Summer only','Omit Sep–Oct 2025','Omit Jan 2026','Omit Apr 2026','Omit May 2026','Omit Jun–Aug 2026','Keep segment ends','Keep excursions']
# Clip heights encompass original marks, including first-row secondary 95% interval.
centres=[18.92+11.5*i for i in range(17)]
BLUE=(.18,.43,.70);GREY=(.34,.34,.34);GREEN=(.08,.66,.51)
def text(p,s,x,y,size=7,font='helv',color=(.1,.1,.1)):
 p.insert_text((x,y),s.replace('–','-'),fontsize=size,fontname=font,color=color)
def line(p,a,b,color=(.2,.2,.2),width=.5,dashes=None):p.draw_line(a,b,color=color,width=width,dashes=dashes)
def rows(p,ids,lx,ax,aw,top,pitch,fs=7,compact=False):
 bottom=top+pitch*(9 if len(ids) in (8,9) else len(ids))
 # Continuous reference band/line through row gaps.
 p.draw_rect(f.Rect(ax+aw*(243.97235107421875-x0)/(x1-x0),top-5,ax+aw*(266.3465576171875-x0)/(x1-x0),bottom-5),fill=(.9281568629,.9711372566,.9582745099),color=None)
 line(p,(ax+aw*.5,top-5),(ax+aw*.5,bottom-5),color=(.2,.2,.2),dashes='[2 2]')
 scale=aw/(x1-x0);half=5.6
 for j,i in enumerate(ids):
  cy=top+pitch*j+pitch/2
  clip=f.Rect(x0,centres[i]-half,x1,centres[i]+half)
  dh=clip.height*scale
  # Uniform transform preserves every mark/interval exactly, without stretching circles.
  p.show_pdf_page(f.Rect(ax,cy-dh/2,ax+aw,cy+dh/2),src,0,clip=clip,keep_proportion=True)
  s=short[i] if compact else labels[i]
  maxwidth=ax-lx-7
  # Fit complete label; wrap only at spaces.
  words=s.split();ls=[];curr=''
  for w in words:
   trial=(curr+' '+w).strip()
   if f.get_text_length(trial,fontname='helv',fontsize=fs)>maxwidth and curr:ls.append(curr);curr=w
   else:curr=trial
  ls.append(curr)
  for k,v in enumerate(ls):text(p,v,lx,cy+(k-(len(ls)-1)/2)*fs*1.05+fs*.32,fs)
 yy=bottom+1
 line(p,(ax,yy),(ax+aw,yy))
 for q in [0,.5,1]:
  xx=ax+aw*q;line(p,(xx,yy),(xx,yy+3));text(p,f'{.5+q:.1f}',xx-5,yy+11,fs)
 text(p,'Lunar amplitude factor A',ax+aw/2-40,yy+23,fs)
 return bottom

def bars(p,x,y,w,h,legend_y=None,fs=7):
 # Keep source bars as vectors; crop text, then replace labels without stretching fonts.
 oldtop,oldbottom=38.55118,187.93701
 span=oldbottom-oldtop
 clip=f.Rect(394.24252,46.2,508.36536,oldbottom)
 dy=(46.2-oldtop)/span*h
 p.show_pdf_page(f.Rect(x,y+dy,x+w,y+h),src,0,clip=clip,keep_proportion=False)
 line(p,(x,y),(x,y+h));line(p,(x,y+h),(x+w,y+h))
 gy=y+(45.66479-oldtop)/span*h
 line(p,(x,gy),(x+w,gy),color=GREEN,width=.5,dashes='[3 2]')
 for v in [0,.04,.08,.12,.14]:
  yy=y+(oldbottom-v/.02*20.29873-oldtop)/span*h
  text(p,f'{v:.2f}',x-20,yy+2,fs)
 for q,lab in [(.23262,'24 h'),(.76738,'12 h')]:text(p,lab,x+w*q-7,y+h+11,fs)
 text(p,'Change of lunar A per 10',x-9,y+h+25,fs)
 text(p,'-18',x-9+f.get_text_length('Change of lunar A per 10',fontsize=fs),y+h+22,fs*.7)
 text(p,'uncertainty',x+w-39,gy-4,fs,color=GREEN)
 ly=legend_y if legend_y is not None else y-25
 for j,(s,c) in enumerate([('Phase common to all campaigns',BLUE),('Independent phase per campaign',GREY)]):
  p.draw_rect(f.Rect(x-10,ly+j*10-5,x-2,ly+j*10),fill=c,color=None);text(p,s,x+2,ly+j*10,fs)

def save(name,w,h,setup):
 d=f.open();p=d.new_page(width=w,height=h);setup(p)
 d.save(R/(name+'.pdf'))
 p.get_pixmap(matrix=f.Matrix(3,3),alpha=False).save(R/(name+'.png'))
 # SVG retains vector figure content and labels.
 (R/(name+'.svg')).write_text(p.get_svg_image())
 d.close()

# A: larger labels in two equal columns; b below. Prioritizes readability.
def A(p):
 text(p,'a',7,13,10,'hebo');text(p,'Model and daily-term checks',25,13,8,'hebo')
 text(p,'Campaign and data-selection checks',270,13,8,'hebo')
 rows(p,list(range(9)),10,142,100,22,17,7.5)
 rows(p,list(range(9,17)),269,401,100,22,17,7.5)
 text(p,'b',100,222,10,'hebo');bars(p,215,239,150,65,legend_y=216,fs=7.5)
save('OPTION_A_two_columns_below',510,341,A)
# B: all panels side by side; abbreviated labels preserve their meaning.
def B(p):
 text(p,'a',5,12,10,'hebo');text(p,'Model / daily terms',20,12,7,'hebo');text(p,'Campaign / selection',190,12,7,'hebo')
 rows(p,list(range(9)),5,111,61,22,15,6.5,True)
 rows(p,list(range(9,17)),181,287,61,22,15,6.5,True)
 text(p,'b',361,12,10,'hebo');bars(p,391,67,110,84,legend_y=35,fs=6.5)
save('OPTION_B_three_columns',510,192,B)
# C: shortest textual change; retains one continuous forest, reduced whitespace.
def C(p):
 text(p,'a',5,12,10,'hebo');text(p,'Robustness checks',22,12,8,'hebo')
 rows(p,list(range(17)),10,171,65,20,10,7,True)
 text(p,'b',300,12,10,'hebo');bars(p,361,61,140,106,legend_y=30,fs=7)
save('OPTION_C_compact_single_column',510,225,C)
result={'source':str(S),'sha256':hashlib.sha256(S.read_bytes()).hexdigest(),'method':'Reflow original PDF vector marks; no raw data read, no fits, no manufactured observations','a_x_axis_original_ticks':[-.5,0,.5,1,1.5,2],'a_x_axis_preview_ticks':[.5,1,1.5],'source_a_rows':len(labels),'options':{},'shortened_labels':dict(zip(labels,short))}
for name in ['OPTION_A_two_columns_below','OPTION_B_three_columns','OPTION_C_compact_single_column']:
 p=f.open(R/(name+'.pdf'))[0]
 result['options'][name]={'width_mm':round(p.rect.width/72*25.4,1),'height_mm':round(p.rect.height/72*25.4,1)}
(R/'LAYOUT_PROVENANCE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps(result['options']))
