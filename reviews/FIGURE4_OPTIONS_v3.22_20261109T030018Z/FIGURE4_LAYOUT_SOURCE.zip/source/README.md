# Layout-only previews
Run `python make_options.py` in a Python environment with PyMuPDF. The supplied frozen PDF supplies all original vector marks. No raw observations or scientific fits are used. These are alternatives only; no manuscript replacement.
