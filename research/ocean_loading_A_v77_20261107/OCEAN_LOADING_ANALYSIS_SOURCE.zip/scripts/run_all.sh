#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
research_python="${RESEARCH_PYTHON:-/home/room115/pytorch_env/bin/python}"
"$research_python" -B scripts/build_geometry.py
"$research_python" -B scripts/analyse.py
"$research_python" -B scripts/check_analysis.py
"$research_python" -B scripts/simulate_coverage.py
"$research_python" -B scripts/conditional_checks.py
"$research_python" -B scripts/report.py
