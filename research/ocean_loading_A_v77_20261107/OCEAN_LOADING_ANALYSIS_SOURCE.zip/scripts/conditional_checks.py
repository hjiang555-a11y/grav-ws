"""Do not let a theory-conditioned coefficient inherit unsupported significance."""
from pathlib import Path
import itertools,json
import numpy as np
from core import fit,serial
from analyse import deletion_operators,replicate_statistics
O=Path(__file__).resolve().parents[1]
d=np.load(O/'results/design.npz');j=json.loads((O/'results/FIT_RESULTS.json').read_text())
SL=np.c_[d['E'][:,0],d['O'][:,0],d['three'][:,1:]]
labels=np.unique(d['period']);patterns=np.array(list(itertools.product([-1,1],repeat=len(labels))))
signs=patterns[:,np.searchsorted(labels,d['period'])].T
out={}
for name,S,y,oi in [('S54_solid_fixed_one',SL[:,[1,2,3]],d['y']-SL[:,0],0),('S54_common_source_all_bands',np.c_[d['solid_full'],d['ocean_full']],d['y_raw'],1)]:
    keep=[i for i in range(S.shape[1]) if i!=oi]
    null=fit(S[:,keep],y,d['sigma'],d['seg']);f=fit(S,y,d['sigma'],d['seg'])
    J=deletion_operators(S,y,d['sigma'],d['seg'],d['days'])
    Y=(y-null['residual'])[:,None]+null['residual'][:,None]*signs
    B,se,_,_=replicate_statistics(S,Y,d['sigma'],d['seg'],f['H'],J,f['C0'])
    observed=j['models'][name]['A'][oi]/j['models'][name]['reported_SE'][oi]
    count=int(np.sum(abs(B[oi]/se[oi])>=abs(observed)-1e-10))
    out[name]=dict(observed_T=observed,tail_count=count,patterns=len(patterns),two_sided_probability=count/len(patterns),scope='Restricted period residual wild bootstrap; theory constraints as stated, not independent source identification')
(O/'results/CONDITIONAL_HYPOTHESIS_CHECKS.json').write_text(json.dumps(out,indent=2,default=serial));print(json.dumps(out,indent=2,default=serial))
