"""Freeze all sampling-window diagnostics before fitting observations."""
from pathlib import Path
import json,hashlib,sys
import numpy as np
import pandas as pd
from core import geometry,serial
O=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(O/'vendor'))
import template

def main():
    for row in json.loads((O/'INPUT_MANIFEST.json').read_text()):
        assert hashlib.sha256((O/row['copy']).read_bytes()).hexdigest()==row['sha256']
    b=pd.read_csv(O/'inputs/bins.csv');t=pd.read_csv(O/'inputs/template.csv');c=pd.read_csv(O/'inputs/constituents.csv')
    aligned=b[['t_utc']].merge(t,on='t_utc',how='left',validate='many_to_one',sort=False)
    _,three,fixed,secs=template.bands_at_bins(aligned,c)
    phase,nodal=template._arguments(secs,template.CONSTITUENTS)
    c=c.set_index('constituent').loc[template.CONSTITUENTS]
    parts=[]
    for name in ['solid','loading']:
        C=c[name+'_real'].to_numpy()+1j*c[name+'_imag'].to_numpy()
        parts.append(nodal*np.real(C[None,:]*np.exp(-1j*phase)))
    E,Oload=parts;groups=[[0,2],[1,3],[4,5,6,7]]
    Eg=np.column_stack([E[:,k].sum(axis=1) for k in groups])
    Og=np.column_stack([Oload[:,k].sum(axis=1) for k in groups])
    saved=np.load(O/'inputs/design.npz');baseline=json.loads((O/'inputs/RESULTS.json').read_text())
    checks=dict(rows=len(b),members=int(b.n.sum()),segment_count=int(b.seg.nunique()),
                period_count=int(b.period.nunique()),group_closure_max_e18=float(np.max(abs(Eg+Og-three))),
                frozen_three_max_e18=float(np.max(abs(three-saved['three']))),
                fixed_remainder_max_e18=float(np.max(abs(fixed-saved['fixed']))),
                time_max_seconds=float(np.max(abs(secs-saved['seconds']))))
    assert checks['rows']==3299 and checks['members']==1965327
    assert checks['segment_count']==54 and checks['period_count']==8
    assert checks['group_closure_max_e18']<2e-14 and checks['frozen_three_max_e18']<2e-14
    assert checks['fixed_remainder_max_e18']<2e-14 and checks['time_max_seconds']==0
    sig=b.sigma.to_numpy();seg=b.seg.to_numpy();period=b.period.to_numpy();day=pd.to_datetime(b.t_utc,utc=True).dt.strftime('%Y-%m-%d').to_numpy()
    geo={}
    for name,labels,s in [('S54_Allan',seg,sig),('P8_Allan',period,sig),('G29_Allan',b.group.to_numpy(),sig),('S54_equal',seg,np.ones(len(b)))]:
        geo[name]=geometry(np.c_[Eg[:,0],Og[:,0]],three[:,1:],s,labels)
    for name,keep in [('early',~np.isin(period,['P6','P7','P8'])),('summer',np.isin(period,['P6','P7','P8']))]:
        geo[name]=geometry(np.c_[Eg[keep,0],Og[keep,0]],three[keep,1:],sig[keep],seg[keep])
    # Each source pair conditional on all other separately scaled source bands.
    six=np.column_stack([q for k in range(3) for q in [Eg[:,k],Og[:,k]]])
    for k,name in enumerate(['lunar','near12','diurnal']):
        ix=[2*k,2*k+1];others=[i for i in range(6) if i not in ix]
        geo['six_band_'+name]=geometry(six[:,ix],six[:,others],sig,seg)
    geo['common_all_bands']=geometry(aligned[['solid','loading']].to_numpy(),None,sig,seg)
    manifest=dict(status='PASS',scope='Design-only, before any new observation fit',checks=checks,
                  conditional_lunar_model='[solid M2+N2, loading M2+N2]; project [combined S2+K2, combined K1+O1+P1+Q1, 54 segment constants]',
                  geometries=geo)
    (O/'results/DESIGN_GEOMETRY.json').write_text(json.dumps(manifest,indent=2,default=serial))
    frame=b.copy()
    for k,name in enumerate(['lunar','near12','diurnal']):
        frame['solid_'+name]=Eg[:,k];frame['ocean_'+name]=Og[:,k];frame['total_'+name]=three[:,k]
    frame['fixed_remainder']=fixed;frame.to_csv(O/'results/analysis_rows.csv',index=False)
    np.savez(O/'results/design.npz',E=Eg,O=Og,three=three,fixed=fixed,y=b.y.to_numpy()-fixed,
             y_raw=b.y.to_numpy(),sigma=sig,seg=seg,group=b.group.to_numpy(),period=period.astype(str),
             days=day.astype(str),seconds=secs,solid_full=aligned.solid.to_numpy(),ocean_full=aligned.loading.to_numpy())
    print(json.dumps(dict(status='PASS',primary_geometry=geo['S54_Allan']),indent=2,default=serial))

if __name__=='__main__':main()
