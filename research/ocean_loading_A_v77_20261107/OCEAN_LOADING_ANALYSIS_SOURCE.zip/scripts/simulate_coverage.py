"""New source-coefficient coverage under explicit conditional noise laws.

Simulated quantities are never mixed with observed rows or filled into gaps.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from analyse import replicate_statistics
O=Path(__file__).resolve().parents[1]
d=np.load(O/'results/design.npz');op=np.load(O/'results/primary_operators.npz')
sig=d['sigma'];seg=d['seg'];per=d['period'];seconds=d['seconds']
scale=json.loads((O/'inputs/RESULTS.json').read_text())['primary']['scale']
N=len(sig);M=1000;seed=2026110705;rng=np.random.default_rng(seed)
def ou(tau,labels):
    z=np.empty((N,M))
    for lab in np.unique(labels):
        ix=np.flatnonzero(labels==lab);ix=ix[np.argsort(seconds[ix],kind='stable')]
        for k,i in enumerate(ix):
            if not k:z[i]=rng.standard_normal(M)
            else:
                a=np.exp(-max(0.,seconds[i]-seconds[ix[k-1]])/tau)
                z[i]=a*z[ix[k-1]]+np.sqrt(1-a*a)*rng.standard_normal(M)
    return z
rows=[]
for scenario in ['independent_Gaussian','half_OU6h_segment','half_OU24h_period','independent_Student_t5']:
    if scenario=='independent_Gaussian':u=rng.standard_normal((N,M))
    elif scenario=='independent_Student_t5':u=rng.standard_t(5,(N,M))/np.sqrt(5/3)
    else:
        z=ou(6*3600,seg) if '6h' in scenario else ou(24*3600,per)
        u=(rng.standard_normal((N,M))+z)/np.sqrt(2)
    noise=u*sig[:,None]*np.sqrt(scale)
    # Linear unbiased response errors do not depend on the arbitrary true beta.
    B,se,ls,jd=replicate_statistics(op['S'],noise,sig,seg,op['H'],op['J'],op['C0'])
    for k,param in enumerate(['solid_lunar','ocean_lunar','combined_near12','combined_diurnal']):
        cov=np.mean(abs(B[k])<=1.96*se[k])
        rows.append(dict(scenario=scenario,parameter=param,n_simulations=M,bias=B[k].mean(),empirical_SD=B[k].std(ddof=1),mean_scaled_LS=ls[k].mean(),mean_day_JK=jd[k].mean(),mean_reported_SE=se[k].mean(),coverage_95=cov,MC_SE=np.sqrt(cov*(1-cov)/M)))
    print('Completed conditional scenario: '+scenario,flush=True)
pd.DataFrame(rows).to_csv(O/'results/source_coefficient_coverage.csv',index=False)
(O/'verification/COVERAGE_PROTOCOL.json').write_text(json.dumps(dict(seed=seed,n_each=M,truth='Any fixed source coefficients; translation-invariant linear model, reported numbers are coefficient errors',actual_sampling=True,noise_scale='Frozen A_v77 S54 residual scale times original sigma; not tuned to new coefficient',working_interval='estimate +/- 1.96 max(scaled LS, UTC-day jackknife)',scope='Conditional simulation only; not a universal interval calibration or evidence about the actual noise law'),indent=2))
print(pd.DataFrame(rows).query("parameter == 'ocean_lunar'").to_string(index=False))
