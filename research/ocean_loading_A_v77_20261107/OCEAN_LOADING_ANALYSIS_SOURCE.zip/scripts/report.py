"""Data-linked figures and author report for the source-identifiability study."""
from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
from core import centred
O=Path(__file__).resolve().parents[1]
j=json.loads((O/'results/FIT_RESULTS.json').read_text());geo=json.loads((O/'results/DESIGN_GEOMETRY.json').read_text())['geometries']
checks=json.loads((O/'results/CONDITIONAL_HYPOTHESIS_CHECKS.json').read_text());d=np.load(O/'results/design.npz')
a=j['models']['S54_lunar_split'];g=geo['S54_Allan'];leave=pd.read_csv(O/'results/leave_period.csv');held=pd.read_csv(O/'results/held_out_prediction.csv');coverage=pd.read_csv(O/'results/source_coefficient_coverage.csv')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.labelsize':8,'axes.titlesize':8,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
blue='#17648c';orange='#c65c19';green='#3c8066'
def save(fig,name):
    for ext in ['pdf','svg','png']:fig.savefig(O/'figures'/f'{name}.{ext}',bbox_inches='tight',dpi=220)
    plt.close(fig)

fig,axes=plt.subplots(1,3,figsize=(8.4,2.8),layout='constrained')
c=pd.read_csv(O/'inputs/constituents.csv').set_index('constituent').loc['M2']
E=complex(c.solid_real,c.solid_imag);L=complex(c.loading_real,c.loading_imag);q=np.exp(-1j*np.angle(E));E*=q;L*=q
ax=axes[0]
for z,label,col in [(E,'Solid',blue),(L,'Loading',orange),(E+L,'Combined',green)]:
    ax.annotate('',xy=(z.real,z.imag),xytext=(0,0),arrowprops=dict(arrowstyle='->',color=col,lw=1.5))
    ax.text(z.real,z.imag+.12,label,color='black',ha='center')
ax.plot([E.real,(E+L).real],[E.imag,(E+L).imag],':',c=orange,lw=1)
ax.set(xlim=(-.3,5.4),ylim=(-1.6,4.1),xlabel=r'In-phase prediction ($10^{-18}$)',ylabel=r'Quadrature prediction ($10^{-18}$)',title='M$_2$ prediction; solid phase = 0')
ax.set_aspect('equal',adjustable='box')
ax.text(.04,.95,'19.8° source phase difference',transform=ax.transAxes,va='top',fontsize=7)

S=np.c_[d['E'][:,0],d['O'][:,0],d['three'][:,1:]]
X=centred(S,d['sigma'],d['seg'])/d['sigma'][:,None]
Q=np.linalg.qr(X[:,2:],mode='reduced')[0];P=X[:,:2]-Q@(Q.T@X[:,:2]);P*=d['sigma'][:,None]
ax=axes[1];ax.scatter(P[:,0],P[:,1],s=2,alpha=.17,c=blue,rasterized=True)
ax.set(xlabel=r'Projected solid template ($10^{-18}$)',ylabel=r'Projected load template ($10^{-18}$)',title='Actual sampling; other groups removed')
ax.text(.04,.95,f'Weighted correlation = {g["correlation"]:.3f}\nUnique load norm$^2$ = {100*g["ocean_norm_fraction_after_solid"]:.1f}%',transform=ax.transAxes,va='top',fontsize=7)

ax=axes[2]
for cov,col,label in [(np.array(a['cov_scaled_LS'])[:2,:2],blue,'Scaled-LS geometry'),(np.array(a['cov_day_JK'])[:2,:2],orange,'Delete-day geometry')]:
    eig,V=np.linalg.eigh(cov);order=np.argsort(eig)[::-1];eig=eig[order];V=V[:,order];angle=np.degrees(np.arctan2(V[1,0],V[0,0]))
    ax.add_patch(Ellipse(a['A'][:2],2*np.sqrt(eig[0]),2*np.sqrt(eig[1]),angle=angle,fill=False,ec=col,lw=1.1,label=label))
ax.plot(*a['A'][:2],'o',c='black',ms=3);ax.plot(1,1,'+',c=green,ms=7,mew=1.4,label='Unit source prediction')
ax.axhline(0,c='.65',lw=.6);ax.set(xlim=(-.05,2.65),ylim=(-2.6,3.6),xlabel=r'Solid lunar scale $A_E$',ylabel=r'Loading lunar scale $A_O$',title='Source coefficient trade-off')
ax.legend(fontsize=6,loc='upper right',frameon=False)
for i,ax in enumerate(axes):ax.text(-.20,1.08,chr(97+i),transform=ax.transAxes,fontweight='bold',fontsize=9)
save(fig,'identifiability_geometry')

fig,axes=plt.subplots(1,2,figsize=(8,3.6),layout='constrained')
spec=[('S54_lunar_split',1,'54 segments; lunar split'),('P8_lunar_split',1,'8 periods; lunar split'),('S54_equal_lunar_split',1,'54 segments; equal weights'),('S54_six_source_groups',1,'Six source/group coefficients'),('S54_common_source_all_bands',1,'Common source scale across bands'),('S54_solid_fixed_one',0,'Solid lunar scale fixed to 1')]
for n,(key,k,label) in enumerate(spec):
    m=j['models'][key];axes[0].errorbar(m['A'][k],n,xerr=m['reported_SE'][k],fmt='o',ms=4,color=blue if n<4 else orange,capsize=2)
axes[0].set_yticks(range(len(spec)),[s[2] for s in spec]);axes[0].invert_yaxis();axes[0].set(xlabel='Loading scale (one working standard error)',title='Assumptions change the question')
axes[1].axvspan(a['A'][1]-a['reported_SE'][1],a['A'][1]+a['reported_SE'][1],color='.92')
axes[1].errorbar(leave.A_O,np.arange(len(leave)),xerr=leave.u_O,fmt='o',color=blue,capsize=2,ms=3)
axes[1].set_yticks(range(len(leave)),['Omit '+p for p in leave.omitted]);axes[1].invert_yaxis();axes[1].set(xlabel='Loading scale (one working standard error)',title='Period deletion on the primary split')
for i,ax in enumerate(axes):
    ax.axvline(0,c='.3',lw=.7);ax.axvline(1,c=green,ls='--',lw=.8);ax.text(-.15,1.06,chr(97+i),transform=ax.transAxes,fontweight='bold',fontsize=9)
save(fig,'source_estimates_and_deletions')

for name in ['scaled_LS','day_JK','period_JK']:
    pd.DataFrame(a['cov_'+name],index=j['parameters'],columns=j['parameters']).to_csv(O/'results'/f'covariance_{name}.csv')
cost=(held.rss_split.sum()/held.rss_common_lunar_scale.sum()-1)*100
info=held.loc[held.held_out.isin(['P6','P7','P8']),'unique_ocean_information_share'].sum()
covO=coverage[coverage.parameter=='ocean_lunar']
table=pd.DataFrame([dict(模型=label,负荷尺度=f"{j['models'][key]['A'][k]:.2f} ± {j['models'][key]['reported_SE'][k]:.2f}",解释=('固体固定，条件估计' if 'fixed' in key else ('频带共用尺度，强约束' if 'common' in key else '固体与负荷分别估计'))) for key,k,label in spec])
note=r'''# 固体潮与海洋负荷：独立可辨识性核查

**结论：当前数据支持包含显著海洋负荷模型贡献的联合潮汐势测量，但不能新增“独立测量海洋负荷”的主张。** 可以把沿海—内陆几何作为有量化依据的地球物理动机，并给出下一代观测需要提高的分离灵敏度。本分析不改动 A_v77 两个半日潮组的主结果。

## 数据与问题

使用 A_v77 冻结的 3,299 个均值、54 段、8 期、43 个 UTC 日，成员总计 1,965,327 个名义秒（545.924 h），日历跨度 353.389 天。实验单位为同一个上海 Sr—武汉 Yb 钟对；这些是重复观测，不能当作数千次独立实验。保持 UTC、缺测、原掩膜、钟修正、Allan 权重和固体/负荷模板不变。

海水高程、海洋质量负荷的有效引力势、钟所测的联合差分势是不同对象。现行负荷核包含海水直接引力、形变引起的感应势和钟位移；本研究中的固体项包括外部天体直接势及地球响应的现稿实现。这里的尺度参数不是海面高度或单独的 Love 数。

先检验最受数据约束的月球半日组，模型为

$$y_i-r_{0i}=c_{s(i)}+A_E E_{L,i}+A_O O_{L,i}+A_S T_{S,i}+A_D T_{D,i}+\epsilon_i.$$

$E_L$、$O_L$ 分别是 M₂+N₂ 的固体潮与负荷模板；$T_S$ 为 S₂+K₂ 联合模板，$T_D$ 为辅助日潮联合模板。组内天文相位及相对振幅固定。没有经验日项、非负约束、平移接续或新增筛点。先保存设计诊断，后拟合观测。另计算六个源/频带系数以及跨全频带共用源尺度，明确后者增加了物理约束，不挑选最靠近 1 的结果。

## 设计几何先于幅度拟合

现稿 M₂ 预测的固体、负荷、合成振幅为 3.43、1.42、4.78×10⁻¹⁸；相位差约 19.8°。全采样负荷/合成 RMS 比值 33.1% 描述模型贡献，并非观测分离信息的比例。

在加权空间内同时投影掉段常数及其他潮汐组后，两个源模板相关系数为 **RHO**，列归一化条件数 **COND**，原物理列条件数 **PCOND**，Gram 矩阵条件数 **GCOND**。秩为 2，数值求解稳定；精度不足并非线性代数奇异。

负荷模板在进一步投影掉固体潮后，仅保留 **FRAC% 的平方范数**，方差膨胀因子 **VIF**。其独有变化为 **RMSVALUE×10⁻¹⁸ RMS**，约 **POT m²/s²**。不同天体的相位漂移能帮助分开 M₂ 邻域与 S₂ 邻域；同一个 M₂ 的固体潮和海洋负荷具有相同天文频率，区别主要在预测相位和各分潮的振幅结构，不能因日历跨度长便自动分开。

![设计与参数几何](figures/identifiability_geometry.pdf){width=100%}

图 1：a，预测相量；b，真实采样上的投影模板，所有 3,299 行均保留；c，分别由缩放最小二乘和删日协方差生成的单位半径几何椭圆。椭圆并非另行校准的联合置信域；图中十字是单位源预测。

## 观测约束与严格检验

独立自由估计给出 **$A_E=AE\pmUE$、$A_O=AO\pmUO$**。± 沿用主稿规则，为缩放最小二乘与 UTC 日删除刀切标准误中的较大者；不是模板系统误差预算。

| 误差来源 | 固体月球尺度 | 负荷月球尺度 |
|---|---:|---:|
| 缩放最小二乘 | ELS | OLS |
| 删日刀切（43 日） | EJK | OJK |
| 删期刀切（8 期） | EPJK | OPJK |

负荷的双侧工作 95% 区间为 **[LOW, HIGH]**；按删期标准误和 $t_7$ 的工作区间为 **[PLOW, PHIGH]**。前者在本轮四类条件噪声模拟下有覆盖检查，后者仍是少量时期的工作近似，均未包含未知模型系统误差。

检验 $A_O=0$ 时，固体月球响应、其他物理组和段常数保持自由。枚举 8 期的 256 种残差符号翻转，双侧结果 **P=PZERO**。这是依赖分期误差对称性等假设的 restricted residual wild bootstrap，并不是随机试验的精确检验。没有零假设排除证据。

逐期删除的负荷点估计范围 **[DMIN, DMAX]**；夏季只占该负荷独有投影平方范数的 **INFO%**（设计量）。额外源系数只在 8 个留出期中的 **IMPROVED** 个减少预测残差平方和，合并残差平方和反而增加 **COST%**。留出期只重新消去自身段常数，不重新估计物理幅度。这些检查使用共享记录，不是新增独立实验。

MODEL_TABLE

把固体潮固定为 1，得到 **0.96±0.44**，相应八期残差翻转 **P=PFIX**；其较小误差来自外加理论约束。跨所有频带共用两个源尺度得到 **0.61±0.51**，相应 **P=PCOMMON**；它假设频带响应共同，不能作为无约束的月球负荷测量。历史 0.89±0.55 属于另一套滤波/固体模型归算，本轮不与它平均，也不宣称复现了它。

![源尺度与删期检验](figures/source_estimates_and_deletions.pdf){width=100%}

图 2：所有误差棒为一个工作标准误。a，固定观测的不同源约束，橙色两行含额外跨频带或固体理论约束；b，主拆分模型逐期删除。零线和单位线分别代表无该负荷分量与理论负荷尺度。

## 误差和实现验收

冻结主稿的三个系数及各误差分量先复现至 2×10⁻⁹ 容差以内，再开始新拆分。独立全设计最小二乘与本轮加权消均值/SVD 的系数、协方差最大差低于 10⁻¹⁴；任意改变 54 个段常数、打乱行序、注入互不相同的已知源尺度均通过。九项验收全部通过，输入原件及副本 SHA256 均未变。

新源系数单独做四种条件模拟，每种 1,000 次，种子 2026110705：独立 Gaussian、半方差 Gaussian+段内 6 h OU、半方差 Gaussian+期内 24 h OU、独立标准化 Student-t₅。保留实际 UTC 和原 sigma，噪声总尺度取冻结主稿残差尺度。模拟数据没有进入观测表或填补缺测。负荷的 $\hat A_O\pm1.96u$ 覆盖率如下；Monte Carlo 标准误约 0.6–0.7 个百分点。这些条件情景不证明真实噪声满足其中任意一种。

COVERAGE_TABLE

## 能增加什么科学内容

可增加的定量内容是：联合潮汐势检验的基线对负荷具有显著模型灵敏度，但源分离依赖负荷模板中区别于固体潮的正交部分。**几何提供机会，当前数据还未提供独立负荷测量。** 可在 Methods/Extended Data 给一个源分离表和设计诊断，不用把这项探索性未分辨结果扩成主文主要局限性。

下一步应改善这部分独有信号的灵敏度、时段稳定性和独立物理模板核查；增加海岸负荷相位更不同的基线也可改变设计相关性。沿当前采样和误差规律作纯缩放估算，单位负荷要达到 3 个工作标准误，需约 FACTOR 倍的噪声降低；这不是观测时间保证，也不能简单按日历跨度外推。无需为了得到漂亮系数而固定未知源尺度或挑选月份。

## 文献核查与需醒目标识的边界

**需纠正的引用口径：** Stahl 的 1.00±0.12 是包括其他比对在内的全部结果加权平均，不是仅 1.42±0.35 与 1.12±0.24 两项的平均。其 Methods 将直接潮汐势、地球形变及海洋负荷纳入完整预测，估计该预测的共同尺度；未报告独立海洋负荷系数。[Stahl 等，原文 Results、Discussion 和 Methods](https://arxiv.org/html/2610.39635v1)

**不得升级的条件结果：** 0.96±0.44 只在固体尺度固定为 1 时成立。33.1% 是预测 RMS 比值。两者均不能独自支持“测到了海面涨落”或“独立检出了海洋负荷”。未发现本轮数值实现或输入完整性错误。

## 复现与交付

全部新输出在独立 `research/ocean_loading_A_v77_20261107/`。`INPUT_MANIFEST.json` 登记原路径、版本、SHA256；`results/analysis_rows.csv` 为同一成员上的派生列；`results/DESIGN_GEOMETRY.json`、`FIT_RESULTS.json`、逐期 CSV、协方差 CSV、条件模拟 CSV 和 `verification/` 提供证据。图的 PDF/SVG/PNG、源码和英文候选 Methods 段均保留。

实际环境：Python 3.12.3、NumPy 2.5.3、SciPy 1.18.1、pandas 2.3.3、Matplotlib 3.11.2、pyTMD 3.0.9。运行 `bash scripts/run_all.sh`。该入口只写本研究目录，不修改 A_v77、不重新选择观测、不生成拟合接续长期稳定度、不上传或投稿。作者仍需确认物理模板的外部系统误差；本分析不能替代其独立验证。
'''
repl={'RHO':f'{g["correlation"]:.3f}','COND':f'{g["condition_column_normalized"]:.2f}','PCOND':f'{g["condition_physical_units"]:.2f}','GCOND':f'{g["condition_gram"]:.2f}','FRAC':f'{100*g["ocean_norm_fraction_after_solid"]:.2f}','VIF':f'{g["variance_inflation"]:.2f}','RMSVALUE':f'{g["ocean_orthogonal_rms_e18"]:.3f}','POT':f'{g["ocean_orthogonal_rms_e18"]*1e-18*299792458.**2:.4f}',
      'AE':f'{a["A"][0]:.2f}','UE':f'{a["reported_SE"][0]:.2f}','AO':f'{a["A"][1]:.2f}','UO':f'{a["reported_SE"][1]:.2f}',
      'ELS':f'{a["scaled_LS"][0]:.3f}','OLS':f'{a["scaled_LS"][1]:.3f}','EJK':f'{a["day_JK"][0]:.3f}','OJK':f'{a["day_JK"][1]:.3f}','EPJK':f'{a["period_JK"][0]:.3f}','OPJK':f'{a["period_JK"][1]:.3f}',
      'LOW':f'{j["inference"]["ocean_working_95_interval"][0]:.2f}','HIGH':f'{j["inference"]["ocean_working_95_interval"][1]:.2f}','PLOW':f'{j["inference"]["ocean_period_jackknife_t7_interval"][0]:.2f}','PHIGH':f'{j["inference"]["ocean_period_jackknife_t7_interval"][1]:.2f}',
      'PZERO':str(j['inference']['ocean_zero_test']['probability']),'DMIN':f'{leave.A_O.min():.2f}','DMAX':f'{leave.A_O.max():.2f}','INFO':f'{100*info:.1f}','IMPROVED':str(sum(held.rss_split<held.rss_common_lunar_scale)),'COST':f'{cost:.3f}',
      'PFIX':str(checks['S54_solid_fixed_one']['two_sided_probability']),'PCOMMON':f'{checks["S54_common_source_all_bands"]["two_sided_probability"]:.3f}','FACTOR':f'{3*a["reported_SE"][1]:.1f}',
      'MODEL_TABLE':table.to_markdown(index=False),'COVERAGE_TABLE':pd.DataFrame({'噪声情景':covO.scenario,'负荷覆盖率':covO.coverage_95.map(lambda x:f'{100*x:.1f}%')}).to_markdown(index=False)}
# Replace whole placeholders, longest first so PLOW is not partially replaced.
import re
note=note.replace(r'\pmUE',r'\pm '+repl['UE']).replace(r'\pmUO',r'\pm '+repl['UO'])
note=re.sub(r'\b('+'|'.join(sorted(repl,key=len,reverse=True))+r')\b',lambda m:repl[m[0]],note)
(O/'OCEAN_LOADING_IDENTIFIABILITY_REPORT_ZH.md').write_text(note)
(O/'SUMMARY_ZH.md').write_text(f'''# 海洋负荷是否有新增结果？

**可以强化地球物理动机，目前不能新增独立负荷检出。** 这不改变稿件的两个半日潮组主结果。

- 相同 3,299 个均值、54 段零点、原权重和完整模板；没有重新挑点或补齐空档。
- 月球组固体潮与负荷分别估计：**1.21±0.81、0.47±2.01**，± 为与主稿相同规则的工作标准误。
- 投影后源模板相关 **0.941**；负荷独有平方范数仅 **11.4%**，独有 RMS **0.298×10⁻¹⁸**。
- 负荷双侧工作 95% 区间 **[−3.46, 4.41]**；八期残差符号翻转 **P=0.84375**。
- 删期点估计 **−1.61 至 1.44**；新增源系数使合并留出预测残差平方和增加 **{cost:.3f}%**。
- 固体固定为 1 后是 **0.96±0.44**，但这是条件估计，其分期检验 **P=0.09375**；不能称独立分离。
- 四类条件模拟共 4,000 次，新负荷区间覆盖 **95.0–95.9%**；九项实现/输入核验通过。未发现数值错误。

建议：主文继续突出两组半日潮和沿海—内陆负荷敏感几何；Methods/Extended Data 可加入此次可辨识性结果。源分离需要提高负荷独有波形的信噪比或增加几何不同的基线，并非仅延长日历跨度。完整来源、脚本、协方差、删期和图见同目录报告。

**引用更正：** 欧洲 1.00±0.12 是全部比对的平均，不是两个主图系数的平均。正文仅在结尾中性引用同期工作；不把预印本上线日期当作创新性排序。
''')
english='''### Separability of the solid-Earth and ocean-loading responses

We assessed whether the observations distinguish the two physical contributions within the lunar semidiurnal group. We replaced its combined template by separate solid-Earth and ocean-loading templates, retaining the neighbouring semidiurnal and auxiliary diurnal groups, the fixed remainder, the same 54 segment constants and the original weights. After projecting out the other groups and constants, the two source templates have a weighted correlation of 0.941. Their normalized condition number is 5.74; the loading component orthogonal to the solid template retains 11.4% of its squared norm and has an rms amplitude of 0.298×10⁻¹⁸ on this sampling. The separate response scales are 1.21±0.81 for the solid contribution and 0.47±2.01 for loading, using the larger of scaled least-squares and UTC-day jackknife standard errors. A restricted residual sign-flip diagnostic over eight periods gives a two-sided probability of 0.844 for zero lunar loading. The joint source fit therefore does not resolve loading independently. Fixing the solid scale to unity gives a conditional loading scale of 0.96±0.44, which answers a different, theory-constrained question. These source diagnostics use the same observations as the primary semidiurnal measurement.

Author note: exploratory candidate text only; not inserted into the frozen A_v77 manuscript. The intervals concern statistical fluctuations conditional on the adopted physical templates. Tables, covariance matrices and full noise tests accompany the report.
'''
(O/'METHODS_CANDIDATE_EN.md').write_text(english)
(O/'verification/FIGURE_PROVENANCE.json').write_text(json.dumps(dict(figures=['identifiability_geometry','source_estimates_and_deletions'],inputs=['inputs/constituents.csv','results/design.npz','results/DESIGN_GEOMETRY.json','results/FIT_RESULTS.json','results/leave_period.csv'],data_unchanged=True,no_interpolation_into_gaps=True),indent=2))
print('Generated 2 figures, full report, summary and candidate Methods.')
