"""Independent algebra, signal-recovery and invariance checks on this study."""
from pathlib import Path
import json,hashlib
import numpy as np
from core import fit,serial
O=Path(__file__).resolve().parents[1]
d=np.load(O/'results/design.npz');S=np.c_[d['E'][:,0],d['O'][:,0],d['three'][:,1:]]
y=d['y'];sig=d['sigma'];lab=d['seg'];checks=[]
def check(name,value,tol):
    checks.append(dict(name=name,value=float(value),tolerance=tol,passed=bool(value<=tol)))
f=fit(S,y,sig,lab)
Z=(lab[:,None]==np.unique(lab)[None,:]).astype(float)
X=np.c_[S,Z];A=X/sig[:,None]
beta=np.linalg.lstsq(A,y/sig,rcond=None)[0]
check('Independent full-design least squares vs centred SVD',np.max(abs(beta[:4]-f['beta'])),2e-9)
_,R=np.linalg.qr(A,mode='reduced');Ri=np.linalg.solve(R,np.eye(len(R)))
check('Independent full-design covariance vs centred SVD',np.max(abs((Ri@Ri.T)[:4,:4]-f['C0'])),2e-9)
rng=np.random.default_rng(2026110705)
newzero=rng.normal(0,200,54)
check('Arbitrary segment-level changes leave responses unchanged',np.max(abs(fit(S,y+Z@newzero,sig,lab)['beta']-f['beta'])),2e-9)
ix=rng.permutation(len(y))
check('Observation-order invariance',np.max(abs(fit(S[ix],y[ix],sig[ix],lab[ix])['beta']-f['beta'])),2e-9)
truth=np.array([.8,1.3,.9,.6]);synthetic=S@truth+Z@newzero
check('Noise-free distinct source injection recovers all coefficients',np.max(abs(fit(S,synthetic,sig,lab)['beta']-truth)),2e-9)
check('Original grouped prediction equals unit source sum',np.max(abs(S@np.ones(4)-d['three']@np.ones(3))),2e-13)
g=json.loads((O/'results/DESIGN_GEOMETRY.json').read_text())['geometries']['S54_Allan']
check('Schur complement covariance matches source fit',np.max(abs(np.array(g['unscaled_pair_covariance'])-f['C0'][:2,:2])),2e-9)
check('Negative covariance equals negative projected template correlation',abs(g['covariance_correlation']+g['correlation']),2e-13)
input_ok=all(hashlib.sha256((O/x['copy']).read_bytes()).hexdigest()==x['sha256'] and hashlib.sha256(Path(x['source']).read_bytes()).hexdigest()==x['sha256'] for x in json.loads((O/'INPUT_MANIFEST.json').read_text()))
check('Original inputs and frozen copies unchanged',0 if input_ok else 1,0)
result=dict(status='PASS' if all(x['passed'] for x in checks) else 'FAIL',checks=checks,
            scope='Numerical implementation, provenance and mathematical identifiability; not validation of systematic errors')
(O/'verification/ANALYSIS_CHECKS.json').write_text(json.dumps(result,indent=2,default=serial));print(json.dumps(result,indent=2));assert result['status']=='PASS'
