"""Weighted physical-template fits with nuisance segment constants.

All observation and template amplitudes are in 1e-18 fractional-frequency units.
Only derived results are written by callers. No filling or fitted stitching.
"""
import numpy as np

def centred(a, sigma, labels):
    a=np.asarray(a,float); one=a.ndim==1
    if one:a=a[:,None]
    out=a.copy();w=1/np.asarray(sigma)**2
    for lab in np.unique(labels):
        ix=labels==lab
        out[ix]-=np.average(a[ix],axis=0,weights=w[ix])
    return out[:,0] if one else out

def fit(S,y,sigma,labels):
    S=np.asarray(S,float);y=np.asarray(y,float)
    Sc=centred(S,sigma,labels); A=Sc/sigma[:,None]
    U,d,Vh=np.linalg.svd(A,full_matrices=False)
    tol=np.finfo(float).eps*max(A.shape)*d[0]
    rank=int(np.sum(d>tol))
    if rank!=S.shape[1]:raise ValueError(f'Physical design rank {rank}/{S.shape[1]}')
    inv=(Vh.T/d)@U.T; H=inv/sigma[None,:]
    beta=H@y
    r=centred(y-S@beta,sigma,labels)
    df=len(y)-len(np.unique(labels))-rank
    rss=np.sum((r/sigma)**2);scale=rss/df
    C0=inv@inv.T
    return dict(beta=beta,cov=scale*C0,C0=C0,residual=r,H=H,scale=scale,
                df=df,rss=rss,n=len(y),n_intercepts=len(np.unique(labels)),
                singular_values=d)

def jackknife(S,y,sigma,labels,groups):
    reps=[]
    for group in np.unique(groups):
        k=groups!=group
        reps.append(fit(S[k],y[k],sigma[k],labels[k])['beta'])
    reps=np.array(reps);g=len(reps);z=reps-reps.mean(axis=0)
    return (g-1)/g*z.T@z,reps

def estimate(S,y,sigma,labels,days,periods):
    f=fit(S,y,sigma,labels)
    day,reps=jackknife(S,y,sigma,labels,days)
    per,pr=jackknife(S,y,sigma,labels,periods)
    uls=np.sqrt(np.diag(f['cov']));uday=np.sqrt(np.diag(day));uper=np.sqrt(np.diag(per))
    return dict(A=f['beta'],scaled_LS=uls,day_JK=uday,period_JK=uper,
                reported_SE=np.maximum(uls,uday),cov_scaled_LS=f['cov'],
                cov_day_JK=day,cov_period_JK=per,day_replicates=reps,
                period_replicates=pr,n=f['n'],n_days=len(np.unique(days)),
                n_periods=len(np.unique(periods)),n_intercepts=f['n_intercepts'],
                residual_scale=f['scale'],weighted_rss=f['rss'],df=f['df'])

def geometry(pair,nuisance,sigma,labels):
    # Conditional on the explicitly stated other physical group columns.
    X=centred(pair,sigma,labels)/sigma[:,None]
    if nuisance is not None and nuisance.shape[1]:
        N=centred(nuisance,sigma,labels)/sigma[:,None]
        Q=np.linalg.qr(N,mode='reduced')[0];X=X-Q@(Q.T@X)
    norms=np.linalg.norm(X,axis=0);Xs=X/norms
    rho=float(Xs[:,0]@Xs[:,1]);G=X.T@X
    C0=np.linalg.inv(G);sv=np.linalg.svd(X,compute_uv=False)
    sN=np.linalg.svd(Xs,compute_uv=False)
    orth=X[:,1]-X[:,0]*(X[:,0]@X[:,1])/(X[:,0]@X[:,0])
    return dict(n=len(sigma),n_intercepts=len(np.unique(labels)),
                correlation=rho,rank=int(np.linalg.matrix_rank(X)),
                condition_column_normalized=sN[0]/sN[-1],
                condition_physical_units=sv[0]/sv[-1],
                condition_gram=np.linalg.cond(G),variance_inflation=1/(1-rho*rho),
                ocean_norm_fraction_after_solid=1-rho*rho,
                ocean_orthogonal_rms_e18=np.sqrt(np.sum(orth**2)/np.sum(1/sigma**2)),
                projected_template_rms_e18=norms/np.sqrt(np.sum(1/sigma**2)),
                gram=G,unscaled_pair_covariance=C0,
                covariance_correlation=C0[0,1]/np.sqrt(C0[0,0]*C0[1,1]),
                singular_values=sv)

def serial(x):
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,np.generic):return x.item()
    raise TypeError(type(x).__name__)
