"""Exploratory source split on the frozen A_v77 observations, no reselection."""
from pathlib import Path
import json,itertools,hashlib,platform
import numpy as np
import pandas as pd
import scipy
from scipy.stats import t as student_t
from core import fit,estimate,centred,serial,geometry
O=Path(__file__).resolve().parents[1]

def deletion_operators(S,y,sig,lab,days):
    J=[]
    for day in np.unique(days):
        k=days!=day;h=fit(S[k],y[k],sig[k],lab[k])['H']
        H=np.zeros((S.shape[1],len(y)));H[:,k]=h;J.append(H)
    return np.array(J)

def replicate_statistics(S,Y,sig,lab,H,J,C0):
    B=H@Y;r=centred(Y-S@B,sig,lab)
    var=np.sum((r/sig[:,None])**2,axis=0)/(len(sig)-len(np.unique(lab))-S.shape[1])
    ls=np.sqrt(np.diag(C0)[:,None]*var[None,:])
    be=np.einsum('gkn,nm->gkm',J,Y,optimize=True);be-=be.mean(axis=0)
    jd=np.sqrt((len(J)-1)/len(J)*np.sum(be*be,axis=0))
    return B,np.maximum(ls,jd),ls,jd

def main():
    assert json.loads((O/'results/DESIGN_GEOMETRY.json').read_text())['status']=='PASS'
    d=np.load(O/'results/design.npz');E=d['E'];Oc=d['O'];T=d['three'];y=d['y'];sig=d['sigma'];seg=d['seg'];p=d['period'];days=d['days']
    baseline=json.loads((O/'inputs/RESULTS.json').read_text())
    bfit=estimate(T,y,sig,seg,days,p)
    for k,orig in [('A','A'),('scaled_LS','scaled_ls'),('day_JK','day_jackknife'),('period_JK','period_jackknife'),('reported_SE','u')]:
        np.testing.assert_allclose(bfit[k],baseline['primary'][orig],atol=2e-9,rtol=0)
    SL=np.c_[E[:,0],Oc[:,0],T[:,1:]]
    names=['solid_lunar','ocean_lunar','combined_near12','combined_diurnal']
    models={}
    for name,labels,s in [('S54_lunar_split',seg,sig),('G29_lunar_split',d['group'],sig),('P8_lunar_split',p,sig),('S54_equal_lunar_split',seg,np.ones(len(y)))]:
        models[name]=estimate(SL,y,s,labels,days,p);models[name]['parameters']=names
    six=np.column_stack([q for k in range(3) for q in [E[:,k],Oc[:,k]]])
    models['S54_six_source_groups']=estimate(six,y,sig,seg,days,p)
    models['S54_six_source_groups']['parameters']=['solid_lunar','ocean_lunar','solid_near12','ocean_near12','solid_diurnal','ocean_diurnal']
    common=np.c_[d['solid_full'],d['ocean_full']]
    models['S54_common_source_all_bands']=estimate(common,d['y_raw'],sig,seg,days,p)
    models['S54_common_source_all_bands']['parameters']=['solid_all','ocean_all']
    for name,keep in [('early',~np.isin(p,['P6','P7','P8'])),('summer',np.isin(p,['P6','P7','P8']))]:
        models[name]=estimate(SL[keep],y[keep],sig[keep],seg[keep],days[keep],p[keep]);models[name]['parameters']=names
    primary=models['S54_lunar_split'];full=fit(SL,y,sig,seg)
    null=fit(SL[:,[0,2,3]],y,sig,seg)
    noextra=fit(T,y,sig,seg)
    # Solid scale fixed to one: a conditional physical-model check, not separation.
    fixed_E=estimate(SL[:,[1,2,3]],y-SL[:,0],sig,seg,days,p)
    fixed_E['parameters']=['ocean_lunar_given_solid_1','combined_near12','combined_diurnal']
    models['S54_solid_fixed_one']=fixed_E
    deletions=[];held=[];geomrows=[]
    # Components contributing to the information unique to lunar loading.
    SX=centred(SL,sig,seg)/sig[:,None]
    N=SX[:,[0,2,3]];Q=np.linalg.qr(N,mode='reduced')[0]
    uO=SX[:,1]-Q@(Q.T@SX[:,1])
    for pp in np.unique(p):
        keep=p!=pp;test=~keep
        a=estimate(SL[keep],y[keep],sig[keep],seg[keep],days[keep],p[keep])
        deletions.append(dict(omitted=pp,n=int(keep.sum()),A_E=a['A'][0],A_O=a['A'][1],u_E=a['reported_SE'][0],u_O=a['reported_SE'][1],period_JK_O=a['period_JK'][1]))
        g=geometry(SL[keep,:2],SL[keep,2:],sig[keep],seg[keep]);geomrows.append(dict(omitted=pp,correlation=g['correlation'],condition=g['condition_column_normalized']))
        f0=fit(T[keep],y[keep],sig[keep],seg[keep]);f1=fit(SL[keep],y[keep],sig[keep],seg[keep])
        r0=centred(y[test]-T[test]@f0['beta'],sig[test],seg[test]);r1=centred(y[test]-SL[test]@f1['beta'],sig[test],seg[test])
        rno=centred(y[test]-SL[test][:,[0,2,3]]@fit(SL[keep][:,[0,2,3]],y[keep],sig[keep],seg[keep])['beta'],sig[test],seg[test])
        held.append(dict(held_out=pp,n=int(test.sum()),unique_ocean_information_share=np.sum(uO[test]**2)/np.sum(uO**2),
                         rss_common_lunar_scale=np.sum((r0/sig[test])**2),rss_split=np.sum((r1/sig[test])**2),rss_no_lunar_loading=np.sum((rno/sig[test])**2)))
    pd.DataFrame(deletions).to_csv(O/'results/leave_period.csv',index=False)
    pd.DataFrame(geomrows).to_csv(O/'results/leave_period_geometry.csv',index=False)
    pd.DataFrame(held).to_csv(O/'results/held_out_prediction.csv',index=False)

    # Period-level restricted residual sign flips, fully enumerated, two-sided.
    J=deletion_operators(SL,y,sig,seg,days)
    labels=np.unique(p);signs=np.array(list(itertools.product([-1,1],repeat=len(labels))))
    rowindex=np.searchsorted(labels,p)
    Y=(y-null['residual'])[:,None]+null['residual'][:,None]*signs[:,rowindex].T
    B,se,_,_=replicate_statistics(SL,Y,sig,seg,full['H'],J,full['C0'])
    Tobs=primary['A'][1]/primary['reported_SE'][1];Tstar=B[1]/se[1]
    count=int(np.sum(abs(Tstar)>=abs(Tobs)-1e-10));prob=count/len(signs)
    pd.DataFrame(dict(pattern=np.arange(len(signs)),A_O=B[1],SE_O=se[1],T=Tstar)).to_csv(O/'results/restricted_period_signflip.csv',index=False)
    contrast=np.array([-1.,1.,0.,0.]);diff=contrast@primary['A']
    diff_ls=np.sqrt(contrast@primary['cov_scaled_LS']@contrast);diff_day=np.sqrt(contrast@primary['cov_day_JK']@contrast)
    inference=dict(ocean_zero_test=dict(null='A_O,lunar=0; solid lunar, other groups and segment levels free',
                        two_sided_statistic=Tobs,enumerated_patterns=len(signs),tail_count=count,probability=prob,
                        calibration='Restricted residual wild bootstrap over 8 observational periods; symmetry/cluster assumptions; not an exact randomized experiment'),
                   ocean_working_95_interval=primary['A'][1]+np.array([-1,1])*1.96*primary['reported_SE'][1],
                   ocean_period_jackknife_t7_interval=primary['A'][1]+np.array([-1,1])*student_t.ppf(.975,7)*primary['period_JK'][1],
                   source_difference_AO_minus_AE=diff,source_difference_SE=max(diff_ls,diff_day),
                   delta_weighted_rss_adding_ocean=null['rss']-full['rss'],
                   delta_weighted_rss_separating_sources=noextra['rss']-full['rss'],
                   fixed_solid_is_conditional=True)
    records=[]
    for name,m in models.items():
        for k,param in enumerate(m['parameters']):records.append(dict(model=name,parameter=param,A=m['A'][k],scaled_LS=m['scaled_LS'][k],day_JK=m['day_JK'][k],period_JK=m['period_JK'][k],reported_SE=m['reported_SE'][k],n=m['n']))
    pd.DataFrame(records).to_csv(O/'results/model_comparison.csv',index=False)
    out=dict(status='COMPUTED_EXPLORATORY',primary_model='S54_lunar_split',parameters=names,
             baseline_reproduced=bfit,models=models,inference=inference,
             interpretation_scope='Statistical source scales conditional on the frozen solid and load potential realization; no independent ocean-height or Love-number measurement',
             software=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__))
    (O/'results/FIT_RESULTS.json').write_text(json.dumps(out,indent=2,default=serial))
    # Saved operators allow conditional simulation without repeated numerical solves.
    np.savez(O/'results/primary_operators.npz',S=SL,H=full['H'],J=J,C0=full['C0'])
    print(json.dumps(dict(primary={k:primary[k] for k in ['A','scaled_LS','day_JK','period_JK','reported_SE']},inference=inference),indent=2,default=serial))

if __name__=='__main__':main()
