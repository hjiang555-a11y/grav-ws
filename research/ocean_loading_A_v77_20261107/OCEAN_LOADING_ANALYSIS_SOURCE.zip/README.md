# Ocean-loading identifiability on A_v77

Start with SUMMARY_ZH.md or OCEAN_LOADING_IDENTIFIABILITY_REPORT_ZH.pdf. The independently free lunar source scales are solid 1.21 +/- 0.81 and ocean loading 0.47 +/- 2.01. This does not support independent loading detection. The two primary semidiurnal results in A_v77 are untouched.

Reproduce using `bash scripts/run_all.sh` with Python specified by RESEARCH_PYTHON if needed. The inputs are frozen derived observations/templates, not raw counters. Results and conditional simulations write only to this research directory. To verify original hashes as well as bundled copies, the original source paths in INPUT_MANIFEST.json must be accessible.

For the Chinese PDF, use Pandoc with XeLaTeX, DejaVu Serif and Noto Serif CJK SC; the report is Markdown with generated figures. No script in run_all.sh uploads or submits research.
