# Sources checked 2026-11-07

- Local A_v77 frozen model, phasors, bins, weights and code: exact paths/hashes in INPUT_MANIFEST.json.
- Stahl et al., arXiv:2610.39635v1, Results, Discussion and Methods; full primary HTML checked. https://arxiv.org/html/2610.39635v1
  Their fit is a scale of the combined tidal prediction. No independent ocean-loading coefficient is reported. The mean 1.00(12) includes the other comparisons, not only the two highlighted comparisons.
- The later author instruction concerns manuscript presentation: one neutral sentence on Europe at the end. The separate source-identifiability calculation does not change that positioning.
