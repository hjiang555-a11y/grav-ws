# Solid/ocean loading identifiability — A_v77 follow-up

status: ACTIVE
upstream: final_candidates/A_v77 frozen bins, template, constituent phasors, weights and verification results (read only).
consumers: separate author-review report; no automatic revision of A_v77.

Authorized by the user's request to complete the manuscript first and then assess independent solid-Earth/ocean-loading responses. A_v77 packaging and exact replay completed before starting this analysis. No raw edits, new data selection, gap filling, intercept stitching, scheduler changes or manuscript submission.

Primary exploratory model splits only the lunar M2+N2 group into solid and ocean components, retaining the two other physical group templates, fixed minor remainder and 54 segment constants. This isolates the question relevant to the best-constrained band. The two source coefficients are dimensionless scales of the adopted complete effective-potential contributions, not independent measurements of ocean height or individual load Love numbers.

Secondary predeclared models: separate all six source-by-band coefficients; one pair of source coefficients shared across all bands (explicit strong physical constraint); same lunar split with period/group constants or equal weights, and early/summer subsets. Do not choose a model because its coefficient is close to one.

Before fitting observations: verify frozen hashes, exact group closure, weighted residualized template correlations, rank, scaled/unscaled condition numbers, VIF, Schur complement and unscaled covariance. Then WLS with the existing weights, scaled-LS/day-jackknife errors, period deletion, and a restricted period-sign-flip diagnostic. The latter enumerates 256 sign patterns but is not an exact-level randomization test of this observational experiment. No positivity constraint on source coefficients. Two-sided working intervals, no post hoc signal selection.

New coefficient coverage checked under four explicitly conditional noise scenarios using the original scale and actual UTC. Conditional simulations are not experimental observations or validation of the physical template. Manuscript main results remain untouched, whatever this exploratory analysis finds.
