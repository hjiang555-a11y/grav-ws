# Figure contract

Python/matplotlib, following the established task backend. All plots are exploratory diagnostics, not replacements for the manuscript figures.

Question: does the actual observation window predict half-day leakage into the daily band, and what remains after phase-preserving subtraction?

Figure 1: quantitative grid. Panel a = window geometry, maximum phase-dependent source-to-target squared-norm coupling, four half-day by four daily constituents. Panel b = validation on all eight held-out periods, retaining the negative result. Panel c = actual daily-band projection density, predicted half-day leakage, and residual after coherent subtraction. The same 3299 rows, weights and period constants enter every calculation. The mapping is not random-noise prediction.

Figure 2: one-panel half-day validation on measured data: original spectrum, prediction assembled from held-out periods, and remaining spectrum. All predictions for a period use amplitudes trained on the other seven. Actual UTC gaps are preserved.

Export: 180 mm wide PDF/SVG, 600 dpi PNG, editable text and glyph floor at least 5 pt. Shared-height top panels in Figure 1 are explicitly compared; colour bar is auxiliary, the spectrum spans the bottom. Real fitted/data traces are not independent experiments. Source data and their numeric units are retained in data/. No observations are removed for aesthetics.
