# Reproduce this diagnostic

Use the recorded environment in data/RESULTS.json. Executed interpreter: /home/room115/pytorch_env/bin/python. Work in a new copy.

~~~bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python -B scripts/window_transfer.py
python -B scripts/plot_transfer.py
python -B scripts/write_reports.py
python -B -m pytest -q -c /dev/null -p no:cacheprovider scripts/test_window_transfer.py
python -B scripts/render_note.py
~~~

The final command creates render_final/ and requires that directory not exist. Pandoc and XeLaTeX are needed. Tests include full frozen-input replay in a separate temporary directory with byte-exact output comparisons. coverage/pytest-cov, pyright and ruff were unavailable; those checks are not claimed.

Frozen derived observations and templates are supplied. Raw selection and global geophysical convolution are not rerun. Synthetic probes only test the operator. No gap observations, masks or manuscript changes are generated. Inputs remain unchanged; derived outputs go to data/, figures/, verification/ and render/.
