from pathlib import Path
import json
import pandas as pd
O=Path(__file__).resolve().parents[1];j=json.loads((O/'data/RESULTS.json').read_text())
h=pd.read_csv(O/'data/halfday_heldout.csv');nom=pd.read_csv(O/'data/nominal_mapping.csv')
d=nom[nom.constituent.isin(['K1','O1','P1','Q1'])]
table=d[['constituent','observed_potential_PSD_per_uHz','predicted_semidiurnal_leakage_potential_PSD_per_uHz','after_semidiurnal_potential_PSD_per_uHz']].copy()
table.columns=['Constituent','Observed','Predicted half-day leakage','After coherent subtraction']
maxmap=max(x['mapping_direct_max_abs_error_e18'] for x in j['phase_mapping_validation'])
maxprobe=max(x['max_coefficient_error'] for x in j['synthetic_probes'])
text=f'''# 采样时段到频段的映射：半日验证与全日应用

结论：**可以建立，已完成第一版。** 映射由真实时间戳、缺测模式、权重和时段常数确定；半日数据用来验证它预测旁瓣的能力。应用全日后可以减少半日信号的混入，但现有全日组仍为0.678±0.359，未获得新的明确检出。本记录是独立方法诊断，v72论文与主数据未修改。

## 数据与实验单位

沿用v72已核验3299行、54段、8期、545.924167 h，2025-09至2026-08、跨度353.39日。保留所有真实UTC空缺、原Allan-based相对权重和period截距。研究单位是一条钟比较；行、期和频谱点不当作独立实验。输入SHA256见INPUTS.json。

源模型为已保存的固体有效势与海洋负荷联合模板；没有重建全球负荷网格。日带固体模板原有近似仍存在，不能由采样校正解决。

## 映射方法

对源频率g的cos/sin两列，计算它在扫描频率f上引起的两个表观系数。矩阵同时携带幅度和相位，包括加权去period均值操作。任意两频率之间都可用同一公式，无需从半日噪声强行学习全日噪声。

算子为 K(f,g)=[Hfᵀ W Mz Hf]⁻¹ Hfᵀ W Mz Hg；Mz去除原8期常数。天文源基底保留结点因子和相位。frequency_response.npz保存扫描范围到16个源正交分量的映射；source_response_matrix.csv保存8个分潮间的16×16响应矩阵。

观测窗与真实信号相乘会在频域产生卷积；缺测去卷积需要保留复振幅并处理非唯一性。[VanderPlas 2018](https://doi.org/10.3847/1538-4365/aab766)；相关CLEAN时序谱方法见[Roberts et al. 1987](https://doi.org/10.1086/114383)。本实现使用固定天文基底的线性响应和联合加权估计，没有CLEAN迭代或事后选峰。

## 半日验证

1. 在真实时刻放入已知幅度/相位的合成探针，仅用于算子测试，绝不加入实验观测。矩阵预测与直接时域扫描的最大差为{maxmap:.2e}（以10^-18为幅度单位）；已知16个系数反演最大误差为{maxprobe:.2e}。
2. 实际观测逐期留出，另外7期估计两个半日组幅度，再预测未参与训练的第8期。全日物理模板通过相同投影保护；频率、相位、掩膜和权重未为效果调优。
3. 8期中7期的加权残差降低，合并降幅{100*j['halfday_heldout']['pooled_RSS_reduction']:.3f}%。P1反而上升0.402%，已保留。训练集重叠，7/8不是独立重复的显著性检验。

{h[['period','test_rows']].assign(reduction_percent=100*h.reduction_fraction).to_markdown(index=False,floatfmt='.4f')}

半日实测、整期留出预测及扣除后的谱见figures/halfday_heldout_spectrum.pdf。这检验可预测的物理波形/采样响应，不证明随机噪声可逐点预测。

## 迁移到全日

用同一算子预测半日波形在全日频带的泄漏，在带相位的幅度或时域层面扣除。以下全部使用原3299行，功率密度单位为(m²/s²)²/µHz。

{table.to_markdown(index=False,floatfmt='.6f')}

K1附近减小，P1附近反而增大：原先存在相消干涉，不能采用“观测功率−泄漏功率”的简单相减。9.5–12.5 µHz固定扫描网格上的平均名义密度降低约{100*(1-j['daily_fixed_grid_description']['after_semi_power_area_div_before']):.2f}%；这不是Parseval总噪声方差降低率或检测显著性的改善。

单个半日分潮到单个全日分潮的最大相位依赖平方范数转移约0.05%–1.70%。半日信号较强，小比例泄漏仍可影响弱日带。矩阵图和全日谱见figures/mapping_and_daily_transfer.pdf。

## 是否促进日信号提取

可以纠正混叠偏差，目前没有额外统计信息增益。忽略半日成分只拟合全日模板时系数为{j['sequential']['daily_only_before']:.6f}；完整映射/联合估计给出{j['sequential']['correct_joint']:.6f}，工作标准误0.358623。它与v72原三组联合拟合一致，因为原设计矩阵已处理了这部分混合。

“先拟合强信号，扣掉后直接拟合原弱模板”会同时损失弱信号。本设计对指定全日组的无噪声单位注入仅保留{100*j['sequential']['injected_daily_retention_if_unprojected_template']:.4f}%，损失约0.523%。正确方法把弱模板也经过相同强信号投影，并传播完整协方差；单位注入恢复100%，与联合拟合一致。该损失比例仅适用于本采样/权重/模板。

附加16列I/Q反混叠将8个已知分潮分别估计。去掉另一频带后的归一化设计条件数约半日1.801、全日1.919，数值求解稳定；但日分潮观测误差仍大。条件数良好不等于实验检出。全部点值、工作标准误与逐期删除误差在data/constituent_inverse.csv，不替代主结果、不择优报告。

## 可预测的范围

可预测的是已指定信号通过采样窗产生的响应。随机噪声的具体实现不能由缺测时刻单独决定；另有可信噪声协方差时，才能预测其统计分布及跨频率相关。算子能纠正有限已知频率之间的混叠，不能恢复空缺时间的全部连续信号。未监测钟/实验室支路、真实日变化和物理模板误差仍可能留在残差。

建议用于Methods的采样窗验证与谱解释。它支持半日图的物理解释、量化日带污染，目前不支持把日潮升级成新发现，也不将残差称为纯测量噪声。

## 可复现交付

- scripts/window_transfer.py：完整映射、留期、反演、信号保护与谱输出。
- scripts/test_window_transfer.py：独立代数/单位/整套干净目录回放。
- scripts/plot_transfer.py：两幅解释图，PDF/SVG与600 dpi PNG。
- data/RESULTS.json、CSV、NPZ：数值、频点映射及协方差。
- verification/：输入身份、数值等价、图形审计与测试日志。
- METHOD_NOTE.md、render_final/METHOD_NOTE.pdf：英文方法说明。

复现入口REPRODUCE.md；实际软件版本在data/RESULTS.json的software字段。合成探针均明确标记；没有填补无效时刻。原论文、原始数据、其他工作树和科研服务保持不变。
'''
(O/'WINDOW_TRANSFER_REPORT.md').write_text(text)
note=r'''# Mapping an interrupted observing window between tidal bands

Exploratory technical note on the fixed author-review observation design

## Result

The actual observing window predicts a transferable, phase-dependent response between frequency bands. Known half-day probes agree with direct sampling to numerical precision. On measured data, a half-day prediction fitted to seven observing periods reduces weighted residuals in seven of the eight held-out periods; the pooled reduction is 3.151%. Applying the same window to the daily band removes a calculable half-day contribution. The correctly projected daily-group coefficient remains 0.678 with a working standard error of 0.359, identical to the existing joint physical fit. This is a sampling diagnostic, not a new daily-tide detection.

## Observations and fixed rules

All 3,299 ten-minute rows, 54 segments, eight periods and 545.924 h of retained nominal one-second members are used. Calendar time extends from September 2025 to August 2026. Actual UTC gaps, stored relative noise weights and period constants are preserved. No observation is supplied in a missing interval. The fixed solid-effective-potential and loading template is inherited unchanged; its daily-band solid-model approximation remains outside this correction.

The half-day constituents are M2, S2, N2 and K2; the daily constituents are K1, O1, P1 and Q1. Frequencies and astronomical arguments are fixed, including nodal corrections. The main model retains three grouped amplitudes. Separate constituent quadratures are an exploratory inverse-response diagnostic only.

## The mapping

Let $Z$ contain period indicators and $W$ the stored inverse-variance weights. The residual operator is

$$M_Z=I-Z(Z^T WZ)^{-1}Z^T W.$$

Let $H_f$ contain cosine and sine columns at trial frequency $f$, evaluated only at the observed times. The amplitude response to an input pair at $g$ is

$$K(f,g)=(H_f^T W M_Z H_f)^{-1}H_f^T W M_Z H_g.$$

This is a two-by-two amplitude-and-phase map, not a power-subtraction rule. Astronomical source columns include nodal factors and arguments. The retained response array covers 9.5--12.5 and 21--24.5 microhertz. The full operator includes weighted period removal; simply translating an unweighted Fourier window would omit that step.

For fixed source constituents, independent two-quadrature scans satisfy $b=K a+\eta$. Solving their response system returns the same coefficients as simultaneous weighted harmonic regression. It adds no independent measurements. A dense unrestricted spectrum cannot be uniquely recovered across missing intervals without further assumptions. Window aliases and deconvolution limitations are discussed by VanderPlas (2018); complex-amplitude CLEAN methods have a related motivation (Roberts et al., 1987).

## Half-day verification and migration

Synthetic probes only test the algebra: known constituent quadratures and period offsets are evaluated on the real timestamps. They are never added to the observation table. Mapping predictions agree with independent direct least-squares scans at all nine named test frequencies.

For measured-data validation, each entire period is held out. The other seven estimate the two half-day amplitudes while protecting the fixed daily template by the same nuisance projection. The omitted-period prediction uses those training amplitudes, fixed phases and its actual timestamps. Seven periods improve; P1 worsens by 0.402%. The pooled weighted residual reduction is 3.151%. Overlapping training sets prevent treating 7/8 as an independent binomial significance test.

The identical mapping is then applied to the daily band. A half-day waveform has a daily projection because of the observation window. Subtraction acts coherently on the waveform or the two-quadrature amplitudes. If $L_f$ is the scan operator and $G_f$ its Gram matrix,

$$P(y)=P(s)+P(y-s)+2(L_fs)^T G_f L_f(y-s).$$

The cross term may be negative. Removing a contaminating waveform can therefore increase power at an individual frequency, as occurs near P1 in these data.

{{TABLE}}

The density unit is $(\mathrm{m^2/s^2})^2$/µHz. The fixed-grid average of nominal daily density falls by 14.44% after same-record half-day subtraction. This is a descriptive scan statistic, not a Parseval noise-variance reduction or independently calibrated sensitivity gain. Uncertainty in the fitted half-day waveform must remain in subsequent inference.

## Protecting the weak signal

In period-centred, whitened coordinates, let $S$ be the strong half-day design and $d$ the daily template. Set $M_S=I-S(S^TS)^{-1}S^T$. Correct strong-first estimation uses

$$\widehat A_D=\frac{(M_Sd)^T(M_Sy)}{(M_Sd)^T(M_Sd)}.$$

The same projection acts on template and data; covariance follows the complete linear operator. This is identical to the joint fit. Projecting only the observations attenuates a daily injection by $d^TM_Sd/(d^Td)$, equal to 0.994772 on this design. Correct projection returns unit response.

An isolated daily fit gives 0.8133 before accounting for half-day mixing. The full response gives 0.6779, with scaled-LS/day-jackknife working error 0.3586 and period-jackknife error 0.4118. No precision improvement over the existing joint estimator is claimed. The individual-frequency inverse is numerically well conditioned after normalization, but the daily estimates remain imprecise.

## What can be predicted

The window determines how a specified signal appears at other frequencies. It does not determine a realization of random clock or transfer noise. With an independently supported noise covariance $C$, spectral covariance is $L_f C L_g^T$: a statistical prediction, not a known additive waveform. Unknown laboratory effects and model discrepancies remain possible in the residual. The present contribution is measured-window validation and explicit leakage accounting.

\clearpage

![](figures/mapping_and_daily_transfer.png){width=180mm}

**Figure 1 | Geometry, validation and daily-band application.** **a,** Maximum phase-dependent squared-norm projection between half-day sources and daily targets on the weighted, period-centred observations. Values are geometric coupling percentages, not fractions of observed noise. **b,** Weighted residual change in every held-out period after a half-day prediction trained on the other seven. The fixed daily template is protected by the specified projection. **c,** Daily density of all 3,299 rows, the daily projection of the fitted half-day waveform, and observations after coherent subtraction. These curves share data. The two axes obey $S_W=c^4S_y$. Changes include interference and do not establish an independent daily detection.

\clearpage

![](figures/halfday_heldout_spectrum.png){width=180mm}

**Figure 2 | Half-day validation with predictions from other periods.** Original weighted projection density, the half-day waveform assembled from held-out predictions, and the remaining density after coherent subtraction. Actual UTC gaps and original weights are preserved. Each period's amplitudes were estimated without its observations. Training sets and spectral ordinates remain correlated. No frequency or source phase was retuned to improve agreement.

## References

1. VanderPlas, J. T. Understanding the Lomb--Scargle periodogram. *Astrophys. J. Suppl. Ser.* **236**, 16 (2018). https://doi.org/10.3847/1538-4365/aab766
2. Roberts, D. H., Lehar, J. & Dreher, J. W. Time series analysis with CLEAN. I. Derivation of a spectrum. *Astron. J.* **93**, 968 (1987). https://doi.org/10.1086/114383
'''.replace('{{TABLE}}',table.to_markdown(index=False,floatfmt='.6f'))
(O/'METHOD_NOTE.md').write_text(note)
(O/'REPRODUCE.md').write_text('''# Reproduce this diagnostic

Use the recorded environment in data/RESULTS.json. Executed interpreter: /home/room115/pytorch_env/bin/python. Work in a new copy.

~~~bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1 python -B scripts/window_transfer.py
python -B scripts/plot_transfer.py
python -B scripts/write_reports.py
python -B -m pytest -q -c /dev/null -p no:cacheprovider scripts/test_window_transfer.py
python -B scripts/render_note.py
~~~

The final command creates render_final/ and requires that directory not exist. Pandoc and XeLaTeX are needed. Tests include full frozen-input replay in a separate temporary directory with byte-exact output comparisons. coverage/pytest-cov, pyright and ruff were unavailable; those checks are not claimed.

Frozen derived observations and templates are supplied. Raw selection and global geophysical convolution are not rerun. Synthetic probes only test the operator. No gap observations, masks or manuscript changes are generated. Inputs remain unchanged; derived outputs go to data/, figures/, verification/ and render/.
''')
print('Chinese report and English method note written from computed results.')
