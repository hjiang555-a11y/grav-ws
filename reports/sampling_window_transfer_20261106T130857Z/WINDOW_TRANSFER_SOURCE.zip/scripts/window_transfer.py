"""Actual-window amplitude mapping, half-day validation and daily-band transfer.

No observations are synthesized at missing times. Synthetic probes are explicitly
labelled operator tests and are never mixed with measured observations.
"""
from pathlib import Path
import sys,json,hashlib,importlib.metadata
import numpy as np
import pandas as pd

O=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(O/'vendor'))
import template


def scalar(x):
    if isinstance(x,np.ndarray):return x.tolist()
    if isinstance(x,np.generic):return x.item()
    raise TypeError(str(type(x)))


def wproject(v,nuisance,sigma):
    q=np.linalg.qr(nuisance/sigma[:,None],mode='reduced')[0]
    z=v/(sigma if v.ndim==1 else sigma[:,None])
    return z-q@(q.T@z)


def fit(signal,y,sigma,labels):
    Z=(labels[:,None]==np.unique(labels)[None,:]).astype(float)
    X=np.column_stack([signal,Z]);A=X/sigma[:,None]
    Q,R=np.linalg.qr(A,mode='reduced')
    assert np.linalg.matrix_rank(A/np.linalg.norm(A,axis=0))==A.shape[1]
    H=np.linalg.solve(R,Q.T)/sigma[None,:];a=H@y;res=y-X@a
    scale=np.sum((res/sigma)**2)/(len(y)-len(a));ri=np.linalg.solve(R,np.eye(len(R)))
    return a,scale*(ri@ri.T),res,H


def with_errors(signal,y,sigma,labels,days):
    a,c,res,h=fit(signal,y,sigma,labels);k=signal.shape[1]
    j=dict(a=a[:k],scaled_ls=np.sqrt(np.diag(c)[:k]),cov_scaled_ls=c[:k,:k])
    for name,clusters in [('day',days),('period',labels)]:
        reps=[]
        for u in np.unique(clusters):
            take=clusters!=u;reps.append(fit(signal[take],y[take],sigma[take],labels[take])[0][:k])
        reps=np.array(reps);dif=reps-reps.mean(axis=0);cv=(len(reps)-1)/len(reps)*(dif.T@dif)
        j[name+'_jackknife']=np.sqrt(np.diag(cv));j['cov_'+name]=cv
    j['reported_working_se']=np.maximum(j['scaled_ls'],j['day_jackknife'])
    return j


def block_mapping(bw,yw):
    """Independent 2-quadrature scans and their exact mixing matrix."""
    G=bw.T@bw;K=np.empty_like(G);u=np.empty(G.shape[0])
    for lo in range(0,len(G),2):
        take=slice(lo,lo+2)
        K[take]=np.linalg.solve(G[take,take],G[take])
        u[take]=np.linalg.solve(G[take,take],bw[:,take].T@yw)
    a=np.linalg.solve(K,u)
    return K,u,a


def main():
    inputspec=json.loads((O/'INPUTS.json').read_text())
    for item in inputspec['files']:assert hashlib.sha256((O/item['copy']).read_bytes()).hexdigest()==item['sha256']
    x=np.load(O/'sources/primary_design.npz');S=x['three'];y=x['y_minus_fixed'];sig=x['sigma'];t=x['seconds'];p=x['periods'];n=len(y)
    rows=pd.read_csv(O/'sources/bins.csv');days=pd.to_datetime(rows.t_utc,utc=True).dt.strftime('%Y-%m-%d').to_numpy()
    Z=(p[:,None]==np.unique(p)[None,:]).astype(float);names=template.CONSTITUENTS
    c=pd.read_csv(O/'sources/constituents.csv').set_index('constituent')
    C=np.array([complex(c.loc[k,'solid_real']+c.loc[k,'loading_real'],c.loc[k,'solid_imag']+c.loc[k,'loading_imag']) for k in names])
    phase,factor=template._arguments(t,names)
    B=np.empty((n,16))
    for k in range(8):
        B[:,2*k]=factor[:,k]*np.real(C[k]*np.exp(-1j*phase[:,k]))
        B[:,2*k+1]=factor[:,k]*np.real(1j*C[k]*np.exp(-1j*phase[:,k]))
    np.testing.assert_allclose(B[:,[0,4]].sum(axis=1),S[:,0],rtol=0,atol=1e-13)
    np.testing.assert_allclose(B[:,[2,6]].sum(axis=1),S[:,1],rtol=0,atol=1e-13)
    np.testing.assert_allclose(B[:,[8,10,12,14]].sum(axis=1),S[:,2],rtol=0,atol=1e-13)
    bw=wproject(B,Z,sig);yw=wproject(y,Z,sig);K,u,a=block_mapping(bw,yw)
    original=json.loads((O/'sources/PRIMARY_RESULTS.json').read_text())
    group=with_errors(S,y,sig,p,days)
    np.testing.assert_allclose(group['a'],original['primary']['A'],atol=1e-12,rtol=0)
    detailed=with_errors(B,y,sig,p,days)
    np.testing.assert_allclose(a,detailed['a'],atol=1e-10,rtol=0)
    out=[]
    for k,name in enumerate(names):
        out.append(dict(constituent=name,inphase=a[2*k],quadrature=a[2*k+1],u_inphase=detailed['reported_working_se'][2*k],u_quadrature=detailed['reported_working_se'][2*k+1],period_se_inphase=detailed['period_jackknife'][2*k],period_se_quadrature=detailed['period_jackknife'][2*k+1],independent_scan_inphase=u[2*k],independent_scan_quadrature=u[2*k+1],template_amplitude_e18=abs(C[k])))
    pd.DataFrame(out).to_csv(O/'data/constituent_inverse.csv',index=False)
    pd.DataFrame(K).to_csv(O/'data/source_response_matrix.csv',index=False)
    np.savez_compressed(O/'data/source_inversion.npz',matrix=K,independent_scans=u,joint=a,cov_scaled_ls=detailed['cov_scaled_ls'],cov_day=detailed['cov_day'],cov_period=detailed['cov_period'],basis=B)
    # Half-day validation first: known signals on the actual irregular timestamps.
    rng=np.random.default_rng(20261106);probes=[]
    for label,true in [('unit_physical',np.tile([1.,0.],8)),('phase_stress',rng.normal(size=16))]:
        synthetic=B@true+Z@rng.normal(size=Z.shape[1])
        syn=wproject(synthetic,Z,sig);kmap,raw,recovered=block_mapping(bw,syn)
        err=float(np.max(abs(recovered-true)))
        np.testing.assert_allclose(recovered,true,rtol=0,atol=1e-10)
        probes.append(dict(test=label,synthetic_only=True,max_coefficient_error=err))
    # Same mapping algorithm used in each band, with the other band protected.
    band_inversion=[]
    for name,cols,other in [('semidiurnal',np.arange(8),np.arange(8,16)),('diurnal',np.arange(8,16),np.arange(8))]:
        N=np.column_stack([Z,B[:,other]]);bb=wproject(B[:,cols],N,sig);zz=wproject(y,N,sig)
        km,raw,inv=block_mapping(bb,zz)
        np.testing.assert_allclose(inv,a[cols],rtol=0,atol=1e-9)
        band_inversion.append(dict(band=name,normalized_design_condition=float(np.linalg.cond(bb/np.linalg.norm(bb,axis=0))),mapping_condition=float(np.linalg.cond(km)),joint_max_difference=float(np.max(abs(inv-a[cols])))))
    # Leave-one-period prediction: strong amplitudes learned on other periods.
    held=[];pred_cf=np.zeros(n)
    for val in np.unique(p):
        train=p!=val;test=~train;aa=fit(S[train],y[train],sig[train],p[train])[0][:3]
        pred=S[test,:2]@aa[:2];pred_cf[test]=pred
        N=np.column_stack([np.ones(test.sum()),S[test,2]])
        v=wproject(y[test],N,sig[test]);f=wproject(pred,N,sig[test])
        rss0=float(v@v);rss1=float((v-f)@(v-f))
        held.append(dict(period=val,training_rows=int(train.sum()),test_rows=int(test.sum()),train_A_L=aa[0],train_A_S=aa[1],rss_without_semidiurnal=rss0,rss_with_predicted_semidiurnal=rss1,reduction_fraction=1-rss1/rss0))
    pd.DataFrame(held).to_csv(O/'data/halfday_heldout.csv',index=False)
    # Correct strong-to-weak sequential calculation must project both sides.
    sq=wproject(S[:,:2],Z,sig);dq=wproject(S[:,2],Z,sig)
    qs=np.linalg.qr(sq,mode='reduced')[0];my=yw-qs@(qs.T@yw);md=dq-qs@(qs.T@dq)
    naive_after=float(dq@my/(dq@dq));fwl=float(md@my/(md@md))
    naive_before=float(dq@yw/(dq@dq));retention=float(md@md/(dq@dq))
    np.testing.assert_allclose(fwl,group['a'][2],rtol=0,atol=1e-12)
    # Signal-protection probes on the actual observed support, not new observations.
    strong=S[:,:2]@np.array([1.,1.]);injection=[]
    for ad in [-1.,0.,1.,2.]:
        yy=strong+ad*S[:,2];zz=wproject(yy,Z,sig);rz=zz-qs@(qs.T@zz)
        correct=float(md@rz/(md@md));naive=float(dq@rz/(dq@dq))
        np.testing.assert_allclose(correct,ad,atol=1e-12,rtol=0)
        injection.append(dict(injected_A_D=ad,correct_FWL=correct,naive_after_subtraction=naive,synthetic_only=True))
    pd.DataFrame(injection).to_csv(O/'data/signal_protection.csv',index=False)
    # Arbitrary-frequency response map: true dates, weights and period indicators.
    sp=pd.read_csv(O/'sources/primary_spectra.csv');fs=sp.frequency_uHz.to_numpy()*1e-6
    W=1/sig**2;W/=W.mean();sw=np.sqrt(W);qz=np.linalg.qr(Z*sw[:,None],mode='reduced')[0]
    def project(v):
        z=v*(sw if v.ndim==1 else sw[:,None]);return z-qz@(qz.T@z)
    semi=S[:,:2]@group['a'][:2];daily=S[:,2]*group['a'][2]
    Y=project(np.column_stack([y,semi,y-semi,daily,y-semi-daily,pred_cf,y-pred_cf]))
    source=project(B);allK=[];allA=[];allG=[];power=[]
    for lo in range(0,len(fs),96):
        f=fs[lo:lo+96];ang=2*np.pi*(t-t.min())[:,None]*f
        co=project(np.cos(ang));si=project(np.sin(ang));g00=(co*co).sum(axis=0);g11=(si*si).sum(axis=0);g01=(co*si).sum(axis=0)
        gram=np.empty((len(f),2,2));gram[:,0,0]=g00;gram[:,1,1]=g11;gram[:,0,1]=gram[:,1,0]=g01
        rhs=np.stack([co.T@Y,si.T@Y],axis=1);rhsB=np.stack([co.T@source,si.T@source],axis=1)
        amp=np.linalg.solve(gram,rhs);mapping=np.linalg.solve(gram,rhsB)
        rss=np.einsum('fki,fki->fi',rhs,amp);power.append(600*1e-42*299792458.0**4*rss)
        allK.append(mapping);allA.append(amp);allG.append(gram)
    power=np.vstack(power);allK=np.concatenate(allK);allA=np.concatenate(allA);allG=np.concatenate(allG)
    # Known 16-column source waveforms reproduce both bands through the mapping.
    unit=np.tile([1.,0.],8);recon=np.einsum('fki,i->fk',allK,unit)
    validation=[]
    nominal=pd.read_csv(O/'sources/nominal_spectrum.csv')
    for row in nominal.itertuples():
        f=row.f_uHz*1e-6;i=np.argmin(abs(fs-f));h=np.column_stack([np.cos(2*np.pi*f*(t-t.min())),np.sin(2*np.pi*f*(t-t.min()))]);X=np.column_stack([Z,h])
        direct=np.linalg.lstsq(X*sw[:,None],(B@unit)*sw,rcond=None)[0][-2:]
        error=float(np.max(abs(recon[i]-direct)))
        np.testing.assert_allclose(recon[i],direct,rtol=0,atol=1e-9)
        validation.append(dict(f_uHz=row.f_uHz,name=row.constituent,mapping_direct_max_abs_error_e18=error))
    result=pd.DataFrame(dict(frequency_uHz=fs*1e6))
    labels=['observed','predicted_semidiurnal_leakage','after_semidiurnal','predicted_diurnal','after_all_groups','heldout_semidiurnal_prediction','after_heldout_semidiurnal']
    for i,label in enumerate(labels):result[label+'_potential_PSD_per_uHz']=power[:,i]
    result['interference_cross_term_potential_PSD_per_uHz']=power[:,0]-power[:,1]-power[:,2]
    result.to_csv(O/'data/mapped_spectra.csv',index=False)
    np.savez_compressed(O/'data/frequency_response.npz',frequency_Hz=fs,K=allK,observed_scan_amplitudes_e18=allA,gram=allG)
    # Exact nominal-frequency row table and canonical subspace coupling.
    nominal_rows=[]
    for row in nominal.itertuples():
        ii=np.argmin(abs(result.frequency_uHz-row.f_uHz));rr=result.iloc[ii].to_dict();rr['constituent']=row.constituent;nominal_rows.append(rr)
    pd.DataFrame(nominal_rows).to_csv(O/'data/nominal_mapping.csv',index=False)
    couplings=[]
    for i in range(8):
        qi=np.linalg.qr(bw[:,2*i:2*i+2],mode='reduced')[0]
        for k in range(8):
            qk=np.linalg.qr(bw[:,2*k:2*k+2],mode='reduced')[0]
            coupling=float(np.linalg.svd(qk.T@qi,compute_uv=False)[0]**2)
            couplings.append(dict(source=names[i],target=names[k],max_phase_power_coupling=coupling))
    pd.DataFrame(couplings).to_csv(O/'data/coupling_matrix.csv',index=False)
    diurnal_mask=(result.frequency_uHz>=9.5)&(result.frequency_uHz<=12.5)
    weights=np.diff(np.r_[fs[diurnal_mask],fs[diurnal_mask][-1]+np.median(np.diff(fs[diurnal_mask]))])
    observed_daily_area=float(weights@power[diurnal_mask,0]);alias_daily_area=float(weights@power[diurnal_mask,1]);remaining_area=float(weights@power[diurnal_mask,2])
    # Keep this as a fixed-grid descriptive measure, not physical variance integral.
    summary=dict(sample_rows=n,sample_hours=float(rows.n.sum()/3600),observing_periods=len(np.unique(p)),phase_mapping_validation=validation,synthetic_probes=probes,
        primary_group=group,constituents=detailed,band_inverse=band_inversion,source_matrix_condition=float(np.linalg.cond(K)),normalized_design_condition=float(np.linalg.cond(bw/np.linalg.norm(bw,axis=0))),
        halfday_heldout=dict(positive_periods=sum(r['reduction_fraction']>0 for r in held),total_periods=len(held),pooled_RSS_reduction=1-sum(r['rss_with_predicted_semidiurnal'] for r in held)/sum(r['rss_without_semidiurnal'] for r in held)),
        sequential=dict(daily_only_before=naive_before,naive_daily_after_semidiurnal_only_fit=naive_after,correct_same_projection_FWL=fwl,correct_joint=group['a'][2],injected_daily_retention_if_unprojected_template=retention,projected_daily_norm_loss=1-retention),
        daily_fixed_grid_description=dict(predicted_semi_power_area_div_observed=alias_daily_area/observed_daily_area,after_semi_power_area_div_before=remaining_area/observed_daily_area,scope='Grid-averaged nominal projection density, not a Parseval variance decomposition or percentage of attributable noise; cross terms retained'),
        conclusions_scope='Sampling response is computed from geometry and weights, not learned noise. Inversion returns ordinary joint weighted harmonic estimation. No new independent data or random-noise prediction.',
        original_manuscript_changed=False,missing_observations_filled=0,software={'python':sys.version,'packages':{k:importlib.metadata.version(k) for k in ['numpy','scipy','pandas','pyTMD','matplotlib']}})
    (O/'data/RESULTS.json').write_text(json.dumps(summary,default=scalar,indent=2))
    (O/'verification/NUMERIC_CHECK.json').write_text(json.dumps(dict(status='PASS',input_sha256_verified=True,source_template_identity=True,mapping_matches_direct_scans=True,full_matrix_matches_QR=True,strong_first_matches_joint=True,injected_daily_response_preserved=True,observed_rows=n,synthetic_rows_added_to_observations=0,raw_sources_changed=False),indent=2))
    print(json.dumps({k:summary[k] for k in ['halfday_heldout','sequential','daily_fixed_grid_description','band_inverse']},default=scalar,indent=2))
    print(pd.DataFrame(out).to_string(index=False))

if __name__=='__main__':main()
