from pathlib import Path
import subprocess,json
O=Path(__file__).resolve().parents[1];R=O/'render_final';R.mkdir(exist_ok=False)
text=(O/'METHOD_NOTE.md').read_text().replace('figures/mapping_and_daily_transfer.png','figures/mapping_and_daily_transfer.pdf').replace('figures/halfday_heldout_spectrum.png','figures/halfday_heldout_spectrum.pdf')
(R/'input.md').write_text(text)
(R/'header.tex').write_text(r'''\usepackage{float}
\floatplacement{figure}{H}
\setlength{\emergencystretch}{2em}
\usepackage{fancyhdr}
\pagestyle{fancy}\fancyhf{}\fancyhead[L]{\small Sampling-window transfer: exploratory diagnostic}
\fancyfoot[C]{\thepage}\setlength{\headheight}{14pt}
''')
cmd=['pandoc',str(R/'input.md'),'--standalone','--resource-path='+str(O),'--pdf-engine=xelatex','--pdf-engine-opt=-no-shell-escape','-V','mainfont=DejaVu Serif','-V','sansfont=DejaVu Sans','-V','papersize=a4','-V','geometry:left=15mm,right=15mm,top=20mm,bottom=20mm','-V','fontsize=10pt','-H',str(R/'header.tex'),'-o',str(R/'METHOD_NOTE.pdf')]
p=subprocess.run(cmd,cwd=O,capture_output=True,text=True);(R/'pdf.log').write_text(p.stdout+p.stderr)
(R/'BUILD.json').write_text(json.dumps(dict(exit_code=p.returncode,status='PASS' if p.returncode==0 else 'FAIL'),indent=2))
if p.returncode:raise SystemExit(p.returncode)
print('Method note PDF compiled.')
