"""Independent algebraic identities and a complete frozen-input replay."""
from pathlib import Path
import json,shutil
import numpy as np
import pandas as pd
import window_transfer as w
O=Path(__file__).resolve().parents[1]

def test_mapping_recovers_known_quadratures_and_offsets():
    x=np.load(O/'sources/primary_design.npz');p=x['periods'];sig=x['sigma'];t=x['seconds']-x['seconds'].min()
    Z=(p[:,None]==np.unique(p)[None,:]).astype(float)
    B=np.column_stack([np.cos(2*np.pi*t/f) if q==0 else np.sin(2*np.pi*t/f) for f in [12*3600,12.42*3600,24*3600] for q in [0,1]])
    truth=np.array([.3,-.7,.2,.9,-.4,.8]);y=B@truth+Z@np.arange(Z.shape[1])
    bw=w.wproject(B,Z,sig);yw=w.wproject(y,Z,sig)
    _,_,got=w.block_mapping(bw,yw)
    np.testing.assert_allclose(got,truth,atol=1e-11,rtol=0)

def test_projection_protects_real_daily_signal():
    x=np.load(O/'sources/primary_design.npz');S=x['three'];p=x['periods'];sig=x['sigma'];Z=(p[:,None]==np.unique(p)[None,:]).astype(float)
    a=w.wproject(S[:,:2],Z,sig);d=w.wproject(S[:,2],Z,sig);q=np.linalg.qr(a,mode='reduced')[0];dp=d-q@(q.T@d)
    y=2*a[:,0]-.4*a[:,1]+1.7*d;yp=y-q@(q.T@y)
    np.testing.assert_allclose(dp@yp/(dp@dp),1.7,rtol=0,atol=1e-12)
    assert d@yp/(d@d)<1.7

def test_saved_psd_and_units():
    a=pd.read_csv(O/'data/mapped_spectra.csv',float_precision='round_trip');b=pd.read_csv(O/'sources/primary_spectra.csv',float_precision='round_trip')
    np.testing.assert_allclose(a.observed_potential_PSD_per_uHz,b.observed_potential_PSD_per_uHz,rtol=1e-9,atol=1e-15)
    np.testing.assert_allclose(a.after_all_groups_potential_PSD_per_uHz,b.residual_potential_PSD_per_uHz,rtol=1e-9,atol=1e-15)
    np.testing.assert_allclose(a.observed_potential_PSD_per_uHz-a.predicted_semidiurnal_leakage_potential_PSD_per_uHz-a.after_semidiurnal_potential_PSD_per_uHz,a.interference_cross_term_potential_PSD_per_uHz,rtol=1e-10,atol=1e-15)
    assert np.min(a.interference_cross_term_potential_PSD_per_uHz)<0

def test_complete_independent_directory_replay(tmp_path,monkeypatch):
    shutil.copytree(O/'sources',tmp_path/'sources');shutil.copy2(O/'INPUTS.json',tmp_path/'INPUTS.json');(tmp_path/'data').mkdir();(tmp_path/'verification').mkdir()
    monkeypatch.setattr(w,'O',tmp_path);w.main()
    for name in ['RESULTS.json','mapped_spectra.csv','constituent_inverse.csv','source_response_matrix.csv','halfday_heldout.csv','signal_protection.csv']:
        assert (O/'data'/name).read_bytes()==(tmp_path/'data'/name).read_bytes(),name
    assert json.loads((tmp_path/'verification/NUMERIC_CHECK.json').read_text())['status']=='PASS'
