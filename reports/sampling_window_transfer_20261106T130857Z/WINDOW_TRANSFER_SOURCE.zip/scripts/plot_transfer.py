"""Geometry, held-period validation and actual daily-band subtraction."""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(O/'vendor'))
from audit_panel_alignment import require_matplotlib_panel_alignment
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans'],'font.size':7,'axes.labelsize':7,'axes.titlesize':7.3,'xtick.labelsize':6.5,'ytick.labelsize':6.5,'legend.fontsize':6.5,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'legend.frameon':False})
blue='#126080';orange='#bc651f';green='#50816c'
c=pd.read_csv(O/'data/coupling_matrix.csv');h=pd.read_csv(O/'data/halfday_heldout.csv');s=pd.read_csv(O/'data/mapped_spectra.csv')
def letter(ax,label):ax.annotate(label,(0,1),xycoords='axes fraction',xytext=(-15,10),textcoords='offset points',fontweight='bold',fontsize=9)
def save(fig,name):
    fig.savefig(O/'figures'/(name+'.pdf'))
    fig.savefig(O/'figures'/(name+'.svg'))
    fig.savefig(O/'figures'/(name+'.png'),dpi=600)
    plt.close(fig)
def density(ax,low,high,held=False):
    z=s[s.frequency_uHz.between(low,high)]
    pred='heldout_semidiurnal_prediction' if held else 'predicted_semidiurnal_leakage';rem='after_heldout_semidiurnal' if held else 'after_semidiurnal'
    ax.plot(z.frequency_uHz,z.observed_potential_PSD_per_uHz,color=blue,lw=.85,label='Observed')
    ax.plot(z.frequency_uHz,z[pred+'_potential_PSD_per_uHz'],color=green,lw=.8,label='Predicted half-day contribution')
    ax.plot(z.frequency_uHz,z[rem+'_potential_PSD_per_uHz'],color=orange,ls='--',lw=.85,label='After coherent subtraction')
    ax.set(xlim=(low,high),ylim=(0,None),xlabel='Frequency (µHz)',ylabel='Potential power density\n[(m²/s²)²/µHz]')
    ax.legend(loc='lower left',bbox_to_anchor=(0,1.04),ncol=3)
    sec=ax.secondary_yaxis('right',functions=(lambda x:x/299792458.0**4/1e-35,lambda x:x*1e-35*299792458.0**4))
    sec.set_ylabel('Fractional-frequency density\n(10⁻³⁵/µHz)');sec.spines['right'].set_visible(True)
fig=plt.figure(figsize=(180/25.4,145/25.4));a=fig.add_axes([.13,.64,.29,.25]);b=fig.add_axes([.61,.64,.29,.25]);d=fig.add_axes([.13,.12,.74,.30]);ca=fig.add_axes([.44,.64,.016,.25])
source=['M2','S2','N2','K2'];target=['K1','O1','P1','Q1'];m=c.pivot(index='source',columns='target',values='max_phase_power_coupling').loc[source,target].to_numpy()*100
im=a.imshow(m,origin='upper',aspect='auto',cmap='Blues',vmin=0,vmax=2)
a.set(xticks=range(4),xticklabels=['K₁','O₁','P₁','Q₁'],yticks=range(4),yticklabels=['M₂','S₂','N₂','K₂'],xlabel='Daily target',ylabel='Half-day source')
for i in range(4):
    for k in range(4):a.text(k,i,f'{m[i,k]:.2f}',ha='center',va='center',fontsize=6.5,color='white' if m[i,k]>1.2 else 'black')
fig.colorbar(im,cax=ca).set_label('Maximum power coupling (%)',fontsize=6.5)
a.set_title('Window geometry',loc='left',pad=14)
x=np.arange(8);b.axhline(0,color='.6',lw=.7);b.plot(x,h.reduction_fraction*100,'o',color=blue,ms=3)
b.set(xticks=x,xticklabels=h.period,xlim=(-.5,7.5),ylim=(-1.5,8.7),xlabel='Held-out observing period',ylabel='Weighted residual reduction (%)')
b.set_title('Half-day prediction: 7 of 8 improve',loc='left',pad=14)
density(d,9.5,12.5)
for ax,l in [(a,'a'),(b,'b'),(d,'c')]:letter(ax,l)
fig.canvas.draw();require_matplotlib_panel_alignment(fig,json_out=O/'verification/mapping_alignment.json',overlay_svg=O/'verification/mapping_alignment.svg',axes=[a,b,d],panel_ids=['a','b','c'],row_groups=[['a','b']],strict=True)
save(fig,'mapping_and_daily_transfer')
fig=plt.figure(figsize=(180/25.4,72/25.4));a=fig.add_axes([.14,.22,.72,.55]);density(a,21,24.5,held=True)
save(fig,'halfday_heldout_spectrum')
print('Two diagnostic figures generated from all 3299 real observation rows.')
