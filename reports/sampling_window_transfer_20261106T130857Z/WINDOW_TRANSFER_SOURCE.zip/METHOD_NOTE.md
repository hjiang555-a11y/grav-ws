# Mapping an interrupted observing window between tidal bands

Exploratory technical note on the fixed author-review observation design

## Result

The actual observing window predicts a transferable, phase-dependent response between frequency bands. Known half-day probes agree with direct sampling to numerical precision. On measured data, a half-day prediction fitted to seven observing periods reduces weighted residuals in seven of the eight held-out periods; the pooled reduction is 3.151%. Applying the same window to the daily band removes a calculable half-day contribution. The correctly projected daily-group coefficient remains 0.678 with a working standard error of 0.359, identical to the existing joint physical fit. This is a sampling diagnostic, not a new daily-tide detection.

## Observations and fixed rules

All 3,299 ten-minute rows, 54 segments, eight periods and 545.924 h of retained nominal one-second members are used. Calendar time extends from September 2025 to August 2026. Actual UTC gaps, stored relative noise weights and period constants are preserved. No observation is supplied in a missing interval. The fixed solid-effective-potential and loading template is inherited unchanged; its daily-band solid-model approximation remains outside this correction.

The half-day constituents are M2, S2, N2 and K2; the daily constituents are K1, O1, P1 and Q1. Frequencies and astronomical arguments are fixed, including nodal corrections. The main model retains three grouped amplitudes. Separate constituent quadratures are an exploratory inverse-response diagnostic only.

## The mapping

Let $Z$ contain period indicators and $W$ the stored inverse-variance weights. The residual operator is

$$M_Z=I-Z(Z^T WZ)^{-1}Z^T W.$$

Let $H_f$ contain cosine and sine columns at trial frequency $f$, evaluated only at the observed times. The amplitude response to an input pair at $g$ is

$$K(f,g)=(H_f^T W M_Z H_f)^{-1}H_f^T W M_Z H_g.$$

This is a two-by-two amplitude-and-phase map, not a power-subtraction rule. Astronomical source columns include nodal factors and arguments. The retained response array covers 9.5--12.5 and 21--24.5 microhertz. The full operator includes weighted period removal; simply translating an unweighted Fourier window would omit that step.

For fixed source constituents, independent two-quadrature scans satisfy $b=K a+\eta$. Solving their response system returns the same coefficients as simultaneous weighted harmonic regression. It adds no independent measurements. A dense unrestricted spectrum cannot be uniquely recovered across missing intervals without further assumptions. Window aliases and deconvolution limitations are discussed by VanderPlas (2018); complex-amplitude CLEAN methods have a related motivation (Roberts et al., 1987).

## Half-day verification and migration

Synthetic probes only test the algebra: known constituent quadratures and period offsets are evaluated on the real timestamps. They are never added to the observation table. Mapping predictions agree with independent direct least-squares scans at all nine named test frequencies.

For measured-data validation, each entire period is held out. The other seven estimate the two half-day amplitudes while protecting the fixed daily template by the same nuisance projection. The omitted-period prediction uses those training amplitudes, fixed phases and its actual timestamps. Seven periods improve; P1 worsens by 0.402%. The pooled weighted residual reduction is 3.151%. Overlapping training sets prevent treating 7/8 as an independent binomial significance test.

The identical mapping is then applied to the daily band. A half-day waveform has a daily projection because of the observation window. Subtraction acts coherently on the waveform or the two-quadrature amplitudes. If $L_f$ is the scan operator and $G_f$ its Gram matrix,

$$P(y)=P(s)+P(y-s)+2(L_fs)^T G_f L_f(y-s).$$

The cross term may be negative. Removing a contaminating waveform can therefore increase power at an individual frequency, as occurs near P1 in these data.

| Constituent   |   Observed |   Predicted half-day leakage |   After coherent subtraction |
|:--------------|-----------:|-----------------------------:|-----------------------------:|
| K1            |   0.030830 |                     0.002809 |                     0.019489 |
| O1            |   0.000522 |                     0.000176 |                     0.000093 |
| P1            |   0.012873 |                     0.000587 |                     0.015507 |
| Q1            |   0.046455 |                     0.000141 |                     0.041754 |

The density unit is $(\mathrm{m^2/s^2})^2$/µHz. The fixed-grid average of nominal daily density falls by 14.44% after same-record half-day subtraction. This is a descriptive scan statistic, not a Parseval noise-variance reduction or independently calibrated sensitivity gain. Uncertainty in the fitted half-day waveform must remain in subsequent inference.

## Protecting the weak signal

In period-centred, whitened coordinates, let $S$ be the strong half-day design and $d$ the daily template. Set $M_S=I-S(S^TS)^{-1}S^T$. Correct strong-first estimation uses

$$\widehat A_D=\frac{(M_Sd)^T(M_Sy)}{(M_Sd)^T(M_Sd)}.$$

The same projection acts on template and data; covariance follows the complete linear operator. This is identical to the joint fit. Projecting only the observations attenuates a daily injection by $d^TM_Sd/(d^Td)$, equal to 0.994772 on this design. Correct projection returns unit response.

An isolated daily fit gives 0.8133 before accounting for half-day mixing. The full response gives 0.6779, with scaled-LS/day-jackknife working error 0.3586 and period-jackknife error 0.4118. No precision improvement over the existing joint estimator is claimed. The individual-frequency inverse is numerically well conditioned after normalization, but the daily estimates remain imprecise.

## What can be predicted

The window determines how a specified signal appears at other frequencies. It does not determine a realization of random clock or transfer noise. With an independently supported noise covariance $C$, spectral covariance is $L_f C L_g^T$: a statistical prediction, not a known additive waveform. Unknown laboratory effects and model discrepancies remain possible in the residual. The present contribution is measured-window validation and explicit leakage accounting.

\clearpage

![](figures/mapping_and_daily_transfer.png){width=180mm}

**Figure 1 | Geometry, validation and daily-band application.** **a,** Maximum phase-dependent squared-norm projection between half-day sources and daily targets on the weighted, period-centred observations. Values are geometric coupling percentages, not fractions of observed noise. **b,** Weighted residual change in every held-out period after a half-day prediction trained on the other seven. The fixed daily template is protected by the specified projection. **c,** Daily density of all 3,299 rows, the daily projection of the fitted half-day waveform, and observations after coherent subtraction. These curves share data. The two axes obey $S_W=c^4S_y$. Changes include interference and do not establish an independent daily detection.

\clearpage

![](figures/halfday_heldout_spectrum.png){width=180mm}

**Figure 2 | Half-day validation with predictions from other periods.** Original weighted projection density, the half-day waveform assembled from held-out predictions, and the remaining density after coherent subtraction. Actual UTC gaps and original weights are preserved. Each period's amplitudes were estimated without its observations. Training sets and spectral ordinates remain correlated. No frequency or source phase was retuned to improve agreement.

## References

1. VanderPlas, J. T. Understanding the Lomb--Scargle periodogram. *Astrophys. J. Suppl. Ser.* **236**, 16 (2018). https://doi.org/10.3847/1538-4365/aab766
2. Roberts, D. H., Lehar, J. & Dreher, J. W. Time series analysis with CLEAN. I. Derivation of a spectrum. *Astron. J.* **93**, 968 (1987). https://doi.org/10.1086/114383
