"""Release checks: source identity, numerical invariants, one-chain prose and renders."""
from pathlib import Path
import json,re,hashlib,sys,importlib.metadata,subprocess
import numpy as np
import pandas as pd
import fitz
from docx import Document

O=Path(__file__).resolve().parents[1];R=O/'render_v72_final';checks=[]
def check(name,ok,detail=''):
    checks.append(dict(name=name,passed=bool(ok),detail=detail))
    if not ok:print('FAILED',name,detail)
j=json.loads((O/'data/PRIMARY_RESULTS.json').read_text());b=pd.read_csv(O/'sources/bins.csv');r=pd.read_csv(O/'data/primary_rows.csv')
for n,h in j['input_sha256'].items():check('unchanged input '+n,hashlib.sha256((O/'sources'/n).read_bytes()).hexdigest()==h)
csv_delta=float(np.max(np.abs(b.y.to_numpy()-r.y.to_numpy())))
check('all observed rows retained',len(b)==len(r)==3299 and np.allclose(b.y,r.y,rtol=0,atol=1e-12),{'max_CSV_serialization_difference_in_1e18_units':csv_delta,'input_identity_verified_separately_by_SHA256':True})
check('annual-span main support',set(b.period)=={f'P{x}' for x in range(1,9)} and abs(b.n.sum()/3600-545.9241666666667)<1e-10 and b.seg.nunique()==54)
check('primary arithmetic',np.max(abs(np.array(j['primary']['A'])-[.9865534280086422,1.1290981367762234,.6779266362233434]))<1e-10)
check('primary errors',np.allclose(j['primary']['u'],np.maximum(j['primary']['scaled_ls'],j['primary']['day_jackknife']),rtol=0,atol=1e-14))
check('period sensitivity not hidden',j['primary']['period_jackknife'][0]>j['primary']['u'][0])
m=j['monitor'];check('monitor distinct subset',m['support']['rows']==1482 and m['support']['periods']==['P6','P7','P8'] and m['support']['retained_member_hours']<j['sample_hours'])
check('monitor paired lunar delta',abs(m['delta'][0]-.006407606621343653)<1e-10)
fold=pd.read_csv(O/'data/phase_fold.csv');V=pd.read_csv(O/'data/phase_covariance.csv').to_numpy()
check('all phase support',fold.n_rows.sum()==3299 and fold.n_seconds.sum()==b.n.sum())
check('propagated covariance',np.allclose(fold.se**2,np.diag(V)) and np.linalg.matrix_rank(V)==11)
s=pd.read_csv(O/'data/primary_spectra.csv',float_precision='round_trip')
for name in ['observed','residual','fitted_tide']:
    check(name+' PSD units',np.allclose(s[name+'_potential_PSD_per_uHz'],s[name+'_fractional_PSD_per_uHz']*299792458.0**4,rtol=5e-13,atol=1e-25))
    check(name+' ASD square',np.allclose(s[name+'_potential_ASD_per_sqrt_uHz']**2,s[name+'_potential_PSD_per_uHz'],rtol=5e-12,atol=1e-25))
check('independent SI spectral regressions',max(x['relative_difference'] for x in j['spectrum']['unit_checks'])<1e-9)
check('no synthetic gap rows',j['spectrum']['gap_fill'] is False and len(r)==len(b))
t=(O/'NATURE_ARTICLE_v72.md').read_text();main=t.split('## Main text\n')[1].split('## Methods')[0];ab=t.split('## Abstract\n')[1].split('## Main text')[0]
check('single main reduction',not re.search(r'\b(?:R7|v68|v71|v29|0\.97|474)\b',ab+main))
check('author-requested general title',t.splitlines()[0]=='# Tidal potential measured on a coastal–inland optical-clock baseline')
check('plain-language constituent explanation','### What the tidal names mean' in t and 'not a purely solar measurement' in t)
check('short monitoring does not replace fit','the main fit continues to use all eight periods' in main.lower())
check('no false completed direct-potential replay','not a degree- and frequency-resolved direct-potential reconstruction' in t)
check('no unsupported laboratory noise bound','not a pure instrumental noise floor' in t)
check('no placeholders in mathematical body',not re.search(r'\{\{|\[@',t))
refsection=t.split('## References\n')[1].split('## Figure legends')[0]
refs=re.findall(r'^\d+\. (.+)$',refsection,re.M)
check('reference parser restricted to bibliography',len(refs)==20 and 'Ludlow' in refs[0] and all(('http' in x) for x in refs))
seen=[]
pre_refs=t.split('## Abstract')[1].split('## References')[0]
for m0 in re.finditer(r'\^(\d+(?:,\d+)*)\^',pre_refs):
    for x in map(int,m0.group(1).split(',')):
        if x not in seen:seen.append(x)
check('citations in first-use order',seen==list(range(1,21)),str(seen))
fig_order=[]
for x in re.findall(r'(?:Fig\.|Figure) (\d+)',main):
    if x not in fig_order:fig_order.append(x)
check('main figure first-use order',fig_order==['1','2','3','4'])
wc=json.loads((O/'verification/TEXT_STRUCTURE.json').read_text())
check('abstract at most 150 words',wc['abstract']<=150,str(wc['abstract']))
check('legends below 250 words',all(n<250 for _,n in wc['legends']))
for name in ['figure1','figure2','figure3','figure4','ed_figure1','ed_figure2']:
    for ext in ['pdf','svg','png']:check('figure file '+name+'.'+ext,(O/'figures'/(name+'.'+ext)).is_file())
    qa=json.loads((O/'verification'/(name+'_collisions.json')).read_text())
    check('collision '+name,qa['summary']['fail']==qa['summary']['warn']==0)
check('source figure QA',json.loads((O/'verification/figure_source.json').read_text())['summary']['ready'])
build=json.loads((R/'BUILD_RESULTS.json').read_text());check('pdf and Word compiled',build['status']=='BUILT_FOR_REVIEW')
doc=fitz.open(R/'NATURE_ARTICLE_v72.pdf');pt='\n'.join(p.get_text() for p in doc)
check('PDF complete',len(doc)>=15 and all(x in pt for x in ['What the tidal names mean','246.6','545.9','Ludlow','NOAA']))
check('PDF lacks failed bibliography entries','1. Campaign time series.' not in pt)
check('PDF font/render log',not re.search(r'Missing character|Undefined control|Error', (R/'pdf.log').read_text(),re.I))
d=Document(R/'NATURE_ARTICLE_v72.docx');check('editable tables',len(d.tables)==4,str(len(d.tables)))
xml=(R/'NATURE_ARTICLE_v72.docx')
import zipfile
with zipfile.ZipFile(xml) as z:wordxml=z.read('word/document.xml')
check('Word equations native',wordxml.count(b'<m:oMath>')>10)
env={'python':sys.version,'executable':sys.executable,'packages':{n:importlib.metadata.version(n) for n in ['numpy','pandas','scipy','pyTMD','matplotlib','cartopy','shapely','PyMuPDF','python-docx']}}
(O/'verification/ENVIRONMENT.json').write_text(json.dumps(env,indent=2))
result=dict(status='PASS' if all(c['passed'] for c in checks) else 'FAIL',checks=checks,pdf_pages=len(doc),main_numeric_scope='Selected saved-input estimator and displays; no fresh raw selection or global geophysical convolution',scientific_submission_clearance=False,author_decision_required=True)
(O/'verification/FINAL_CHECK.json').write_text(json.dumps(result,indent=2));print(json.dumps({'status':result['status'],'checks':len(checks),'pages':len(doc)}))
if result['status']!='PASS':raise SystemExit(1)
