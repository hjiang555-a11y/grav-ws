"""Only the user-authorized private repository; never overwrite differing files."""
from pathlib import Path
import subprocess,json,hashlib,base64
import requests
O=Path(__file__).resolve().parents[1];R=O/'render_v72_final'
for n in ['FINAL_CHECK.json','CLEAN_REPLAY.json','PACKAGE_CHECK.json']:assert json.loads((O/'verification'/n).read_text())['status']=='PASS'
repo='hjiang555-a11y/grav-ws';prefix='reports/merge_v68_r7_codex_v72_20261106T1211Z/'
t=subprocess.run(['gh','auth','token','--hostname','github.com','--user','hjiang555-a11y'],capture_output=True,text=True,timeout=20)
if t.returncode:raise RuntimeError('Owner authentication unavailable')
s=requests.Session();s.headers.update({'Authorization':'Bearer '+t.stdout.strip(),'Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28'})
base='https://api.github.com/repos/'+repo
def api(path,method='GET',body=None):return s.request(method,base+path,json=body,timeout=(15,90))
r=api('');r.raise_for_status();meta=r.json();assert meta['private'] and meta['full_name']==repo
branch=meta['default_branch'];receipts=[]
files=[R/'NATURE_ARTICLE_v72.pdf',R/'NATURE_ARTICLE_v72.docx',O/'NATURE_ARTICLE_v72.md',O/'V72_REVISION_REPORT.md',O/'V72_MANUSCRIPT_SOURCE.zip',O/'NATURE_SELF_REVIEW.md',O/'COVER_LETTER_DRAFT.md',O/'figures/figure3.pdf']
for f in files:
    data=f.read_bytes();h=hashlib.sha256(data).hexdigest();gs=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    dest=prefix+f.name;path='/contents/'+dest;r=api(path+'?ref='+branch);commit=None
    if r.status_code==404:
        r=api(path,'PUT',{'branch':branch,'message':'docs: deliver v72 annual-span tidal manuscript '+f.name,'content':base64.b64encode(data).decode()})
        r.raise_for_status();obj=r.json()['content'];commit=r.json()['commit']['sha']
    else:r.raise_for_status();obj=r.json()
    assert obj['sha']==gs and obj['size']==len(data),'Existing remote content differs; no overwrite'
    row=dict(file=str(f.relative_to(O)),sha256=h,remote_git_blob=gs,remote_size=len(data),commit=commit,url=f'https://github.com/{repo}/blob/{branch}/{dest}',verification='Git blob and byte length match; SHA256 locally recorded')
    if len(data)<3000000:
        rb=api('/git/blobs/'+gs);rb.raise_for_status();raw=base64.b64decode(rb.json()['content']);assert hashlib.sha256(raw).hexdigest()==h
        row['readback_sha256']=h;row['verification']='Full decoded remote readback SHA256 and Git blob identity'
    receipts.append(row);(O/'PRIVATE_DELIVERY_PROGRESS.json').write_text(json.dumps(receipts,indent=2));print('Verified private content: '+f.name,flush=True)
(O/'PRIVATE_DELIVERY.json').write_text(json.dumps(dict(status='PRIVATE_V72_DELIVERED',private=True,external_submission=False,primary_estimator='single R7 P8/Allan chain',files=receipts),indent=2))
