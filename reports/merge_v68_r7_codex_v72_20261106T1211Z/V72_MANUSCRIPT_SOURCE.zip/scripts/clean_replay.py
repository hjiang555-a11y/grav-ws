"""Replay the deliverable from a separate folder, without raw observations."""
from pathlib import Path
import shutil,subprocess,os,json,hashlib,sys,time
import fitz
import numpy as np
O=Path(__file__).resolve().parents[1];C=O/'verification/clean_replay'
C.mkdir(exist_ok=False)
for name in ['sources','data','scripts','vendor']:
    shutil.copytree(O/name,C/name,ignore=shutil.ignore_patterns('__pycache__'))
for name in ['manuscript_template.md','render_working.py','layout_working.lua']:
    shutil.copy2(O/name,C/name)
(C/'figures').mkdir();(C/'verification').mkdir()
for p in (O/'verification').glob('*.json'):shutil.copy2(p,C/'verification'/p.name)
env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1');runs=[]
for args in [['scripts/recompute_primary.py'],['scripts/draw_figures.py'],['scripts/assemble_article.py'],['render_working.py','NATURE_ARTICLE_v72.md','render_v72_final'],['scripts/verify_final.py']]:
    start=time.monotonic();name=Path(args[0]).stem
    with (C/'verification'/(name+'.log')).open('w') as f:
        r=subprocess.run([sys.executable,'-B',*args],cwd=C,env=env,stdout=f,stderr=subprocess.STDOUT)
    runs.append(dict(command=args,returncode=r.returncode,elapsed_seconds=time.monotonic()-start))
    print(name,r.returncode,flush=True)
    if r.returncode:raise RuntimeError(str(C/'verification'/(name+'.log')))
# Exact machine outputs, not merely rounded manuscript numbers.
comparisons=[]
for name in ['PRIMARY_RESULTS.json','primary_rows.csv','phase_fold.csv','phase_covariance.csv','leave_period.csv','primary_spectra.csv','nominal_spectrum.csv','error_table.csv','offset_table.csv','coverage_table.csv']:
    a=(O/'data'/name).read_bytes();b=(C/'data'/name).read_bytes()
    assert a==b,name
    comparisons.append(dict(file='data/'+name,sha256=hashlib.sha256(b).hexdigest(),identity='byte exact'))
assert (O/'NATURE_ARTICLE_v72.md').read_bytes()==(C/'NATURE_ARTICLE_v72.md').read_bytes()
a=fitz.open(O/'render_v72_final/NATURE_ARTICLE_v72.pdf');b=fitz.open(C/'render_v72_final/NATURE_ARTICLE_v72.pdf')
assert len(a)==len(b)==19
assert [p.get_text() for p in a]==[p.get_text() for p in b]
# Compare rendered page pixels, excluding variable PDF creation metadata.
for pa,pb in zip(a,b):assert pa.get_pixmap().samples==pb.get_pixmap().samples
j=dict(status='PASS',directory=str(C),runs=runs,comparisons=comparisons,markdown_byte_exact=True,pdf_pages=19,pdf_text_exact=True,pdf_render_pixels_exact=True,raw_counters_required=False,scope='Replay from frozen derived rows and physical templates; does not regenerate raw masks or global geophysical grids')
(O/'verification/CLEAN_REPLAY.json').write_text(json.dumps(j,indent=2));print('Clean replay PASS',flush=True)
