"""Arithmetic-only coverage replay; creates no new simulated observations."""
from pathlib import Path
import numpy as np
import pandas as pd
O=Path(__file__).resolve().parents[1]
expected=pd.read_csv(O/'data/R7_saved_simulation_recount.csv').set_index('scenario')
files=sorted((O/'sources/conditional_simulations/draws').glob('*.npz'))
assert len(files)==13
for p in files:
    with np.load(p) as z:
        assert set(z.files)=={'target_error','u_ls','u_jk','u_max'}
        assert len(z['target_error'])==10000
        np.testing.assert_array_equal(z['u_max'],np.maximum(z['u_ls'],z['u_jk']))
        coverage=np.mean(np.abs(z['target_error'])<=1.959963984540054*z['u_max'])
        assert coverage==expected.loc[p.stem,'coverage_95_working']
        assert abs(z['target_error'].mean()-expected.loc[p.stem,'bias'])<1e-15
print('PASS: all 13 archived scenarios / 130000 draws; no fresh simulations.')
