"""Create a versioned, byte-verified author-review bundle."""
from pathlib import Path
import hashlib,json,zipfile
O=Path(__file__).resolve().parents[1]
assert json.loads((O/'verification/FINAL_CHECK.json').read_text())['status']=='PASS'
assert json.loads((O/'verification/CLEAN_REPLAY.json').read_text())['status']=='PASS'
roots=['sources','data','scripts','vendor','figures']
files=[p for name in roots for p in (O/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
files += [O/name for name in ['NATURE_ARTICLE_v72.md','manuscript_template.md','render_working.py','layout_working.lua','REPRODUCE.md','PLAN.md','V72_REVISION_REPORT.md','NATURE_SELF_REVIEW.md','COVER_LETTER_DRAFT.md','INPUT_MANIFEST.json']]
files += list((O/'verification').glob('*.json'))
files += [O/'render_v72_final'/name for name in ['NATURE_ARTICLE_v72.pdf','NATURE_ARTICLE_v72.docx','BUILD_RESULTS.json','pdf.log']]
files=sorted(set(files))
manifest=dict(version='v72',scope='author-review manuscript, derived-data replay and figures; no original counter files',files=[dict(path=str(p.relative_to(O)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),bytes=p.stat().st_size) for p in files])
M=O/'PACKAGE_MANIFEST.json';M.write_text(json.dumps(manifest,indent=2))
Z=O/'V72_MANUSCRIPT_SOURCE.zip'
with zipfile.ZipFile(Z,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in files+[M]:z.write(p,p.relative_to(O).as_posix())
with zipfile.ZipFile(Z) as z:
    for row in manifest['files']:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
result=dict(status='PASS',files=len(files),bytes=Z.stat().st_size,zip_sha256=hashlib.sha256(Z.read_bytes()).hexdigest(),members_all_read_back=True,raw_counters_included=False,clean_replay='verification/CLEAN_REPLAY.json')
(O/'verification/PACKAGE_CHECK.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
