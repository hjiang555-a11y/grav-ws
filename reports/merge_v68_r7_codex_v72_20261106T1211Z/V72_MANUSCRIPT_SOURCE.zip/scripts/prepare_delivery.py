"""Freeze provenance and prepare an author-review package, without raw counters."""
from pathlib import Path
import json,hashlib,shutil,datetime
import numpy as np
import pandas as pd
O=Path(__file__).resolve().parents[1];B=O.parent;ROOT=B.parents[1];PEER=B.parent/'opencode'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
copies=[]
def copy(src,dest):
    src=Path(src);dest=O/dest;dest.parent.mkdir(parents=True,exist_ok=True)
    if dest.exists():assert digest(src)==digest(dest),str(dest)
    else:shutil.copy2(src,dest)
    copies.append(dict(source=str(src),copy=str(dest.relative_to(O)),sha256=digest(dest),bytes=dest.stat().st_size))
copy(ROOT/'research/tidal-spring/gpu_otl_prem.json','sources/loading_phasors_18.json')
copy(ROOT/'research/tidal-spring/love_prem.py','sources/loading_kernel_reference.py')
copy(PEER/'R7_HANDOFF.md','sources/R7_HANDOFF.md')
copy(PEER/'data/raw_support/source_manifest.json','sources/raw_archive_manifest.json')
copy(PEER/'data/raw_support/segment_ledger.csv','sources/raw_segment_ledger.csv')
copy(PEER/'data/zero_point_boundaries.csv','sources/zero_point_boundaries.csv')
copy(B/'INPUTS.json','sources/original_draft_inputs.json')
S=B/'sources/R7_tree/paper/nature/opencode-period-offset-20261105/source-data/r6'
for name in ['rules_snapshot.json','seeds.json','scenario_metrics.csv','summary.json','REPLAY.md','provenance.json']:
    copy(S/name,'sources/conditional_simulations/'+name)
for p in sorted((S/'draws').glob('*.npz')):copy(p,'sources/conditional_simulations/draws/'+p.name)
# Derived reference diagnostics retain their original source identity.
for name in ['R7_phase_fold_recomputed.csv','R7_phase_covariance.csv','R7_leave_period_recomputed.csv','R7_saved_simulation_recount.csv','R7_controlled_bridge.csv','RECOMPUTED_DIAGNOSTICS.json']:
    p=B/'data'/name
    if p.exists():
        assert digest(p)==digest(O/'data'/name)
        copies.append(dict(source=str(p),copy='data/'+name,sha256=digest(p),role='prior independent saved-input check, rechecked where used'))
# Bind already frozen main inputs to the immutable R7 archive, not a moving tree.
for name in ['bins.csv','template.csv','constituents.csv','evidence.json']:
    p=B/'sources/R7_tree/paper/nature/opencode-period-offset-20261105/source-data'/name
    assert p.exists() and digest(p)==digest(O/'sources'/name)
    copies.append(dict(source=str(p),copy='sources/'+name,sha256=digest(p),role='selected primary chain'))
for name,src in [('monitor_fits.json','fits.json'),('monitor_fit_coefficients.csv','fit_coefficients.csv'),('monitor_monitor_rows.csv','monitor_rows.csv'),('monitor_run_manifest.json','run_manifest.json')]:
    p=PEER/'data/instrument_controls'/src
    assert digest(p)==digest(O/'sources'/name)
    copies.append(dict(source=str(p),copy='sources/'+name,sha256=digest(p),role='same-member summer control'))
# No simulations generated: arithmetic recount of supplied compact draw arrays.
old=pd.read_csv(O/'data/R7_saved_simulation_recount.csv').set_index('scenario');recount=[]
for p in sorted((O/'sources/conditional_simulations/draws').glob('*.npz')):
    with np.load(p) as z:
        assert set(z.files)=={'target_error','u_ls','u_jk','u_max'}
        assert len(z['target_error'])==10000 and np.all(np.isfinite(z['target_error']))
        np.testing.assert_allclose(z['u_max'],np.maximum(z['u_ls'],z['u_jk']),rtol=0,atol=0)
        cov=float(np.mean(np.abs(z['target_error'])<=1.959963984540054*z['u_max']));bias=float(z['target_error'].mean())
        assert cov==old.loc[p.stem,'coverage_95_working']
        assert abs(bias-old.loc[p.stem,'bias'])<1e-15
        recount.append(dict(scenario=p.stem,n=10000,coverage95=cov,bias=bias,sha256=digest(p)))
(O/'verification/SIMULATION_RECOUNT.json').write_text(json.dumps(dict(status='PASS',fresh_draws=0,stored_draws=130000,scenarios=recount),indent=2))
all_inputs=[dict(path=str(p.relative_to(O)),sha256=digest(p),bytes=p.stat().st_size) for p in sorted((O/'sources').rglob('*')) if p.is_file()]
manifest=dict(version='v72',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),R7_commit='27de8630633648feea8fc874e1f629b741f19fe6',copies=copies,inputs=all_inputs,
    scope='Independent replay of supplied derived observations and saved physical templates; archived simulations recounted; original raw selection and spatial loading convolution not rerun in v72.',
    raw_data_included=False,raw_archive_reference='sources/raw_archive_manifest.json',original_drafts='sources/original_draft_inputs.json',author_handoff='sources/R7_HANDOFF.md',
    remaining_physical_checks=['full degree/frequency resolved solid potential','period-internal interruption zero levels and time-dependent clock corrections','complete spatial-loading regeneration with original grids'])
(O/'INPUT_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
b=pd.read_csv(O/'sources/bins.csv');b['month_UTC']=pd.to_datetime(b.t_utc,utc=True).dt.strftime('%Y-%m')
m=b.groupby('month_UTC').agg(rows=('n','size'),members=('n','sum'));m['hours']=m.members/3600;m.to_csv(O/'data/month_support.csv')
j=json.loads((O/'data/PRIMARY_RESULTS.json').read_text());v=json.loads((O/'verification/FINAL_CHECK.json').read_text())
month_table=m.reset_index().to_markdown(index=False,floatfmt='.3f')
text=f'''# v72 科研主稿与技术闭环记录

2026-11-06；Codex 独立目录。英文正文、Methods、四幅主图、两幅扩展图、可编辑表格与投稿信草稿已生成。本文是供作者决策的审阅稿，未投稿。

## 主估计器与选择依据

采用 R7 的一条完整可追溯归算：3299 行观测，54 段，8 个 period 常数，Allan-based 相对权重，固定天文相位三组模板；误差为 scaled LS 与按 UTC 日删除 jackknife 的较大值。全文展示这一条链，不与 v68 平均、不转移其误差或实测对照。

依据是输入/模板/权重/算子齐备，独立 QR 回放一致，且同数据同权重改为 54 段常数时月球响应仍为 1.0004±0.1320。选择不意味着已证明所有跨中断零点连续，也不意味着 0.99 因接近 1 而更正确。用户确认将其作为主展示；最终物理近似仍须作者接受。

研究单位是一条沪汉钟比较的重复观测，并非3299次独立实验。按日和按期重算用来检查相关误差；分组、重复归算和两篇论文不能合并显著性。

## 全年支撑与短光纤对照

- 主拟合：545.924167 h，1965327 个名义1 s成员，3299个箱，54段、8期、43个UTC观测日期。首末箱中心为2025-09-06 16:05 UTC与2026-08-26 01:25 UTC，跨度353.389日。
- 实际有观测的月份为2025年9、10月和2026年1、4、5、6、7、8月。**跨全年跨度，不是12个月逐月有数据；2025年11、12月及2026年2、3月无入选观测。** 没有填充这些时间空缺。
- 光纤对照仅P6–P8的246.633889 h、1482行，2026-06-29至2026-08-25。同支撑加/不加监测回归检验被监测传输通道，主拟合始终保留全年数据。

{month_table}

时数来自名义1 s成员计数，不把3299×600 s或首末跨度冒充有效积分时间。54段与29组的原始对应见sources/raw_segment_ledger.csv。

## 主要结果与摘要溯源

| 量 | 本轮独立回放 | 文件与估计器 |
|---|---:|---|
| 月球组 M2+N2 | {j['primary']['A'][0]:.6f} ± {j['primary']['u'][0]:.6f} | data/PRIMARY_RESULTS.json → primary，P8/Allan三组联合 |
| 邻近半日组 S2+K2 | {j['primary']['A'][1]:.6f} ± {j['primary']['u'][1]:.6f} | 同一联合估计；K2有日月共同作用 |
| 全日组 | {j['primary']['A'][2]:.6f} ± {j['primary']['u'][2]:.6f} | 同一联合估计，不给未经校准的单侧上限 |
| 月球/邻近半日相关 | {j['primary']['corr'][0][1]:.6f} | 同一scaled-LS协方差 |
| 负荷/合成预测RMS | {100*j['loading_rms_fraction']:.3f}% | 同一权重、去period均值的预测范数；不是测出独立负荷 |
| 光纤回归月球尺度变化 | {j['monitor']['delta'][0]:.6f} ± {j['monitor']['paired_day_se'][0]:.6f} | 同一246.6h成员支撑，误差保留配对协方差 |

摘要逐项来源另见sources/ABSTRACT_CLAIMS.json，输入SHA256见INPUT_MANIFEST.json。误差为工作标准误，并非所有系统项已纳入的置信区间。保存的13×10000次条件模拟重计数通过，月球名义95%区间覆盖94.16%–97.79%；本轮没有新生成模拟观测，也没有把这些场景当实际噪声的完整认证。

## 吸收与重算

保留R7全记录相位图思路，观测与单位模板使用相同干扰投影；12箱全部3299点、支持数与传播协方差齐全。I/Q、早期/夏季、逐期删除、三种误差来源和同成员监测均用同一主设计重算。主图谱也改为同一P8/Allan权重；旧版无权谱没有挪来混用。v68仅继续提供写作框架、已给定机构和背景引文；其0.97、温度0.98、474h与负荷0.89并未移入这条链。

题目去掉Lunar；Methods新增通俗分潮解释。正文突出两组半日响应与相位覆盖，光纤只是短时实测对照。日周期谱与等效势幅度密度在Extended Data。Hou的重叠夏季观测与独立同期Stahl预印本按研究内容披露，不按上线日期主张优先。

## 醒目提示与闭环状态

**已解决：单位和来源。** PSD每Hz改每µHz必须乘10^-6；势PSD乘c^4，ASD乘c^2。9个天文/日频率的独立SI回归校验通过，左右坐标与源表一致。CSV序列化的最大小差为约1.4×10^-14（以10^-18为单位），原始输入SHA256不变。参考文献解析曾误读目录，已修复并逐项核对最终PDF。

**重要限制：谱峰不能逐峰认定。** 当前主权重谱M2附近最大值约22.3619µHz；12h附近局部最大值约23.0934µHz，未恰在S2的23.1481µHz。实际观测窗与权重形成旁瓣，两频率间最大相位依赖功率泄漏11.8%。两组响应由同时拟合的天文模板鉴别，未把任意峰或扣模板后的谱当独立探测。

**仍需作者确认：物理与实验日志。** 固体部分使用h2=0.6078、k2=0.3010位移换有效势近似，不冒称已复算完整直接势；日带K1的既有约18%差异保留在Methods。只改半日k22的有界检查使AL改变+0.0030，不能当完整模板误差上限。P8跨中断零点和随时间变化的钟修正仍需运行记录。所有旧数据与报告保持只读，未产生fit接续的长期稳定度。

## 验收与交付

- {len(v['checks'])}项源数据身份、数值、谱单位、相位协方差、引用顺序、图文和编译检查全部通过：verification/FINAL_CHECK.json。
- 四幅主图及两幅扩展图的字体、碰撞、可比面板对齐与人工目视检查通过。主图PDF/SVG保留矢量元素；密集观测散点为声明的栅格层。
- 单轮主笔Nature自审见NATURE_SELF_REVIEW.md，不冒充额外独立审稿。
- 英文可编辑源：NATURE_ARTICLE_v72.md；Word/PDF：render_v72_final/；图源与数据：figures/、data/。
- 从干净副本复算的结果见verification/CLEAN_REPLAY.json；运行方法见REPRODUCE.md，版本见verification/ENVIRONMENT.json。
- 当前验证从已保存派生观测开始。先前42原文件成员回放由移交材料提供，本轮没有重新执行原始筛选或全球FES空间卷积。原始依赖位置与SHA256随清单保留；不把局部通过说成整个实验链无待项。

作者、贡献、基金、利益冲突、编辑可访问数据地址/永久存档，以及上述实验/物理事项由作者确认。未自动投稿。按既有授权仅交付私有grav-ws版本目录；是否上传成功以PRIVATE_DELIVERY.json为准。
'''
(O/'V72_REVISION_REPORT.md').write_text(text)
print(json.dumps(dict(source_files=len(all_inputs),stored_simulations_recounted=130000,months=m.index.tolist(),hours=float(m.hours.sum()))))
