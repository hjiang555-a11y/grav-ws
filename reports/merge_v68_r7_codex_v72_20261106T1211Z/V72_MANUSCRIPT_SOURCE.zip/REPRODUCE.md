# v72：单一归算主稿的复现范围

此目录由 Codex 单独维护，原始计数器、原稿、其他工作树和科研服务未改动。

主设计为固定 R7 提供的 3,299 行观测 / 8 period 截距 / Allan-based 相对权重 / 现行固体与负荷模板。正文和四幅主图均使用这一条链。`sources/editorial_source_v68.md` 仅为参考文献和已给定单位的编辑来源，不提供本版主文数值、观测点或图形。

现有可用解释器：`/home/room115/pytorch_env/bin/python`。运行时设置 `OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 PYTHONDONTWRITEBYTECODE=1`。以下命令应在本目录的新工作副本运行；旧交付目录保持不动。

```bash
python -B scripts/recompute_primary.py
python -B scripts/draw_figures.py
python -B scripts/assemble_article.py
python -B render_working.py NATURE_ARTICLE_v72.md render_new
```

最后一条要求输出目录尚不存在。需要 Pandoc、XeLaTeX、python-docx；数值及图形依赖见 `verification/ENVIRONMENT.json`。图中地图使用随包的 Natural Earth 110 m 陆地边界，光纤连线是示意路线。图源保持 PDF/SVG，PNG 用于预览和 Word；两个 Extended Data 图为300 dpi，其余 PNG 为600 dpi。

`recompute_primary.py` 重新验算已给定派生数据上的主拟合、逐日/逐期误差、54段/29组对照、I/Q、完整同投影相位图、共同监测支撑和频谱。计算不生成任何补入缺测时刻的观测值。频谱密度归一化和 SI 单位独立检验保存在 `data/PRIMARY_RESULTS.json`。

本包不是从零执行全部原始文件读取、FES 全球卷积和固体潮生成的完整归档。42个原始计数器的先前回放与成员对账已在同事移交记录核验；本轮不声称重新运行全部原始选择。空间负荷卷积未重跑；固体潮的固定位移换算不是直接势重建。原始支撑与生成记录绝对路径、版本及哈希另列 `INPUT_MANIFEST.json`。上述范围不得被渲染成功或图形检查替代。

主拟合包括全年跨度的545.924小时；246.634小时仅是夏季光纤控制的共同有效支撑。两者必须分别引用。投稿前仍需作者确认实验日志、作者声明、数据访问地址和模板近似的最终接受范围。

保存模拟的区间覆盖可直接复核，不需新生成模拟：

```bash
python -B scripts/recount_archived.py
```

全部13组紧凑draw数组、规则和种子保存在sources/conditional_simulations/。该步骤仅重新计数已保存结果；原完整生成程序的归档位置由该目录的provenance.json记录。

已执行的干净工作副本回放见verification/CLEAN_REPLAY.json。重跑逐行数值/谱/表格应精确相同；PDF创建时间等元数据可不同，验收比较正文和页面渲染。FINAL_CHECK.json中的科学投稿许可仍为false：数值和文稿检查不能代替实验记录与作者确认。
