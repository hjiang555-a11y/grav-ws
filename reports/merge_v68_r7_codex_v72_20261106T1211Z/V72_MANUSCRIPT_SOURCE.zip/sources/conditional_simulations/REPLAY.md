# R6 saved-design conditional stress module

Run commands from the repository root, or the root extracted from
`out/v1/replay-package.zip`. The package retains the same repository-shaped
paths, includes the original estimator and reused branch modules, and needs
no raw clock inputs or global model grids. The saved bins table is included
unchanged for hash verification; R6 excludes `y` and `y_relative` when parsing it.

## Runtime and tests

The executed environment uses `/home/room115/pytorch_env/bin/python3`.
`environment.json` gives the full installed distribution inventory, Python
version and NumPy build configuration. Required runtime libraries include
NumPy, pandas, SciPy and pyTMD; pytest is needed for tests. The paths can be
adapted to an equivalent environment after checking those versions.

```bash
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 /home/room115/pytorch_env/bin/python3 -m pytest -q -p no:cacheprovider --basetemp=/tmp/opencode/r6-package-tests research/opencode-period-offset-20261105/tests/test_r6_conditional.py
```

## Arithmetic replay (no new random draws)

```bash
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 PYTHONPATH=research/opencode-period-offset-20261105 /home/room115/pytorch_env/bin/python3 -m revision_r6.run_conditional --replay research/opencode-period-offset-20261105/revision_r6/out/v1
```

This checks the SHA256 of every compact NPZ, verifies that it contains exactly
`target_error,u_ls,u_jk,u_max`, recomputes **all** scenario metrics and demands
exact JSON arithmetic equality. NPZ arrays have 10,000 entries in draw order;
the draw index and scenario ID are implicit, so no simulated observations are
retained. Signed target error is `Ahat_L - 1`.

## Full regeneration (130,000 new draws with the recorded seeds)

```bash
PYTHONDONTWRITEBYTECODE=1 OPENBLAS_NUM_THREADS=1 PYTHONPATH=research/opencode-period-offset-20261105 /home/room115/pytorch_env/bin/python3 -m revision_r6.run_conditional --out-dir /tmp/opencode/r6-package-regeneration
```

The output directory must not already exist. The adopted rules are immutable;
the runner supplies no scenario, seed, budget or uncertainty-rule overrides.
The original scientific command omitted `--out-dir`, creating the default
`research/opencode-period-offset-20261105/revision_r6/out/v1/`. Regeneration
should reproduce draw arrays and scientific metrics in the pinned environment;
timestamps, runtime, environment paths and consequently the summary/package
hash are execution-specific.

## Inventory and verification

- `artifact_inventory.json`: exact relative paths, byte lengths and SHA256 of
  all delivered output artifacts except itself. Its own hash is returned by
  the runner.
- `package_members.json` and ZIP `PACKAGE_MANIFEST.json`: exact archived
  member paths, byte lengths and SHA256 (manifest self excluded).
- `summary.json`: all 13 definitions, moments, MC metrics, seed states and
  source/code bindings. `scenario_metrics.csv` flattens every scenario field.
- `analytic.json`: covariance/expected-error moments computed before MC.
- `draws/*.npz` and `scenarios/*.json`: all 13 compact draw sets and scenario
  records, including any invalid realizations.
- `operators.npz`: full design, weights, fixed waveform, H, Q, centered and
  uncentered padded deletion responses, row times/membership and sample counts.
- `day_support.csv`, `verification.json`: all 43 support/rank checks, saved h
  identity and direct original-estimator synthetic checks.
- `instrumental.json`, `instrument_{groups,periods,partitions,solar}.csv`:
  signed deterministic derivatives, units and symbolic propagation.
- `seeds.json`, `environment.json`, `provenance.json`, `rules_snapshot.json`:
  actual RNG mapping, environment and frozen input identities.
- `REPORT.md`: complete outcomes, allowed interpretation, remaining assessment
  and explicit process/numerical choices.
- `arithmetic_replay.json`: execution-time compact-draw replay result.
- `replay-package.zip`: all of the above scientific evidence (excluding the
  outer inventory/ZIP), three saved tables, primary/R4 evidence and saved h,
  reviewed R5 PDF, adopted/review rules, R6 tests/code and reused source modules.

This is finite-law conditional performance on a selected bin-centred design,
not certification of actual noise, instrumental uncertainty or the whole
selection/weight-estimation procedure. Independent scientific assessment is
still required before broader claims.
