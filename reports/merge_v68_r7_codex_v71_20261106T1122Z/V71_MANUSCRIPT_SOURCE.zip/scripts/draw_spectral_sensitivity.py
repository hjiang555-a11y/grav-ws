"""Physical-unit background at daily and half-daily periods, all measured samples."""
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.insert(0,'/home/room115/.codex/skills/nature-figure/scripts')
from audit_panel_alignment import require_matplotlib_panel_alignment

O=Path(__file__).resolve().parents[1]
d=pd.read_csv(O/'data/spectral_amplitude_density.csv')
nom=pd.read_csv(O/'data/nominal_amplitude_density.csv').set_index('constituent')
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans'],'font.size':8,
    'axes.labelsize':8,'axes.titlesize':8,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,
    'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,
    'axes.linewidth':.7,'legend.frameon':False})
blue='#126080';orange='#b75b19'
fig,axes=plt.subplots(2,1,figsize=(180/25.4,145/25.4))
fig.subplots_adjust(left=.16,right=.83,top=.84,bottom=.11,hspace=.58)
for ax,band,limits,targets,letter in zip(axes,['diurnal','semidiurnal'],[(9.5,12.5),(21,24.5)],
        [['Q1','O1','P1','K1'],['M2','S2']],['a','b']):
    for series,color,label in [('observed',blue,'Observed'),('residual',orange,'Residual, fixed tide prediction')]:
        s=d[(d.band==band)&(d.series==series)]
        ax.plot(s.frequency_uHz,s.potential_ASD_per_sqrt_uHz,color=color,lw=.8,ls='-' if series=='observed' else '--',label=label)
    ax.set_xlim(*limits);ax.set_ylim(0,.55);ax.set_yticks([0,.2,.4])
    ax.set_xlabel('Frequency (µHz)')
    ax.set_ylabel('Potential amplitude density\n[(m²/s²)/√µHz]')
    sec=ax.secondary_yaxis('right',functions=(lambda x:x/299792458.0**2/1e-18,
        lambda x:x*1e-18*299792458.0**2))
    sec.set_ylabel('Fractional-frequency amplitude density\n(10⁻¹⁸/√µHz)',labelpad=6)
    sec.set_yticks([0,2,4,6]);sec.spines['right'].set_visible(True)
    for target in targets:
        f=nom.loc[target,'frequency_uHz'];ax.axvline(f,color='.65',ls='--',lw=.6,ymax=.83)
        label=target.replace('1','₁').replace('2','₂')
        # Nearby P1/K1 labels use their own true frequencies, with opposite anchors.
        ha='right' if target=='P1' else 'left' if target=='K1' else 'center'
        ax.text(f,.515,label,ha=ha,va='center')
    ax.annotate(letter,xy=(0,1),xycoords='axes fraction',xytext=(-12,10),textcoords='offset points',fontweight='bold',fontsize=9)
    ax.set_title('Daily periods' if band=='diurnal' else 'Half-daily periods',loc='left',pad=10)
fig.legend(*axes[0].get_legend_handles_labels(),loc='upper center',bbox_to_anchor=(.5,.975),ncol=2)
fig.canvas.draw()
require_matplotlib_panel_alignment(fig,json_out=O/'figures/ed_figure1.alignment.json',
    overlay_svg=O/'figures/ed_figure1.alignment.svg',axes=axes,panel_ids=['a','b'],strict=True)
for ext in ['pdf','svg']:fig.savefig(O/f'figures/ed_figure1.{ext}')
fig.savefig(O/'figures/ed_figure1.png',dpi=300)
plt.close(fig)

# Same measured diurnal data, displaying the effect of only the fixed strong band.
fig,ax=plt.subplots(figsize=(180/25.4,82/25.4))
fig.subplots_adjust(left=.16,right=.83,top=.72,bottom=.20)
for series,color,style,label in [('observed',blue,'-','Observed'),('semidiurnal_residual','#7b4a8d',':','After fixed half-daily prediction'),('residual',orange,'--','After fixed full prediction')]:
    s=d[(d.band=='diurnal')&(d.series==series)]
    ax.plot(s.frequency_uHz,s.potential_PSD_per_uHz,color=color,ls=style,lw=.9,label=label)
ax.set_xlim(11.4,11.75);ax.set_ylim(0,.07);ax.set_yticks([0,.02,.04,.06])
ax.set_xlabel('Frequency (µHz)');ax.set_ylabel('Potential power density\n[(m²/s²)²/µHz]')
sec=ax.secondary_yaxis('right',functions=(lambda v:v/299792458.0**4/1e-35,lambda v:v*1e-35*299792458.0**4))
sec.set_ylabel('Fractional-frequency power density\n(10⁻³⁵/µHz)',labelpad=6);sec.spines['right'].set_visible(True)
for target,label in [('P1','P₁'),('S1','24 h'),('K1','K₁')]:
    f=nom.loc[target,'frequency_uHz'];ax.axvline(f,color='.65',ls='--',lw=.6,ymax=.85);ax.text(f,.064,label,ha='center')
fig.legend(*ax.get_legend_handles_labels(),loc='upper center',bbox_to_anchor=(.5,.985),ncol=1)
fig.savefig(O/'figures/ed_figure2.pdf');fig.savefig(O/'figures/ed_figure2.svg');fig.savefig(O/'figures/ed_figure2.png',dpi=300)
plt.close(fig)
