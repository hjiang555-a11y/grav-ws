"""Verify the manuscript, reversible spectral transforms and frozen provenance."""
from pathlib import Path
import hashlib,json,re,subprocess,zipfile
import numpy as np
import pandas as pd
import fitz
from lxml import etree

O=Path(__file__).resolve().parents[1];R=O/'render_v71_03'
src=O/'NATURE_ARTICLE_v71_WORKING.md';text=src.read_text();old=(O/'sources/NATURE_ARTICLE_v70_WORKING.md').read_text()
checks={}
manifest=json.loads((O/'INPUTS.json').read_text())['files']
checks['inputs_and_copies_unchanged']=all(hashlib.sha256(Path(r['source']).read_bytes()).hexdigest()==r['sha256']==hashlib.sha256((O/r['copy']).read_bytes()).hexdigest() for r in manifest)
build=json.loads((R/'BUILD_RESULTS.json').read_text())
checks['pdf_docx_clean_build']=len(build['builds'])==2 and all(x['exit']==0 and x['warnings']=='' for x in build['builds'])
checks['built_source_current']=build['source_sha256']==hashlib.sha256(src.read_bytes()).hexdigest()
abstract=text.split('## Abstract',1)[1].split('## Main text',1)[0]
main=text.split('## Main text',1)[1].split('## References',1)[0]
methods=text.split('## Methods\n',1)[1].split('## Methods references',1)[0]
checks['abstract_under_150']=len(abstract.split())<=150
checks['methods_under_3000_guideline']=len(methods.split())<3000
checks['no_figures_tables_in_methods']='![](' not in methods and not re.search(r'(?m)^\|',methods)
checks['four_main_two_ed_figures']=len(re.findall(r'!\[.*?\]\(figures/figure',text))==4 and len(re.findall(r'!\[.*?\]\(figures/ed_figure',text))==2
checks['ed_display_count_within_ten']=len(re.findall(r'\*\*Extended Data (?:Table|Fig\.) \d+ \|',text))==6
legends=re.findall(r'\*\*(?:Fig\.|Extended Data Fig\.) \d+ \|[\s\S]+?(?=\n\n)',text)
checks['legends_under_300_words']=len(legends)==6 and max(map(lambda s:len(s.split()),legends))<300
def refs(t):return {int(n):s for n,s in re.findall(r'(?m)^(\d+)\. (.+)$',t)}
checks['existing_references_unchanged']=refs(text)==refs(old)
seen=[]
for group in re.findall(r'\^([\d,]+)\^',main+'\n'+methods):
    for n in map(int,group.split(',')):
        if n not in seen:seen.append(n)
checks['first_citation_order']=seen==list(range(1,24))
checks['author_statements_after_methods_references']=text.index('### Author statements')>text.index('## Methods references')
checks['working_scientific_status_explicit']='WORKING DRAFT v71' in text and 'no final common estimator is declared' in text
checks['no_new_noise_floor_claim']='not an independently calibrated minimum detectable potential' in methods
checks['calendar_is_not_exposure']='would count unobserved time as exposure' in methods
checks['diurnal_scope_clear']='daily-band spectrum is less distinctive' in main and 'increases power by a factor of 2.005' in methods
checks['sidelobes_in_main']='sidelobes of the observation window' in main
d=pd.read_csv(O/'data/spectral_amplitude_density.csv');c2=299792458.0**2
checks['amplitude_density_squared_matches_power']=bool(np.allclose(d.potential_ASD_per_sqrt_uHz**2,d.potential_PSD_per_uHz,rtol=1e-12,atol=1e-16))
checks['dual_ASD_axes_c_squared']=bool(np.allclose(d.fractional_ASD_per_sqrt_uHz*c2,d.potential_ASD_per_sqrt_uHz,rtol=1e-12,atol=1e-16))
checks['sqrt_Hz_conversion']=bool(np.allclose(d.potential_ASD_per_sqrt_Hz,d.potential_ASD_per_sqrt_uHz*1000,rtol=1e-12,atol=1e-16))
nom=pd.read_csv(O/'data/nominal_amplitude_density.csv')
checks['table_all_seven_frequencies']=len(nom)==7
for _,r in nom.iterrows():
    label='24 h' if r.constituent=='S1' else r.constituent
    expected=f'| {label} | {r.frequency_uHz:.6f} | {r.observed_potential_ASD_per_sqrt_uHz:.4f} | {r.residual_potential_ASD_per_sqrt_uHz:.4f} | {r.residual_fractional_ASD_per_sqrt_uHz/1e-18:.4f} |'
    checks['table_'+r.constituent+'_source_bound']=expected in text
for name in ['figure3','ed_figure1','ed_figure2']:
    checks[name+'_glyphs']=json.loads((O/f'verification/{name}_glyphs.json').read_text())['minimum_found_pt']>=5
    checks[name+'_no_collisions']=json.loads((O/f'verification/{name}_collisions.json').read_text())['verdict']=='PASS'
for name in ['figure3','ed_figures']:
    checks[name+'_source_ready']=json.loads((O/f'verification/{name}_source.json').read_text())['summary']['ready']
for name in ['figure3','ed_figure1']:
    checks[name+'_alignment']=json.loads((O/f'figures/{name}.alignment.json').read_text())['verdict']=='PASS'
ast=json.loads(subprocess.check_output(['pandoc',str(src),'-t','json']))
def maths(x):
    if isinstance(x,list):return sum(map(maths,x))
    if isinstance(x,dict):return int(x.get('t')=='Math')+sum(map(maths,x.values()))
    return 0
with zipfile.ZipFile(R/(src.stem+'.docx')) as z:
    root=etree.fromstring(z.read('word/document.xml'))
    word_math=len(root.xpath('//*[local-name()="oMath"]'))
    tables=len(root.xpath('//*[local-name()="tbl"]'));drawings=len(root.xpath('//*[local-name()="drawing"]'))
checks['native_word_math']=word_math==maths(ast)
checks['six_images_four_native_tables']=drawings==6 and tables==4
pdf=fitz.open(R/(src.stem+'.pdf'));pages=[];clipped=[];inspect=[]
for i,page in enumerate(pdf):
    txt=page.get_text();pages.append({'page':i+1,'characters':len(txt)})
    if i==0 or any(s in txt for s in ['Semidiurnal amplitudes, phase','Spectral background and measurement','Potential-equivalent spectral background.','How the strong half-daily prediction','Spectral levels at prescribed']):inspect.append(i)
    for b in page.get_text('dict')['blocks']:
        for line in b.get('lines',[]):
            for span in line['spans']:
                if span['text'].strip() and not page.rect.contains(fitz.Rect(span['bbox'])):clipped.append({'page':i+1,'text':span['text']})
checks['no_clipped_pdf_text']=not clipped
checks['no_blank_pdf_pages']=min(p['characters'] for p in pages)>100
for i in inspect:pdf[i].get_pixmap(matrix=fitz.Matrix(1.25,1.25)).save(O/f'verification/page_{i+1}.png')
result={'status':'PASS' if all(checks.values()) else 'FAIL','scope':'Editorial, figure, and derived-unit validation; not final primary-estimator approval',
    'checks':{k:bool(v) for k,v in checks.items()},'abstract_words':len(abstract.split()),'main_words':len(main.split()),
    'methods_words':len(methods.split()),'main_figures':4,'ed_figures':2,'ed_tables':4,
    'native_word_math':word_math,'pages':pages,'visual_review_pages':[i+1 for i in inspect], 'clipped':clipped,
    'accepted_figure_warnings':'PDF/SVG are vector deliverables. PNG is preview; ED previews are deliberately 300 dpi.',
    'scientific_pending':'Matched v68 direct-potential/filter/resampling chain, common-estimator decision, author declarations and public/reviewer data location.',
    'external_submission':False}
(O/'verification/FINAL_CHECK.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2));assert result['status']=='PASS'
