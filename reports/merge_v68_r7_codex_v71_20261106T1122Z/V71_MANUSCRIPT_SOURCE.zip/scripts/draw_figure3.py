"""Figure 3: named group estimates, R7 phase, and audited observed narrow-band PSD."""
from pathlib import Path
import json
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.insert(0, '/home/room115/.codex/skills/nature-figure/scripts')
from audit_panel_alignment import require_matplotlib_panel_alignment

O=Path(__file__).resolve().parents[1]
j=json.loads((O/'data/RECOMPUTED_DIAGNOSTICS.json').read_text())
d=pd.read_csv(O/'data/annual_spectrum_dual_units.csv')
info=json.loads((O/'data/ANNUAL_SPECTRUM_RESULTS.json').read_text())
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans'],'font.size':7.5,'axes.labelsize':7.5,
 'axes.titlesize':7.5,'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,
 'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,
 'axes.spines.right':False,'axes.linewidth':.7,'legend.frameon':False})
blue='#126080';grey='#666666';orange='#b75b19'
fig=plt.figure(figsize=(178/25.4,132/25.4))
a=fig.add_axes([.19,.57,.26,.29])
b=fig.add_axes([.64,.57,.21,.29])
c=fig.add_axes([.19,.12,.66,.28])
yy=np.arange(3)[::-1]
a.axvline(0,color='.8',lw=.6);a.axvline(1,color='.5',ls='--',lw=.7)
a.errorbar([.97,.90,.35],yy+.10,xerr=[.14,.29,.51],fmt='D',mfc='white',
 mec=grey,ecolor=grey,capsize=2,ms=4,label='Segment reduction')
a.errorbar(j['R7_primary']['A'],yy-.10,xerr=j['R7_primary']['u'],fmt='o',
 color=blue,capsize=2,ms=3.8,label='Period reduction')
a.set_yticks(yy,['Lunar M₂ + N₂','Near-12 h S₂ + K₂','Diurnal group'])
a.set_ylim(-.5,2.5);a.set_xlim(-.3,1.6);a.set_xticks([0,.5,1,1.5])
a.set_xlabel('Group response coefficient')
a.legend(loc='lower left',bbox_to_anchor=(.02,1.03),ncol=1)
iq=j['R7_IQ']
b.axhline(0,color='.8',lw=.6);b.axvline(1,color='.8',lw=.6)
b.errorbar(iq['A'][0],iq['A'][1],xerr=iq['u'][0],yerr=iq['u'][1],fmt='o',ms=4,capsize=3,color=blue)
b.plot(1,0,'+',ms=7,color='black');b.set_xlim(.60,1.35);b.set_ylim(-.55,.22)
b.set_xlabel('Lunar in-phase response');b.set_ylabel('Lunar quadrature response')
b.set_title('Period reduction · lunar phase',loc='left',pad=12)
c.plot(d.frequency_uHz,d.observed_potential_PSD_m4_sminus4_per_uHz,color=blue,lw=.85,label='Observed')
c.plot(d.frequency_uHz,d.residual_potential_PSD_m4_sminus4_per_uHz,color=orange,lw=.9,ls='--',label='Residual, fixed tide prediction')
c.set_xlim(21,24.5);c.set_xticks(np.arange(21,24.51,.5));c.set_ylim(0,.24);c.set_yticks([0,.1,.2])
c.set_xlabel('Frequency (µHz)');c.set_ylabel('Potential power density\n[(m²/s²)²/µHz]')
secondary=c.secondary_yaxis('right',functions=(lambda v:v/299792458.0**4/1e-35,lambda v:v*1e-35*299792458.0**4))
secondary.set_ylabel('Fractional-frequency power density\n(10⁻³⁵/µHz)',labelpad=6)
secondary.set_yticks([0,1,2]);secondary.spines['right'].set_visible(True)
c.legend(loc='lower left',bbox_to_anchor=(0,1.12),ncol=2,handlelength=1.5,columnspacing=1.3)
for key,label in [('M2','M₂ · 12.42 h'),('S2','S₂ · 12.00 h')]:
 f=info['frequency_Hz'][key]*1e6
 c.axvline(f,color='#888888',ls='--',lw=.65,ymax=.81)
 c.text(f,.218,label,ha='center',va='center',color=blue)
for ax,letter in zip([a,b,c],'abc'):
 ax.annotate(letter,xy=(0,1),xycoords='axes fraction',xytext=(-12,7),
  textcoords='offset points',fontweight='bold',fontsize=9,va='bottom')
fig.canvas.draw()
np.testing.assert_allclose(secondary.get_ylim(),np.array(c.get_ylim())/299792458.0**4/1e-35,rtol=1e-13)
require_matplotlib_panel_alignment(fig,json_out=O/'figures/figure3.alignment.json',
 overlay_svg=O/'figures/figure3.alignment.svg',axes=[a,b,c],panel_ids=['a','b','c'],row_groups=[['a','b']],strict=True)
fig.savefig(O/'figures/figure3.pdf')
fig.savefig(O/'figures/figure3.svg')
fig.savefig(O/'figures/figure3.png',dpi=600)
plt.close(fig)
