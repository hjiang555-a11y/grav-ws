"""Re-express verified measured spectra; no new fit or sensitivity threshold."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

O = Path(__file__).resolve().parents[1]
C = 299792458.0
annual = pd.read_csv(O/'data/annual_spectrum_dual_units.csv')
daily = pd.read_csv(O/'data/diurnal_spectra.csv')
info = json.loads((O/'data/ANNUAL_SPECTRUM_RESULTS.json').read_text())
curves = []
for band, frame, columns in [
    ('diurnal', daily, {'observed':'observed_potential_PSD_per_uHz', 'residual':'residual_fixed_full_potential_PSD_per_uHz', 'semidiurnal_residual':'residual_fixed_semidiurnal_potential_PSD_per_uHz'}),
    ('semidiurnal', annual.loc[annual.frequency_uHz.between(21,24.5)], {'observed':'observed_potential_PSD_m4_sminus4_per_uHz','residual':'residual_potential_PSD_m4_sminus4_per_uHz'}),
]:
    for series, col in columns.items():
        psd = frame[col].to_numpy()
        assert np.isfinite(psd).all() and (psd >= 0).all()
        asd = np.sqrt(psd)
        np.testing.assert_allclose(asd**2, psd, rtol=2e-15, atol=0)
        curves.append(pd.DataFrame({'band':band,'series':series,'frequency_uHz':frame.frequency_uHz,
            'potential_PSD_per_uHz':psd,'potential_ASD_per_sqrt_uHz':asd,
            'fractional_ASD_per_sqrt_uHz':asd/C**2,'potential_ASD_per_sqrt_Hz':asd*1000}))
out = pd.concat(curves,ignore_index=True)
out.to_csv(O/'data/spectral_amplitude_density.csv',index=False)
rows=[]
for name in ['M2','S2','Q1','O1','P1','S1','K1']:
    f=(1/86400 if name=='S1' else info['frequency_Hz'][name])*1e6
    band='semidiurnal' if name in ['M2','S2'] else 'diurnal'
    row={'constituent':name,'frequency_uHz':f}
    for series in ['observed','residual']:
        frame=out[(out.band==band)&(out.series==series)]
        i=int(np.argmin(abs(frame.frequency_uHz.to_numpy()-f)))
        match=frame.iloc[i]
        assert abs(match.frequency_uHz-f)<1e-12, 'Use exact nominal frequency, never a nearby extremum'
        row[series+'_potential_ASD_per_sqrt_uHz']=float(match.potential_ASD_per_sqrt_uHz)
        row[series+'_fractional_ASD_per_sqrt_uHz']=float(match.fractional_ASD_per_sqrt_uHz)
    rows.append(row)
nominal=pd.DataFrame(rows)
nominal.to_csv(O/'data/nominal_amplitude_density.csv',index=False)
result={'status':'PASS','source_bins':3299,'source_segments':54,'new_primary_fit':False,
    'spectral_curves_recomputed':False,'transformation':'ASD=sqrt(PSD), ASD_W=c^2 ASD_y; per sqrt(Hz) is 1000 times per sqrt(uHz)',
    'fractional_1e_minus18_equivalent_potential_m2_per_s2':C**2*1e-18,
    'nominal_frequency_table':rows,
    'interpretation':'Frequency-resolved potential-equivalent background, not a calibrated instrument noise floor or minimum detectable tide.',
    'no_calendar_span_noise_integration':True}
(O/'data/SPECTRAL_SENSITIVITY.json').write_text(json.dumps(result,indent=2)+'\n')
print(nominal.to_string(index=False))
