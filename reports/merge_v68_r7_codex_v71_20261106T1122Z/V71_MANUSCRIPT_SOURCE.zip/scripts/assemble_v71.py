"""Compose the source-bound Article; preserve both existing response estimators."""
from pathlib import Path
import re
import pandas as pd

O=Path(__file__).resolve().parents[1]
t=(O/'sources/NATURE_ARTICLE_v70_WORKING.md').read_text()
t=t.replace('WORKING DRAFT v70 — spectrum-led v68/R7 synthesis, 6 November 2026.',
 'WORKING DRAFT v71 — physical-unit spectra and measurement sensitivity, 6 November 2026.')
t=t.replace('its measured-record spectral analysis is incorporated here.',
 'its measured-record spectral analysis and the diurnal-band diagnostic are incorporated here.')
start=t.index('Optical clocks can compare',t.index('## Main text'))
end=t.index('### A coastal–inland clock comparison',start)
t=t[:start]+r'''An optical-clock network can sense Earth's gravitational potential by comparing how fast time passes at different sites.^1,2^ Phase-stabilized fibres carry clock signals between laboratories, extending this comparison across a landscape.^3,4^ Static potential differences have been measured with laboratory, transportable and fibre-connected clocks.^5,6,7,8^ Following a changing potential adds a different challenge: the clock-rate variation must be distinguished from changes in the clocks and the connections between them.^9,10,11^ A fractional rate change of $10^{-18}$ corresponds to a potential difference of about 0.09 m²/s², providing a common physical scale for the clock signal and its residual background.

Tides provide a natural test with timing set by celestial motion. The Moon and Sun change the potential directly, deform the solid Earth and move ocean water. Two strong rhythms are close together: lunar M2 repeats every 12.42 h and solar S2 every 12 h. Their relative phase drifts with date. Observing across that drift allows their contributions to be estimated separately, even when the clock comparison is interrupted.^12^

Here we compare coastal Shanghai with inland Wuhan. The geographical contrast makes ocean loading a substantial part of the predicted potential difference. We estimate the lunar M2+N2 and neighbouring S2+K2 responses jointly, with their astronomical phase and relative amplitude fixed within each group. K2 contains lunar and solar forcing. The approximately daily K1+O1+P1+Q1 group is included in the same model. This tests two prescribed half-daily patterns without first subtracting an empirical daily waveform.

'''+t[end:]
t=t.replace('Expressing the vertical axis as equivalent-potential density connects the clock record to the physical quantity being tested; the right axis retains fractional-frequency density.',
 'The left axis expresses power per unit frequency as an equivalent gravitational-potential variation; the right axis gives exactly the same signal in fractional clock-rate units. This places the two half-daily features and their surrounding background on one physical scale.')
t=t.replace('The two local maxima remain in conditional scans that account for the other frequency (Methods).',
 'The two local maxima remain when the other frequency is included in the scan (Methods).')
anchor='The phase fold, quadrature fit and frequency scan provide complementary views of the same observations, with their distinct projections and uncertainty definitions retained.'
assert anchor in t
t=t.replace(anchor,anchor+'\n\n'+r'''The daily-band spectrum is less distinctive and does not identify separate daily constituents (Methods and Extended Data Figs. 1 and 2). Frequency-resolved background levels are reported in potential units, with their relation to measurement sensitivity described in Methods.''')
# A physical-unit spectrum is the same measurement in another coordinate, not another experiment.
t=t.replace('The left axis gives nominal equivalent-potential PSD in (m²/s²)²/µHz and the right gives the same quantity as fractional-frequency PSD in 10⁻³⁵/µHz.',
 'The left axis gives equivalent-potential power per µHz, in (m²/s²)²/µHz; the right gives the same signal as fractional-frequency power per µHz. The two axes are related by the fixed factor c⁴.')
t=t.replace('Generalized least-squares periodograms distinguish the frequency response of this sampling from the periodic content of the measurements.',
 'Least-squares periodograms permit scanning the irregular timestamps; physical interpretation additionally requires the sampling-window response.')
anchor='The residual contains measurement noise together with any template error or unmodelled signal; it is not a separately calibrated instrumental noise floor.'
assert anchor in t
extra=r'''

### Spectral background and measurement sensitivity

For a physical-unit view of sensitivity, Extended Data Fig. 1 shows the amplitude density $D_W(f)=\sqrt{S_W(f)}$, in (m²/s²)/√µHz. Its right axis is $D_y=D_W/c^2$. These are square roots of the same measured power densities, not another estimator or a new selection of observations. A density per √µHz has a numerical value $10^{-3}$ times that per √Hz; power densities differ by $10^{-6}$. All conversions are performed before plotting. At the exact M2 and S2 frequencies, the fixed-prediction residual amplitude densities are 0.0774 and 0.0909 (m²/s²)/√µHz, respectively (Extended Data Table 4). The table reports prescribed frequencies, rather than choosing local minima as a sensitivity floor.

This frequency-resolved residual level is an empirical background against which a further signal would have to be distinguished. It includes measurement noise, any unmodelled signal and any error in the fixed prediction. It is not an independently calibrated minimum detectable potential. For stationary noise with a calibrated one-sided PSD and complete uniform observing time $T_{\mathrm{obs}}$, the standard error of a known-frequency sinusoidal quadrature is approximately $\sqrt{S_W^{(\mathrm{Hz})}(f)/T_{\mathrm{obs}}}$. Applying that approximation to the 353-day calendar span would count unobserved time as exposure.

For the actual sampling, let $H_f$ contain the scanned sine and cosine, $M_Z$ project out the segment constants and $C_y$ describe the noise covariance on the observed rows. The physical-unit coefficient covariance is instead

$$\operatorname{Cov}(\hat{\boldsymbol\beta}_W)=c^4K_f C_y K_f^T,\qquad K_f=(H_f^TM_ZH_f)^{-1}H_f^TM_Z.$$

This expression retains the sampling gaps, nuisance projection and correlation structure. A detectable-amplitude threshold also needs its phase, false-alarm and frequency-search conventions. We therefore report the residual density and the separately defined group-amplitude errors, without deriving a new detection limit from the plotted density. The inverse calendar span describes a frequency scale; the number, timing and covariance of accepted measurements determine amplitude precision.

### Diurnal-band and strong-signal leakage checks

The daily scan uses the same measured rows, segment projection, weights and normalization over 9.5–12.5 µHz. Exact Q1, O1, P1, K1 and 24-h frequencies are included in the grid. The local K1 maximum remains between 11.60765 and 11.61311 µHz under the specified intercept, weight and timestamp checks. The normalized P1/24-h/K1 sine–cosine design has condition number 3.26, so this diagnostic does not show severe rank deficiency.

At the exact K1 frequency, subtraction of only the fixed M2+N2+S2+K2 prediction reduces scan power by 64%; subtraction of the full prediction reduces it by 69% (Extended Data Fig. 2). At P1, full-prediction subtraction increases power by a factor of 2.005. These changes retain coherent cross terms and are not additive fractions of constituent power. They show why a residual peak or a reduction after subtraction cannot by itself identify a daily constituent. No individual-diurnal detection probability or upper limit is assigned. The fixed physical template in these checks remains the R7 implementation specified above.
'''
t=t.replace(anchor,anchor+extra)
t=t.replace("These complementary baselines show how geography and observing duration shape a clock network's sensitivity.",
 "These complementary baselines show how geography and observing duration shape a clock network's sensitivity. Expressing signal and residual background in potential units provides a common scale on which to compare them.")
t=t.replace('The residual contains measurement noise together with any template error or unmodelled signal; it is not a separately calibrated instrumental noise floor.', 'The residual contains measurement noise together with any template error or unmodelled signal; it is not a separately calibrated instrumental noise floor. The archived R7 spectrum uses a different diagnostic: weighted floating-mean, separately variance-normalized curves before and after a fitted two-band response. Those curves and their white-noise reference are not converted into the physical densities shown here.')
# Match Nature's ordering: methods references followed by the author declarations.
start=t.index('### Author statements');end=t.index('## Methods references')
statements=t[start:end].strip()
t=t[:start]+t[end:]
ed=t.index('\\clearpage\n\n## Extended Data')
t=t[:ed]+statements+'\n\n'+t[ed:]
# Additional displays are Extended Data, never embedded inside Methods.
t+=r'''

\clearpage

![](figures/ed_figure1.png){width=180mm}

**Extended Data Fig. 1 | Potential-equivalent spectral background.** **a,** Daily and **b,** half-daily frequency bands from the same 3,299 R7 observations used in the main spectrum. Blue shows the measured record and dashed orange the residual after subtraction of the fixed unit physical prediction. The vertical coordinate is the square root of the nominal power density, expressed as potential amplitude per square-root microhertz; the right axis is its exact fractional-frequency equivalent. Both panels use equal weights, 54 segment constants and recorded calendar times. All accepted observations are retained, and missing times are not filled. The shared vertical scale makes the two bands comparable. Dashed lines mark nominal astronomical frequencies. Curves have no confidence envelope: the residual level includes noise and possible prediction error, and is not a calibrated detection threshold. The same observations underlie both curves and panels.

\clearpage

![](figures/ed_figure2.png){width=180mm}

**Extended Data Fig. 2 | How the strong half-daily prediction affects the daily spectrum.** Blue shows the measured record near P1, exact 24 h and K1. Dotted purple follows subtraction of only the fixed M2+N2+S2+K2 prediction; dashed orange follows subtraction of the fixed full prediction. All curves use the same observed times and spectral operator as Fig. 3c. Subtraction is in the time domain, without refitting amplitudes or phases. At the exact K1 frequency, power decreases by 64% after half-daily subtraction and 69% after full subtraction; at P1 it increases after full subtraction. These are coherent scan-power changes, not additive power fractions or independent detection tests. Axes show potential and fractional-frequency power densities linked by c⁴. Individual daily-constituent assignments require the sampling response and phase information as well as peak position.

\clearpage

**Extended Data Table 4 | Spectral levels at prescribed astronomical frequencies.** All entries use the same measured rows and equal-weight segment-constant scan. Potential amplitude density is in (m²/s²)/√µHz; the fractional-frequency residual column is in 10⁻¹⁸/√µHz. Residuals follow subtraction of the fixed full physical prediction. Entries are descriptive amplitudes, not uncertainties, detection thresholds or independent estimates. Exact 24 h is a frequency reference, not a measured laboratory disturbance.

| Frequency label | Frequency / µHz | Observed potential amplitude density | Residual potential amplitude density | Residual fractional-frequency amplitude density |
|---|---:|---:|---:|---:|
'''
d=pd.read_csv(O/'data/nominal_amplitude_density.csv')
for _,r in d.iterrows():
    label='24 h' if r.constituent=='S1' else r.constituent
    t+=f'| {label} | {r.frequency_uHz:.6f} | {r.observed_potential_ASD_per_sqrt_uHz:.4f} | {r.residual_potential_ASD_per_sqrt_uHz:.4f} | {r.residual_fractional_ASD_per_sqrt_uHz/1e-18:.4f} |\n'
t+='\nThe nominal scan-density normalization is documented in Methods; it is not integrated as a continuous-year variance. This table does not supply a separate laboratory or clock noise budget.\n'
(O/'NATURE_ARTICLE_v71_WORKING.md').write_text(t)
abstract=t.split('## Abstract',1)[1].split('## Main text',1)[0]
main=t.split('## Main text',1)[1].split('## References',1)[0]
methods=t.split('## Methods\n',1)[1].split('## Methods references',1)[0]
print({'abstract_words':len(abstract.split()),'main_words':len(main.split()),'methods_words':len(methods.split())})
