# v71 manuscript source package

The package contains the editable English Markdown, vector/preview figures, native table content, build scripts, derived spectral source tables and the revision record. It is an author working manuscript, not a submitted paper or a completed common-estimator certification.

To rebuild the PDF and Word file, install/use Pandoc, XeLaTeX, python-docx and the specified DejaVu fonts, then run from this directory:

```sh
python render_working.py NATURE_ARTICLE_v71_WORKING.md render_rebuilt
```

Use a new output-directory name. This manuscript build is self-contained and uses supplied figures. It does not rerun the primary scientific analysis.

To regenerate the new spectral unit transforms and figure sources, use the recorded Python environment and run `scripts/spectral_sensitivity.py`, `scripts/assemble_v71.py`, `scripts/draw_figure3.py` and `scripts/draw_spectral_sensitivity.py`. Plot rendering uses the locally installed Nature figure alignment checker; its required path is explicit in the scripts. The full verification script also checks immutable inputs at their recorded workstation paths, so that provenance check requires the original workspace.

The inherited main figures are frozen artifacts. Raw counters, the colleague's PDF/source ZIP and full third-party tide-model inputs are excluded from this transferable package. The complete source identities and scientific limits are documented in the reports. No generated observations or gap filling are used.
