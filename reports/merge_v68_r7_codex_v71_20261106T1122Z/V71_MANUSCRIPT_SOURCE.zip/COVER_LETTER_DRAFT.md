Dear Editors,

Please consider “Tidal potential measured on a coastal–inland optical-clock baseline” as an Article. A fibre-linked comparison between coastal Shanghai and inland Wuhan tests changing gravitational potential where ocean loading makes a substantial contribution to the prediction. Observations across the drifting lunar–solar phase permit the lunar and neighbouring semidiurnal responses to be estimated jointly. Physical-unit spectra make the measured features and residual background accessible alongside the time-domain estimates; loading is not claimed as a separately resolved parameter.

Hou et al. (arXiv:2610.34250) report the absolute Yb/Sr ratio on the same link using overlapping summer observations. This Article addresses the tidal components in the extended interrupted record; it neither updates that ratio nor imports its earlier significance. Stahl et al. (arXiv:2610.39635) report independent, contemporaneous European network observations with complementary baselines and tidal mixtures. Both preprints are disclosed and cited according to their content. We understand that Nature Portfolio excludes preprints from prior publication and does not count preprint-server manuscripts when assessing the advance under consideration.

[Corresponding author, reviewer-accessible data/code location and final author approval to be completed before submission.]
