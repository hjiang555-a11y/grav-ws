# Lunar tide on a coastal–inland optical-clock link

[To be completed]

^1^ Hefei National Laboratory, University of Science and Technology of China, Hefei, China

^2^ Shanghai Research Center for Quantum Sciences and CAS Center for Excellence in Quantum Information and Quantum Physics, University of Science and Technology of China, Shanghai, China

^3^ Hefei National Research Center for Physical Sciences at the Microscale and School of Physical Sciences, University of Science and Technology of China, Hefei, China

^4^ Innovation Academy for Precision Measurement Science and Technology, Chinese Academy of Sciences, Wuhan, China

^5^ Jinan Institute of Quantum Technology and CAS Center for Excellence in Quantum Information and Quantum Physics, University of Science and Technology of China, Jinan, China

^6^ Time and Frequency Geodesy Center (TFGC), School of Geodesy and Geomatics, Wuhan University, Wuhan, China

\clearpage

## Abstract

Optical clocks measure gravitational potential through their relative rates. We compare strontium and ytterbium clocks in Shanghai and Wuhan, 692 km apart and connected by a 1,350-km fibre link, during five campaigns. Ocean loading contributes about a third of the predicted signal on this coastal–inland baseline. A summer campaign accumulating 274 h samples the lunar phase across the solar day. With ephemeris-based tides and no empirical daily terms, the lunar amplitude relative to the solid Earth tide plus the full ocean-loading potential is $0.97\pm0.14$, where the uncertainty is a residual-resampling standard deviation. A common-phase daily disturbance of amplitude $10^{-18}$ changes this scale by at most 0.020. The whole-template response, $0.90\pm0.12$, provides a consistency check. Independent reprocessing and fibre round-trip diagnostics support the lunar response to a prediction with substantial ocean loading.

## Main text

Optical clocks compare gravitational potential through the relative rates of atomic transitions.^1,2^ Static chronometric levelling is established, from laboratory height differences to transportable clocks and fibre-linked stations.^3–5,10–12^ A changing potential presents a further measurement problem: the predicted variation must be distinguished from changes in the clocks and their transfer system. Tides provide an astronomical signal with specified frequencies and phases, while their spatial structure connects a clock comparison to the deformation and redistribution of mass around the stations.^13–15^ A coastal–inland baseline is especially informative because ocean loading makes a substantial contribution to the prediction, rather than a small correction to the solid Earth tide.

The laboratory day complicates this test. The diurnal constituents K1 and P1 lie within 0.3% of one cycle per solar day, and S2 has exactly two cycles per solar day. In a short campaign, these astronomical variations can be difficult to distinguish from an environmental effect repeating daily. The lunar semidiurnal constituent M2 offers a different clock: its maximum falls about 50 min later on successive days. An extended record therefore moves the lunar phase through the solar day. We use that phase diversity to test a fixed lunar prediction and quantify its sensitivity to daily disturbances, without subtracting fitted empirical daily sinusoids before estimating the tide.

### A prediction sensitive to ocean loading

We compare a Sr clock in Shanghai (31.130° N, 121.570° E) with a Yb clock in Wuhan (30.529° N, 114.357° E), 692 km apart and connected by a 1,350-km phase-stabilized fibre link.^16–20^ Shanghai lies near the East China Sea, whereas Wuhan is inland (Fig. 1a). The predicted clock potential combines the IERS 2010 solid Earth tide with the full FES2022 ocean-loading potential.^6–9,22^ The loading calculation includes the attraction of redistributed water, the induced potential of the deformed Earth and the displacement of the clock. It is not a conversion of vertical loading displacement alone.

For differential M2, the solid and loading amplitudes are $3.41\times10^{-18}$ and $1.42\times10^{-18}$ in fractional frequency. Their phase difference is about 20°, and their vector sum is $4.77\times10^{-18}$ (Fig. 1b). On the actual sampling, after segment means are removed, the solid tide, loading and combined prediction have root-mean-square values of 3.0, 1.35 and $4.1\times10^{-18}$, respectively. Loading is thus about a third of the predicted variation. These numbers describe the model and the sampling; the measurement tests the combined potential.

The record contains 54 segments and 544 h of retained samples in five campaigns between September 2025 and August 2026 (Fig. 1c). The summer campaign contributes 274 h across June–August. It samples the full relative S2–M2 phase cycle, whereas each shorter campaign occupies a narrower range (Fig. 1d). Accumulated observing hours quantify operation; the distribution of those hours in astronomical phase determines the separation available to the fit. Neither the full calendar span nor the number of filtered samples alone describes that separation. In particular, a longer calendar record can add measurements at new relative phases without maintaining a continuous frequency level between campaigns. The segment-offset design uses that phase coverage for short-period response while leaving absolute level continuity outside the measurement.

### The lunar response

Data and predictions pass through the same 1,200-s triangular filter, evaluated every 600 s. Each segment receives a constant offset. In the primary fit, the lunar group (M2, N2), near-12-h group (S2, K2) and diurnal group have separate amplitudes, while phases and within-group amplitude ratios follow the astronomical prediction. A small theoretical remainder is included once at its predicted value. Segment constants and tidal amplitudes are fitted simultaneously; empirical daily terms are absent. Constants accommodate unknown static levels without constructing a calibrated sequence of levels across interruptions or between years.

The lunar amplitude relative to the solid Earth tide plus the full ocean-loading potential is $0.97\pm0.14$. The uncertainty is a standard deviation calibrated by residual resampling, and the result is 0.2 standard deviations from unity. Figure 2 shows the summer record after removing segment constants and fitted non-lunar tidal groups, followed by a fold on the predicted M2 phase. The lunar curve uses the same sampling. This display retains the physical distinction between astronomical components and empirical daily disturbances: no empirical daily sinusoid has been removed. The fold reuses the observations in the fit and is a visualization of the response, rather than an independent significance test.

The near-12-h amplitude is $0.90\pm0.29$, with correlation $-0.32$ with the lunar scale (Fig. 3). Its simultaneous estimation allows the measured lunar response to differ from that group. The diurnal value, $0.35\pm0.51$, does not support a separate physical claim. As consistency checks on the combined prediction, a single whole-template scale is $0.90\pm0.12$, and the semidiurnal-band scale is $0.96\pm0.12$. Their errors and observations overlap those of the primary result; the estimates are not averaged.

Summer alone gives a lunar response of $0.87\pm0.18$ and contributes 61% of the nuisance-projected lunar-template squared norm. The other four campaigns together give $1.05\pm0.31$. The five separately fitted campaign amplitudes agree at the level of $\chi^2=4.1$ for four degrees of freedom ($P=0.40$). The extended summer record supplies most of the separation from nearby solar frequencies, while the shorter campaigns sample different parts of the relative phase cycle. The norm share is a design diagnostic, not a claim that summer contributes 61% of independent statistical information under every noise model.

### Discrimination from the laboratory day

The lunar estimator's response to a prescribed daily disturbance can be calculated directly from its linear fit operator. For a 24-h or 12-h sinusoid of fractional-frequency amplitude $10^{-18}$ with one phase common to the record, the maximum change in lunar amplitude is 0.020. Allowing a separate phase in each campaign increases the bounds to 0.032 at 24 h and 0.12 at 12 h (Fig. 4b). These are sensitivities per specified disturbance amplitude, not measurements of the disturbance itself. The coherent 12-h disturbance couples more strongly to the whole-template estimator, with a gain of 0.087, which motivates the lunar group as the principal observable.

Joint fits with additional daily descriptions assess this boundary (Fig. 4a). Campaign-specific 24-h terms at the phase of local air temperature give $0.99\pm0.14$; air-temperature regressors from both sites give $0.98\pm0.13$; and shared 24-h and 12-h terms give $1.00\pm0.13$. In contrast, a free-phase 12-h term in every campaign gives $0.82\pm0.17$. Within a short campaign, that term is nearly degenerate with semidiurnal tides, so this fit retains essentially the summer lunar information. Adding campaign-specific 24-h terms gives $0.86\pm0.18$. The resetting tests delimit the effect of allowing daily structure to compete with the target; their broader freedom is not a measurement of a new environmental variable.

For noise diagnosis, the ordering is physical: estimate and subtract the target and other specified tidal components first, then examine daily structure remaining in the residual. Because the target and daily bases are correlated, both the residual and the diagnostic basis must use the same projection. Such a diagnostic characterizes remaining daily structure conditional on the physical fit; it cannot recover a disturbance component already absorbed by that fit. The joint daily variants above remain separate sensitivity checks. They neither define a daily-cleaned primary dataset nor supply noise amplitudes inferred from the post-fit diagnostic.

### Checks on sampling and transfer

Transient rejection uses local deviations from a running median, without the tidal prediction. The six-robust-standard-deviation criterion removes 0.4% of samples; adding the tidal model at factors of $-1$, 1 and 3 leaves the mask unchanged. Retaining the excursions gives $0.96\pm0.14$ for the lunar group. This check addresses dependence on a small set of transient samples without selecting observations for agreement with the tide.

Under four specified residual-resampling scenarios without a lunar signal, none of 20,000 simulated records reaches the observed lunar amplitude. This is a conditional simulation result, not a zero probability. Transferring a whole-template amplitude learned from the other observation periods reduces residual sums of squares in seven of eight held-out periods, by 4.9% when pooled. These eight periods are subdivisions of the five campaigns, and the overlapping training sets do not constitute eight independent experiments. The lunar transfer check improves six of eight periods, by 1.7% when pooled; it is distinct from the whole-template check.

An independent processing of the 2026 records uses non-overlapping 600-s means and ten-day calendar baselines. It gives a whole-template scale of $0.88\pm0.10$ and a lunar scale of $0.89\pm0.28$ with daily terms in each block. These are processing checks on shared observations, with different estimators and uncertainty rules. The fibre round-trip record covers 474 h; adding it as a regressor changes the lunar and whole-template scales on that overlap by less than 0.005. This constrains the recorded transfer channel, while clocks and unmonitored laboratory branches remain outside that control.

### Physical scope

The related frequency-ratio preprint by Hou et al. uses the overlapping summer record and reports a whole-template correlation of 0.87(15).^16^ With the present prediction, its segment-wise estimator gives $0.78\pm0.19$ for summer, whereas the joint lunar estimator gives $0.87\pm0.18$. This Article does not update the absolute ratio or reuse the earlier significance. It addresses the lunar component in an extended interrupted record, with different grouping of the astronomical signal and explicit daily-disturbance tests.

The measured response is consistent with including the full ocean-loading potential. Fitting the solid tide alone gives $1.19\pm0.20$, compared with 1.32 expected on this sampling if the combined prediction is correct. A separate loading scale, $0.89\pm0.55$, is unresolved. The geographic advantage therefore concerns sensitivity to a combined prediction with substantial loading, rather than an independent measurement of loading or Love numbers. A contemporaneous European clock-network preprint reports independently acquired observations with different baselines and a different diurnal–semidiurnal mixture, complementary to the coastal–inland lunar test here.^21^ Longer coastal records with calibrated transfer branches could turn this sensitivity into a separate test of ocean loading.

\clearpage

## Figure legends

![](figures_final/figure1.png){width=180mm}

**Fig. 1 | Coastal–inland sensitivity and lunar–solar phase coverage.** **a,** Shanghai Sr and Wuhan Yb stations, their 692-km separation and the schematic 1,350-km fibre route through Hefei. Land colour shows predicted M2 clock potential, including solid tide and loading; sea colour shows FES2022 ocean-tide amplitude. The inset resolves the loading contribution around Shanghai. **b,** Differential M2 phasors, with the solid tide as phase reference: solid $3.41\times10^{-18}$, loading $1.42\times10^{-18}$, separation about 20°, and sum $4.77\times10^{-18}$. **c,** Sampling of five campaigns; campaign labels retain the reported integer-hour durations, and the retained-sample total is reported as 544 h. **d,** Relative S2–M2 astronomical phase, including nodal corrections, at the filtered sample times. Only the summer campaign samples the full cycle. Panels a and b are predictions and c and d describe sampling; none is a hypothesis test. The retained figure shows repeated measurements, not independent replicates.

\clearpage

![](figures_final/figure2.png){width=180mm}

**Fig. 2 | Summer lunar modulation in time and phase.** **a,** Three-hour display averages of the 16 summer segments after subtracting jointly fitted segment constants and non-lunar tidal groups, compared with the lunar prediction. Gaps longer than 6 h are removed from the horizontal axis and marked by grey lines. Some excursions extend below the displayed range. **b,** The same record in 30° M2 phase bins, with the M2+N2 model folded over the same sampling. Error bars are one delete-day jackknife error with fitted non-lunar terms held fixed; they are conditional display errors and do not propagate the full uncertainty of the nuisance fit. No empirical daily term is removed. The time series and fold reuse the data entering the amplitude estimate and do not constitute independent confirmations. The primary uncertainty is the residual-resampling standard deviation reported in the text.

\clearpage

![](figures_final/figure3.png){width=180mm}

**Fig. 3 | Responses of the astronomical groups.** **a,** Whole-template and semidiurnal-band checks and the jointly estimated lunar, near-12-h and diurnal groups, with segment offsets and no empirical daily terms. Bars denote one standard deviation from residual resampling for the full model, semidiurnal band and lunar group; for near-12-h and diurnal groups they are the larger of scaled least-squares and delete-day jackknife errors. The primary lunar response is highlighted; the dashed line denotes unit response. **b,** Joint lunar and near-12-h response. Curves use the least-squares correlation, $-0.32$, scaled to the reported marginal uncertainties, at standardized radii of one and two. They visualize covariance geometry and are not independently calibrated joint confidence regions. The cross marks unit response in both groups. All estimates share observations.

\clearpage

![](figures_final/figure4.png){width=180mm}

**Fig. 4 | Daily-disturbance boundary of the lunar estimate.** **a,** Primary result, joint fits with daily or temperature terms, and summer-only and no-summer estimates. Bars are one residual-resampling standard deviation for the primary estimate and max(scaled least-squares, delete-day jackknife) for daily-term variants. Campaign-subset bars retain their reported marginal errors; the primary coverage calibration is not assigned to them. The shaded band is the primary $0.97\pm0.14$ interval; the vertical line is unity. These are fits to overlapping data, not independent measurements. **b,** Largest change in the primary lunar scale from a $10^{-18}$ sinusoid, with either a common phase or independently chosen phases in each campaign. The dashed horizontal line is the primary standard deviation for comparison. The gains are deterministic properties of the design and carry no observation-error bars. Daily variants in a are joint sensitivity fits; b does not estimate environmental noise amplitudes.

\clearpage

## Methods

### Clocks, link and the frequency observable

The frequency chain compares the Yb transition in Wuhan with the Sr transition in Shanghai through the phase-stabilized 1,350-km fibre link. The apparatus and absolute-ratio measurement are described by Hou et al.; the clock evaluations report systematic uncertainties of $9.2\times10^{-19}$ for Sr and $1.3\times10^{-18}$ for Yb.^16–18^ A 1,550-nm carrier referenced to Sr is transmitted to Wuhan and beaten against the Yb-referenced comb. Frequency counters record the beat at nominal 1-s intervals. Other long field-fibre demonstrations provide technical context, rather than a performance calibration for this experiment.^19,20^

The fractional observable is the variation in $R=f_{\mathrm{Yb,WUH}}/f_{\mathrm{Sr,SHA}}$ about a constant reference. A positive variation means Wuhan Yb runs faster relative to Shanghai Sr. With positive Newtonian potential $W$, the predicted fractional change is $s(t)=-[\delta W_{\mathrm{WUH}}(t)-\delta W_{\mathrm{SHA}}(t)]/c^2$, using the same convention for solid tide and loading. Constant potential and frequency-reference contributions enter the segment offsets. In 2026, a 1-Hz beat deviation corresponds to $5.17\times10^{-15}$ in the ratio. In 2025 the recorded beat was divided by two, so its deviations receive the corresponding factor of two. The September–October campaign alone gives $1.28\pm0.31$, a within-campaign scale check. No calibrated cross-year level or long-term stability is inferred from fitted offsets.

### Segments, selection and matched filtering

The experiment-defined 54 segments comprise 38 segments before June 2026 and 16 in summer. They form five campaigns: September–October 2025, January, April, May and June–August 2026. The retained sample totals are approximately 270 h before June and 274 h in summer. Eight observation periods provide a finer grouping for held-out and sign-flip checks; they are not eight campaigns. All are repeated observations of the same clock pair. Hours count retained nominal one-second samples, rather than independent observations or one uninterrupted run.

For each source file, time is reconstructed from the first timestamp and sample index. Samples more than 10 Hz from the segment median are excluded, the longest uninterrupted run is retained, and leading and trailing samples differing from the median by more than 1% of the peak-to-peak range are trimmed. A second screen averages retained samples over 300 s, compares each average with a running median over $\pm30$ min, and excludes deviations exceeding six robust standard deviations of those differences within the segment, together with their neighbours. This removes 0.4% of samples, or 2.2 h. The rule does not use tidal residuals.

Adding $-1$, 1 or 3 times the theoretical tide leaves the removal mask unchanged. Thresholds of four to eight robust standard deviations and 60-s or 300-s blocks give lunar scales between 0.93 and 1.02; retaining excursions gives $0.96\pm0.14$. Six is the lowest tested threshold with the stated model-invariance property, rather than a documented prospectively registered cut. Data and predictions then receive the identical 1,200-s triangular filter at 600-s steps. Adjacent outputs share samples. Local timestamps are interpreted as UTC+8; a $\pm10$-min template-shift test changes the amplitude by less than 0.02, but is not a measurement of counter synchronization.

### Solid Earth and full loading potential

The solid-tide prediction is

$$\delta W_{\mathrm{solid}}=\sum_m(1+k_{2m})V_{2m}+(1+k_3)V_3-g u_r,$$

where $V_{2m}$ are the lunar and solar degree-two tide-generating potentials by order, $V_3$ is the lunar degree-three term, and $u_r$ is the radial displacement from the IERS algorithm.^6^ The adopted values are $k_{20}=0.29525$, $k_{22}=0.29801$ and $k_3=0.093$. Constituent-dependent $k_{21}$ follows the IERS resonance expression; the displacement includes the frequency and latitude dependence of $h$. These fixed response coefficients define the prediction and are not estimated from the clock observations.

The full loading potential is evaluated by convolution,

$$\delta W_{\mathrm{load}}(t)=\int_{\mathrm{ocean}}\rho_w\zeta(\mathbf r',t)G_W(\psi)\,\mathrm dA,$$

$$G_W(\psi)=\frac{ga}{M_E}\sum_n(1+k'_n-h'_n)P_n(\cos\psi).$$

Here $\zeta$ is FES2022 ocean elevation, $\rho_w=1{,}025\,\mathrm{kg\,m^{-3}}$, $a$ and $M_E$ are Earth's radius and mass, and $\psi$ is angular separation.^7–9,22^ The three terms in the kernel represent direct attraction, induced potential and clock displacement. PREM load Love numbers through degree 696 are taken from the gravity-toolkit distribution; the high-degree displacement response joins its Boussinesq limit of $-6.22$, with Kummer summation to degree 40,000.^9,24^ The $1/30^\circ$ grid is retained within 3° of either station; farther away, $8\times8$ cell blocks are summed. The latter approximation changes differential M2 and K1 loading by at most 0.05% in the source calculation.

Ocean means are removed for mass conservation. Eight constituents, Q1, O1, P1, K1, N2, M2, S2 and K2, use astronomical arguments and nodal corrections. The radial-displacement calculation agrees with the comparison load-tide grid within 2% and 1.2° for seven constituents. For S2, an 18% amplitude difference and a 54° Wuhan phase difference occur between model releases. Substituting that S2 loading changes the whole-template scale by 0.001 and leaves the reported lunar result unchanged. Filling near-Shanghai coastal land masks of 0.3° and 0.6° with nearest-ocean values lowers the lunar scale by 0.06 and 0.07. These are sensitivity checks, not fitted corrections or independently calibrated model-error distributions.

### Estimator and residual-resampling uncertainty

For the primary three-group fit,

$$y_i=c_{j(i)}+A_Ls_L(t_i)+A_Ss_S(t_i)+A_Ds_D(t_i)+r_0(t_i)+\epsilon_i.$$

Here $j(i)$ identifies the segment; $s_L$, $s_S$ and $s_D$ contain the lunar, near-12-h and diurnal constituents. Their relative phases and amplitudes within each group are fixed. The eight-constituent representation explains 99.84% of the prediction variance; the remainder $r_0$, with RMS $0.18\times10^{-18}$, is included at unit amplitude. Setting it to zero or doubling it gives lunar scales of 0.95–0.99. Least squares estimates all group amplitudes and constants jointly. The whole-template and two-band fits are separately labelled checks. Subtracting fitted constants for display does not create independent calibrated segment levels.

Residual resampling supplies the quoted standard deviation for the lunar, whole-template and semidiurnal results. Residuals are shifted circularly within each continuous filtered run and added to the unit-response model, preserving within-run correlation structure under that resampling assumption. Two independent sets of 200 realizations give lunar standard deviations of 0.13 and 0.14; max(scaled least-squares, delete-day jackknife) is 0.13. The reported value is 0.14, with a resampling bias of +0.01. This reporting rule is documented for the analysis, without claiming an independent prospective registration.

Four specified disturbance scenarios, each with 5,000 realizations, give coverage of 67%–68% for $\hat A_L\pm0.14$, and 94.5%–95.2% for $\hat A_L\pm1.96(0.14)$. Thus the quoted error is approximately a one-standard-deviation scale; the latter range assesses nominal 95% intervals under those scenarios. Near-12-h, diurnal and daily-term fits use max(scaled least-squares, delete-day jackknife); their reported errors differ from resampling scales by factors of 0.8–1.3. These constructions must not be pooled into one universal coverage claim.^26^

The null simulations use no lunar group and four daily-disturbance cases: none; campaign-specific 24-h terms with temperature-derived phases; shared 24-h and 12-h terms; and the summer daily terms. None of 20,000 point estimates reaches the observed lunar response. A period-level restricted wild sign-flip test gives two-sided $P=0.008$ for the lunar estimate, at the eight-period enumeration limit $2/256$.^27^ It relies on period-level sign symmetry and the specified null fit. This conditional probability does not replace the resampling error or establish insensitivity to unmodelled disturbances. Campaign information shares are sums of squares of the lunar column after projection off all other fitted columns.

### Daily diagnostics and physical controls

For a sinusoid of amplitude $B$ at angular frequency $\omega$, let $h_L$ be the row of the primary fit operator mapping the observations to lunar amplitude. Its largest effect with common phase is

$$G_{\mathrm{common}}=B\left\|(h_L\cos\omega t,h_L\sin\omega t)\right\|_2.$$

With independently chosen campaign phases, the bound is the sum of the corresponding campaign norms. The 0.020, 0.032 and 0.12 gains refer to $B=10^{-18}$ and the unchanged primary design. They are linear sensitivities, not disturbance estimates. Temperature-phase checks use hourly ERA5 2-m air temperatures; daily anomalies relative to a 24-h running mean form the two-site regression alternative.^23^ The quoted daily-term variants are joint fits and remain distinct from post-fit noise diagnostics.

For the latter diagnostic, let $X$ contain the physical group and offset columns, with the fixed remainder removed from $y$. After the primary fit, define $M_X=I-XX^+$, residual $r=M_Xy$ and projected daily basis $D_\perp=M_XD$. Estimate identifiable remaining daily directions from $(D_\perp)^+r$, retaining the original physical estimate. An unprojected regression of $r$ on $D$ would attenuate correlated components. Any uncertainty calculation must repeat or propagate the complete fit and projection; exactly overlapping directions are not identifiable.^25^ This diagnostic cannot bound daily structure already absorbed by $X$. No new experimental residual-diagnostic amplitude is assigned to the inherited joint-fit values.

The summer Sr chamber record averages 20 PT100 sensors and overlaps 98 h of ratio data. Both clocks correct blackbody shifts in real time. Regressing the corresponding Sr correction-shaped signal gives $0.92\pm0.74$, or $0.72\pm0.74$ with the chamber transient excluded, consistent with zero. This is a check on residual correction error over that overlap, not on all daily clock effects.

The Shanghai round-trip beat is optically normalized without division by two, screened at 10 Hz about its median and filtered like the ratio. Its 474-h overlap is used identically in the baseline and monitor-augmented fits. Excluding additional 300-s monitor blocks above $5\times10^{-16}$ changes the regression result by less than 0.005. A small response shift constrains the monitored channel; it does not calibrate a one-way transfer coefficient or cover unmonitored branches. The independent 2026 reprocessing, held-out checks and joint daily variants retain their own sampling and error rules. No fit-adjusted sequence is used to calculate long-term stability.

\clearpage

## References

1. Ludlow, A. D., Boyd, M. M., Ye, J., Peik, E. & Schmidt, P. O. Optical atomic clocks. *Rev. Mod. Phys.* **87**, 637–701 (2015). [Source](https://doi.org/10.1103/revmodphys.87.637)
2. Mehlstäubler, T. E., Grosche, G., Lisdat, C., Schmidt, P. O. & Denker, H. Atomic clocks for geodesy. *Rep. Prog. Phys.* **81**, 064401 (2018). [Source](https://doi.org/10.1088/1361-6633/aab409)
3. Chou, C. W., Hume, D. B., Rosenband, T. & Wineland, D. J. Optical Clocks and Relativity. *Science* **329**, 1630–1633 (2010). [Source](https://doi.org/10.1126/science.1192720)
4. McGrew, W. F. et al. Atomic clock performance enabling geodesy below the centimetre level. *Nature* **564**, 87–90 (2018). [Source](https://doi.org/10.1038/s41586-018-0738-2)
5. Bothwell, T. et al. Resolving the gravitational redshift across a millimetre-scale atomic sample. *Nature* **602**, 420–424 (2022). [Source](https://doi.org/10.1038/s41586-021-04349-7)
6. Petit, G. & Luzum, B. (eds) IERS Conventions (2010). *IERS Technical Note* **36** (2010). [Source](https://iers-conventions.obspm.fr/content/tn36.pdf)
7. LEGOS, NOVELTIS & CLS FES2022 (Finite Element Solution) Ocean Tide. *CNES data set* (2024). [Source](https://doi.org/10.24400/527896/a01-2024.004)
8. Farrell, W. E. Deformation of the Earth by surface loads. *Rev. Geophys.* **10**, 761–797 (1972). [Source](https://doi.org/10.1029/RG010i003p00761)
9. Han, D. & Wahr, J. The viscoelastic relaxation of a realistically stratified earth, and a further analysis of postglacial rebound. *Geophys. J. Int.* **120**, 287–311 (1995). [Source](https://doi.org/10.1111/j.1365-246x.1995.tb01819.x)
10. Grotti, J. et al. Geodesy and metrology with a transportable optical clock. *Nat. Phys.* **14**, 437–441 (2018). [Source](https://doi.org/10.1038/s41567-017-0042-3)
11. Lisdat, C. et al. A clock network for geodesy and fundamental science. *Nat. Commun.* **7**, 12443 (2016). [Source](https://doi.org/10.1038/ncomms12443)
12. Riehle, F. Optical clock networks. *Nat. Photon.* **11**, 25–31 (2017). [Source](https://doi.org/10.1038/nphoton.2016.235)
13. Voigt, C., Denker, H. & Timmen, L. Time-variable gravity potential components for optical clock comparisons and the definition of international time scales. *Metrologia* **53**, 1365–1383 (2016). [Source](https://doi.org/10.1088/0026-1394/53/6/1365)
14. Denker, H. et al. Geodetic methods to determine the relativistic redshift at the level of $10^{-18}$ in the context of international timescales: a review and practical results. *J. Geod.* **92**, 487–516 (2018). [Source](https://doi.org/10.1007/s00190-017-1075-1)
15. Schröder, S., Stellmer, S. & Kusche, J. Potential and scientific requirements of optical clock networks for validating satellite-derived time-variable gravity data. *Geophys. J. Int.* **226**, 764–779 (2021). [Source](https://academic.oup.com/gji/article/226/2/764/6212226)
16. Hou, L. et al. Yb/Sr optical clock comparison at $2.2\times10^{-18}$ uncertainty over a 1350-km fiber link. *arXiv*, 2610.34250v1 (2026). [Source](https://arxiv.org/abs/2610.34250v1)
17. Jia, Z.-P. et al. Improved systematic evaluation of a strontium optical clock with uncertainty below $1\times10^{-18}$. *Metrologia* **63**, 025002 (2026). [Source](https://doi.org/10.1088/1681-7575/ae449e)
18. Zhu, Q. et al. Ytterbium lattice clock with systematic uncertainty of $1.3\times 10^{-18}$ and instability at the $10^{-19}$ level. *arXiv*, 2606.10514v2 (2026). [Source](https://arxiv.org/abs/2606.10514v2)
19. Chen, F.-X. et al. $10^{-21}$-Level optical frequency dissemination over 2067 km of noise-loaded field-deployed fiber network. *Light Sci. Appl.* **15**, 276 (2026). [Source](https://doi.org/10.1038/s41377-026-02299-1)
20. Schioppo, M. et al. Comparing ultrastable lasers at $7\times10^{-17}$ fractional frequency instability through a 2220 km optical fibre network. *Nat. Commun.* **13**, 212 (2022). [Source](https://doi.org/10.1038/s41467-021-27884-3)
21. Stahl, K. et al. Optical clock network tracks tidal variations of the gravity potential. *arXiv*, 2610.39635v1 (2026). [Source](https://arxiv.org/abs/2610.39635v1)
22. Lyard, F. H., Allain, D. J., Cancet, M., Carrère, L. & Picot, N. FES2014 global ocean tide atlas: design and performance. *Ocean Sci.* **17**, 615–649 (2021). [Source](https://doi.org/10.5194/os-17-615-2021)
23. Hersbach, H. et al. The ERA5 global reanalysis. *Q. J. R. Meteorol. Soc.* **146**, 1999–2049 (2020). [Source](https://doi.org/10.1002/qj.3803)
24. Sutterley, T. C. gravity-toolkit: Python tools for obtaining and working with time-variable gravity fields. [Software](https://github.com/tsutterley/gravity-toolkit).
25. Ding, P. The Frisch–Waugh–Lovell theorem for standard errors. *arXiv*, 2009.06621 (2020). [Source](https://arxiv.org/abs/2009.06621)
26. Efron, B. & Stein, C. The Jackknife Estimate of Variance. *Ann. Stat.* **9**, 586–596 (1981). [Source](https://doi.org/10.1214/aos/1176345462)
27. Cameron, A. C., Gelbach, J. B. & Miller, D. L. Bootstrap-Based Improvements for Inference with Clustered Errors. *Rev. Econ. Stat.* **90**, 414–427 (2008). [Source](https://doi.org/10.1162/rest.90.3.414)

## Data availability

The frequency records, segment definitions, matched tidal predictions and figure source data may be requested from the corresponding authors. Data DOI: [To be completed]. The review package must include the inputs for the primary five-campaign estimator as well as the separate 2026 reprocessing; those reductions are not interchangeable datasets.

## Code availability

Analysis and figure-generation code may be requested from the corresponding authors. Code DOI: [To be completed]. The primary reduction, residual-resampling implementation and processing comparison require separately identified versions.

## Author statements

Acknowledgements, funding, author contributions and competing-interest declarations require confirmation by the authors before submission. Correspondence details will accompany the completed author list. OpenAI Codex assisted the synthesis, code checks and figure preparation; authors retain responsibility for scientific verification and approval.
