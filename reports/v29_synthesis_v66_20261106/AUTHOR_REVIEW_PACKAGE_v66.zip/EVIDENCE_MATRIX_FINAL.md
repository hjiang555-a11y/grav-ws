# v66 evidence matrix

VERIFIED means the stated check was actually executed; it does not upgrade a PDF-reported measurement into an independently reproduced result. AUTHOR-REPORTED means the value and definition were checked against the supplied v29 PDF. PENDING and BLOCKED are release-local evidence labels, not mutations of historical task states.

| Item | Status | Evidence / scope |
|---|---|---|
| Source identity | VERIFIED | 15-page v29 PDF; SHA256 `3483abc17e4b2c44d8f4c76fd9877b7f8b90119be5cca2304222da0a5c4fef7b`; exact source copied, text extracted |
| Primary lunar .97±.14, near-12-h .90±.29, correlation −.32 | AUTHOR-REPORTED | PDF pp.2,5–6,11; three simultaneous physical groups, segment constants, fixed remainder |
| Full .90±.12 / semidiurnal .96±.12 | AUTHOR-REPORTED | pp.2,5–6; shared-data checks, not second primary results |
| ±.14 versus 95% coverage | VERIFIED (definition) | p.6 explicitly separates 67–68% for ±.14 from 94.5–95.2% for ±1.96×.14; simulations themselves not rerun |
| Bias +.01; two sets of 200 | AUTHOR-REPORTED | pp.5–6; largest .14 retained; not labelled prospectively registered |
| 5 campaigns / 8 periods / 29 groups / 54 segments | AUTHOR-REPORTED | pp.2–6; distinct hierarchical groupings; exact ID crosswalk PENDING |
| 544 h total / 274 h summer / 474 h B2 overlap | AUTHOR-REPORTED | pp.2–7; retained nominal samples, not independent count or continuous duty time |
| Summer .87±.18, 61%; other campaigns1.05±.31; χ²4.1/4df/P.40 | AUTHOR-REPORTED | p.2; subset coverage not transferred from primary calibration |
| Loading contribution / M2 vectors / separate loading .89±.55 | AUTHOR-REPORTED | pp.2,4–5,10; combined potential tested; no loading detection |
| Common daily gain .020 / separate phase .032,.12 | AUTHOR-REPORTED | pp.2,6; deterministic operator sensitivity per 10^-18 |
| Daily variants .99±.14,.98±.13,1.00±.13,.82±.17,.86±.18 | AUTHOR-REPORTED | p.2; original joint fits, not residual-only measured noise |
| B2 shifts <.005 | AUTHOR-REPORTED | pp.3,7; only matched 474-h support; unmonitored branches not excluded |
| Post-primary daily projection algebra | VERIFIED | Four deterministic synthetic unit tests; weighted covariance, full-chain cluster deletion, exact non-identifiability, primary frozen |
| Experimental post-primary residual diagnostic | PENDING | No corresponding v29 design matrix/response table loaded in this release; no amplitude invented |
| Fig.2 conditional display errors | VERIFIED (caption scope) | pp.10–11: non-lunar fitted terms held fixed; not full nuisance-error propagation |
| Fig.3 ellipse confidence interpretation | VERIFIED (construction scope) | p.11: LS correlation rescaled to marginal errors; no calibrated joint confidence assigned |
| Source spectrum threshold | BLOCKED | p.11 caption 200 resamples/5–40 μHz versus p.6 Methods1,000/max above15 μHz; primary unchanged, spectrum moved to ED plan |
| Primary raw reproduction | PENDING | New primary is source-reported v29 reduction; earlier v65 2905-bin reproduction does not certify it |
| Nature preprint policy | VERIFIED | Official Nature page indexed this session; quoted words restricted to20; policy only in cover letter |
| Manuscript and figure assembly | VERIFIED at final build | See VALIDATION.json, final PDF/DOCX build and page checks |
| Submission/public release readiness | BLOCKED | Primary executable evidence, source tables, author declarations and final production assets still require completion |

Prior source files, reports and task approval records remain unchanged. No scientific fit or raw-data mutation was performed in this synthesis.
