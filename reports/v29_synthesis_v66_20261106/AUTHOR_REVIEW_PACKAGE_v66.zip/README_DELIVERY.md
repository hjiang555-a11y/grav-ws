# v66 合稿交付入口

本目录最终状态以CURRENT_STATUS_v66_FINAL.json为准。早期CURRENT_STATUS_v66.json记录的是找到原稿前的准备检查点，保留为历史，不代表当前状态。

- [论文PDF](render_v66_release/NATURE_ARTICLE_v66.pdf)
- [可编辑Word稿](render_v66_release/NATURE_ARTICLE_v66.docx)
- [Markdown全文](NATURE_ARTICLE_v66.md)
- [核查报告与红色提示](CHECK_REPORT.md)
- [证据矩阵](EVIDENCE_MATRIX_FINAL.md)
- [投稿信PDF](ancillary/COVER_LETTER_v66.pdf)
- [一页Claims not made](ancillary/CLAIMS_NOT_MADE_v66.pdf)
- [Extended Data组装清单](EXTENDED_DATA_PLAN.md)
- [技术规则](RESIDUAL_DAILY_PROTOCOL.md)
- [实际验收记录](VALIDATION.json)
- [图形审计判读](verification/FIGURE_QA_TRIAGE.md)

作者审阅稿：主结果来源已核对，但本轮没有独立重跑v29的原始归约。未投稿，未批准历史任务，未改科研原始数据或运行中的服务。

## 重建

```bash
/home/room115/pytorch_env/bin/python finish_figures.py
/home/room115/pytorch_env/bin/python assemble_v66.py
/home/room115/pytorch_env/bin/python render_release_final.py NATURE_ARTICLE_v66.md render_new_review
/data/AI_Research/environments/python/sci/bin/python tests/test_residual_daily.py
```

输出目录必须为新目录。初次图件及构建保留在figures/、render_v66/等目录；交付只取figures_final/与render_v66_release/。输入PDF、逐页提取文本和身份散列位于sources/。这些步骤只重建本轮合稿与图件，不能替代原始计数器的科研复现。
