# Claims not made

**Separate detection of ocean loading.** The measured response concerns the sum of the solid-Earth tide and the predicted ocean-loading potential. Loading contributes substantially to that prediction, but a separate loading coefficient is not resolved. Agreement with the combined template does not identify the loading contribution independently.

**Measurement of Love numbers.** The tidal response and loading calculation use adopted Earth-response coefficients. Scaling the combined prediction does not determine a Love number or distinguish all contributions to the clock potential.

**Detection of the diurnal tide.** The diurnal group is retained in the constituent model. Its reported uncertainty and overlap with solar-day disturbances do not support a separate physical detection claim.

**An updated absolute Yb/Sr frequency ratio.** The manuscript concerns time-variable tidal response. It does not update the absolute ratio reported by Hou and colleagues, establish continuity of frequency levels across interrupted segments, or inherit the significance of their overlapping summer correlation check.

**Priority over Stahl and colleagues.** The European clock-network observations are independent and complementary. The manuscript does not assert priority over that contemporaneous preprint or ask editors to adjudicate a priority dispute.

The same observations support several estimators, displays and sensitivity checks. These are not independent discoveries and are not combined into a weighted primary result. Measured round-trip control data constrain their monitored transfer channel; they do not exclude every clock or unmonitored laboratory disturbance.
