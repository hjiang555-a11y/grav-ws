from pathlib import Path
import hashlib,json,csv,unicodedata,re
import fitz
O=Path(__file__).resolve().parents[1];P=O/'sources/Lunar_tide_coastal_inland_v29_20261105.pdf';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=fitz.open(P)
texts=[unicodedata.normalize('NFKC',p.get_text()) for p in d]
# Reported summaries only. This table is never read as an observation table.
rows=[
('primary_lunar',.97,.14,'residual-resampling SD','0.97','0.14'),('whole_template_check',.90,.12,'residual-resampling SD','0.90','0.12'),('semidiurnal_check',.96,.12,'residual-resampling SD','0.96','0.12'),('near_12h_group',.90,.29,'max(scaled LS, delete-day JK)','0.90','0.29'),('diurnal_group',.35,.51,'max(scaled LS, delete-day JK)','0.35','0.51'),('summer_lunar',.87,.18,'reported subset marginal error','0.87','0.18'),('without_summer_lunar',1.05,.31,'reported subset marginal error','1.05','0.31'),('temperature_phase',.99,.14,'daily sensitivity: max(LS, day JK)','0.99','0.14'),('two_site_temperature',.98,.13,'daily sensitivity: max(LS, day JK)','0.98','0.13'),('shared_daily',1.,.13,'daily sensitivity: max(LS, day JK)','1.00','0.13'),('free_campaign_12h',.82,.17,'daily sensitivity: max(LS, day JK)','0.82','0.17'),('retain_transients',.96,.14,'reported sensitivity error','0.96','0.14'),('independent_2026_full',.88,.10,'separate reprocessing error rule','0.88','0.10'),('independent_2026_daily_lunar',.89,.28,'separate reprocessing error rule','0.89','0.28'),('solid_only',1.19,.20,'reported model check error','1.19','0.20'),('loading_separate',.89,.55,'reported component error','0.89','0.55'),('2025_scale_check',1.28,.31,'reported within-campaign check','1.28','0.31'),('blackbody_residual',.92,.74,'delete-day JK','0.92','0.74'),('blackbody_without_transient',.72,.74,'delete-day JK','0.72','0.74')]
output=[]
for ident,a,u,rule,k1,k2 in rows:
 pages=[i+1 for i,t in enumerate(texts) if k1 in t and k2 in t]
 assert pages,(ident,'missing numbers in source')
 output.append({'id':ident,'estimate':a,'reported_uncertainty':u,'uncertainty_definition':rule,'data_type':'reported_estimator_summary_not_observation','source':'v29 PDF','source_sha256':sha(P),'candidate_source_pages':','.join(map(str,pages)),'verification':'AUTHOR_REPORTED_PDF_VERIFIED','primary_raw_replay':False})
with (O/'data/reported_primary_estimates.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(output[0]));w.writeheader();w.writerows(output)
R=O/'sources/R7_tree/paper/nature/opencode-period-offset-20261105/source-data';e=json.loads((R/'evidence.json').read_text());r=json.loads((R/'r4/diagnostics.json').read_text());shares=r['information']['A_L']['shares'];summer=sum(shares[x] for x in ['P6','P7','P8']);summary={'role':'secondary_reduction_only','fixed_commit':'27de8630633648feea8fc874e1f629b741f19fe6','primary_three':e['primary']['three'],'common_lunar_IQ':{k:r['common_lunar_IQ'][k] for k in ['A','u','coefficient_order']},'norm_shares':{'early':1-summer,'summer':summer},'saved_table_replay':'VERIFIED_THIS_ROUND','physical_template_certification':False,'primary_v66_replay':False,'source_sha256':{'evidence.json':sha(R/'evidence.json'),'r4/diagnostics.json':sha(R/'r4/diagnostics.json')}}
(O/'data/secondary_R7_replayed_summary.json').write_text(json.dumps(summary,indent=2))
items=[]
for p in [P,O/'sources/NATURE_ARTICLE_v66.md',O/'sources/R7_opencode-ws.pdf',O/'sources/R7_opencode-ws-source.zip',R/'bins.csv',R/'template.csv',R/'constituents.csv',R/'evidence.json',R/'r4/diagnostics.json']:
 items.append({'path':str(p.relative_to(O)),'sha256':sha(p),'bytes':p.stat().st_size,'primary_use':'source document only' if p.suffix in ['.pdf','.md'] else 'R7 secondary replay only'})
(O/'data/INPUT_MANIFEST.json').write_text(json.dumps(items,indent=2))
print('Source-bound reported estimates:',len(output));print('R7 norm shares',summary['norm_shares'])
