from pathlib import Path
import re,json,hashlib,zipfile,subprocess
import fitz
O=Path(__file__).resolve().parents[1];M=(O/'NATURE_ARTICLE_v68.md').read_text();V=O/'verification';(V/'pages').mkdir(exist_ok=True)
main=M.split('## Main text',1)[1].split('## References',1)[0];abstract=M.split('## Abstract',1)[1].split('## Main text',1)[0];methods=M.split('## Methods\n',1)[1].split('## Methods references',1)[0]
def wc(s):
 s=re.sub(r'\$\$[\s\S]*?\$\$',' MATH ',s);s=re.sub(r'\$[^$]+\$',' MATH ',s);s=re.sub(r'\^[\d,–-]+\^|^#+.*$|\\clearpage','',s,flags=re.M);return len(s.split())
checks={'title':M.splitlines()[0]=='# Lunar tidal potential measured on a coastal–inland optical-clock baseline','title_length':len(M.splitlines()[0][2:])<=75,'main_length':1800<=wc(main)<=2200,'abstract_length':wc(abstract)<=150,'cover_length':wc((O/'COVER_LETTER_v68.md').read_text())<=200,'primary_sentence':'The lunar amplitude relative to the solid Earth tide plus the full ocean-loading potential is $0.97\\pm0.14$.' in main,'no_R7_primary':r'0.99\pm0.12' not in main,'no_legacy_uncertainty':'1.26' not in M,'physical_constants':all(s in methods for s in ['0.29525','0.29801','0.093']),'no_displacement_constants':all(s not in methods for s in ['0.6078','0.3010']),'no_unneeded_references':all(s not in M for s in ['Frisch','Ding,','Cameron,','Lyard,','[Source]']),'exactly_four_figures':len(re.findall(r'!\[\]\(figures/figure[1-4].png\)',M))==4,'no_figure_5':'Fig. 5' not in M,'spectrum_is_3c':'**Fig. 3 |' in M and '200 residual resamples' in M,'conditional_display_errors':'hold fitted non-lunar terms fixed' in methods,'full_record_gap_disclosed':'Full-record fold to be substituted' in M,'source_placeholders_honest':'[Author list and order to be confirmed]' in M and '[repository; DOI to be supplied]' in M,'no_draft_header':'Author-review' not in M,'methods_displays_absent':'![]' not in methods,'ED_directory_only':'## Extended Data directory' in M and '|---' not in M}
refs=M.split('## References\n',1)[1].split('## Figure legends',1)[0]+M.split('## Methods references\n',1)[1].split('## Author statements',1)[0];checks['reference_numbers']=[int(n) for n in re.findall(r'^(\d+)\. ',refs,re.M)]==list(range(1,24))
text=M.split('## Abstract',1)[1];text=re.sub(r'## References\n[\s\S]*?(?=## Figure legends)','',text);text=re.sub(r'## Methods references\n[\s\S]*?(?=## Author statements)','',text);order=[]
for group in re.findall(r'\^([\d,–-]+)\^',text):
 for token in group.split(','):
  z=re.split('[–-]',token)
  for n in range(int(z[0]),int(z[-1])+1):
   if n not in order:order.append(n)
checks['reference_first_appearance']=order==list(range(1,24))
r7=methods.split('### Separate reduction')[1].split('### AI-assisted')[0];checks['R7_under_120']=wc(r7)<=120
caps={};csec=M.split('## Figure legends')[1].split('## Methods\n')[0]
for n,s in re.findall(r'\*\*Fig\. ([1-4]) \|([\s\S]*?)(?=\\clearpage)',csec):caps[n]=wc(s)
checks['caption_lengths']=len(caps)==4 and max(caps.values())<250
pdf=fitz.open(O/'render_v68_release/NATURE_ARTICLE_v68.pdf');pages=[]
for i,p in enumerate(pdf):
 t=p.get_text();spans=[s for b in p.get_text('dict')['blocks'] for l in b.get('lines',[]) for s in l['spans']];outside=[s['text'] for s in spans if s['text'].strip() and (s['bbox'][0]<-.5 or s['bbox'][2]>p.rect.width+.5 or s['bbox'][3]>p.rect.height+.5)];pages.append({'page':i+1,'chars':len(t),'figures':re.findall(r'Fig\. [1-4] \|',t),'outside':outside});p.get_pixmap(matrix=fitz.Matrix(.9,.9)).save(V/'pages'/f'page_{i+1:02d}.png')
checks['no_page_overflow']=all(not p['outside'] for p in pages);checks['no_nearly_empty_page']=all(p['chars']>150 for p in pages)
ast=json.loads(subprocess.check_output(['pandoc',str(O/'NATURE_ARTICLE_v68.md'),'-t','json']))
def math_nodes(obj):
 if isinstance(obj,dict):return int(obj.get('t')=='Math')+sum(math_nodes(v) for v in obj.values())
 if isinstance(obj,list):return sum(math_nodes(v) for v in obj)
 return 0
with zipfile.ZipFile(O/'render_v68_release/NATURE_ARTICLE_v68.docx') as z:checks['native_docx_math']=z.read('word/document.xml').count(b'<m:oMath>')==math_nodes(ast)>0
report={'status':'DOCUMENT_CHECKS_PASS' if all(checks.values()) else 'DOCUMENT_CHECKS_FAIL','checks':checks,'word_counts':{'main':wc(main),'abstract':wc(abstract),'methods_including_availability':wc(methods),'cover':wc((O/'COVER_LETTER_v68.md').read_text()),'R7_methods':wc(r7),'captions':caps},'pages':pages,'pdf_sha256':hashlib.sha256((O/'render_v68_release/NATURE_ARTICLE_v68.pdf').read_bytes()).hexdigest(),'visual_status':'PENDING_FINAL_VIEW','primary_numerical_replay':'PENDING_SOURCE_INPUTS','submission_ready':False,'scientific_all_calculations_verified':False}
(O/'VALIDATION.json').write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ['checks','pages']},ensure_ascii=False));print('Failed checks:',[k for k,v in checks.items() if not v]);print('Page summary:',[(p['page'],p['chars'],p['figures']) for p in pages])
