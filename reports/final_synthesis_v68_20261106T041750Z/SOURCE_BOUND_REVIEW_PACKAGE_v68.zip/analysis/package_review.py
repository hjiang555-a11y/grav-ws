"""Package an explicitly incomplete scientific review, never a claimed raw-data release."""
from pathlib import Path
import hashlib
import json
import zipfile

O = Path(__file__).resolve().parents[1]
qa = json.loads((O / 'VALIDATION.json').read_text())
assert qa['status'] == 'DOCUMENT_CHECKS_PASS'
assert qa['visual_status'] == 'PASS_FOR_SOURCE_BOUND_REVIEW'
assert qa['submission_ready'] is False
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
files = {}

def add(p, archive=None):
    p = O / p
    assert p.is_file() and p.resolve().is_relative_to(O)
    name = archive or str(p.relative_to(O))
    assert name not in files
    files[name] = p

for name in ['NATURE_ARTICLE_v68.md', 'COVER_LETTER_v68.md', 'CHECK_REPORT.md',
             'REVIEW_README.md', 'REPRODUCE.md', 'NATURE_REQUIREMENTS_20261106.md',
             'EVIDENCE_MATRIX.json', 'CURRENT_STATUS_v68_REVIEW.json', 'VALIDATION.json',
             'render_v68.py', 'layout_v68.lua', 'PLAN.md']:
    add(name)
for ext in ['pdf', 'docx']:
    add(f'render_v68_release/NATURE_ARTICLE_v68.{ext}', f'NATURE_ARTICLE_v68.{ext}')
for n in range(1, 5):
    for ext in ['pdf', 'png', 'svg', 'tiff']:
        add(f'figures/figure{n}.{ext}')
for directory, patterns in [('data', ['*.json', '*.csv', '*.md']),
                            ('reports', ['*.md']),
                            ('verification', ['*.json', '*.log']),
                            ('drafts', ['*.md'])]:
    for pattern in patterns:
        for p in sorted((O / directory).glob(pattern)):
            add(p.relative_to(O))
for p in ['figures/FIGURE_PROVENANCE.json', 'figures/FIGURE_CONTRACT.md',
          'figures/figure3_reported_scalars.json', 'figures/figure3_top.alignment.json',
          'figures/assemble_figures_v68.py', 'figures/add_solar_markers.py',
          'figures/finish_units.py', 'figures/source_panels/v66_figure1.pdf',
          'figures/source_panels/v66_figure2.pdf',
          'sources/Lunar_tide_coastal_inland_v29_20261105.pdf',
          'sources/NATURE_ARTICLE_v66.md', 'sources/V29_IDENTITY.json',
          'sources/R7_IDENTITY.json', 'sources/R7_SHA256SUMS',
          'verification/page_overview.png', 'analysis/build_evidence_index.py',
          'analysis/validate_document.py', 'analysis/package_review.py']:
    add(p)

manifest = [{'path': k, 'sha256': sha(p), 'bytes': p.stat().st_size}
            for k, p in sorted(files.items())]
manifest_text = json.dumps({'scope': 'source-bound review package, not full primary reproduction data',
                            'primary_numerical_replay': 'PENDING_SOURCE_INPUTS',
                            'files': manifest}, indent=2)
with (O / 'REVIEW_PACKAGE_MANIFEST.json').open('x') as f:
    f.write(manifest_text)
dest = O / 'SOURCE_BOUND_REVIEW_PACKAGE_v68.zip'
with zipfile.ZipFile(dest, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for k, p in sorted(files.items()):
        z.write(p, k)
    z.writestr('REVIEW_PACKAGE_MANIFEST.json', manifest_text)
with zipfile.ZipFile(dest) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(manifest) + 1
    for r in manifest:
        assert hashlib.sha256(z.read(r['path'])).hexdigest() == r['sha256']
result = {'archive': dest.name, 'sha256': sha(dest), 'bytes': dest.stat().st_size,
          'members': len(manifest) + 1, 'verification': 'EVERY_MEMBER_SHA256_VERIFIED',
          'primary_raw_reproduction_complete': False}
with (O / 'REVIEW_PACKAGE_VERIFICATION.json').open('x') as f:
    json.dump(result, f, indent=2)
print(json.dumps(result, indent=2))
