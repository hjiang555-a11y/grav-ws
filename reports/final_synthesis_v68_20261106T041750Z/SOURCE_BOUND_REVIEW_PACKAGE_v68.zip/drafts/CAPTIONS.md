## Figure legends

![](figures/figure1.png){width=180mm}

**Fig. 1 | Coastal–inland prediction and lunar–solar phase coverage.** **a,** Shanghai Sr and Wuhan Yb clocks, their 692-km separation and the schematic 1,350-km fibre route through Hefei. Land colour shows predicted M2 clock potential, including solid tide and loading; sea colour shows FES2022 M2 ocean-tide amplitude. The Shanghai inset shows the loading contribution. **b,** Differential M2 phasors with the solid tide as phase reference: solid 3.41, loading 1.42, separation approximately 20°, and sum 4.77, in units of $10^{-18}$. **c,** Five campaigns and their reported integer-hour durations; the retained-sample total is approximately 544 h. **d,** Relative S2–M2 astronomical phase, including nodal corrections, at the filtered sample times. Only summer covers the full cycle. Panels a and b are predictions, and c and d describe sampling; these panels are not hypothesis tests.

\clearpage

![](figures/figure2.png){width=180mm}

**Fig. 2 | Lunar modulation in phase and time.** **a,** Summer observations in twelve 30° M2 phase bins after subtraction of jointly fitted segment constants and non-lunar tidal groups, with the M2+N2 prediction folded on the same sampling. Error bars are conditional delete-day jackknife errors with fitted non-lunar terms held fixed; they omit the uncertainty from re-estimating those terms. **[Full-record fold to be substituted after recomputation on the primary estimator.]** **b,** Three-hour display averages of the 16 summer segments after subtraction of the same components, with the lunar prediction. Gaps longer than 6 h are removed from the horizontal axis and marked by grey lines; some negative excursions extend below the displayed range. No empirical daily term is removed. Both panels visualize observations used in the amplitude fit, rather than an independent test; primary inference uses the residual-resampling standard deviation of 0.14.

\clearpage

![](figures/figure3.png){width=180mm}

**Fig. 3 | Astronomical-group responses and spectral modulation.** **a,** Whole-template and semidiurnal checks and the jointly estimated lunar, near-12-h and diurnal groups. Filled symbols and solid bars denote residual-resampling standard deviations; open squares and dashed bars denote the larger of scaled least-squares and delete-day jackknife errors. The filled diamond identifies the primary lunar result. **b,** Lunar–near-12-h covariance geometry, using correlation $-0.32$ scaled to the quoted marginal errors, at standardized radii of one and two; the cross is $(1,1)$. These curves are not separately calibrated joint confidence regions. **c,** Sinusoidal power of the full record after projection of segment constants, before and after subtraction of the fitted whole template. The dotted line is the 99% level of the maximum over 5–40 μHz from 200 residual resamples; short markers identify one and two cycles per solar day. Interrupted sampling does not resolve M2 from S2 in this display. Subtraction uses a template fitted to the same observations, so peak removal is not an independent significance test. Lunar–near-12-h separation comes from the phase coverage in Fig. 1d and simultaneous fitting, with the daily-disturbance response quantified in Fig. 4b.

\clearpage

![](figures/figure4.png){width=180mm}

**Fig. 4 | Sampling and daily-disturbance sensitivity.** **a,** The primary lunar result (filled diamond and shaded one-standard-deviation band), alternative operating-group or period offsets, daily and temperature terms, summer alone, deletion of each campaign, and selection variants. Bars show reported one-standard-deviation uncertainties: residual resampling for the primary result and the reported scaled least-squares/delete-day maximum for the daily-term fits. Subset and other variant errors retain their source definitions. The thin line below the primary result is the 95% operating-group-resampling interval. These fits share observations and are sensitivity displays, not independent confirmations. **b,** Largest change in lunar amplitude caused by a $10^{-18}$ sinusoid at 24 h or 12 h, for one phase common to the record or independently chosen phases in each campaign. The dashed line is 0.14. These gains are properties of the linear design and have no observation-error bars.
