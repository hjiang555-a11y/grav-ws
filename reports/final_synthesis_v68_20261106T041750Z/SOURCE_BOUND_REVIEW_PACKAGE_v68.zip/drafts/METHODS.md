## Methods

### Frequency comparison and sampling

The apparatus and frequency-ratio measurement are described by Hou et al.; the clock evaluations provide the corresponding systematic uncertainty budgets.^16–18^ Related long field-fibre demonstrations give technical context.^19,20^ The Shanghai Sr reference is transferred on a 1,550-nm carrier and compared with the Wuhan Yb-referenced comb. Counters record the beat at nominal 1-s intervals. We analyse fractional variations in $R=f_{\mathrm{Yb,WUH}}/f_{\mathrm{Sr,SHA}}$. With positive Newtonian potential $W$, the prediction is

$$y(t)=-[\delta W_{\mathrm{Wuhan}}(t)-\delta W_{\mathrm{Shanghai}}(t)]/c^2.$$

A positive variation means Wuhan Yb runs faster relative to Shanghai Sr. In 2026, the magnitude of the conversion is $5.17\times10^{-15}$ per hertz of beat deviation. The 2025 counter records a divided-by-two beat; deviations receive the factor of two before conversion. September–October alone gives a scale of $1.28\pm0.31$. Segment constants accommodate static levels; no long-term stability is inferred from a fit-adjusted concatenation.

The 54 segments comprise 38 before June 2026 and 16 in summer. Samples more than 10 Hz from the segment median are excluded, the longest continuous run is retained, and ends differing from the median by more than 1% of the peak-to-peak range are trimmed. A second screen forms 300-s averages, subtracts a running median over $\pm30$ min and rejects deviations exceeding six robust standard deviations within a segment, together with neighbouring samples. This removes 0.4%, or 2.2 h, without using tidal residuals. Adding the prediction at factors of $-1$, 1 and 3 leaves the mask unchanged. Data and theoretical series receive the identical 1,200-s triangular filter at 600-s steps. Hours count retained nominal one-second samples, rather than independent filtered outputs. The five campaigns and eight periods used for period-level diagnostics are different groupings of the same observations.

### Solid Earth and loading potentials

The IERS 2010 prediction uses the direct tide-generating potential and the radial displacement,^6^

$$\delta W_{\mathrm{solid}}=\sum_m(1+k_{2m})V_{2m}+(1+k_3)V_3-gu_r.$$

Here $V_{2m}$ are lunar and solar degree-two components and $V_3$ is the lunar degree-three term. We use $k_{20}=0.29525$, $k_{22}=0.29801$ and $k_3=0.093$; $k_{21}$ follows the IERS resonance formula. The IERS displacement includes the frequency and latitude dependence of $h$.

FES2022 ocean elevation $\zeta$ enters the full loading-potential convolution,^7–9^

$$\delta W_{\mathrm{load}}(t)=\int_{\mathrm{ocean}}\rho_w\zeta(\mathbf r',t)G_W(\psi)\,\mathrm dA,\qquad G_W(\psi)=\frac{ga}{M_E}\sum_n(1+k'_n-h'_n)P_n(\cos\psi).$$

The three kernel terms represent water attraction, induced potential and clock displacement. We use $\rho_w=1{,}025\,\mathrm{kg\,m^{-3}}$ and PREM load Love numbers through degree 696 distributed with gravity-toolkit.^9,24^ The high-degree displacement response joins the Boussinesq limit $-6.22$, with Kummer summation to degree 40,000. The $1/30^\circ$ grid is retained within 3° of either station; distant $8\times8$ cell blocks are summed, changing differential M2 and K1 loading by at most 0.05%. Ocean means are removed for mass conservation. Eight constituents (Q1, O1, P1, K1, N2, M2, S2 and K2) use astronomical arguments and nodal corrections.

The comparison radial-load grid differs for S2 by 18% in amplitude and 54° in Wuhan phase between releases. Substituting that S2 loading changes the whole-template scale by 0.001 and leaves the lunar result unchanged at reported precision. Filling coastal masks of 0.3° and 0.6° near Shanghai lowers the lunar scale by 0.06 and 0.07. These are model sensitivities, not additional fitted corrections.

### Joint estimation and uncertainty

The primary equal-weight model is

$$y_i=c_{j(i)}+A_Ls_L(t_i)+A_Ss_S(t_i)+A_Ds_D(t_i)+r_0(t_i)+\epsilon_i,$$

where $j(i)$ is the segment. The three templates have fixed within-group phases and amplitude ratios. Their eight constituents explain 99.84% of the prediction variance; the remainder $r_0$, of RMS $0.18\times10^{-18}$, enters at unit amplitude. Omitting or doubling it gives lunar scales of 0.95–0.99. Least squares estimates the group amplitudes and segment constants together.

Residuals are shifted circularly within each continuous filtered run and added to the unit-response model. Two independent sets of 200 realizations give lunar standard deviations of 0.13 and 0.14; the scaled least-squares/delete-day maximum is 0.13. We report the largest, 0.14, with resampling bias $+0.01$. Four specified disturbance scenarios, each with 5,000 realizations, give 67–68% coverage for $\hat A_L\pm0.14$ and 94.5–95.2% for $\hat A_L\pm1.96(0.14)$. Coverage is conditional on those scenarios. Near-12-h, diurnal and daily-term errors use the larger of scaled least squares and delete-day jackknife.

The null simulations remove the lunar group and include four daily-disturbance cases: none, campaign-specific 24-h terms with temperature phases, common 24-h and 12-h terms, and the summer daily terms. None of 20,000 simulated estimates reaches the measured amplitude; this is not a zero probability. An eight-period restricted wild sign-flip test gives two-sided $P=0.008$, at its resolution limit $2/256$, under the specified null and period-level sign symmetry. It does not replace the residual-resampling uncertainty. The campaign norm share is computed after projecting the lunar template off every other fitted column.

### Daily sensitivity, controls and displays

If $h_L$ maps observations to lunar amplitude, the maximum response to a common-phase sinusoid of amplitude $B$ is

$$G(\omega)=B\left\|(h_L\cos\omega t,\,h_L\sin\omega t)\right\|_2.$$

Independent campaign phases give the sum of campaign-specific norms. The gains use $B=10^{-18}$ and the primary design. Temperature-phase tests use hourly ERA5 2-m temperatures; two-site regressors use anomalies relative to a 24-h running mean.^23^ Post-fit noise diagnostics retain the physical estimate and project both residual data and daily diagnostic bases through the same physical-fit residual operator. Uncertainty must propagate through both stages. The reported joint daily fits remain separate sensitivity checks.

The round-trip beat is normalized by the optical carrier without division by two, screened at 10 Hz and filtered like the ratio. Baseline and monitor-augmented regressions use the same 474-h support. The Sr chamber record averages 20 PT100 sensors over a 98-h overlap. Both clocks correct blackbody shifts in real time; the residual Sr correction-shaped coefficient is $0.92\pm0.74$, or $0.72\pm0.74$ with the chamber transient omitted.

Figure 2 retains the summer display: its delete-day error bars hold fitted non-lunar terms fixed. A full-record phase fold requires the primary data and unit lunar template to receive the same nuisance projection before twelve-bin averaging. Figure 3c retains the original 5–40 μHz full-record spectrum and its 200-resample maximum-power threshold. The 1,000-resample threshold described for the separate April spectrum concerns a different display. None of these views supplies another amplitude significance test.

### Separate reduction

A second reduction uses eight period constants, Allan-based weights and a displacement-based solid-tide implementation. It gives $0.99\pm0.12$ for the lunar group, and in-phase and quadrature coefficients of 0.99 and $-0.18$. Its early/summer projected-norm shares are 49.8/50.2%, compared with the primary summer share of 61%; the constant hierarchy and weights differ, and the shares are not combined. This is another reduction of overlapping observations, not an independent experiment or calibration of the primary uncertainty. Its phase-fold and deletion layouts inform presentation only. Historical loading-series fits are excluded from the primary estimate and error budget.

### AI-assisted preparation

OpenAI Codex assisted manuscript synthesis, citation checks, diagnostic-code preparation and figure assembly. [Author verification responsibilities and scope to be confirmed.]

### Data availability

The frequency records required to reproduce the primary analysis, segment definitions, matched tidal templates and figure source data will be deposited in [repository; DOI to be supplied]. Editorial and referee access: [review link to be supplied]. Third-party model products will be identified by their originating data citations and access terms.

### Code availability

The versioned primary reduction, residual-resampling implementation and figure-generation code will be deposited in [repository; DOI to be supplied], with the software environment and input manifest. Editorial and referee access: [review link to be supplied].
