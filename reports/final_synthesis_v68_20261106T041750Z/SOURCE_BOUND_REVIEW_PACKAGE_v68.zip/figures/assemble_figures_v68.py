from pathlib import Path
import json,hashlib,shutil,sys
import fitz
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
sys.path.insert(0,'/home/room115/.codex/skills/nature-figure/scripts')
from audit_panel_alignment import require_matplotlib_panel_alignment
F=Path(__file__).resolve().parent;O=F.parent;I=F/'source_panels';I.mkdir(exist_ok=True)
OLD=Path('/data/AI_Research/projects/grav-ws/manuscript_48h/v29_synthesis_v66_20261106T025045Z/figures_final')
srcpath=O/'sources/Lunar_tide_coastal_inland_v29_20261105.pdf'
assert hashlib.sha256(srcpath.read_bytes()).hexdigest()=='3483abc17e4b2c44d8f4c76fd9877b7f8b90119be5cca2304222da0a5c4fef7b'
source=fitz.open(srcpath);width=180/25.4*72
records=[]
def crop(src,page,rect,path,w=width):
    r=fitz.Rect(rect);s=fitz.open();s.insert_pdf(src,from_page=page,to_page=page);p=s[0]
    W,H=p.rect.width,p.rect.height
    for b in [(0,0,W,r.y0),(0,r.y1,W,H),(0,r.y0,r.x0,r.y1),(r.x1,r.y0,W,r.y1)]:
        if fitz.Rect(b).get_area()>0:p.add_redact_annot(fitz.Rect(b),fill=None,cross_out=False)
    p.apply_redactions(images=0,graphics=1,text=0)
    d=fitz.open();q=d.new_page(width=w,height=w*r.height/r.width);q.show_pdf_page(q.rect,s,0,clip=r);d.save(path,garbage=4,deflate=True);s.close();d.close()
def exports(pdf,name):
 d=fitz.open(pdf);p=d[0];pix=p.get_pixmap(matrix=fitz.Matrix(300/72,300/72));pix.save(F/(name+'.png'))
 from PIL import Image
 Image.frombytes('RGB',[pix.width,pix.height],pix.samples).save(F/(name+'.tiff'),compression='tiff_lzw',dpi=(300,300))
 (F/(name+'.svg')).write_text(p.get_svg_image(text_as_path=False));d.close()
for name in ['figure1.pdf','figure2.pdf']:
 shutil.copy2(OLD/name,I/('v66_'+name))
shutil.copy2(I/'v66_figure1.pdf',F/'figure1.pdf');exports(F/'figure1.pdf','figure1')
records.append({'figure':1,'source':'v66 final Fig.1 from v29 p.10','method':'unchanged vector artwork','scientific_status':'SOURCE_PDF_VERIFIED'})
# Swap the two existing panels. No point, model curve or error bar is recomputed.
s=fitz.open(I/'v66_figure2.pdf');H=s[0].rect.height;W=s[0].rect.width
crop(s,0,(0,0,350,H),I/'summer_time.pdf',w=330)
crop(s,0,(350,0,W,H),I/'summer_fold.pdf',w=160)
d=fitz.open();p=d.new_page(width=width,height=H+6)
for filename,dest,label in [('summer_fold.pdf',fitz.Rect(0,0,160,H),'a'),('summer_time.pdf',fitz.Rect(180,0,width,H),'b')]:
 panel=fitz.open(I/filename)
 # Replace only the original panel letter, not plot labels or data.
 for b in panel[0].get_text('dict')['blocks']:
  for l in b.get('lines',[]):
   for span in l['spans']:
    if span['text'] in ['a','b'] and span['bbox'][1]<25:
     panel[0].add_redact_annot(fitz.Rect(span['bbox'])+(.1,.1,-.1,-.1),fill=None,cross_out=False)
 panel[0].apply_redactions(images=0,graphics=0,text=0)
 p.show_pdf_page(dest,panel,0);panel.close();p.insert_text((dest.x0+4,10),label,fontname='hebo',fontsize=8)
d.save(F/'figure2.pdf',garbage=4,deflate=True);d.close();exports(F/'figure2.pdf','figure2')
records.append({'figure':2,'source':'v66 final Fig.2 / v29 p.10 Fig.2','method':'reordered source vector panels; no new fit','full_record_fold':'PENDING_PRIMARY_TABLES','scientific_status':'SOURCE_PDF_VERIFIED','errors':'conditional delete-day errors with non-lunar fitted terms held fixed'})
# Exact original Fig.3c; no new frequency estimator, window or resampling threshold.
crop(source,10,(62,205,535,344),I/'v29_spectrum.pdf')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':7,'axes.labelsize':7,'xtick.labelsize':7,'ytick.labelsize':7,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,'legend.frameon':False})
fig=plt.figure(figsize=(180/25.4,66/25.4));gs=fig.add_gridspec(1,2,left=.25,right=.985,bottom=.22,top=.87,wspace=.65)
a,b=fig.add_subplot(gs[0]),fig.add_subplot(gs[1]);labels=['Full model','Semidiurnal band','Lunar (M2 + N2)','Near-12-h (S2 + K2)','Diurnal'];vals=[.90,.96,.97,.90,.35];err=[.12,.12,.14,.29,.51]
a.axvline(0,color='.8',lw=.7);a.axvline(1,color='.5',lw=.8,ls='--')
for i,(v,e) in enumerate(zip(vals,err)):
 color='#0072B2' if i==2 else ('#555555' if i<3 else '#9A6324')
 obj=a.errorbar(v,4-i,xerr=e,fmt='D' if i==2 else ('o' if i<3 else 's'),mfc=color if i<3 else 'white',mec=color,color=color,ms=4 if i==2 else 3.4,capsize=2,lw=1)
 if i>=3:
  for bar in obj[2]:bar.set_linestyle('--')
a.set_yticks(range(5),labels[::-1]);a.tick_params(axis='y',length=0);a.set_ylim(-.6,4.6);a.set_xlim(-.3,1.5);a.set_xticks([0,.5,1,1.5]);a.set_xlabel('Amplitude factor')
cov=np.array([[.14**2,-.32*.14*.29],[-.32*.14*.29,.29**2]]);eig,vec=np.linalg.eigh(cov);ix=np.argsort(eig)[::-1];eig,vec=eig[ix],vec[:,ix];angle=np.degrees(np.arctan2(vec[1,0],vec[0,0]))
for rad,alpha in [(2,.45),(1,1.)]:b.add_patch(Ellipse((.97,.90),2*rad*np.sqrt(eig[0]),2*rad*np.sqrt(eig[1]),angle=angle,fill=False,color='#0072B2',alpha=alpha,lw=1))
b.plot(.97,.90,'D',color='#0072B2',ms=4);b.plot(1,1,'+',color='.25',ms=7);b.set_xlim(.5,1.45);b.set_ylim(.2,1.65);b.set_xlabel('Lunar amplitude factor');b.set_ylabel('Near-12-h amplitude factor');b.text(.03,.97,'Correlation −0.32',transform=b.transAxes,va='top',fontsize=6.5)
for ax,label in [(a,'a'),(b,'b')]:ax.text(-.05,1.08,label,transform=ax.transAxes,fontweight='bold',fontsize=8,ha='right')
require_matplotlib_panel_alignment(fig,json_out=F/'figure3_top.alignment.json',overlay_svg=F/'figure3_top.alignment.svg',axes=[a,b],panel_ids=['a','b'],row_groups=[['a','b']],strict=True)
fig.savefig(I/'figure3_top.pdf');plt.close(fig)
top=fitz.open(I/'figure3_top.pdf');bottom=fitz.open(I/'v29_spectrum.pdf');d=fitz.open();th=top[0].rect.height;bh=bottom[0].rect.height;p=d.new_page(width=width,height=th+bh+12);p.show_pdf_page(fitz.Rect(0,0,width,th),top,0);p.show_pdf_page(fitz.Rect(0,th+12,width,th+12+bh),bottom,0);d.save(F/'figure3.pdf',garbage=4,deflate=True);d.close();exports(F/'figure3.pdf','figure3')
(F/'figure3_reported_scalars.json').write_text(json.dumps({'source':'v29 pp.2,11; v66 primary estimator','labels':labels,'values':vals,'errors':err,'error_types':['resampling_SD']*3+['max_scaled_LS_day_JK']*2,'correlation':-.32,'raw_reproduction':False},indent=2))
records.append({'figure':3,'source':'v29 p.11 Fig.3 and reported coefficients','ab':'redrawn from explicit reported scalars','c_crop_pdf_points':[62,205,535,344],'c':'original vector panel, 200 residual resamples / 5–40 microHz; not recomputed','scientific_status':'SOURCE_PDF_VERIFIED'})
crop(source,10,(62,463,535,682),F/'figure4.pdf');exports(F/'figure4.pdf','figure4')
records.append({'figure':4,'source':'v29 p.11 Fig.4','crop_pdf_points':[62,463,535,682],'method':'unchanged original complete vector artwork, no digitized leave-campaign estimates','scientific_status':'SOURCE_PDF_VERIFIED; numerical replay pending primary input'})
for r in records:r['sha256']=hashlib.sha256((F/f'figure{r["figure"]}.pdf').read_bytes()).hexdigest()
(F/'FIGURE_PROVENANCE.json').write_text(json.dumps(records,indent=2));print('Four source-bound figures prepared; full-record fold remains pending.')
