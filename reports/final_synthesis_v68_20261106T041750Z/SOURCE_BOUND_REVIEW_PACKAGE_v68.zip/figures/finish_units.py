from pathlib import Path
import fitz,shutil,json,hashlib
from PIL import Image
F=Path(__file__).resolve().parent;B=F/'before_unit_fixes';B.mkdir(exist_ok=True)
fontfile='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';font=fitz.Font(fontfile=fontfile)
for n,rect,text,x,center in [(3,(16,220,29,314),'Power (amplitude²/2, 10⁻³⁶)',24,276),(4,(351,65,364,161),'Change of lunar A per 10⁻¹⁸',360,113)]:
 for ext in ['pdf','png','svg','tiff']:shutil.copy2(F/f'figure{n}.{ext}',B/f'figure{n}.{ext}')
 d=fitz.open(B/f'figure{n}.pdf');p=d[0];p.add_redact_annot(fitz.Rect(rect),fill=None,cross_out=False)
 if n==4:p.add_redact_annot(fitz.Rect(471,40,500,48),fill=None,cross_out=False)
 p.apply_redactions(images=0,graphics=0,text=0);p.insert_font(fontname='DF2',fontfile=fontfile)
 p.insert_text((x,center+font.text_length(text,fontsize=7)/2),text,fontname='DF2',fontsize=7,rotate=90)
 if n==4:p.insert_text((466,37.5),'uncertainty',fontname='DF2',fontsize=6,color=(.1,.55,.43))
 d.save(F/f'figure{n}.pdf',garbage=4,deflate=True);pix=p.get_pixmap(matrix=fitz.Matrix(300/72,300/72));pix.save(F/f'figure{n}.png');Image.frombytes('RGB',[pix.width,pix.height],pix.samples).save(F/f'figure{n}.tiff',compression='tiff_lzw',dpi=(300,300));(F/f'figure{n}.svg').write_text(p.get_svg_image(text_as_path=False));d.close()
j=F/'FIGURE_PROVENANCE.json';r=json.loads(j.read_text())
for a in r:
 if a['figure'] in [3,4]:a['label_fix']='Complete unit labels reset with 7 pt Unicode superscripts; observational marks unchanged';a['sha256']=hashlib.sha256((F/f'figure{a["figure"]}.pdf').read_bytes()).hexdigest()
j.write_text(json.dumps(r,indent=2))
print('Unit-label font floor repaired; no data marks changed.')
