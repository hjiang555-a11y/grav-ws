# v68 Figure contract

Backend: Python/matplotlib for new scalar drawing; Python/PyMuPDF for lossless vector-panel assembly. No digitized clock observations. Four figures only, 180 mm wide, editable vector text and at least 5 pt visible glyphs where possible. Source geometry is recorded for reused panels; original plotting-code alignment is not certified without that code.

| Figure | Scientific role | Panels and source | Verification boundary |
|---|---|---|---|
| 1 | Physical prediction and sampling separation | v66 final artwork, bound to v29: coastal potential map, M2 phasors, five-campaign support, S2–M2 phase coverage | Prediction and sampling; not hypothesis tests. 545/544 integer-hour question retained in report. |
| 2 | Visualize the same primary observations | a: summer fold from v66 pending primary full-record computation; b: v29 summer time series via verified v66 artwork | Same data; fixed-nuisance display errors. Full-record replacement awaits actual primary input tables. |
| 3 | Group estimates plus descriptive spectral behaviour | a: reported coefficients, with distinct symbols/line styles for resampling vs max-SE; b: scaled covariance geometry; c: unchanged v29 Fig.3c vector panel | c cannot resolve M2/S2; fitted subtraction is in sample. No second significance claim. |
| 4 | Sensitivity to model choices and daily disturbance | v29 Fig.4 original complete two-panel vector artwork, including leave-campaign points | Source-bound display; numeric replay of these variants awaits primary data. No borrowed R7 values. |

Final review checks: first-appearance callouts, scientific label accuracy, coefficient/error contract, panel labels, text font size, alignment for newly drawn panels and final PDF collision audit plus visual inspection. Original source limitations remain in the report; a rendered figure is not certification of original analysis.
