from pathlib import Path
import fitz,hashlib,json,shutil
from PIL import Image
F=Path(__file__).resolve().parent;I=F/'source_panels';W=180/25.4*72
pdoc=fitz.open(I/'v29_spectrum.pdf');p=pdoc[0]
for b in p.get_text('dict')['blocks']:
 for l in b.get('lines',[]):
  for s in l['spans']:
   if s['text'] in ['Diurnal','Semidiurnal']:p.add_redact_annot(fitz.Rect(s['bbox'])+(.05,.05,-.05,-.05),fill=None,cross_out=False)
p.apply_redactions(images=0,graphics=0,text=0)
p.insert_font(fontname='DF',fontfile='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
for cycles,label in [(1,'1 cycle / solar day'),(2,'2 cycles / solar day')]:
 f=cycles*1e6/86400
 x=(100.00863+(f-5)/35*(523.52685-100.00863)-62)*W/473
 p.insert_text((x-29,8.7),label,fontname='DF',fontsize=6.2,color=(.2,.2,.2))
 p.draw_line((x,11),(x,18),color=(.3,.3,.3),width=.6)
pdoc.save(I/'v29_spectrum_marked.pdf',garbage=4,deflate=True)
old=F/'v1';old.mkdir(exist_ok=True)
for ext in ['pdf','png','svg','tiff']:shutil.copy2(F/f'figure3.{ext}',old/f'figure3.{ext}')
top=fitz.open(I/'figure3_top.pdf');bottom=fitz.open(I/'v29_spectrum_marked.pdf');d=fitz.open();th=top[0].rect.height;bh=bottom[0].rect.height;p=d.new_page(width=W,height=th+12+bh)
p.show_pdf_page(fitz.Rect(0,0,W,th),top,0);p.show_pdf_page(fitz.Rect(0,th+12,W,th+12+bh),bottom,0);d.save(F/'figure3.pdf',garbage=4,deflate=True)
pix=p.get_pixmap(matrix=fitz.Matrix(300/72,300/72));pix.save(F/'figure3.png');Image.frombytes('RGB',[pix.width,pix.height],pix.samples).save(F/'figure3.tiff',compression='tiff_lzw',dpi=(300,300));(F/'figure3.svg').write_text(p.get_svg_image(text_as_path=False))
j=F/'FIGURE_PROVENANCE.json';v=json.loads(j.read_text());r=next(x for x in v if x['figure']==3);r['c_reference_markers_microHz']=[1e6/86400,2e6/86400];r['c']='Original v29 curves and threshold, with solar-day reference markers added; no new spectrum';r['sha256']=hashlib.sha256((F/'figure3.pdf').read_bytes()).hexdigest();j.write_text(json.dumps(v,indent=2))
print('Solar-day markers added without changing the source spectrum.')
