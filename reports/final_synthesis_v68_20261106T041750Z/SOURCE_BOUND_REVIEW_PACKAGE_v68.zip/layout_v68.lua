function Div(el)
  if el.classes:includes('pagebreak') then
    if FORMAT:match('latex') then return pandoc.RawBlock('latex','\\clearpage')
    elseif FORMAT:match('docx') then return pandoc.RawBlock('openxml','<w:p><w:r><w:br w:type="page"/></w:r></w:p>') end
  end
end
function Header(el)
  if FORMAT:match('latex') then
    local name=pandoc.utils.stringify(el.content)
    if name=='Extended Data' then
      return {pandoc.RawBlock('latex','\\singlespacing\\sffamily\\fontsize{7}{9}\\selectfont'),el}
    elseif name=='References' or name=='Methods references' or name=='Figure legends' or name=='Extended Data' then
      return {pandoc.RawBlock('latex','\\singlespacing'),el}
    elseif name=='Supplementary Methods' then
      return {pandoc.RawBlock('latex','\\onehalfspacing'),el}
    elseif name=='Methods' then
      return {pandoc.RawBlock('latex','\\doublespacing'),el}
    end
  end
end
