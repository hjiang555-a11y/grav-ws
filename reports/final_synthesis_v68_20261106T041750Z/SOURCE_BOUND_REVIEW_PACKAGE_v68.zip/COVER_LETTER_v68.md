Dear Editors,

We submit “Lunar tidal potential measured on a coastal–inland optical-clock baseline” as a Nature Article. A 1,350-km fibre link compares Shanghai Sr and Wuhan Yb clocks on a baseline where ocean loading contributes about one third of the predicted variation. Five campaigns, including 274 h in summer, sample the lunar phase across the solar day. Without empirical daily terms in the primary fit, the lunar-group response is 0.97 ± 0.14 relative to the combined solid Earth and full loading potential. The advance is this constituent-level response and its quantified sensitivity to solar-day disturbances; loading is not separately resolved.

Hou et al., arXiv:2610.34250, report the absolute frequency ratio on the same link using overlapping summer observations. This Article neither updates that ratio nor reuses its tidal-correlation significance. Stahl et al., arXiv:2610.39635, describe independent contemporaneous European observations with different baselines and tidal mixtures, complementary to this measurement. We disclose both preprints; under Nature Portfolio policy, preprints are not prior publication and do not determine the advance of the manuscript under consideration.

Data and code review access: [link to be supplied].

Sincerely,
[Corresponding authors]
