# v68 复现入口与范围

本目录分开保存来源文档、主稿报告值、第二套归约回放及稿件构建。没有完整主链输入时，禁止把第二套归约命名为主结果。

## 论文构建

在本目录执行，输出目录必须尚不存在：

```bash
/home/room115/pytorch_env/bin/python render_v68.py NATURE_ARTICLE_v68.md render_local_review
```

需要 Pandoc、XeLaTeX 和 python-docx。`render_v68.py` 使用已验收的矢量 PDF 图，Word 使用 PNG 图和原生公式。此命令重建文稿，不重做科研分析。Word 的表述与 PDF 相同。

最终图件来源、哈希和拼版方法在 `figures/FIGURE_PROVENANCE.json`。组装脚本依赖保留的 v66/v29 源面板；在缺少源面板时只可构建文稿，不可声称已从原始数据重新绘图。原始频谱没有被数字化或重新选窗。

## 已执行的 R7 第二套归约

固定提交：`27de8630633648feea8fc874e1f629b741f19fe6`，对应仓库 `hjiang555-a11y/gravitation-whsh`。

本地隔离来源树位于 `sources/R7_tree/`，从固定提交的 `paper/nature/opencode-ws/opencode-ws-source.zip` 安全解包得到。核对 `sources/R7_IDENTITY.json` 和 `verification/R7_ARCHIVE_IDENTITY.json` 后，在来源树根目录运行：

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /data/AI_Research/environments/python/sci/bin/python -B paper/nature/opencode-period-offset-20261105/tools/reproduce_saved.py
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 /data/AI_Research/environments/python/sci/bin/python -B paper/nature/opencode-period-offset-20261105/tools/reproduce_r4.py
```

这两项分别回放保存表拟合和诊断；本轮退出码均为0，结果见 `verification/R7_*REPLAY.*`。这些回放不重新生成物理模板，不重读原始计数器，不认证主稿的残差重采样覆盖。私有审阅包不包含该完整来源树；本地工作目录保留它，固定提交提供取回依据。

## 主估计回放

**尚不可运行。** `data/PRIMARY_INPUT_CONTRACT.json` 列出缺少的匹配输入。找到后应先核对掩码、模板定义、时间轴和版本，再按原方案回放。不得调参追求0.97或用R7保存表填补缺项。

主稿数据表 `data/reported_primary_estimates.csv` 的每行都是文献式报告值索引，不可当作观测数据传入拟合程序。谱曲线、夏季折叠和删除图的矢量来源可追踪，但对应数值数组仍需主链作者提供。
