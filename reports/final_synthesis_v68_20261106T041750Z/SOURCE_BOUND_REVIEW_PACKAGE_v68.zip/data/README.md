# v68 数据与来源索引

本目录不把文稿数字伪装成逐点观测。

- `reported_primary_estimates.csv`：19 项 v29/v66 报告值，附原 PDF 的 SHA256、对应数值出现页、误差定义和 `AUTHOR_REPORTED_PDF_VERIFIED` 状态。没有生成或插入原始观测。
- `secondary_R7_replayed_summary.json`：指定提交 R7 的保存表回放结果。固定相位的9组拟合与6张诊断表已分别实际回放；只作为第二套归约的验证记录，不输入主文主估计。
- `INPUT_MANIFEST.json`：实际读取的来源文件和哈希。
- `PRIMARY_INPUT_CONTRACT.json`：主链复核仍需的样本、模板和运行记录；R7 输入不得冒充这些缺项。
- `../figures/FIGURE_PROVENANCE.json`：四图面板来源、原 PDF 页与裁剪坐标、报告值绘制说明、最终哈希。频谱与逐 campaign 删除图没有从图片反推或补造观测数组。
- `../verification/`：本轮实际运行日志和文档/图件检查。`SOURCE_PDF_VERIFIED` 不等于 `RAW_REPRODUCED`。

## 访问与复现范围

原科研目录及原始观测保持只读。固定提交的 R7 文件保存在 `../sources/R7_tree/`；这是隔离的来源副本。R7 算术可在该目录按 `REPRODUCE.md` 回放。主链的完整原始重算尚不能运行，因为与 v29 精确匹配的最终掩码、直接势模板和重采样生成链未定位。

用于私有 GitHub 的审阅包只含文稿、图件、来源索引、报告值及验证记录；不上传原始计数器或完整第三方海潮产品。本地来源副本与主链缺项分开保存，不宣称这个审阅包是完整的主分析复现数据集。
