from pathlib import Path
import re,json,hashlib,zipfile
import fitz
O=Path(__file__).resolve().parent
(O/'verification/delivery').mkdir(parents=True,exist_ok=True)
md=(O/'NATURE_ARTICLE_v67.md').read_text(); base=json.loads((O/'BASELINE.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks={}
checks['primary_sentence_frozen']='The lunar amplitude relative to the solid Earth tide plus the full ocean-loading potential is $0.97\\pm0.14$.' in md
checks['title_correct']=md.splitlines()[0]=='# Lunar tidal potential measured on a coastal–inland optical-clock baseline'
checks['draft_markers_absent']=not any(s in md for s in ['[To be completed]','[Source]','Author-review Article','^25^','^26^','^27^'])
checks['removed_unneeded_references']=not any(s in md for s in ['Lyard,','Ding,','Cameron,','Frisch','Efron,'])
checks['fes_dataset_doi']='10.24400/527896/A01-2024.004' in md
checks['software_concept_doi']='10.5281/zenodo.5156864' in md
checks['figures_unchanged']=all(sha(O/'figures'/f)==s for f,s in base['figure_hashes'].items())
checks['old_manuscript_unchanged']=sha(O/'sources/NATURE_ARTICLE_v66.md')==base['source_sha256']
main=md.split('## Main text\n',1)[1].split('## References\n')[0]
methods=md.split('## Methods\n',1)[1].split('## Methods references\n')[0]
abstract=md.split('## Abstract\n',1)[1].split('## Main text')[0]
def wc(t):
 t=re.sub(r'\$\$[\s\S]*?\$\$',' MATH ',t);t=re.sub(r'\$[^$]+\$',' MATH ',t)
 t=re.sub(r'\^[\d,–-]+\^|\\clearpage|^#+.*$','',t,flags=re.M)
 return len(t.split())
checks['abstract_within_150']=wc(abstract)<=150
checks['title_within_75']=len(md.splitlines()[0][2:])<=75
checks['methods_no_displays']='![]' not in methods and not re.search(r'^\|',methods,re.M)
checks['ed_count_allowed']=len(re.findall(r'^\*\*Extended Data Table \d',md,re.M))==2
checks['period_p_method_only']='P=0.008' in methods and 'P=0.008' not in main
checks['null_count_method_only']='20,000' in methods and '20,000' not in main
checks['no_new_fit']=base['new_fit'] is False
checks['figure2_display_boundary']='inference uses the residual-resampling uncertainty of the amplitude fit' in main and 'holding fitted non-lunar terms fixed' in md
# Reading order excludes bibliography entries; affiliations are not citations.
text=md.split('## Abstract',1)[1]
text=re.sub(r'## References\n[\s\S]*?(?=## Figure legends)','',text)
text=re.sub(r'## Methods references\n[\s\S]*?(?=## Extended Data)','',text)
seen=[]
for match in re.findall(r'\^([\d,–-]+)\^',text):
 for token in match.split(','):
  z=re.split('[–-]',token)
  for n in range(int(z[0]),int(z[-1])+1):
   if n not in seen:seen.append(n)
checks['first_citation_order']=seen==list(range(1,24))
bibnums=[int(x) for x in re.findall(r'^(\d+)\. ',md,re.M)]
checks['bibliography_contiguous']=bibnums==list(range(1,24))
captions=re.findall(r'\*\*Fig\. ([1-4]) \|([\s\S]*?)(?=\\clearpage)',md)
cap_counts={n:wc(cap) for n,cap in captions}
checks['captions_under_250']=len(cap_counts)==4 and all(v<250 for v in cap_counts.values())
pdf=fitz.open(O/'render_v67_delivery/NATURE_ARTICLE_v67.pdf')
pages=[]
for i,p in enumerate(pdf):
 txt=p.get_text();blocks=p.get_text('dict')['blocks'];spans=[s for b in blocks for l in b.get('lines',[]) for s in l.get('spans',[])]
 overflow=[s['text'] for s in spans if s['text'].strip() and (s['bbox'][0]<0 or s['bbox'][2]>p.rect.width+0.5 or s['bbox'][3]>p.rect.height+0.5)]
 pages.append({'page':i+1,'chars':len(txt),'lines':len(txt.splitlines()),'overflow':overflow,'start':' '.join(txt.splitlines()[:9]),'ed_table':re.findall(r'Extended Data Table [12]',txt)})
 checks[f'page_{i+1}_no_overflow']=not overflow
 p.get_pixmap(matrix=fitz.Matrix(0.9,0.9)).save(O/'verification/delivery'/f'page_{i+1:02d}.png')
checks['pdf_no_draft_markers']=not any(x in ''.join(p.get_text() for p in pdf) for x in ['Author-review Article','To be completed'])
with zipfile.ZipFile(O/'render_v67_delivery/NATURE_ARTICLE_v67.docx') as z:
 xml=z.read('word/document.xml').decode();mathcount=xml.count('<m:oMath>');tables=xml.count('<w:tbl>')
checks['docx_native_math']=mathcount>50
checks['docx_editable_tables']=tables==2
result={'status':'DOCUMENT_CHECKS_PASS' if all(checks.values()) else 'FAIL','checks':checks,'word_counts':{'abstract':wc(abstract),'main':wc(main),'methods_including_availability_AI':wc(methods),'captions':cap_counts},'counts':{'main_figures':4,'extended_data_tables':2,'references':23,'pdf_pages':len(pdf),'docx_math':mathcount,'docx_tables':tables},'primary_result_status':'AUTHOR_REPORTED_PDF_VERIFIED','raw_data_reproduced_this_round':False,'new_fit':False,'submission_ready':False,'visual_status':'PENDING','pdf_sha256':sha(O/'render_v67_delivery/NATURE_ARTICLE_v67.pdf'),'pages':pages}
(O/'VALIDATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ['pages','checks']},ensure_ascii=False))
print('Failures:',[k for k,v in checks.items() if not v]);print('Pages:',[(p['page'],p['chars'],p['ed_table']) for p in pages])
