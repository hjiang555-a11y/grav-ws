# v70 editable manuscript source

This package contains the English Markdown, vector figure artwork and the PDF/Word renderer. It does not contain raw counter data or reproduce the full physical analysis. Figure source-data identities and estimator boundaries are documented in V70_REVISION_REPORT.md and figures/FIGURE_PROVENANCE.json.

Compile in this folder using Python with python-docx, Pandoc and XeLaTeX:

    python render_working.py NATURE_ARTICLE_v70_WORKING.md render_new

The output directory must not already exist. The original research audit package remains in the project workspace. No scientific result is newly estimated by this renderer.
