# Referee data and code

The observed sample is exactly 3299 accepted ten-minute means, 54 segments and 1965327 nominal one-second members. The experiment is one Shanghai–Wuhan clock pair. Files under review_diagnostics are conditional simulations or diagnostics, not added experimental measurements. The Source Data workbook identifies each role and units.

This package starts from the verified frozen means and physical predictions. It does not claim a new raw-counter reconstruction. The original counter/member archive is held by the experimental team. Numerical fit entry points: scripts/segment_reduce.py and scripts/full_tide_detection.py. The former is equivalent to fitting 54 independent intercepts; the latter fits one complete physical template. scripts/review_statistics.py and scripts/check_noise_adequacy.py reproduce targeted weak-group stress tests.

The primary fit uses all accepted means, original weights and actual UTC. No fit-based gap filling or cross-segment joining is performed. Source figures can be regenerated with scripts/draw_figure1.py and scripts/draw_segments.py. The geographic panel is an unmodified author-supplied PNG illustration; its background-field generator was not supplied and does not feed the fitted numerical templates.

Use a scratch extraction and the recorded package versions. All output directories are already represented in this archive. Raw measurements and original workspaces remain untouched.
