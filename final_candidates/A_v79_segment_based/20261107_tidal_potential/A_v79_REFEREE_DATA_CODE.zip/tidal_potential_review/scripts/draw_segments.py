"""One frozen v78 reduction: phase, actual segment, and cross-period support."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.patches import Ellipse
from segment_reduce import center

O=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(O/'vendor'))
from audit_panel_alignment import require_matplotlib_panel_alignment
F=O/'figures';S=O/'segment_reduction'
j=json.loads((O/'data/RESULTS.json').read_text());full=json.loads((S/'FULL_TIDE.json').read_text())
r=pd.read_csv(S/'segment_rows.csv');fold=pd.read_csv(O/'data/phase_fold.csv')
d=np.load(O/'data/design.npz');sigma=d['sigma'];seg=d['seg'];w=1/sigma**2
raw,_=center(r.y.to_numpy(),w,seg)
unit,_=center(d['three'].sum(axis=1)+d['fixed'],w,seg)
r['raw_segment_centered']=raw;r['full_unit_segment_centered']=unit
r.to_csv(S/'display_source_rows.csv',index=False)
ledger=pd.read_csv(S/'segment_ledger.csv');chosen=int(ledger.sort_values(['accepted_members','seg'],ascending=[False,True]).iloc[0].seg)
take=np.flatnonzero(seg==chosen);dates=pd.to_datetime(r.t_utc,utc=True)
epoch=dates.map(lambda x:x.timestamp()).to_numpy();groups=(epoch[take]//10800).astype(int)
display=[]
for group in np.unique(groups):
    ix=take[groups==group];ww=w[ix]
    display.append(dict(t_utc=pd.to_datetime(np.average(epoch[ix],weights=ww),unit='s',utc=True).isoformat(),
                        observed=np.average(raw[ix],weights=ww),prediction=np.average(unit[ix],weights=ww),
                        SE=np.sqrt(max(0,full['scale']*(1/ww.sum()-1/w[take].sum()))),
                        rows=len(ix),members=int(r.iloc[ix].n.sum())))
display=pd.DataFrame(display);display.to_csv(S/'representative_UTC_3h.csv',index=False)
assert display.rows.sum()==len(take) and display.members.sum()==int(r.iloc[take].n.sum())
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans'],'font.size':7,
 'axes.labelsize':7,'axes.titlesize':7,'xtick.labelsize':6,'ytick.labelsize':6,'legend.fontsize':6,
 'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,
 'axes.linewidth':.7,'legend.frameon':False})
blue='#126080';orange='#bc651f';green='#50816c';purple='#80619b';grey='#737373'
factor=299792458.0**2*1e-18
provenance=[]
selected=set(sys.argv[1:])

def letter(ax,label):
    ax.annotate(label,(0,1),xycoords='axes fraction',xytext=(-12,7),textcoords='offset points',
                fontsize=8,fontweight='bold',va='bottom')

def save(fig,name,axes,labels,**kwargs):
    if selected and name not in selected:
        plt.close(fig)
        return
    fig.canvas.draw()
    require_matplotlib_panel_alignment(fig,json_out=F/(name+'.alignment.json'),
        overlay_svg=F/(name+'.alignment.svg'),axes=axes,panel_ids=labels,strict=True,**kwargs)
    fig.savefig(F/(name+'.pdf'));fig.savefig(F/(name+'.svg'));fig.savefig(F/(name+'.png'),dpi=450)
    plt.close(fig)
    provenance.append(dict(figure=name,pdf_SHA256=hashlib.sha256((F/(name+'.pdf')).read_bytes()).hexdigest()))

def potential_axis(ax):
    ax.set_ylabel('Equivalent potential U\n(m²/s²)')
    twin=ax.secondary_yaxis('right',functions=(lambda v:v/factor,lambda v:v*factor))
    twin.set_ylabel('Fractional rate\n(10⁻¹⁸)',labelpad=5)
    twin.spines['right'].set_visible(True)

# Phase evidence is dominant; the longest segment is selected before inspecting fit.
fig=plt.figure(figsize=(180/25.4,163/25.4))
a=fig.add_axes([.16,.67,.68,.24]);b=fig.add_axes([.16,.35,.68,.20]);c=fig.add_axes([.16,.11,.68,.12])
a.errorbar(fold.phase_deg,fold['mean']*factor,yerr=fold.se*factor,fmt='o',ms=3.5,capsize=2,color=blue,label='Observed phase means')
a.plot(fold.phase_deg,fold.unit*factor,color=orange,lw=1.2,label='Unit lunar prediction')
a.set(xlim=(0,360),xticks=fold.phase_deg,xticklabels=[f'{int(x)}°\n{int(n)}' for x,n in zip(fold.phase_deg,fold.n_rows)],
      ylim=(-.72,.72),yticks=[-.6,-.3,0,.3,.6],xlabel='M₂ phase; row count below each bin')
a.legend(loc='lower left',bbox_to_anchor=(0,1.04),ncol=2)
potential_axis(a)
bd=pd.to_datetime(display.t_utc,utc=True,format='ISO8601')
b.errorbar(bd,display.observed*factor,yerr=display.SE*factor,fmt='o',color=blue,ms=3,capsize=2,label='3-h observed means')
b.plot(dates.iloc[take],unit[take]*factor,color=orange,lw=1.1,label='Unit combined prediction')
# Mark the identically averaged unit prediction on the observation-average centres.
b.plot(bd,display.prediction*factor,'s',ms=2.5,color=orange)
limits=np.r_[((display.observed-display.SE)*factor).to_numpy(),((display.observed+display.SE)*factor).to_numpy(),unit[take]*factor]
pad=np.ptp(limits)*.10;b.set_ylim(limits.min()-pad,limits.max()+pad)
b.legend(loc='lower left',bbox_to_anchor=(0,1.03),ncol=2)
potential_axis(b)
c.scatter(dates.iloc[take],raw[take]*factor,s=3,color=grey,alpha=.55,linewidths=0,rasterized=True)
c.plot(dates.iloc[take],unit[take]*factor,color=orange,lw=.8)
lo,hi=(raw[take]*factor).min(),(raw[take]*factor).max();c.set_ylim(lo-.06*(hi-lo),hi+.06*(hi-lo))
potential_axis(c)
for ax in [b,c]:
    ax.set_xlim(dates.iloc[take[0]],dates.iloc[take[-1]])
    ax.xaxis.set_major_locator(mdates.HourLocator(byhour=[0,12],tz=dates.dt.tz))
    ax.xaxis.set_major_formatter(mdates.DateFormatter('%d %b\n%H:%M',tz=dates.dt.tz))
b.tick_params(labelbottom=False)
c.set_xlabel('Actual UTC, 2026; longest accepted segment (42.5 member-hours)')
for ax,label in zip([a,b,c],'abc'):letter(ax,label)
save(fig,'figure2',[a,b,c],list('abc'),column_groups=[list('abc')])

# The overall one-template response precedes the two group coefficients.
spec=pd.read_csv(O/'data/semidiurnal_spectrum.csv')
fig=plt.figure(figsize=(180/25.4,137/25.4))
a=fig.add_axes([.19,.59,.25,.28]);b=fig.add_axes([.63,.59,.22,.28]);c=fig.add_axes([.19,.12,.66,.29])
a.axvline(1,color='.55',ls='--',lw=.7)
for value,error,y0,color in [(full['A'],full['SE'],2,green),(j['primary']['A'][0],j['primary']['u'][0],1,blue),(j['primary']['A'][1],j['primary']['u'][1],0,orange)]:
    a.errorbar(value,y0,xerr=error,fmt='o',color=color,capsize=3,ms=4)
a.set(yticks=[2,1,0],yticklabels=['Full tide','Lunar M₂ + N₂','Neighbouring S₂ + K₂'],ylim=(-.5,2.5),xlim=(-.1,1.65),xticks=[0,.5,1,1.5],xlabel='Response coefficient')
a.set_title('Overall and grouped responses',loc='left',pad=12)
iq=np.array(j['iq']['A'][:2]);cov=np.array(j['iq']['cov_scaled_ls'])[:2,:2]
ev,ve=np.linalg.eigh(cov);order=np.argsort(ev)[::-1];ev=ev[order];ve=ve[:,order]
angle=np.degrees(np.arctan2(ve[1,0],ve[0,0]))
for radius,alpha in [(2,.4),(1,1)]:b.add_patch(Ellipse(iq,2*radius*np.sqrt(ev[0]),2*radius*np.sqrt(ev[1]),angle=angle,fill=False,color=blue,alpha=alpha,lw=1))
b.plot(*iq,'o',color=blue,ms=4);b.plot(1,0,'+',color='black',ms=7)
b.axhline(0,color='.8',lw=.5);b.axvline(1,color='.8',lw=.5)
b.set(xlim=(.60,1.40),ylim=(-.6,.4),xlabel='Lunar in-phase response',ylabel='Lunar quadrature response')
b.set_title('Phase relative to prediction',loc='left',pad=12)
use=spec.frequency_uHz.between(21,24.5);z=spec[use]
c.plot(z.frequency_uHz,z.observed_potential_PSD_m4_sminus4_per_uHz,color=blue,lw=.8,label='Observed')
c.plot(z.frequency_uHz,z.residual_potential_PSD_m4_sminus4_per_uHz,color=orange,lw=.9,ls='--',label='After unit physical prediction')
ymax=max(z.observed_potential_PSD_m4_sminus4_per_uHz.max(),z.residual_potential_PSD_m4_sminus4_per_uHz.max())*1.20
c.set(xlim=(21,24.5),ylim=(0,ymax),xticks=np.arange(21,24.51,.5),xlabel='Frequency (µHz)',ylabel='Potential power density\n[(m²/s²)²/µHz]')
twin=c.secondary_yaxis('right',functions=(lambda x:x/299792458.0**4/1e-35,lambda x:x*1e-35*299792458.0**4))
twin.set_ylabel('Fractional-frequency power density\n(10⁻³⁵/µHz)',labelpad=6);twin.spines['right'].set_visible(True)
c.legend(loc='lower left',bbox_to_anchor=(0,1.08),ncol=2)
for frequency,label,color in [(22.3642775328,'M₂ · 12.42 h',blue),(23.1481474586,'S₂ · 12.00 h',orange)]:
    c.axvline(frequency,color=color,ls=':',lw=.9,ymax=.87)
    c.text(frequency,.93*ymax,label,ha='center',fontsize=7,color='black',fontweight='bold')
for ax,label in zip([a,b,c],'abc'):letter(ax,label)
save(fig,'figure3',[a,b,c],list('abc'),row_groups=[['a','b']],exemptions=[{'panels':['a','b'],'checks':['panel-width'],'reason':'Intentional interval-panel and phase-plane widths retained from v78; different outer labels.'}])

# Both group coefficients have the same deletion/zero-point comparison support.
deletions=pd.read_csv(O/'data/leave_period_all_designs.csv');deletions=deletions[deletions.design=='S54']
fig=plt.figure(figsize=(180/25.4,150/25.4))
a=fig.add_axes([.18,.43,.31,.46]);b=fig.add_axes([.63,.43,.31,.46])
c=fig.add_axes([.18,.12,.31,.16]);e=fig.add_axes([.63,.12,.31,.16])
names=['Full record','Before summer','Summer']+['Omit '+p for p in deletions.omitted]
for k,ax in enumerate([a,b]):
    key='L' if k==0 else 'S';color=blue if k==0 else orange
    values=[j['primary']['A'][k],j['subsets']['early']['A'][k],j['subsets']['summer']['A'][k]]+deletions['A_'+key].tolist()
    errors=[j['primary']['u'][k],j['subsets']['early']['u'][k],j['subsets']['summer']['u'][k]]+deletions['u_'+key].tolist()
    yy=np.arange(len(values))[::-1]
    ax.errorbar(values,yy,xerr=errors,fmt='o',color=color,ms=3,capsize=2)
    ax.axvline(1,color='.6',ls='--',lw=.7)
    if k==1:ax.axvline(0,color='.8',lw=.5)
    ax.set(yticks=yy,yticklabels=names if k==0 else ['']*len(names),ylim=(-.6,len(values)-.4),
           xlabel='Lunar response A_L' if k==0 else 'Neighbouring response A_S')
    if k==0:ax.set_xlim(.35,1.65)
    else:
        bounds=np.r_[np.array(values)-errors,np.array(values)+errors]
        ax.set_xlim(min(-.3,bounds.min()-.1),max(1.7,bounds.max()+.1))
for k,ax in enumerate([c,e]):
    for n,scheme in enumerate(['S54','G29','P8']):
        x=j['designs'][scheme]
        ax.errorbar(x['A'][k],2-n,xerr=x['u'][k],fmt='o',color=blue if k==0 else orange,ms=3,capsize=2)
    ax.axvline(1,color='.6',ls='--',lw=.7)
    ax.set(yticks=[2,1,0],yticklabels=['54 segments','29 groups','8 periods'] if k==0 else ['','',''],
           ylim=(-.5,2.5),xlabel='Lunar response A_L' if k==0 else 'Neighbouring response A_S')
    ax.set_xlim((.70,1.30) if k==0 else (0,1.7))
for ax,label in zip([a,b,c,e],'abcd'):letter(ax,label)
save(fig,'figure4',[a,b,c,e],list('abcd'),row_groups=[['a','b'],['c','d']],column_groups=[['a','c'],['b','d']])

# Diagnostic conditional regions never replace the observed max-SE convention.
review=json.loads((O/'review_diagnostics/REVIEW_RESULTS.json').read_text())
sim=pd.read_csv(O/'review_diagnostics/simulation_draws.csv')
fig=plt.figure(figsize=(180/25.4,104/25.4));a=fig.add_axes([.12,.21,.33,.62]);b=fig.add_axes([.62,.21,.33,.62])
labels=['Gaussian','50% 6 h OU','50% 24 h OU','Student t₅']
colors=[grey,orange,green,purple];styles=['--','-','-.',':']
for record,label,color,style in zip(review['joint_regions'],labels,colors,styles):
    cov=np.array(record['error_covariance']);eigen,vectors=np.linalg.eigh(cov)
    order=np.argsort(eigen)[::-1];eigen=eigen[order];vectors=vectors[:,order]
    angle=np.degrees(np.arctan2(vectors[1,0],vectors[0,0]));radius=np.sqrt(record['mahalanobis_95'])
    a.add_patch(Ellipse(j['primary']['A'][:2],2*radius*np.sqrt(eigen[0]),2*radius*np.sqrt(eigen[1]),
                        angle=angle,fill=False,edgecolor=color,ls=style,lw=1,label=label))
    values=np.sort(sim.loc[sim.scenario==record['scenario'],'delta_RSS'])
    b.semilogy(values,(len(values)-np.arange(len(values)))/(len(values)+1),color=color,ls=style,lw=1,label=label)
a.plot(*j['primary']['A'][:2],'o',color=blue,ms=4);a.plot(1,1,'+',color='black',ms=7)
a.axhline(0,color='.65',lw=.7);a.set(xlim=(.15,1.85),ylim=(-.7,2.6),xlabel='Lunar response A_L',ylabel='Neighbouring response A_S')
a.legend(loc='lower left',bbox_to_anchor=(-.02,1.05),ncol=2,handlelength=1.6,columnspacing=.8)
b.axvline(review['nested']['delta_RSS'],color='black',lw=.8,label='Observed improvement')
b.axhline(.05,color='.75',lw=.6,ls=':');b.set(xlim=(0,50),ylim=(4e-5,1),xlabel='Added-group Δweighted RSS',ylabel='Null tail fraction')
b.set_yticks([1,.1,.01,.001,.0001],labels=['1','0.1','0.01','0.001','0.0001'])
from matplotlib.ticker import NullFormatter
b.yaxis.set_minor_formatter(NullFormatter())
for ax,label in zip([a,b],'ab'):letter(ax,label)
save(fig,'extended4',[a,b],list('ab'),row_groups=[['a','b']])

prior=json.loads((S/'FIGURE_PROVENANCE.json').read_text())['figures'] if selected and (S/'FIGURE_PROVENANCE.json').exists() else []
provenance=[x for x in prior if x['figure'] not in {y['figure'] for y in provenance}]+provenance
(S/'FIGURE_PROVENANCE.json').write_text(json.dumps(dict(figures=provenance,representative_segment=chosen,
 objective_rule='Largest accepted member count, tie broken by smallest segment ID',
 display_3h_all_rows_in_selected_segment=int(display.rows.sum()),primary_all_rows=3299,
 conversion='U=c²y=−(δW_Wuhan−δW_Shanghai), c exact; factor='+str(factor)),indent=2)+'\n')
print('Exported new figure2, figure4 and extended4; selected segment',chosen)
