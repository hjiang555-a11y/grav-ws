"""Create traceable source data and author-review records from executed outputs."""
from pathlib import Path
import json,platform,hashlib
import numpy as np
import pandas as pd

O=Path(__file__).resolve().parents[1]
j=json.loads((O/'data/RESULTS.json').read_text());full=json.loads((O/'segment_reduction/FULL_TIDE.json').read_text())
segment=json.loads((O/'segment_reduction/RESULTS.json').read_text())
review=json.loads((O/'review_diagnostics/REVIEW_RESULTS.json').read_text())
manifest=json.loads((O/'original/INPUT_MANIFEST.json').read_text())
ledger=pd.read_csv(O/'data/period_ledger.csv');ledger['acquisition_relation']=np.where(ledger.period.isin(['P6','P7','P8']),'Overlapping summer acquisition windows','Additional early acquisition windows')
ledger.to_csv(O/'segment_reduction/ACQUISITION_OVERLAP.csv',index=False)

claims=[dict(claim='Full tidal response',value=full['A'],SE=full['SE'],file='segment_reduction/FULL_TIDE.json',estimator='One complete template scale; weighted within-segment reduction',status='RECOMPUTED'),
        dict(claim='Lunar group',value=j['primary']['A'][0],SE=j['primary']['u'][0],file='segment_reduction/RESULTS.json',estimator='Three-group weighted within-segment reduction',status='RECOMPUTED'),
        dict(claim='Neighbouring group',value=j['primary']['A'][1],SE=j['primary']['u'][1],file='segment_reduction/RESULTS.json',estimator='Same joint estimator',status='RECOMPUTED'),
        dict(claim='All accepted observations',rows=3299,segments=54,hours=j['sample_hours'],file='data/primary_rows.csv',status='FROZEN_INPUT_VERIFIED'),
        dict(claim='Measured spectrum',file='data/semidiurnal_spectrum.csv',estimator='Original equal-weight segment-projected scan on actual UTC; no gap filling',status='FROZEN_REPLAYED_IN_BASELINE')]
(O/'data/CLAIM_LEDGER.json').write_text(json.dumps(claims,indent=2)+'\n')
source_data=O/'release/Source_Data_A_v79_SEGMENT.xlsx'
with pd.ExcelWriter(source_data,engine='openpyxl') as writer:
    for sheet,path in [('Observations_3299','data/primary_rows.csv'),('Segment_54','segment_reduction/segment_ledger.csv'),
                       ('Segment_centered_rows','segment_reduction/display_source_rows.csv'),
                       ('UTC_3h_display','segment_reduction/representative_UTC_3h.csv'),('Phase_12','data/phase_fold.csv'),
                       ('Group_estimates','data/error_table.csv'),('12h_sensitivity','review_diagnostics/twelve_hour_sensitivity.csv'),
                       ('Period_deletions','data/leave_period_all_designs.csv'),('Reference_levels','data/design_table.csv'),
                       ('Spectrum_semidiurnal','data/semidiurnal_spectrum.csv'),('Conditional_spectra','data/conditional_scans.csv'),
                       ('Acquisition_overlap','segment_reduction/ACQUISITION_OVERLAP.csv'),
                       ('Simulation_noise_adequacy','review_diagnostics/noise_adequacy.csv')]:
        pd.read_csv(O/path).to_excel(writer,sheet_name=sheet,index=False)
    pd.DataFrame([{k:v for k,v in full.items() if isinstance(v,(int,float,str))}]).to_excel(writer,sheet_name='Full_tide_response',index=False)
    pd.DataFrame(full['conditional_stress_tests']).assign(test='Full template').to_excel(writer,sheet_name='Simulation_full_null',index=False)
    pd.DataFrame(review['null_tests']).to_excel(writer,sheet_name='Simulation_weak_null',index=False)
    pd.DataFrame([dict(scenario=x['scenario'],calibration_n=x['calibration_n'],validation_n=x['validation_n'],
                      nominal_region=.95,validation_coverage=x['validation_coverage'],q95=x['mahalanobis_95'],
                      cov_LL=x['error_covariance'][0][0],cov_LS=x['error_covariance'][0][1],cov_SS=x['error_covariance'][1][1]) for x in review['joint_regions']]).to_excel(writer,sheet_name='Simulation_joint_regions',index=False)
    monitor=pd.read_csv(O/'sources/frozen_v72/monitor_monitor_rows.csv');monitor[monitor.included_in_fit].to_excel(writer,sheet_name='Monitor_paired_members',index=False)
    pd.DataFrame([dict(file=f,SHA256=h) for f,h in manifest['sha256'].items()]).to_excel(writer,sheet_name='Frozen_input_hashes',index=False)
    if (O/'assets/author_figure1a/PROVENANCE.json').exists():
        image=json.loads((O/'assets/author_figure1a/PROVENANCE.json').read_text())
        pd.DataFrame([dict(asset='1a.png',SHA256=image['sha256'],role='Author-supplied model/geographical illustration',
                           numerical_fit_input=False,background_grid_source='Not supplied with the image; author provenance item')]).to_excel(writer,sheet_name='Figure1a_asset',index=False)
    pd.DataFrame([dict(field='Observation units',value='Fractional rate in 1e-18 in CSV columns; potential display U=c²y.'),
                  dict(field='Simulation sheets',value='Synthetic diagnostic records and summaries; never added to experimental observations.'),
                  dict(field='Display averaging',value='Fixed UTC 3-hour means of the objectively longest segment; inference uses all original 3299 rows.'),
                  dict(field='Replication',value='Repeated observations of one clock pair; 43 UTC-day clusters, 8 periods, 54 segment nuisance levels.')]).to_excel(writer,sheet_name='Read_me',index=False)

report=f'''# 段内归算版：潮汐探测与半日潮成分约束

以 v78 为底稿，使用 Nature writing/polishing/figure/statistics 工作流。按作者最新定位，题为 **Tidal potential measured by optical clocks on a coastal-inland baseline**。第一层结论是光钟探测到动态潮汐位势，第二层是同一记录中半日潮组的联合约束。正文没有首次或优先权宣称；欧洲仅讨论最后一句。装置前作不作为本稿统计结果的依据，观测重叠在下文和投稿信单独披露。

## 数据与实验单位

原输入仍为 {j['n_rows']} 个有效均值、54 段、8 期、43 个 UTC 日，{j['n_members']:,} 个名义一秒成员，即 {j['sample_hours']:.6f} h。这是一对光钟的重复观测，不能视为数千次独立实验。全部原始观测文件及 v78 只读，本轮没有增加观测、剔除成员或填补空档。

本轮独立验证从冻结的十分钟均值和模板开始；不冒称重新从全部原始计数独立生成。原始支持清单和既有成员审计保留在来源目录，提交前须由实验团队确认。

## 段内归算是什么

每段对数据与每个模型列分别去掉加权均值，再汇总段内充分统计量，共同估计物理响应。不先逐段估计三个幅度再平均，也不使用拟合潮汐系数调整段中心。该写法与原 54 截距模型严格等价：与完整 QR 相比，最大系数差为 {segment['maximum_difference_from_full_QR']:.3g}，LS、删日、删期标准误均在数值精度内一致。时间单位经过显式 UTC 秒检查，避免 pandas 微秒/纳秒存储精度混淆。

## 新增总体响应

完整组合预测（包括余项）只乘一个尺度，得到 **A_T={full['A']:.6f}±{full['SE']:.6f}**；稿内写 0.96±0.11。缩放 LS={full['scaled_LS']:.6f}，删日={full['day_JK']:.6f}，按日 CR1={full['day_CR1']:.6f}，删期={full['period_JK']:.6f}。工作区间为 [{full['working_95'][0]:.6f}, {full['working_95'][1]:.6f}]，不称作对任意噪声均校准的置信区间。

增加该单一模板使加权 RSS 降低 {full['delta_RSS']:.6f}，残差自由度 {full['df']}。四种事先声明的噪声场景各 20,000 次，均为 0/20,000 达到该改善；plus-one 尾估计为 1/20,001，不能写成零概率。保留期内结构的 256 种受限残差符号翻转给出 P={full['period_restricted_wild_P']:.7f}，已到双侧分辨率下限。该诊断依赖期独立/对称，不能冒充随机试验的精确检验。

## 半日潮结果与边界

共同估计仍给月球组 {j['primary']['A'][0]:.6f}±{j['primary']['u'][0]:.6f}，邻近组 {j['primary']['A'][1]:.6f}±{j['primary']['u'][1]:.6f}。组内幅比、相位由天文模板固定；K₂ 不是纯太阳强迫，N₂/K₂ 没有各自独立测量。全日组仅作辅助分量。三组系数、相位和谱图使用同一观测，不能累加显著性。

弱组零假设的噪声敏感性、12 h 退化和 P=0.0625 的期内结构诊断完整保留。假设 6 h OU 与实测 lag-1 残差结构不相符，其 P=0.126 只作为压力情景；不能将其当成真实测量噪声，也不能反选有利噪声。所有模拟都在单独目录，未混入实验记录。自由 12 h 项是可辨识性情景，不赋予未经实测的实验室变量或幅度。

## 图与可复算来源

- 图 1：按作者指示直接嵌入所供1a.png，原图字节不变；相量、采样和相位面板按冻结输入重绘。地图陆地是归一化钟速、海域是潮高，不混淆单位。合成 M₂ 数值幅度约 0.43 m²/s²。相量采用等数据轴比例。地图背景源网格未随图提供，不参与数值拟合。
- 图 2：全记录相位为主面板；第 51 段仅按最大有效成员数选出（255 点、42.5 h）。真实 UTC 三小时均值与预测用相同算子，下方保留全部十分钟点完整范围。左轴为 U=c²y，右轴为分数频率，未按拟合优度挑选窗口。
- 图 3：总体潮汐尺度置于首位，并列已核验两组幅度、同相/正交检验及真实窗口的半日实测谱；0.78 µHz 是已知天文主频间距，局部峰差为 0.786 µHz，未给出频率估计置信区间。
- 图 4：同时展示两组的删期和同数据零点敏感性。
- 扩展图 4：弱组条件联合区域及模拟零假设，不称作真实噪声已校准区域。旧稿中尚未独立复算的另一条归算结果已移到审阅归档，不作为本版论文证据。

各图 CSV、源代码、PDF/SVG 和源数据工作簿均随包保存。统计脚本在 scripts/，冻结输入在 data/，新段内派生量在 segment_reduction/，合成模拟明确放在 review_diagnostics/。Python/pandas/NumPy/Matplotlib、Pandoc、XeLaTeX 版本由验证记录列出。

## 与前作的观测关系

当前归算的 P6–P8（16 段）覆盖 2026-06-29 至 2026-08-26 UTC，保留 {ledger[ledger.period.isin(['P6','P7','P8'])].accepted_hours.sum():.6f} h，属于与频率比稿重叠的夏季采集窗口。P1–P5 的 38 段增加 {ledger[~ledger.period.isin(['P6','P7','P8'])].accepted_hours.sum():.6f} h，覆盖 2025 年9/10月及2026年1/4/5月。按当前归算给出的小时数不等同于已经证明两稿逐秒掩膜完全相同。原频率比稿的夏季总模板数值归属其独立模型，不用于本稿的检出概率。

## 尚需作者确认

作者名单/顺序/通讯信息、基金与贡献/利益声明、审稿访问和永久数据代码标识仍不能代填。当前已准备可上传的源数据与代码包，但私有 GitHub 不自动赋予编辑/审稿人访问权。实际投稿前需作者选择上传至投稿系统或提供可访问私密链接，并复核原始计数来源。没有自动投稿或公开发布。
'''
(O/'ANALYSIS_AND_REVISION_ZH.md').write_text(report)
(O/'review_diagnostics/README.md').write_text('# Simulations and diagnostics, not new observations\n\nEvery synthetic record is a conditional noise simulation. The experimental input is always the unchanged 3299-row file in data/. No simulation is ever concatenated with observations. Noise laws are declared sensitivity assumptions and are not selected using a favourable tidal P value.\n')

cover='''Dear Editors,

We submit “Tidal potential measured by optical clocks on a coastal-inland baseline” for consideration as a Nature Article. A strontium clock in coastal Shanghai and an ytterbium clock in inland Wuhan, 692 km apart, detect tidal changes in their relative gravitational potential. The complete prediction has a measured scale of 0.96 ± 0.11 on 545.9 hours spread across 353 days. A reduction within 54 interrupted observing segments retains the astronomical phase without transferring their frequency levels. We then constrain two neighbouring semidiurnal groups, with their internal amplitudes and phases fixed, while keeping same-frequency sensitivity distinct from the overall detection.

The summer acquisition windows overlap those used in Hou et al., arXiv:2610.34250, whose primary objective is an absolute frequency ratio. The present reduction contains 273.925 summer member-hours and 271.999 additional early member-hours; the attached acquisition table lists their dates. We do not update the ratio or transfer the statistical significance of its tidal-correlation check. The experimental team must confirm the exact cross-manuscript member-mask overlap before submission.

We cite independent, contemporaneous European results, Stahl et al., arXiv:2610.39635. Nature Portfolio does not treat preprints as prior publication or include them when assessing the advance of a manuscript under consideration. We make no date-based priority claim. The source-data workbook and reproducibility archive are prepared for referee access.

[Corresponding author and contact; author approval and submission declarations to be completed.]
'''
(O/'COVER_LETTER_DRAFT.md').write_text(cover)
readme='''# Reproduce the segment-based author-review candidate

This version starts from the preserved v78 draft and its verified frozen derived observations. It does not modify the original counter archive or the colleague's working tree. The latest author direction adopts a detection-led title; earlier title instructions remain documented in PLAN.md.

From the package root, with the recorded Python environment:

```bash
OPENBLAS_NUM_THREADS=1 python -B scripts/segment_reduce.py
OPENBLAS_NUM_THREADS=1 python -B scripts/full_tide_detection.py
OPENBLAS_NUM_THREADS=1 python -B scripts/draw_figure1.py
OPENBLAS_NUM_THREADS=1 python -B scripts/draw_segments.py
python -B scripts/write_manuscript.py
python -B scripts/assemble_candidate.py
python -B render_candidate.py NATURE_ARTICLE_A_v79_SEGMENT.md render_rebuilt
```

The render destination must not exist. `review_diagnostics/REVIEW_RESULTS.json` and associated tables are bound to the same frozen design by hashes; to rerun those diagnostics, use scripts/review_statistics.py and scripts/check_noise_adequacy.py before plotting. Both explicitly separate synthetic noise from observations. Frozen figure1, figure3 and original Extended Data remain verified v78 assets; the original complete numerical replay entry point is scripts/recompute_candidate.py and is optional for a fresh working copy, since it regenerates the saved derived tables. Exact raw-counter reconstruction requires the separately controlled original archive.

After assembly, scripts/prepare_review_bundle.py builds the Source Data workbook and reports. The main fit always uses original ten-minute means. Three-hour averaging is a display only. The script scripts/verify_segment_candidate.py checks numerical equivalence, observations, complete display membership, physical units and document/figure QA. All output is for author review; this script performs no upload or submission.
'''
(O/'REPRODUCE.md').write_text(readme)
(O/'AUTHOR_SUBMISSION_CHECKLIST.md').write_text('''# Author actions before actual submission

Prepared: complete English candidate, PDF/Word/LaTeX, eight figure assets, Source Data workbook, frozen derived means/templates/weights, source code, input hashes, statistical diagnostics, draft cover letter and overlap table.

Human confirmation still required:

1. Author names/order, corresponding author, affiliation assignments and approval of this manuscript.
2. Funding, author contributions, conflicts and the final AI-assistance/verification statement.
3. Original-counter and correction-log validation, and exact member-level overlap with the frequency-ratio manuscript. The attached overlap table identifies acquisition windows and this reduction's accepted hours.
4. For final figure production, confirm the author-supplied geographic panel and provide its field-grid/generation source or suitable editable artwork. This raster illustration is not a numerical input to the fitted responses.
5. An editor/referee-accessible data/code route: upload the prepared archives with the submission, or provide and test a private review link. The existing private GitHub repository is not automatically accessible to reviewers. Confirm the permanent availability statement and licensing.

No external submission has been made. The PDF retains explicit author-review placeholders for unresolved factual statements.
''')
response='''# v78 审阅意见闭环

| 事项 | 本版处理 | 状态 |
|---|---|---|
| 先展示光钟探测潮汐 | 按最新定位改标题与摘要，先报告全记录合成尺度，再报告组分 | 完成 |
| segment-based reduction | 每段数据/模板独立加权去均值，验证与54截距数值等价 | 完成 |
| 全记录总体量 | 新算 A_T=0.955112±0.108182；按日分簇及相关噪声敏感性单独报告 | 完成 |
| 组内物理约束 | 摘要与正文明确固定幅比/相位；K₂为日月共同强迫 | 完成 |
| 图2实测展示 | 全记录相位主图、客观最长段实际UTC、同窗平均及全原点 | 完成 |
| 频谱与频率间距 | 保留原扫描，区分天文间距、局部峰差、步长与未估计频率区间 | 完成 |
| 弱组零假设/联合区域 | 独立核查、条件噪声场景及期内结构诊断；扩展图4 | 完成，模型适合性边界保留 |
| 12h敏感性 | 两组系数和工作区间并列于扩展表4，退化结果进入正文 | 完成 |
| 光纤对弱组控制 | 报告246.6h同支撑配对变化，区分传输路径与同频情景 | 完成 |
| 欧洲稿位置和优先权 | 讨论末句；独立、同期arXiv；不宣称首次 | 完成 |
| 自引与样本重叠 | 正文装置引用；覆盖窗口/当前小时数在来源记录和投稿信披露 | 待作者确认逐秒成员交集 |
| 另一归算未复算数值 | 从论文移至审阅归档，不借用其误差/474h控制作为本版证据 | 完成 |
| 作者与数据实际审稿访问 | 已打包可用资料，保留必要人工事实确认 | 尚待作者 |

内部 Nature 读者自查：背景先于技术；探测与成分约束不混为同一强度；无独立海潮负荷/首次/太阳纯分潮精确探测的宣称；同源图表不合并显著性。该记录不是来自外部期刊的同行评审。
'''
(O/'REVIEW_RESPONSE_ZH.md').write_text(response)
print('Prepared Source Data and review records:',source_data.stat().st_size,'bytes')
