"""Numerical, sample, unit, figure and manuscript checks with explicit scope."""
from pathlib import Path
import hashlib,json,re,platform,subprocess,argparse
import numpy as np
import pandas as pd
import fitz
from PIL import Image,ImageDraw
from docx import Document
from segment_reduce import fit

O=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser();ap.add_argument('--render',default='render_segment_09');ap.add_argument('--baseline',type=Path);args=ap.parse_args()
render=O/args.render;V=O/'verification'
checks={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
inputs=json.loads((O/'original/INPUT_MANIFEST.json').read_text());base=args.baseline or Path(inputs['base'])
baseline_available=base.exists()
if baseline_available:
    checks['original_v78_unchanged']=all(sha(base/f)==h for f,h in inputs['sha256'].items())
else:
    checks['preserved_v78_source_copy_integrity']=sha(O/'original/NATURE_ARTICLE_A_v78.md')==inputs['sha256']['NATURE_ARTICLE_A_v78.md'] and sha(O/'original/manuscript_template.md')==inputs['sha256']['manuscript_template.md']
frozen=['data/primary_rows.csv','data/design.npz','data/RESULTS.json','data/conditional_scans.csv','data/semidiurnal_spectrum.csv','data/phase_fold.csv']
checks['observations_templates_weights_spectrum_and_preserved_figures_unchanged']=all(sha(O/f)==inputs['sha256'][f] for f in frozen)
d=np.load(O/'data/design.npz');j=json.loads((O/'data/RESULTS.json').read_text());full=json.loads((O/'segment_reduction/FULL_TIDE.json').read_text())
r=pd.read_csv(O/'data/primary_rows.csv');S=d['three'];sigma=d['sigma'];seg=d['seg'];days=d['days']
result=fit(S,d['y'],sigma,seg)
checks['joint_coefficients_match_v78']=np.allclose(result['A'],j['primary']['A'],rtol=0,atol=1e-10)
phase_S=np.column_stack([S[:,0],d['quad'],S[:,1:]])
phase=fit(phase_S,d['y'],sigma,seg)
reps=[]
for day in np.unique(days):
    keep=days!=day;reps.append(fit(phase_S[keep],d['y'][keep],sigma[keep],seg[keep])['A'])
reps=np.array(reps);z=reps-reps.mean(axis=0)
phase_SE=np.maximum(phase['SE_LS'],np.sqrt((len(reps)-1)/len(reps)*np.sum(z*z,axis=0)))
checks['phase_relaxed_estimate_and_SE_replayed']=np.allclose(phase['A'],j['iq']['A'],rtol=0,atol=1e-10) and np.allclose(phase_SE,j['iq']['u'],rtol=0,atol=1e-10)
(V/'PHASE_REPLAY.json').write_text(json.dumps(dict(A=phase['A'].tolist(),SE=phase_SE.tolist()),indent=2)+'\n')
unit=(S.sum(axis=1)+d['fixed'])[:,None]
X=np.column_stack([unit,seg[:,None]==np.unique(seg)[None,:]])
Q,R=np.linalg.qr(X/sigma[:,None],mode='reduced');beta=np.linalg.solve(R,Q.T@(r.y.to_numpy()/sigma))
checks['overall_amplitude_independent_full_QR']=abs(beta[0]-full['A'])<1e-11
injected=unit[:,0]+(seg*13.7)
checks['unit_injection_and_arbitrary_segment_levels']=abs(fit(unit,injected,sigma,seg)['A'][0]-1)<1e-11
checks['segment_level_shift_invariance']=np.allclose(fit(S,d['y']+seg*23.4,sigma,seg)['A'],result['A'],rtol=0,atol=1e-10)
display=pd.read_csv(O/'segment_reduction/representative_UTC_3h.csv')
chosen=json.loads((O/'segment_reduction/FIGURE_PROVENANCE.json').read_text())['representative_segment']
source=r[r.seg==chosen]
checks['representative_segment_objective_longest']=chosen==int(r.groupby('seg').n.sum().idxmax())
checks['display_all_selected_rows_and_members']=display.rows.sum()==len(source) and display.members.sum()==source.n.sum()
checks['all_frozen_sample_counts']=len(r)==3299 and r.seg.nunique()==54 and r.n.sum()==1965327
epoch=pd.to_datetime(r.t_utc,utc=True).map(lambda x:x.timestamp()).to_numpy()
checks['UTC_seconds_and_design_times_consistent']=np.allclose(np.diff(epoch),np.diff(d['seconds']),rtol=0,atol=1e-5)
provenance=json.loads((O/'segment_reduction/FIGURE_PROVENANCE.json').read_text())
checks['potential_conversion_exact']=abs(float(provenance['conversion'].split('factor=')[1])-299792458.0**2*1e-18)<1e-15
observations=pd.read_excel(O/'release/Source_Data_A_v79_SEGMENT.xlsx',sheet_name='Observations_3299')
checks['Source_Data_has_complete_observations']=len(observations)==3299 and observations.n.sum()==1965327 and np.allclose(observations.y,r.y,atol=1e-11,rtol=0)
for f in ['figure1','figure2','figure3','figure4','extended4']:
    checks[f+'_alignment']=json.loads((O/f'figures/{f}.alignment.json').read_text())['verdict']=='PASS'
qa=json.loads((V/'FIGURE_QA_FINAL.json').read_text())
checks['new_figure_font_and_collision_audits']=all(x['exit_code']==0 for x in qa)
t=(O/'NATURE_ARTICLE_A_v79_SEGMENT.md').read_text();front=t.split('\\clearpage')[0]
checks['latest_detection_title']=t.startswith('# Tidal potential measured by optical clocks on a coastal-inland baseline')
checks['three_distinct_estimates_in_summary']=all(x in front for x in [r'$0.96\pm0.11$',r'$1.00\pm0.13$',r'$0.93\pm0.36$'])
checks['fixed_internal_group_constraint_in_summary']='group-internal amplitude ratios and phases fixed' in front
main=t.split('## References')[0]
checks['Europe_only_Discussion_final_sentence']=main.count('European')==1 and main.strip().endswith('arXiv preprint.^22^\n\n\\clearpage')
checks['no_unverified_alternative_estimates_in_paper']=all(x not in t for x in [r'$0.97\pm0.14$',r'$0.89\pm0.55$','474-h','v68'])
checks['no_unexpanded_numeric_tokens']=not re.search(r'\{\{[A-Z_]+\}\}',t)
order=json.loads((O/'editorial/REFERENCE_ORDER.json').read_text())
checks['continuous_first_use_references']=sorted(x['number'] for x in order.values())==list(range(1,len(order)+1))
counts=json.loads((V/'TEXT_STRUCTURE.json').read_text())
checks['Nature_summary_Methods_and_legend_lengths']=counts['abstract']<=200 and counts['methods']<=3000 and all(n<250 for _,n in counts['legends'])
checks['display_item_budget']=len(re.findall(r'!\[Extended Data Figure',t))+len(re.findall(r'\*\*Extended Data Table \d \|',t))<=10
build=json.loads((render/'BUILD_RESULTS.json').read_text())
checks['PDF_Word_compiled_without_warnings']=all(x['exit']==0 and not x['warnings'] for x in build['builds'])
docx=Document(render/'NATURE_ARTICLE_A_v79_SEGMENT.docx')
p=next(p for p in docx.paragraphs if p.text.startswith('Tides alter'))
checks['Word_summary_double_spaced']=(p.paragraph_format.line_spacing or p.style.paragraph_format.line_spacing or docx.styles['Normal'].paragraph_format.line_spacing)==2
pdf=fitz.open(render/'NATURE_ARTICLE_A_v79_SEGMENT.pdf')
checks['PDF_glyphs_and_size']=all('\ufffd' not in p.get_text() for p in pdf) and (render/'NATURE_ARTICLE_A_v79_SEGMENT.pdf').stat().st_size<30_000_000
pages=V/'pages_final';pages.mkdir(exist_ok=True);tiles=[]
for i,page in enumerate(pdf):
    pix=page.get_pixmap(matrix=fitz.Matrix(.5,.5),alpha=False);im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
    tile=Image.new('RGB',(320,450),'#e6e6e6');tile.paste(im,((320-im.width)//2,20));ImageDraw.Draw(tile).text((6,5),f'Page {i+1}',fill='black');tiles.append(tile)
    if i<8 or i in [9,14,15,16,17,len(pdf)-1]:page.get_pixmap(matrix=fitz.Matrix(1.2,1.2),alpha=False).save(pages/f'page_{i+1:02}.png')
canvas=Image.new('RGB',(1280,450*((len(tiles)+3)//4)),'#bbb')
for i,im in enumerate(tiles):canvas.paste(im,((i%4)*320,(i//4)*450))
canvas.save(V/'contact_final.png')
versions=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,pymupdf=fitz.VersionBind)
for label,cmd in [('pandoc',['pandoc','--version']),('xelatex',['xelatex','--version'])]:versions[label]=subprocess.run(cmd,capture_output=True,text=True,check=True).stdout.splitlines()[0]
(V/'SOFTWARE_VERSIONS.json').write_text(json.dumps(versions,indent=2)+'\n')
record=dict(status='PASS' if all(checks.values()) else 'FAIL',checks={k:bool(v) for k,v in checks.items()},
            pages=len(pdf),counts=counts,manuscript_SHA256=sha(O/'NATURE_ARTICLE_A_v79_SEGMENT.md'),
            PDF_SHA256=sha(render/'NATURE_ARTICLE_A_v79_SEGMENT.pdf'),
            original_workspace_check='Performed against the existing baseline' if baseline_available else 'Original workspace unavailable; preserved source copies and frozen input hashes checked instead',
            scope='Verified frozen derived observations; independent segment/QR and phase/full response replay; not a new independent raw-counter reconstruction.',
            author_approval=False,external_submission=False)
(V/'FINAL_CHECK.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(status=record['status'],checks=len(checks),pages=len(pdf),failed=[k for k,v in checks.items() if not v])))
assert record['status']=='PASS'
