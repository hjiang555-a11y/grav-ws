**Extended Data Table 4 | Archived influence diagnostic and alternative reduction.** These rows identify the observation support and estimator of each result. The single-bin diagnostic retains its original eight-period design. The filtered reduction is reported in the alternative manuscript (v68); its measurements overlap the present data and its results are not pooled with the primary estimates.

| Check | Observation support and design | Result and status |
|---|---|---|
| Pre-identified extreme mean | 2026-07-07 01:25 Beijing time, segment 46; archived eight-period model, fixed templates and weights | Omitting the mean changes the daily coefficient from 0.678 to 0.721: +0.043 versus its original 0.359 standard error. The lunar change is +0.039. Uncertainty was not recalibrated. The mean remains in the present 3,299 rows. |
| Filtered lunar response | Approximately 544 h, 54 segments; 1,200-s triangular filter every 600 s; equal weights, direct-potential solid model; continuous-run circular-residual-shift error | $0.97\pm0.14$, author-reported. The other grouped results are in Extended Data Table 2. |
| Separate loading coefficient | Same alternative filtered reduction; loading assigned a separate coefficient | $0.89\pm0.55$, author-reported and unresolved. This is not a separate loading estimate from the primary design. |
| Temperature regressors | Two-site ERA5 2-m air-temperature proxies in the alternative reduction; distinct from its stated 98-h Sr chamber-thermometer record | Lunar $0.98\pm0.13$, author-reported. Exact regression membership is needed for independent replay. |
| Alternative round-trip control | Reported 474-h overlap in the filtered reduction | Lunar and whole-template coefficient changes less than 0.005, author-reported. Exact matching memberships are needed for independent replay; the directly replayed 246.634-h control is shown in Extended Data Fig. 3. |

The archived influence diagnostic is retained for provenance; the current observation membership is unchanged.

\clearpage

