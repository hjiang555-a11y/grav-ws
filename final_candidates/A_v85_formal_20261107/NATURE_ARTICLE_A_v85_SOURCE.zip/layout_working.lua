function Div(el)
  if el.classes:includes('affiliations') and FORMAT:match('latex') then
    local blocks={pandoc.RawBlock('latex','\\begingroup\\singlespacing\\fontsize{10}{12}\\selectfont')}
    for _,b in ipairs(el.content) do table.insert(blocks,b) end
    table.insert(blocks,pandoc.RawBlock('latex','\\endgroup'))
    return blocks
  end
  if el.classes:includes('pagebreak') then
    if FORMAT:match('latex') then return pandoc.RawBlock('latex','\\clearpage')
    elseif FORMAT:match('docx') then return pandoc.RawBlock('openxml','<w:p><w:r><w:br w:type="page"/></w:r></w:p>') end
  end
end
function Header(el)
  if FORMAT:match('latex') then
    local name=pandoc.utils.stringify(el.content)
    if name=='Extended Data' then
      return {pandoc.RawBlock('latex','\\singlespacing\\sffamily\\fontsize{7}{9}\\selectfont'),el}
    elseif name=='Methods references' then
      return {pandoc.RawBlock('latex','\\singlespacing\\fontsize{11}{13}\\selectfont\\Needspace{12\\baselineskip}'),el}
    elseif name=='References' then
      return {pandoc.RawBlock('latex','\\singlespacing\\fontsize{10}{12}\\selectfont'),el}
    elseif name=='Figure legends' then
      return {pandoc.RawBlock('latex','\\singlespacing\\fontsize{10}{12}\\selectfont'),el}
    elseif name=='Data availability' or name=='Code availability' or name=='Acknowledgements' or name=='Funding statement' or name=='Author contributions' or name=='Competing interests' or name=='Additional information' then
      return {pandoc.RawBlock('latex','\\singlespacing\\fontsize{11}{13}\\selectfont'),el}
    elseif name=='Supplementary Methods' then
      return {pandoc.RawBlock('latex','\\onehalfspacing'),el}
    elseif name=='Methods' then
      return {pandoc.RawBlock('latex','\\fontsize{12}{14.4}\\selectfont\\doublespacing'),el}
    end
  end
end
