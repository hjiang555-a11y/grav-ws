## References

1. Stray, B. et al. Quantum sensing for gravity cartography. *Nature* **602**, 590–594 (2022). <https://doi.org/10.1038/s41586-021-04315-3>
2. Grotti, J. et al. Geodesy and metrology with a transportable optical clock. *Nat. Phys.* **14**, 437–441 (2018). <https://doi.org/10.1038/s41567-017-0042-3>
3. Tapley, B. D., Bettadpur, S., Ries, J. C., Thompson, P. F. & Watkins, M. M. GRACE measurements of mass variability in the Earth system. *Science* **305**, 503–505 (2004). <https://doi.org/10.1126/science.1099192>
4. Rodell, M. et al. Emerging trends in global freshwater availability. *Nature* **557**, 651–659 (2018). <https://doi.org/10.1038/s41586-018-0123-1>
5. Schröder, S., Stellmer, S. & Kusche, J. Potential and scientific requirements of optical clock networks for validating satellite-derived time-variable gravity data. *Geophys. J. Int.* **226**, 764–779 (2021). <https://doi.org/10.1093/gji/ggab132>
6. Arbic, B. K. Atmospheric forcing of the oceanic semidiurnal tide. *Geophys. Res. Lett.* **32**, L02610 (2005). <https://doi.org/10.1029/2004GL021668>
7. Voigt, C., Denker, H. & Timmen, L. Time-variable gravity potential components for optical clock comparisons and the definition of international time scales. *Metrologia* **53**, 1365–1383 (2016). <https://doi.org/10.1088/0026-1394/53/6/1365>
8. Mehlstäubler, T. E., Grosche, G., Lisdat, C., Schmidt, P. O. & Denker, H. Atomic clocks for geodesy. *Rep. Prog. Phys.* **81**, 064401 (2018). <https://doi.org/10.1088/1361-6633/aab409>
9. Chou, C. W., Hume, D. B., Rosenband, T. & Wineland, D. J. Optical clocks and relativity. *Science* **329**, 1630–1633 (2010). <https://doi.org/10.1126/science.1192720>
10. Bothwell, T. et al. Resolving the gravitational redshift across a millimetre-scale atomic sample. *Nature* **602**, 420–424 (2022). <https://doi.org/10.1038/s41586-021-04349-7>
11. Takano, T. et al. Geopotential measurements with synchronously linked optical lattice clocks. *Nat. Photon.* **10**, 662–666 (2016). <https://doi.org/10.1038/nphoton.2016.159>
12. Arnold, K. J. et al. Lu$^+$ optical frequency references with accuracy verified at the 19th digit. *Nature* **658**, 60–64 (2026). <https://doi.org/10.1038/s41586-026-11072-8>
13. Oelker, E. et al. Demonstration of $4.8\times10^{-17}$ stability at 1 s for two independent optical clocks. *Nat. Photon.* **13**, 714–719 (2019). <https://doi.org/10.1038/s41566-019-0493-4>
14. Boulder Atomic Clock Optical Network (BACON) Collaboration. Frequency ratio measurements at 18-digit accuracy using an optical clock network. *Nature* **591**, 564–569 (2021). <https://doi.org/10.1038/s41586-021-03253-4>
15. Lisdat, C. et al. A clock network for geodesy and fundamental science. *Nat. Commun.* **7**, 12443 (2016). <https://doi.org/10.1038/ncomms12443>
16. Lindvall, T. et al. Coordinated international comparisons between optical clocks connected via fiber and satellite links. *Optica* **12**, 843–852 (2025). <https://doi.org/10.1364/OPTICA.561754>
17. Shen, Q. et al. Free-space dissemination of time and frequency with $10^{-19}$ instability over 113 km. *Nature* **610**, 661–666 (2022). <https://doi.org/10.1038/s41586-022-05228-5>
18. Caldwell, E. D. et al. Quantum-limited optical time transfer for future geosynchronous links. *Nature* **618**, 721–726 (2023). <https://doi.org/10.1038/s41586-023-06032-5>
