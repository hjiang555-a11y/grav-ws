"""Editorial assembly only; no experimental computation or validation."""
from pathlib import Path
import re, shutil, json, hashlib
P=Path(__file__).resolve().parents[1]
BASE=P.parent/'A_v83_humanized'
STAGE=P.parent/'A_v84_staged_narrative'
old=(BASE/'NATURE_ARTICLE_A_v83.md').read_text()
inputs={
 'NARRATIVE_CHARTER.md': STAGE/'approved_charter_20261107/NARRATIVE_CHARTER.md',
 'AUTHOR_APPROVED_ABSTRACT.txt':STAGE/'abstract_author_final_20261107/AUTHOR_APPROVED_ABSTRACT.txt',
 'INTRODUCTION_ONLY.md':STAGE/'confirmed_sections_r2_no_hou_20261107/INTRODUCTION_ONLY.md',
 'RESULTS1_ONLY.md':STAGE/'results1_draft2_published_refs_20261107/RESULTS1_ONLY.md',
 'FIGURE1_CAPTION.md':STAGE/'results1_draft2_published_refs_20261107/FIGURE1_CAPTION.md',
 'INTRO_REFERENCES.md':STAGE/'confirmed_sections_r2_no_hou_20261107/REFERENCES.md',
 'RESULTS1_REFERENCES.md':STAGE/'results1_draft2_published_refs_20261107/REFERENCES_ADDED.md',
}
manifest=[]
for name,src in inputs.items():
 dst=P/'frozen'/name
 if dst.exists(): assert dst.read_bytes()==src.read_bytes()
 else: shutil.copy2(src,dst)
 manifest.append({'name':name,'source':str(src),'sha256':hashlib.sha256(src.read_bytes()).hexdigest()})
(P/'FREEZE_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
for stem in ['figure1','figure2','figure4','extended4','ed_figure2','ed_figure1','ed_figure3']:
 for ext in ['png','pdf']:
  dst=P/'figures'/f'{stem}.{ext}'
  if not dst.exists():shutil.copy2(BASE/'figures'/f'{stem}.{ext}',dst)

def part(text,start,end=None):
 a=text.index(start)
 return text[a:text.index(end,a) if end else len(text)].strip()
def cap(prefix):
 return next(x for x in old.split('\n\n') if x.startswith(prefix))
def remap_ed(t):
 return re.sub(r'Extended Data Fig\. ([345])',lambda m:{'3':'Fig. 4','4':'Extended Data Fig. 3','5':'Extended Data Fig. 4'}[m[1]],t)
refs=(P/'frozen/INTRO_REFERENCES.md').read_text().strip()+'\n'+re.sub(r'^##[^\n]*\n\n','',(P/'frozen/RESULTS1_REFERENCES.md').read_text().strip())
oldrefs={int(m[1]):m[2] for m in re.finditer(r'^(\d+)\. (.+)$',old,re.M)}
refs+='\n24. '+oldrefs[22]
intro=(P/'frozen/INTRODUCTION_ONLY.md').read_text().strip()
r1=(P/'frozen/RESULTS1_ONLY.md').read_text().strip()
abstract=(P/'frozen/AUTHOR_APPROVED_ABSTRACT.txt').read_text().strip()
affil=part(old,'::: affiliations','\n\n**Optical')
methods=part(old,'## Methods','## Data availability')
methods=re.sub(r'\n\nHou et al\.[^\n]+','',methods)
methods=methods.replace('The instability benchmark quoted with Fig. 1a was reported for the spliced summer comparison.^14^','The instability benchmark quoted with Fig. 1a describes the previously reported summer comparison after joining its levels.')
methods=methods.replace('The selected frozen solid sequence','The solid sequence used here').replace('The Shanghai and Wuhan coordinates used by the frozen prediction','The Shanghai and Wuhan coordinates used by the prediction')
methods=methods.replace('The present analysis reads the frozen constituent and time-series tables rather than substituting an older loading sequence.','The constituent and time-series tables specify this convention throughout the analysis.')
methods=methods.replace('The three terms represent direct water attraction, induced potential and clock displacement.','The three terms represent direct water attraction, induced potential and clock displacement.^26,27^')
methods=methods.replace('^23^','^25^').replace('^24^','^28^')
methods=remap_ed(methods)
methods=methods.replace('### Construction of bin uncertainties',(P/'sections/REFERENCE_LEVEL_COMPARISON.md').read_text().strip()+'\n\n### Construction of bin uncertainties')
methods=methods.replace('An independent full-design QR fit with 54 intercepts reproduces the three coefficients to within $3\\times10^{-15}$. Recomputing the segment means after every deletion also reproduces the original standard errors. ','')
methods=methods.replace('All period fits and day-deletion replicates retain full column rank and were independently checked against an explicit segment-intercept QR calculation. ','')
spectral=r'''For the equivalent-height display, $h_{\mathrm{eq}}=U/g_0$, where $g_0=9.80665\,\mathrm{m/s^2}$ is conventional standard gravity. The density in centimetre-squared units is $S_{h,\mathrm{cm}}=10^4S_W/g_0^2$; this is a representation of potential difference, not station displacement. Both density axes in Fig. 3c use logarithmic scales. Every stored positive spectral value in the displayed band is retained, without adding a floor. The ratios reported in the summary are $10\log_{10}[P_{\mathrm{observed}}(f)/P_{\mathrm{residual}}(f)]$ at the stored scan points nearest the two reported peak positions. The residual spectrum follows subtraction of the fixed unit physical prediction. The values 16.7 and 9.3 dB therefore compare the before-and-after spectra on the same observation window; they are not ratios to an independently measured instrumental-noise spectrum.'''
needle='The frequency step is 0.002729 µHz'
methods=methods.replace(needle,spectral+'\n\n'+needle)
methods=methods.replace('code preparation and checking, numerical replay, and plotting','code preparation and checking, earlier numerical replay, and plotting')
# Established archival methods are retained; this build does not execute them.
fig3=r'''**Fig. 3 | Amplitude, phase and frequency of the tidal response.** **a,** The complete-template response and the jointly fitted lunar and neighbouring semidiurnal coefficients. Error bars are one statistical standard error, the larger of scaled least squares and UTC-day-deletion jackknife errors. These are two fits to the same observations, not averaged estimates. **b,** Lunar in-phase and quadrature fit; the cross marks $(1,0)$. Contours use scaled-LS covariance radii one and two, not independently calibrated joint confidence levels. The marginal working errors are 0.13 and 0.20; the scaled-LS quadrature error is 0.127. **c,** The observed 21–24.5 µHz spectrum and the spectrum after subtracting the fixed unit physical prediction. Both vertical axes are logarithmic. The scan retains all 3,299 original UTC rows and gaps, with equal weights and 54 segment constants. Markers indicate the prescribed M₂ and S₂ frequencies. Equivalent-height density on the left and fractional-frequency density on the right obey $S_{h,\mathrm{cm}}=10^4c^4S_y/g_0^2$, with $g_0=9.80665\,\mathrm{m/s^2}$. Equivalent height represents potential difference, not station motion. The before-and-after power ratios at the reported peaks are 16.7 and 9.3 dB. Sampling cross-power and conditional scans are given in Extended Data Fig. 2; joint group regions appear in Extended Data Fig. 1. Peaks, phase and amplitudes use the same record and do not add independent detection significance.'''
fig4=cap('**Extended Data Fig. 3 |').replace('Extended Data Fig. 3','Fig. 4',1)
captions=[(P/'frozen/FIGURE1_CAPTION.md').read_text().strip(),cap('**Fig. 2 |'),fig3,fig4]
figs='## Figure legends\n\n'+'\n\n\\clearpage\n\n'.join(f'![Figure {i}](figures/figure{i}.png)\n\n{c}' for i,c in enumerate(captions,1))
ed=part(old,'## Extended Data')
a=ed.index('![Extended Data Figure 3]');b=ed.index('![Extended Data Figure 4]')
ed=ed[:a]+ed[b:]
ed=remap_ed(ed).replace('![Extended Data Figure 4]','![Extended Data Figure 3]').replace('![Extended Data Figure 5]','![Extended Data Figure 4]').replace('^17^','^19^')
# Preserve numerical table contents; clarify old status labels as prior work.
ed=ed.replace('All directly replayed designs','All previously replayed designs').replace('Status   |','Prior status |')
statements=part(old,'## Data availability','## Methods references')
methodrefs='## Methods references\n\n25. '+oldrefs[23]+'\n26. '+oldrefs[20]+'\n27. '+oldrefs[21]+'\n28. '+oldrefs[24]
declarations=part(old,'## Acknowledgements','## Extended Data').removesuffix('\\clearpage').strip()
text='\n\n'.join([
 '# Tidal potential measured on a coastal–inland optical-clock baseline',affil,'**'+abstract+'**',intro,r1,
 (P/'sections/RESULTS_REMAINDER.md').read_text().strip(),(P/'sections/DISCUSSION.md').read_text().strip(),
 '\\clearpage',refs,'\\clearpage',figs,'\\clearpage',methods,statements,methodrefs,declarations,'\\clearpage',ed])+'\n'
(P/'NATURE_ARTICLE_A_v85.md').write_text(text)
for n,c in enumerate(captions,1):(P/'sections'/f'FIGURE{n}_CAPTION.md').write_text(c+'\n')
(P/'sections/METHODS.md').write_text(methods+'\n')
# Renderer is copied locally, never mutating an older draft.
r=(BASE/'render_candidate.py').read_text().replace("par.text.startswith('Optical clocks measure gravitational')","par.text.startswith('The Moon and the Sun alter')")
(P/'render_candidate.py').write_text(r)
lua=(BASE/'layout_working.lua').read_text()
lua=lua.replace('\\\\begingroup\\\\singlespacing','\\\\begingroup\\\\singlespacing\\\\fontsize{10}{12}\\\\selectfont')
lua=lua.replace("name=='References' then\n      return {pandoc.RawBlock('latex','\\\\singlespacing\\\\fontsize{11}{13}\\\\selectfont')", "name=='References' then\n      return {pandoc.RawBlock('latex','\\\\singlespacing\\\\fontsize{10}{12}\\\\selectfont')")
lua=lua.replace('Needspace{7','Needspace{12')
(P/'layout_working.lua').write_text(lua)
counts={'abstract_words':len(abstract.split()),'main_words_including_headings':len((intro+'\n'+r1+'\n'+(P/'sections/RESULTS_REMAINDER.md').read_text()+(P/'sections/DISCUSSION.md').read_text()).split()),'methods_words':len(methods.split()),'main_figures':4,'extended_figures':4,'extended_tables':5,'references':28}
(P/'notes/ASSEMBLY_COUNTS.json').write_text(json.dumps(counts,indent=2));print(json.dumps(counts))
