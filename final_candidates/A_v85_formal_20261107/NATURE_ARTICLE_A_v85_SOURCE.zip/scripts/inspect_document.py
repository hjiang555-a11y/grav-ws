"""Check editorial assembly and render PDF previews; never inspect experimental validity."""
from pathlib import Path
import re,json,hashlib,subprocess
from PIL import Image, ImageDraw
P=Path(__file__).resolve().parents[1]
s=(P/'NATURE_ARTICLE_A_v85.md').read_text()
checks={}
for name in ['AUTHOR_APPROVED_ABSTRACT.txt','INTRODUCTION_ONLY.md','RESULTS1_ONLY.md','FIGURE1_CAPTION.md']:
 checks['verbatim_'+name]=(P/'frozen'/name).read_text().strip() in s
manifest=json.loads((P/'FREEZE_MANIFEST.json').read_text())
checks['original_frozen_inputs_unchanged']=all(hashlib.sha256(Path(m['source']).read_bytes()).hexdigest()==m['sha256'] for m in manifest)
checks['no_Hou_reference']=not re.search(r'\bHou\b|2610\.34250',s)
checks['main_figures_4']=len(re.findall(r'^\*\*Fig\. \d \|',s,re.M))==4
checks['extended_figures_4']=len(re.findall(r'^\*\*Extended Data Fig\. \d \|',s,re.M))==4
checks['extended_tables_5']=len(re.findall(r'^\*\*Extended Data Table \d \|',s,re.M))==5
refs=[int(n) for n in re.findall(r'^(\d+)\. ',s,re.M)]
checks['reference_list_1_to_28']=refs==list(range(1,29))
body=re.sub(r'::: affiliations[\s\S]*?:::','',s)
seen=[]
for x in re.findall(r'\^([\d,]+)\^',body):
 for n in map(int,x.split(',')):
  if n not in seen:seen.append(n)
checks['first_citation_order']=seen==list(range(1,29))
checks['Europe_only_Discussion_last_sentence']=s.count('arXiv')==2 and 'preprint.^24^\n\n\\clearpage' in s
checks['log_display_script']= "c.set_yscale('log')" in (P/'scripts/draw_figure3_log.py').read_text()
checks['weights_defined']=r'\sigma_i=\frac{\alpha_{p(i)}}{\sqrt{n_i}}' in s
checks['published_Yb_and_Light']='aeb809' in s and 's41377-026-02299-1' in s
checks['figure_resources']=all((P/x).exists() for x in re.findall(r'!\[[^]]*\]\(([^)]+)\)',s))
checks['original_figures_unchanged']=all((P/'figures'/f'{stem}.{ext}').read_bytes()==(P.parent/'A_v83_humanized/figures'/f'{stem}.{ext}').read_bytes() for stem in ['figure1','figure2','figure4','extended4','ed_figure2','ed_figure1','ed_figure3'] for ext in ['png','pdf'])
(P/'notes/DOCUMENT_CHECKS.json').write_text(json.dumps({'checks':checks,'all_pass':all(checks.values()),'first_citations':seen,'scope':'Document integrity, not scientific-result validation'},indent=2));print(json.dumps(checks,indent=2))
(P/'previews_v4').mkdir(exist_ok=True)
pdf=P/'render_v4/NATURE_ARTICLE_A_v85.pdf'
subprocess.run(['pdftotext','-layout',str(pdf),str(P/'notes/PDF_TEXT.txt')],check=True)
info=subprocess.run(['pdfinfo',str(pdf)],capture_output=True,text=True,check=True).stdout
(P/'notes/PDF_INFO.txt').write_text(info);n=int(re.search(r'Pages:\s+(\d+)',info)[1])
subprocess.run(['pdftoppm','-scale-to','950','-png',str(pdf),str(P/'previews_v4/page')],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
images=sorted((P/'previews_v4').glob('page-*.png'))
for start in range(0,len(images),6):
 sheet=Image.new('RGB',(900,1350),'#d1d1d1');draw=ImageDraw.Draw(sheet)
 for k,file in enumerate(images[start:start+6]):
  im=Image.open(file);im.thumbnail((445,424));x=k%2*450;y=k//2*450
  sheet.paste(im,(x+(450-im.width)//2,y+23));draw.text((x+5,y+5),f'Page {start+k+1}',fill='black')
 sheet.save(P/'previews_v4'/f'contact_{start+1:02d}.png')
print('PDF page count:',n)
if not all(checks.values()):raise SystemExit(1)
