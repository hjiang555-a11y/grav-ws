## Methods

### Observations, frequency sign and averaging

The Shanghai and Wuhan coordinates used by the prediction are 31.130° N, 121.570° E and 30.529° N, 114.357° E. The measured ratio is Wuhan Yb/Shanghai Sr. With positive geodetic potential $W$, its tidal fractional variation is $-[\delta W_{\mathrm{Wuhan}}-\delta W_{\mathrm{Shanghai}}]/c^2$. The period-relative beat conversion is $-d_p(f_{\mathrm{beat}}-f_{{\mathrm{ref}},p})/F_{1550}$, where $F_{1550}=1.933992\times10^{14}$ Hz and $d_p=2$ in 2025 and 1 in 2026. Thus a 2026 beat deviation of 1 Hz has fractional magnitude $5.17\times10^{-15}$. The 2025 division factor is applied before forming the small clock-rate variation.

The supplied valid-interval table defines 54 segments in 29 operating groups and eight periods. Counter members are read across midnight before binning. Beijing-time labels are converted to UTC. Summer group corrections follow the decimal-arithmetic frequency-chain calculation; early absolute correction entries remain incomplete. Their constant part is represented by segment intercepts, while any time variation within a segment remains a possible systematic contribution. Fitted intercepts are not used to join the runs for long-term stability estimation.

The membership record contains 1,966,908 nominal one-second rows before the minimum-bin-support cut. Three boundary rows reconcile its difference from the printed interval total. Means are formed in nominal 600-s bins separately within each segment and require at least 180 retained members. The 3,299 accepted means contain 1,965,327 members, or 545.924 h. There are 3,291 unique bin centres: eight centres contain separate partial means from different segments, with disjoint members. The 353.39-day span contains observations on 43 UTC dates. The inherited valid mask is retained; this work neither applies an additional triangular filter nor selects points using tidal residuals. Exact raw-file memberships and hashes are retained in the controlled archive.

### What the constituent names mean

Semidiurnal tides produce approximately two cycles per day. M₂ is the principal lunar constituent; N₂ describes an additional lunar variation associated with orbital ellipticity. S₂ is the principal solar semidiurnal constituent, whereas K₂ contains lunar and solar forcing. The names identify astronomical frequencies, not separate instruments or independent experiments. The diurnal group contains K₁ (lunisolar), O₁ (principal lunar), P₁ (principal solar) and Q₁ (lunar elliptic). Their periods are listed in Extended Data Table 1.^25^ Internal relative amplitudes, phases and nodal modulation are fixed within each physical group. A group response therefore tests that complete specified pattern.

### Combined solid and loading potential

The physical target includes the direct astronomical potential, the Earth's induced potential and the effect of clock displacement. The solid sequence used here implements these through the IERS radial displacement $u$ and a fixed effective-potential conversion,

$$y_{\mathrm{solid}}=-\frac{1+k_2-h_2}{h_2}\frac{g(u_{\mathrm{Wuhan}}-u_{\mathrm{Shanghai}})}{c^2},$$

with $h_2=0.6078$, $k_2=0.3010$ and $g=9.794\,\mathrm{m/s^2}$. This is a displacement-based approximation to the combined solid potential. The same conversion also acts on degree-three and frequency-dependent displacement contributions in the supplied sequence. A previous implementation comparison found an approximately 18% K₁ amplitude deficit relative to a potential-weighted reference. The daily response is accordingly not used to infer a Love number. The quoted statistical errors are conditional on this solid template. A same-sampling potential-weighted comparison has not been completed for these estimates, so the K₁ discrepancy is not assigned as an error on the semidiurnal response.

For loading, FES2022 sea-surface elevations $\zeta$ are convolved with the effective-potential kernel

$$\delta W_{\mathrm{load}}=\int \rho_w\zeta(\mathbf{r}',t)G_W(\psi)\,\mathrm{d}A,\qquad
G_W(\psi)=\frac{ga}{M_E}\sum_n(1+k'_n-h'_n)P_n(\cos\psi).$$

The three terms represent direct water attraction, induced potential and clock displacement.^26,27^ PREM load Love numbers are retained through degree 696 with the archived high-degree continuation. Eighteen loading constituents are synthesized with their astronomical nodal corrections. The complex convention is $f\,\mathrm{Re}[C\exp(-i\phi)]$; reversing the exponential sign requires conjugating $C$. The constituent and time-series tables specify this convention throughout the analysis.

The eight named constituents form the three physical groups. Minor terms remain once as a fixed remainder $r_0$. On the actual weighted segment-centred sampling, solid, loading and total root-mean-square variations are respectively 2.928, 1.328 and $4.011\times10^{-18}$. Their ratio 0.331 is an amplitude-norm ratio, not an additive fraction of total power. A separate loading coefficient is not estimated here; the measured group responses test the combined prediction.

### Segment reduction and the two estimands

Let $W_s$ be the original diagonal weight matrix in segment $s$, and define $\langle v\rangle_s=(\mathbf{1}^TW_sv)/(\mathbf{1}^TW_s\mathbf{1})$. For each observation vector and each prediction column we form $\widetilde v_s=v_s-\mathbf{1}\langle v\rangle_s$. This operation uses sample times and weights but no fitted tidal amplitude. For a physical design matrix $T_s$, the common coefficients solve

$$\widehat{\boldsymbol A}=\left(\sum_s\widetilde T_s^TW_s\widetilde T_s\right)^{-1}\sum_s\widetilde T_s^TW_s\widetilde y_s.$$

The segment matrices and vectors contain the information needed for this estimate. All 54 segments enter the same fit; separately fitted segment amplitudes are not averaged. No segment level is transferred to create a continuous, calibrated long-term record.

For the full-response estimate, $y$ is the observed fractional rate before removal of the minor remainder. We fit

$$y_i=c_{s(i)}+A_TT_i+\epsilon_i,\qquad T_i=s_{L,i}+s_{S,i}+s_{D,i}+r_{0,i}.$$

The single coefficient multiplies the complete prediction. The restricted comparison retains only the 54 segment constants. For component estimation, we subtract the fixed minor remainder once and fit

$$y_i-r_{0,i}=c_{s(i)}+A_Ls_{L,i}+A_Ss_{S,i}+A_Ds_{D,i}+\epsilon_i.$$

The full-response model tests the combined waveform, whereas the grouped model allows the three astronomical bands to respond differently. Both use $W_{ii}=1/\sigma_i^2$ with the period-dependent Allan-based uncertainties defined below.

For Fig. 4, we repeat the same three-group estimation separately on each of P1–P8. The data, fixed theoretical remainder and Allan-based weights are inherited from the frozen primary design; each period retains its original segment constants. The UTC-day jackknife is recomputed using only the dates present in that period. The individual-period errors use the same working standard-error rule as the full record.

The daily group is an auxiliary physical component; its coefficient remains $0.58\pm0.54$ (Extended Data Table 2). The interval and correction records do not establish calibrated zero transfer at the 46 boundaries where an eight-period intercept would be shared. They document valid observing times but not signed boundary transfers with uncertainties. The segment convention follows that experimental information.

### Effect of reference-level partitioning

The same observations give slightly different group responses when the reference levels are defined over different intervals. With eight period offsets, the lunar and neighbouring coefficients are $0.987\pm0.123$ and $1.129\pm0.288$; with 54 segment offsets they are $1.000\pm0.132$ and $0.925\pm0.365$ (Extended Data Table 2). Thus the lunar coefficient changes by about +0.013 and the neighbouring coefficient by −0.204. The accepted samples, physical templates and noise weights are identical. What changes is the interval over which a common reference level is assumed. The differences are between correlated estimates, not independent measurements, and the segment model follows the absence of calibrated zero transfer across the relevant interruptions.

The two reductions do not discard different observations: both retain all 3,299 means and their actual times. They differ in the nuisance projection. With reference design $C$ and weights $W$, the retained physical design is $M_CT$, where $M_C=I-C(C^TWC)^{-1}C^TW$. Adding reference-level columns removes additional components from the sampled waveforms and changes the conditional information and correlations. The residual and period-deletion comparisons are shown in Extended Data Fig. 3. This is distinct from interpreting every boundary as a measured physical frequency jump.

The spectrum also projects its trial sine–cosine pairs against 54 segment constants, but uses equal weights, as specified below. Its sidelobes depend on the sampling and projection response. The change between the two weighted amplitude fits cannot therefore be identified quantitatively with the equal-weight spectral leakage without a further comparison; none is asserted here.

### Construction of bin uncertainties

For ten-minute bin $i$, the assigned uncertainty is

$$\sigma_i=\frac{\alpha_{p(i)}}{\sqrt{n_i}},$$

where $n_i$ counts retained nominal one-second members and $\alpha_p$ is the one-second fractional-frequency noise level of period $p$. In this convention the corresponding white-frequency instability is $\alpha_p/\sqrt{\tau/(1\,\mathrm{s})}$. The machine-readable source data provide all eight period coefficients, bin member counts and reconstructed uncertainties.

The noise calculation uses original segments containing at least 8,192 retained members. The fixed unit tidal prediction is evaluated at member timestamps and subtracted after centring within each segment. Overlapping Allan deviations are calculated at 256, 512, 1,024, 2,048 and 4,096 nominal seconds, using the acquisition's one-second member convention. At each averaging time the deviations are averaged across eligible segments, weighted by their member counts. The geometric mean of these averaged deviations multiplied by $\sqrt{\tau/(1\,\mathrm{s})}$ gives $\alpha_p$. No Allan window crosses a segment boundary. These coefficients determine relative fitting weights; residual scaling and day deletion determine the reported statistical errors.

The instability benchmark quoted with Fig. 1a describes the previously reported summer comparison after joining its levels. The present weights are reconstructed from the period coefficients and retained member counts, without using this benchmark. No stability estimate from joined, fit-adjusted levels is used in this analysis.

### Statistical errors and conditional coverage

For each group the reported standard error is the larger of residual-scaled least squares and leave-one-UTC-day-out jackknife errors. Deletions remove a calendar day, refit all remaining coefficients and drop empty intercept columns. The jackknife variance is $(G-1)G^{-1}\sum_g(\hat A_{(-g)}-\overline A)^2$. Period-deletion errors are recorded separately. Extended Data Table 2 gives all components and the same-data intercept comparisons. Observations are repeated measurements of one clock pair, not thousands of independent experiments.

Conditional simulations apply both designs to the same 3,299-row sampling and heteroscedastic uncertainties. Each of four scenarios has 1,000 realizations: independent Gaussian noise; equal variance contributions from Gaussian white noise and a 6-h Ornstein–Uhlenbeck process within segments; the corresponding 24-h process within periods; and standardized Student-$t_5$ noise. The overall scale is the observed segment-model residual scale; all true physical response coefficients are one. Each realization recomputes both components of the standard-error rule. Seed 2026110617 fixes the simulation. Coverage of $\hat A\pm1.96u$ is 95.1–97.4% for the segment-model lunar coefficient and 95.4–96.8% for its neighbouring coefficient; Monte Carlo standard errors are about 0.4–0.7 percentage points (Extended Data Table 3). These tests evaluate errors under the declared noise laws. They do not calibrate the errors against every possible disturbance.

The full-template coefficient uses the same standard-error rule. Its scaled-LS, day-deletion, day-cluster CR1 and period-deletion standard errors are respectively 0.0973, 0.1082, 0.1033 and 0.1216. The CR1 sandwich uses 43 UTC-day clusters and the finite-sample factor $[G/(G-1)][(n-1)/(n-K)]$, with $K=55$. The working interval $\widehat A_T\pm1.96u$ is 0.743–1.167. This working interval does not provide a confidence statement valid for every possible noise process.

For targeted zero-response tests, we compare the weighted RSS of nested models on the unchanged rows. The full-template test adds one entire prediction to segment constants. The neighbouring-group test adds one S₂+K₂ coefficient while retaining the lunar and daily groups and the constants. Noise is generated on the true window with the original heteroscedastic uncertainties and the observed full-model residual scale. Each of the four declared noise scenarios has 20,000 realizations; seeds 2026110711 and 2026110709 fix the full-template and neighbouring-group simulations. The exact residualized-template projection computes the RSS improvement, and direct restricted/full refits check that calculation. The full-template statistic is 110.353; none of the 20,000 draws in any scenario reaches it. The plus-one tail estimate is $1/20,001$ in each scenario, not zero. For the neighbouring statistic 10.943, the corresponding tail estimates are 0.00185, 0.12559, 0.01435 and 0.00205 in the listed noise-scenario order.

Restricted period-wise residual sign flips enumerate all $2^8=256$ patterns, preserving each period's internal structure. The diagnostic tail fractions are 2/256 for the full response and 16/256 for the added neighbouring group. They rely on period independence and symmetry and are not exact experimental randomization tests. The two-sided resolution is 2/256; neither enumeration is converted to a Gaussian sigma value.

The noise scenarios are conditional stress tests, not measured noise laws. In separate 2,000-draw diagnostics per law, the observed within-segment lag-one residual correlation is −0.148. The simulated 95% ranges are −0.054–0.015 for Gaussian noise, 0.216–0.347 for the 6-h mixture, 0.072–0.202 for the 24-h mixture and −0.051–0.017 for $t_5$. Thus the positively correlated mixtures do not describe the observed short-lag structure; neither do the other two laws fully reproduce it. No scenario is selected because of its tidal tail probability. No simulated record is added to the observations.

Extended Data Fig. 1 gives conditional two-group regions: the first 10,000 draws estimate error covariance and the empirical 95% Mahalanobis threshold; the other 10,000 assess coverage. Held-out joint coverage is 94.3–94.8%, with binomial Monte Carlo standard errors of about 0.22 percentage points and additional calibration uncertainty. These nominal regions apply to the specified laws. They do not replace the reported marginal working errors with a universally calibrated joint confidence region.

The phase-relaxed model adds a lunar component shifted by a quarter-cycle while retaining the prescribed M₂/N₂ relationship. Covariance contours use scaled least squares. Subset and deletion fits refit the same model on their retained rows. Shared-data estimates are not averaged. The simulation coverage refers to two-sided intervals; the reported $\pm$ values are standard errors.

### Phase means, spectral density and sampling sidelobes

For the phase plot, $N$ contains segment constants and the two non-lunar groups. We project both $y-r_0$ and the unit lunar prediction with $M_N=I-N(N^TWN)^{-1}N^TW$, and average in twelve fixed M₂ phase bins. If $B$ is weighted bin averaging, the mean covariance is $BM_NC_yM_N^TB^T$, where $C_y$ is the scaled working observation covariance. This covariance retains correlations between means and propagates uncertainty from nuisance estimation. The response is estimated from the original ten-minute means, before phase binning.

For the actual-time display, the representative segment maximizes accepted nominal member count, with segment ID breaking ties. Segment 51 contains 255 ten-minute means and 153,000 members. Its 42.5 member-hours extend from 10 August 2026 21:35 UTC to 12 August 15:55 UTC. Three-hour display bins follow fixed UTC boundaries and remain inside the segment. All 255 means are assigned; none is removed to improve the display. Weighted averaging is identical for observed and unit-predicted centred values. If a display bin has total weight $w_b$ and its segment has total weight $w_s$, the centred-observation variance is $\widehat\sigma^2(1/w_b-1/w_s)$. This propagates the segment-mean operation and creates correlations between display means. The curve at ten-minute timestamps is a sampled physical prediction, not gap filling. The potential display uses $U=c^2y$ and the right axis retains the fractional rate.

Figure 3c preserves the independently specified equal-weight, 54-intercept scan of the unchanged observed means, rather than replacing it with the amplitude fit's weights. Every trial sine–cosine pair and the data are projected against the same constants. For a reduction in squared residuals $\Delta\mathrm{RSS}(f)$ with dimensionless $y$, the nominal one-sided projection density is $S_y(f)=600\,\mathrm{s}\,\Delta\mathrm{RSS}(f)$ per Hz, or $10^{-6}$ times that value per µHz. Potential density is $S_W=c^4S_y$; amplitude density is $c^2\sqrt{S_y}$. Uniform-grid checks reproduce the conventional one-sided Fourier density. For interrupted data this normalization is a stated projection density, not a Parseval-calibrated variance over a filled year.^28^

For the equivalent-height display, $h_{\mathrm{eq}}=U/g_0$, where $g_0=9.80665\,\mathrm{m/s^2}$ is conventional standard gravity. The density in centimetre-squared units is $S_{h,\mathrm{cm}}=10^4S_W/g_0^2$; this is a representation of potential difference, not station displacement. Both density axes in Fig. 3c use logarithmic scales. Every stored positive spectral value in the displayed band is retained, without adding a floor. The ratios reported in the summary are $10\log_{10}[P_{\mathrm{observed}}(f)/P_{\mathrm{residual}}(f)]$ at the stored scan points nearest the two reported peak positions. The residual spectrum follows subtraction of the fixed unit physical prediction. The values 16.7 and 9.3 dB therefore compare the before-and-after spectra on the same observation window; they are not ratios to an independently measured instrumental-noise spectrum.

The frequency step is 0.002729 µHz, and the inverse calendar span is 0.032752 µHz. Fine plotting steps do not improve physical resolution. The listed peak positions are scan maxima. No constituent-frequency fit or frequency-confidence interval is reported. M₂-only and S₂-only astronomical injections use the same actual times, nodal factors and equal-weight segment projection. Power at the opposite principal frequency, divided by power at the injected frequency, gives 0.08027 and 0.08149. Conditional scans project out a freely phased sinusoid at the other frequency before scanning the target neighbourhood. Amplitude interference means that such corrections act on sampled waveforms or complex coefficients, not by subtracting scalar power spectra. Gaps alone do not predict the realization of measurement noise. Residual density can describe remaining measurement fluctuations, but includes possible model mismatch and cannot be called a pure instrumental noise floor.

### Instrument and daily-response checks

The matched monitor calculation uses 1,482 rows with 887,882 nominal members, or 246.634 h, in P6–P8. Both baseline and augmented fits have identical members, segment labels and weights. Paired day-deletion replicates propagate uncertainty in their difference. Extended Data Fig. 4 reports the response changes and dates. This comparison concerns the monitored transmission route during the measured overlap.

On the selected data and model, a common 24-h sine–cosine pair gives $A_L=1.036\pm0.133$; separate 24-h pairs in each period give $1.003\pm0.136$. These daily sensitivity designs address a periodicity motivated by temperature and operating schedules, without assigning an independently measured thermal amplitude. A shared 12-h pair gives lunar $0.994\pm0.132$ and neighbouring $2.931\pm1.011$. Separate pairs in each period give $0.751\pm0.242$ and $-5.100\pm15.008$. The normalized design condition number grows from 2.37 to 6.90 and 122.54, respectively; all designs retain full numerical rank. These terms test same-frequency identifiability and are not independently measured disturbances. Extended Data Table 4 reports both groups and their 1.96-SE working intervals.

The full-template sensitivity fits add either one shared 24-h sine–cosine pair or a separate 12-h pair in each of the eight periods. The basis functions are evaluated at the recorded UTC bin centres. All 3,299 observations, 54 segment constants, original weights and the full minor remainder are retained. Each model recomputes scaled least-squares and 43-day-deletion errors; Extended Data Table 5 lists both components. These scalar-response fits are distinct from the grouped models in Extended Data Table 4.

### AI-assisted preparation

OpenAI Codex assisted English drafting, code preparation and checking, earlier numerical replay, and plotting from derived experimental tables using Python. The geographical map in Fig. 1a was supplied by the authors and retained unchanged. No observations were generated to replace or fill the experimental record. This manuscript revision reorganized the existing narrative and displays without rerunning fits or data validation. [Authors to confirm the tool and version details, their verification of the code, source data, statistics, figures and citations, and responsibility for the final work.]
