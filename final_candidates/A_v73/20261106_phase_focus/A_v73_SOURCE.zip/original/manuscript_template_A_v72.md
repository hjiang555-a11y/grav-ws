# Tidal potential measured on a coastal–inland optical-clock baseline

[Author list, order and affiliation assignments to be confirmed by the authors]

{{AFFILIATIONS}}

## Abstract

The principal lunar and solar semidiurnal tides repeat every 12.42 and 12 hours. Their relative phase drifts with date, offering a way to distinguish nearby gravitational signals with interrupted clock observations. We compare a strontium clock in Shanghai and a ytterbium clock in Wuhan, 692 km apart and linked by 1,350 km of optical fibre. Across an annual span, 545.9 hours of observations give responses of $1.00\pm0.13$ for the lunar group M₂+N₂ and $0.93\pm0.36$ for the neighbouring group S₂+K₂, relative to a combined solid-Earth and ocean-loading prediction. Segment reference levels are estimated independently. Ocean loading contributes one third of the predicted variation. Full-record phase folding and the measured semidiurnal spectrum show the recurring signal. A simultaneous summer fibre monitor changes the lunar response by $0.006\pm0.006$. The approximately daily group is less precisely constrained within the same joint model.

## Main text

The strongest lunar and solar semidiurnal tides keep slightly different time. M₂ repeats every 12.42 h, whereas S₂ repeats every 12 h. Their maxima therefore move past one another as the date changes. Over a short observation, the two variations can look much alike; across different lunar–solar phases, they become distinguishable. This offers a natural way to separate nearby gravitational signals when an experiment cannot run continuously.

Optical clocks provide a local measure of gravitational potential through their relative rates.[@ludlow,mehlstaubler] Clock comparisons have resolved height-dependent redshifts in the laboratory and supported geodetic measurements between distant sites.[@chou,mcgrew,grotti] Stabilized optical-fibre networks make these comparisons possible without transporting the clocks, connecting precision timekeeping to measurements of the Earth.[@lisdat,riehle] A changing potential presents a further challenge: its effect must be distinguished from changes in the clocks, their reference levels and the intervening transfer system. Astronomical tides provide frequencies and phases that can be predicted independently of the clock observations.[@voigt,denker,schroder]

Here we exploit the changing lunar–solar phase in interrupted observations between Shanghai and Wuhan. We estimate the lunar semidiurnal group M₂+N₂ and the neighbouring semidiurnal group S₂+K₂ simultaneously. K₂ includes both lunar and solar forcing; the latter group is therefore not a purely solar measurement. Each group's internal phase relationships and relative amplitudes follow the astronomical prediction. The approximately daily constituents K₁, O₁, P₁ and Q₁ form a third group. Four views connect the physical question to the experiment: the coastal–inland geometry, the full-record phase dependence, the measured semidiurnal spectrum and observations of the transfer system.

### A coastal–inland prediction

The strontium clock in Shanghai and ytterbium clock in Wuhan are 692 km apart, joined through Hefei by a 1,350-km phase-stabilized fibre link (Fig. 1a).[@hou] The summer observations overlap the absolute frequency-ratio measurement reported by Hou and colleagues; the present observable is the time-dependent tidal response. The two clock systems have published systematic evaluations, which describe their apparatus rather than the uncertainty of the interrupted tidal estimate.[@jia,zhu] We define a positive frequency-ratio variation as Wuhan Yb running faster relative to Shanghai Sr. In the geodetic potential convention used here, the measured fractional variation is $y=-[\delta W_{\mathrm{Wuhan}}-\delta W_{\mathrm{Shanghai}}]/c^2$.

Tides change the direct gravitational potential and deform the Earth, moving the clocks and changing the Earth's own potential. Ocean tides additionally redistribute water. Their contribution includes its attraction, the Earth's deformation and the accompanying displacement of the clock. We combine an IERS-based solid-tide prediction with FES2022 ocean elevations and a loading kernel containing all three loading contributions (Methods).[@iers,fes,farrell,han] Shanghai lies by the East China Sea, whereas Wuhan is inland. This geometry makes loading a substantial part of the differential prediction.

The predicted M₂ amplitudes are $3.43\times10^{-18}$ for the solid contribution and $1.42\times10^{-18}$ for loading. Their phases differ by 19.8°, giving a combined amplitude of $4.78\times10^{-18}$ (Fig. 1b). Their vector sum matters because the two contributions do not reach their maxima together. On the sampled record, after removing segment means, loading has 33.1% of the combined prediction's weighted root-mean-square variation. This describes the model contribution. A separately processed analysis allowing loading its own coefficient reported $0.89\pm0.55$, which does not resolve that coefficient (Methods). The observable tested here is the combined potential.

The record spans September 2025 to August 2026, with 54 valid segments in eight observing periods (Fig. 1c). Its 3,299 ten-minute means contain 545.9 h of accepted nominal one-second measurements. Observations occur in eight calendar months; the annual span is not continuous operation. Actual UTC times and all gaps are retained. The June–August observations supply 273.9 h and sample a broad range of relative lunar–solar phase, while the earlier periods add different phases and operating conditions (Fig. 1d). Both the duration and placement of the observations determine what can be separated.

### Two nearby semidiurnal responses

Fitting the three physical groups together gives $A_L=1.00\pm0.13$ for M₂+N₂ and $A_S=0.93\pm0.36$ for S₂+K₂. One denotes the specified combined prediction. Each of the 54 segments has its own constant reference level, and the same noise weights are used throughout the amplitude analysis. The coefficients are estimated from the original ten-minute means. No empirical daily sinusoid is subtracted first, and no model values replace missing measurements.

Figure 2 orders the entire record by M₂ phase. The observations, after subtracting the fixed minor tidal remainder, and the unit lunar prediction undergo the same projection against segment constants and the other two fitted groups. Twelve phase bins then reveal the recurring modulation. All individual points and the number supporting each bin are retained. The propagated error bars account for the jointly estimated nuisance terms; the twelve displayed means are a view of the full fit, rather than twelve new independent observations.

Allowing a lunar component one quarter-cycle from the predicted phase gives in-phase and quadrature responses of $1.00\pm0.13$ and $-0.10\pm0.20$ (Fig. 3b). The phase is compatible with the astronomical prediction. The jointly fitted daily group has $A_D=0.58\pm0.54$ (Fig. 3a). Its lower precision is already accounted for through the joint design and covariance; it does not negate the semidiurnal responses. It also does not provide a bound on an unmeasured laboratory daily disturbance.

The reported errors are the larger of residual-scaled least-squares and UTC-day-deletion standard errors. Their components, period-deletion checks and conditional interval coverage are given in Methods. Separating the three groups preserves uncertainty from their overlap. It does not require the daily group to be measured with the same precision as the half-daily groups.

### The measured semidiurnal spectrum

The spectrum presents the same observations in a complementary, physically intuitive form (Fig. 3c). An equal-weight sinusoidal scan with 54 segment constants has local maxima at 22.361 and 23.147 µHz, close to the predicted M₂ and S₂ frequencies of 22.364 and 23.148 µHz. Their separation is much larger than the inverse calendar span, 0.0328 µHz. The left axis expresses spectral density in gravitational-potential units and the right in fractional-frequency units. A fractional variation of $10^{-18}$ corresponds to about $0.09\,\mathrm{m^2/s^2}$ of potential difference.

Interruptions shape this spectrum. Sampling a narrow tidal line at the observed times spreads part of its power into sidelobes, including the neighbourhood of the other principal semidiurnal frequency. Single-constituent injections through the actual sampling and scan give 8.03% M₂-to-S₂ cross-power and 8.15% in the reverse direction. These numbers describe the sampling response, not random noise added by the gaps. Conditional scans retain a local feature near each frequency after projecting out the sine and cosine at the other (Extended Data Fig. 2).

The two features thus support their assignment to the principal lunar and solar semidiurnal neighbourhoods. They do not separately measure N₂ or K₂. The response coefficients instead come from the simultaneous astronomical groups, with their prescribed internal relationships and noise weights. Subtracting the fixed unit physical prediction reduces the spectral structure, as shown by the second curve. That curve is a residual display of the same record, not another significance test. Phase coverage, spectral attribution and grouped estimation answer related but distinct questions.

### Across interruptions and through the fibre

The response is supported by observations on both sides of summer. With the same segment model, the lunar coefficient is $1.21\pm0.23$ before summer and $0.77\pm0.18$ in summer. Deleting each observing period in turn gives point estimates from 0.885 to 1.093 (Fig. 4a). These overlapping fits show the influence of each period; the headline result uses the full record.

The choice of reference levels follows the experimental record. The available interval and correction tables do not establish a calibrated zero transfer across interruptions. We therefore give each valid segment an independent constant. The model with eight period constants reproduces $0.987\pm0.123$ on exactly the same observations, templates and weights. Its lunar result changes little, but its neighbouring-group coefficient becomes $1.129\pm0.288$. Residual structure and deletion results for both designs are retained in Methods and Extended Data Fig. 1. Agreement with one is not used to choose between them.

A simultaneous fibre round-trip record provides a direct instrument control on 246.6 h of summer observations, from 29 June to 25 August 2026. Clock and monitor means are formed from matching valid members. Adding the monitor to the otherwise identical segment model changes the lunar coefficient by $0.0061\pm0.0063$ and the neighbouring coefficient by $0.0059\pm0.0145$ (Fig. 4b). This tests the monitored transmission route on that overlap. Other local transfer branches and clock effects require their own observations.

Daily temperature changes and operating schedules motivate environmental checks. The separately filtered analysis reports a lunar coefficient of $0.98\pm0.13$ with two-site temperature regressors; its distinct sampling and supporting measurements are identified in Methods. On the present observations, adding one shared 24-h sine–cosine pair gives $1.04\pm0.13$. Arbitrary period-specific 12-h terms are retained as sensitivity tests because, over short runs, they compete directly with astronomical semidiurnal variation. They are not assigned an observed laboratory amplitude.

The experiment uses the changing lunar–solar phase to carry information between separated observing dates while allowing their reference levels to remain independent. Its combined potential includes a sizeable ocean-loading contribution, although loading is not separately resolved. Contemporaneous European clock-network observations by Stahl and colleagues use different baselines and tidal mixtures and provide a complementary realization of time-dependent chronometric geodesy.[@stahl] Longer coastal records, together with calibrated local transfer paths, could turn this sensitivity to the combined prediction into a distinct test of ocean loading.

\clearpage

## Figure legends

![Figure 1](figures/figure1.png)

**Fig. 1 | Geometry and changing lunar–solar phase.** **a,** Shanghai Sr and Wuhan Yb, 692 km apart, with the 1,350-km fibre connection through Hefei drawn schematically. **b,** Predicted differential M₂ solid and ocean-loading phasors, with the solid component defining phase zero; amplitudes are fractional clock rates in units of $10^{-18}$. **c,** Actual UTC sampling in eight observing periods, with accepted nominal member-hours. **d,** The S₂−M₂ astronomical phase at those same samples, including nodal corrections. Summer periods P6–P8 are orange. Geography and phasors describe the prediction; the lower panels describe the observation window.

\clearpage

![Figure 2](figures/figure2.png)

**Fig. 2 | The full record ordered by lunar phase.** **a,** Twelve 30° M₂ phase means of all 3,299 observations, after subtracting the fixed minor remainder and projecting against 54 segment constants and the neighbouring semidiurnal and daily groups. Identical weighted projection and averaging are applied to the unit lunar prediction; the fitted curve uses the unbinned primary coefficient. Error bars are one working standard error with the nuisance projection propagated; phase means are correlated. **b,** Every projected observation, with the full observed vertical range. **c,** Number of rows in each bin. Data, weights and templates are the primary segment design throughout. This is a display of the main observations, not an independent experiment.

\clearpage

![Figure 3](figures/figure3.png)

**Fig. 3 | Semidiurnal responses, phase and measured spectral structure.** **a,** Joint group amplitudes with one standard error, defined as the larger of scaled least-squares and UTC-day jackknife errors. **b,** Lunar in-phase and quadrature coefficients; the cross marks the unit prediction. Contours have covariance radii one and two from scaled least squares, not separately calibrated joint confidence levels. **c,** Equal-weight spectral calculation: 3,299 real UTC means, 54 segment constants and equal weights. Blue shows the observed scan; orange follows subtraction of the fixed unit total prediction. No gap is filled or compressed. Both axes show the same nominal one-sided projection density per µHz, related by $S_W=c^4S_y$. Sampling sidelobes contribute about 8% bidirectional M₂/S₂ cross-power. Peak locations support the principal-frequency attribution; group coefficients in **a** use the physical templates and Allan-based weights. All panels use the same observation rows.

\clearpage

![Figure 4](figures/figure4.png)

**Fig. 4 | Temporal support and a simultaneous transmission control.** **a,** Lunar estimates from the full record, the pre-summer and summer subsets, and deletion of each observing period. Each fit uses segment constants and the primary noise weights, with errors recalculated on its retained rows. The shaded band is the full-record one-standard-error range. These fits share observations. **b,** Changes caused by including the simultaneous round-trip monitor, with paired UTC-day-jackknife standard errors. Both fits use identical clock/monitor members: 1,482 means representing 246.6 h in P6–P8, between 29 June and 25 August 2026. This control covers the monitored transmission channel on its measured overlap; the principal tide fit retains the entire 545.9-h clock record.

\clearpage

## Methods

### Observations, frequency sign and averaging

The Shanghai and Wuhan coordinates used by the frozen prediction are 31.130° N, 121.570° E and 30.529° N, 114.357° E. The measured ratio is Wuhan Yb/Shanghai Sr. With positive geodetic potential $W$, its tidal fractional variation is $-[\delta W_{\mathrm{Wuhan}}-\delta W_{\mathrm{Shanghai}}]/c^2$. The period-relative beat conversion is $-d_p(f_{\mathrm{beat}}-f_{{\mathrm{ref}},p})/F_{1550}$, where $F_{1550}=1.933992\times10^{14}$ Hz and $d_p=2$ in 2025 and 1 in 2026. Thus a 2026 beat deviation of 1 Hz has fractional magnitude $5.17\times10^{-15}$. The 2025 division factor is applied before forming the small clock-rate variation.

The supplied valid-interval table defines 54 segments in 29 operating groups and eight periods. Counter members are read across midnight before binning. Beijing-time labels are converted to UTC. Summer group corrections follow the decimal-arithmetic frequency-chain calculation; early absolute correction entries remain incomplete. Their constant part is represented by segment intercepts, while any time variation within a segment remains a possible systematic contribution. Fitted intercepts are never applied to join the runs for long-term stability estimation.

The membership audit contains 1,966,908 nominal one-second rows before the minimum-bin-support cut. Three boundary rows reconcile its difference from the printed interval total. Means are formed in nominal 600-s bins separately within each segment and require at least 180 retained members. The 3,299 accepted means contain 1,965,327 members, or 545.924 h. There are 3,291 unique bin centres: eight centres contain separate partial means from different segments, with disjoint members. The 353.39-day span contains observations on 43 UTC dates. The inherited valid mask is retained; this work neither applies an additional triangular filter nor selects points using tidal residuals. Exact raw-file memberships and hashes are retained in the controlled archive.

### What the constituent names mean

Semidiurnal tides produce approximately two cycles per day. M₂ is the principal lunar constituent; N₂ describes an additional lunar variation associated with orbital ellipticity. S₂ is the principal solar semidiurnal constituent, whereas K₂ contains lunar and solar forcing. The names identify astronomical frequencies, not separate instruments or independent experiments. The diurnal group contains K₁ (lunisolar), O₁ (principal lunar), P₁ (principal solar) and Q₁ (lunar elliptic). Their periods are listed in Extended Data Table 3.[@noaa] Internal relative amplitudes, phases and nodal modulation are fixed within each physical group. A group response therefore tests that complete specified pattern.

### Combined solid and loading potential

The physical target includes the direct astronomical potential, the Earth's induced potential and the effect of clock displacement. The selected frozen solid sequence implements these through the IERS radial displacement $u$ and a fixed effective-potential conversion,

$$y_{\mathrm{solid}}=-\frac{1+k_2-h_2}{h_2}\frac{g(u_{\mathrm{Wuhan}}-u_{\mathrm{Shanghai}})}{c^2},$$

with $h_2=0.6078$, $k_2=0.3010$ and $g=9.794\,\mathrm{m/s^2}$. This is a displacement-based approximation to the combined solid potential, not the alternative frequency-resolved direct-potential implementation. The same conversion also acts on degree-three and frequency-dependent displacement contributions in the supplied sequence. A previous implementation comparison found an approximately 18% K₁ amplitude deficit relative to a potential-weighted reference. The daily response is accordingly not used to infer a Love number. Uncertainty in the solid model remains separate from the quoted statistical errors.

For loading, FES2022 sea-surface elevations $\zeta$ are convolved with the effective-potential kernel

$$\delta W_{\mathrm{load}}=\int \rho_w\zeta(\mathbf{r}',t)G_W(\psi)\,\mathrm{d}A,\qquad
G_W(\psi)=\frac{ga}{M_E}\sum_n(1+k'_n-h'_n)P_n(\cos\psi).$$

The three terms represent direct water attraction, induced potential and clock displacement. PREM load Love numbers are retained through degree 696 with the archived high-degree continuation. Eighteen loading constituents are synthesized with their astronomical nodal corrections. The complex convention is $f\,\mathrm{Re}[C\exp(-i\phi)]$; reversing the exponential sign requires conjugating $C$. The present analysis reads the frozen constituent and time-series tables rather than substituting an older loading sequence.

The eight named constituents are grouped as described above. Minor terms remain once as a fixed remainder $r_0$. On the actual weighted segment-centred sampling, solid, loading and total root-mean-square variations are respectively 2.928, 1.328 and $4.011\times10^{-18}$. Their ratio 0.331 is an amplitude-norm ratio, not an additive fraction of total power. The separately reported $0.89\pm0.55$ loading coefficient belongs to the alternative directly modelled, filtered reduction described below; it has not been recalculated as a separate coefficient of the present estimator.

### Joint estimator and zero-point choice

We fit

$$y_i=c_{s(i)}+A_Ls_{L,i}+A_Ss_{S,i}+A_Ds_{D,i}+r_{0,i}+\epsilon_i,$$

with 54 segment intercepts and three physical response coefficients. Weighted least squares uses the frozen Allan-based uncertainties $\sigma_i$, with $W_{ii}=1/\sigma_i^2$. A period noise coefficient $\alpha_p$ is estimated from within-segment overlapping Allan deviations at 256, 512, 1,024, 2,048 and 4,096 s, after removing the fixed unit tide. No Allan window crosses a segment boundary. The bin uncertainty is $\sigma_i=\alpha_{p(i)}/\sqrt{n_i}$, where $n_i$ is its retained member count. This is a working noise model, not stability calculated after joining fit-adjusted levels. Independent QR replay reproduces the eight-period design on the same rows before changing only its intercept grouping. All comparisons therefore hold sampling, correction values, physical templates and weights fixed.

The inspected interval and correction records contain no documented calibrated zero transfer for the 46 adjacent segment boundaries that share an eight-period intercept. They give valid times, but not a signed boundary transfer with uncertainty or a lock/relock history establishing unchanged reference levels. This motivates the segment design. The eight-period model's weighted residual sum of squares is 3,781.58; the segment model's is 3,713.64, with 46 additional intercept parameters. Their unweighted residual root-mean-square values are 24.114 and $23.934\times10^{-18}$. Reduced residual sums of squares are {{REDUCED_RSS}}. The numerical improvement alone does not establish a physical jump at each boundary.

With period constants, weighted segment-mean residuals range from $-6.75$ to $12.00\times10^{-18}$. Adjacent standardized residual correlations, restricted to the same segment and separations of at most 900 s, are −0.127 and −0.148 for the period and segment designs. Deleting a period gives lunar point-estimate ranges 0.877–1.052 and 0.885–1.093, respectively (Extended Data Fig. 1). These checks retain substantial lunar support under either reference-level assumption. They do not supply missing calibration logs. Coefficient proximity to one is not a model-selection rule.

### Statistical errors and conditional coverage

For each group the reported standard error is the larger of residual-scaled least squares and leave-one-UTC-day-out jackknife errors. Deletions remove a calendar day, refit all remaining coefficients and drop empty intercept columns. The jackknife variance is $(G-1)G^{-1}\sum_g(\hat A_{(-g)}-\overline A)^2$. Period-deletion errors are recorded separately. Extended Data Table 1 gives all components and the same-data intercept comparisons. Observations are repeated measurements of one clock pair, not thousands of independent experiments.

New conditional simulations apply both designs to the same 3,299-row sampling and heteroscedastic uncertainties. Each of four scenarios has 1,000 realizations: independent Gaussian noise; equal variance contributions from Gaussian white noise and a 6-h Ornstein–Uhlenbeck process within segments; the corresponding 24-h process within periods; and standardized Student-$t_5$ noise. The overall scale is the observed segment-model residual scale; all true physical response coefficients are one. Each realization recomputes both components of the standard-error rule. Seed 2026110617 fixes the simulation. Coverage of $\hat A\pm1.96u$ is 95.1–97.4% for the segment-model lunar coefficient and 95.4–96.8% for its neighbouring coefficient; Monte Carlo standard errors are about 0.4–0.7 percentage points (Extended Data Table 2). These are tests under declared noise laws, not a calibration against every possible disturbance.

The phase-relaxed model adds the lunar quadrature while retaining the prescribed M₂/N₂ relationship. Covariance contours use scaled least squares. Subset and deletion fits refit the same model on their retained rows. No shared-data estimates are averaged, and no half-daily coefficient is converted into a daily upper limit.

### Phase means, spectral density and sampling sidelobes

For the phase plot, $N$ contains segment constants and the two non-lunar groups. We project both $y-r_0$ and the unit lunar prediction with $M_N=I-N(N^TWN)^{-1}N^TW$, and average in twelve fixed M₂ phase bins. If $B$ is weighted bin averaging, the mean covariance is $BM_NC_yM_N^TB^T$, where $C_y$ is the scaled working observation covariance. It retains correlations between means and propagates nuisance estimation. The full unbinned response remains primary.

Figure 3c preserves the independently specified equal-weight, 54-intercept scan of the unchanged observed means, rather than replacing it with the amplitude fit's weights. Every trial sine–cosine pair and the data are projected against the same constants. For a reduction in squared residuals $\Delta\mathrm{RSS}(f)$ with dimensionless $y$, the nominal one-sided projection density is $S_y(f)=600\,\mathrm{s}\,\Delta\mathrm{RSS}(f)$ per Hz, or $10^{-6}$ times that value per µHz. Potential density is $S_W=c^4S_y$; amplitude density is $c^2\sqrt{S_y}$. Uniform-grid checks reproduce the conventional one-sided Fourier density. For interrupted data this normalization is a stated projection density, not a Parseval-calibrated variance over a filled year.[@vanderplas]

The frequency step is 0.002729 µHz; the inverse calendar span is 0.032752 µHz. Fine plotting steps do not improve physical resolution. M₂-only and S₂-only astronomical injections use the same actual times, nodal factors and equal-weight segment projection. Power at the opposite principal frequency, divided by power at the injected frequency, gives 0.08027 and 0.08149. Conditional scans project out a freely phased sinusoid at the other frequency before scanning the target neighbourhood. Amplitude interference means that such corrections act on sampled waveforms or complex coefficients, not by subtracting scalar power spectra. Gaps alone do not predict the realization of measurement noise. Residual density can describe remaining measurement fluctuations, but includes possible model mismatch and cannot be called a pure instrumental noise floor.

### Instruments, environmental checks and the alternative reduction

The matched monitor calculation uses 1,482 rows with 887,882 nominal members, or 246.634 h, in P6–P8. Both baseline and augmented fits have identical members, segment labels and weights. Paired day-deletion replicates propagate uncertainty in their difference. The lunar, neighbouring and daily coefficient changes are respectively $0.00606\pm0.00627$, $0.00594\pm0.01453$ and $0.00791\pm0.01388$. The archive does not provide that paired control for the pre-summer periods or every laboratory transfer branch.

The alternative v68 reduction reports $A_L=0.97\pm0.14$ from approximately 544 h in 54 segments, with a 1,200-s triangular filter sampled every 600 s, equal weights, a direct-potential solid model and a continuous-run circular-residual-shift error. It reports $0.98\pm0.13$ with two-site ERA5 temperature regressors and a 474-h round-trip overlap changing lunar and whole-template coefficients by less than 0.005. These are author-reported manuscript results, not the present replay. The stated 98-h Sr chamber record is a distinct thermometer measurement; ERA5 2-m air temperatures are environmental proxies. Exact membership for the 474-h control and temperature-regression support must be supplied for an independent replay. These checks are not combined with the current uncertainty.

On the selected data and model, a common 24-h sine–cosine pair gives $A_L=1.036\pm0.133$; separate 24-h pairs in each period give $1.003\pm0.136$. These are mechanism-motivated daily sensitivity designs, not measurements of an independently observed thermal amplitude. Free 12-h pairs in each period give $0.751\pm0.242$ and a very poorly constrained neighbouring coefficient; the design competes with astronomical semidiurnal variation within short periods. It is retained as a sensitivity boundary, with no assumed laboratory disturbance assigned to it. A sequential residual diagnostic must project its test basis through the same physical-fit operator and propagate uncertainty.

## Data availability

The author review package contains the 3,299 derived means, fixed templates, noise weights, figure source tables and immutable input hashes. The original counters and membership ledger are held in the controlled experimental archive. [Authors to supply an editor-accessible location and confirm the permanent data-access statement and repository identifier before submission.]

## Code availability

The package contains the independent QR replay, same-data design comparison, conditional simulations, spectral calculations, covariance propagation and figure scripts, with software versions and a reproducible entry point. [Authors to confirm the code licence and permanent repository identifier before submission.]

## Author statements

**Author contributions:** [To be completed and approved by all authors.]

**Acknowledgements and funding:** [To be completed by the authors.]

**Competing interests:** [Declaration to be supplied by the authors.]

**Correspondence:** [Corresponding author names and email addresses to be supplied.]

**AI-assisted preparation:** OpenAI Codex assisted English drafting, numerical replay and figure preparation. [Authors to confirm their verification of the analyses, citations and final text, and responsibility for the submitted work.]

\clearpage

## References

{{REFERENCES}}

\clearpage

## Extended Data

![Extended Data Figure 1](figures/ed_figure1.png)

**Extended Data Fig. 1 | Same-data comparison of reference-level designs.** **a,** Weighted mean residual of each segment after the eight-period joint fit. The additional segment intercepts make these means zero by construction, so a zero line would not demonstrate calibration. **b,** Lunar point estimates after deleting each observing period under eight-period and 54-segment designs. Both use the same frozen observations, physical templates, corrections and noise weights. These diagnostics do not replace lock/relock or zero-transfer records.

![Extended Data Figure 2](figures/ed_figure2.png)

**Extended Data Fig. 2 | Conditional semidiurnal scans.** Equal-weight scans of the same 3,299 observations with 54 segment intercepts. **a,** M₂ neighbourhood before and after projection of a sine–cosine pair at S₂. **b,** S₂ neighbourhood before and after projection at M₂. Dotted lines show the astronomical target frequencies. These are descriptive projections on shared observations, not additional detection probabilities.

\clearpage

**Extended Data Table 1 | Estimator and uncertainty comparison.** All directly replayed designs use the same 3,299 means, physical templates and Allan-based weights. Errors are standard errors. The alternative filtered estimate is separately labelled author-reported.

{{DESIGN_TABLE}}

{{ERROR_TABLE}}

**Extended Data Table 2 | Conditional 95% interval coverage.** Each scenario has 1,000 simulated realizations per design, with fixed observed sampling and weights. Values are percentages for the larger-of-LS-and-day-jackknife rule, using multiplier 1.96. They assess the specified scenarios, not unknown systematic effects.

{{COVERAGE_TABLE}}

**Extended Data Table 3 | Astronomical constituent guide.** Names specify forcing and frequency; one response coefficient multiplies each complete group with its internal ratios and phases fixed.

{{TIDE_TABLE}}
