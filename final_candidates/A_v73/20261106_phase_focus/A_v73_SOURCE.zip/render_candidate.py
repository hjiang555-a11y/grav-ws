"""Render a versioned review manuscript with vector figures, native Word math and editable Extended Data tables."""
from pathlib import Path
import argparse, re, json, hashlib, subprocess
from docx import Document
from docx.shared import Mm,Pt

HERE=Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('source',type=Path);ap.add_argument('out',type=Path);a=ap.parse_args()
source=a.source.resolve();out=a.out.resolve();assert source.is_relative_to(HERE) and out.is_relative_to(HERE)
out.mkdir();text=source.read_text();resources=re.findall(r'!\[[^]]*\]\(([^)]+)\)',text)
text=text.replace('\\clearpage','\n::: pagebreak\n:::\n')
text=text.replace(r'G_{\rm shared}',r'G_{\mathrm{shared}}').replace(r'G_{\rm separate}',r'G_{\mathrm{separate}}')
pdftext=text
for value in resources:
    p=(HERE/value).resolve();assert p.is_relative_to(HERE) and p.is_file() and p.with_suffix('.pdf').is_file()
    pdftext=pdftext.replace(value,str(Path(value).with_suffix('.pdf')))
(out/'pdf_input.md').write_text(pdftext);(out/'docx_input.md').write_text(text)
(out/'header.tex').write_text(r'''\usepackage{sectsty}
\allsectionsfont{\raggedright}
\usepackage{lineno}
\linenumbers
\usepackage{setspace}
\doublespacing
\usepackage{fancyhdr}
\pagestyle{fancy}\fancyhf{}
\fancyhead[L]{\small Optical clocks distinguish neighbouring semidiurnal tides}
\fancyfoot[C]{\thepage}\setlength{\headheight}{14pt}
\usepackage{float}\floatplacement{figure}{H}
\setlength{\emergencystretch}{2em}
''')
doc=Document();sec=doc.sections[0];sec.page_width=Mm(210);sec.page_height=Mm(297)
sec.left_margin=sec.right_margin=Mm(15);sec.top_margin=sec.bottom_margin=Mm(20)
style=doc.styles['Normal'];style.font.name='Times New Roman';style.font.size=Pt(10);style.paragraph_format.line_spacing=2
doc.save(out/'reference.docx')

texcmd=['pandoc',str(out/'pdf_input.md'),'--standalone','--from=markdown-implicit_figures','--lua-filter='+str(HERE/'layout_working.lua'),'--resource-path='+str(HERE),'-t','latex','-o',str(out/(source.stem+'.tex')),'-V','mainfont=DejaVu Serif','-V','sansfont=DejaVu Sans','-V','papersize=a4','-V','geometry:left=15mm,right=15mm,top=20mm,bottom=20mm','-V','fontsize=10pt','-H',str(out/'header.tex')]
subprocess.run(texcmd,cwd=HERE,check=True)
builds=[]
for ext in ['pdf','docx']:
    cmd=['pandoc',str(out/(ext+'_input.md')),'--standalone','--from=markdown-implicit_figures','--lua-filter='+str(HERE/'layout_working.lua'),'--resource-path='+str(HERE),'-o',str(out/(source.stem+'.'+ext))]
    if ext=='pdf':cmd+=['--pdf-engine=xelatex','--pdf-engine-opt=-no-shell-escape','-V','mainfont=DejaVu Serif','-V','sansfont=DejaVu Sans','-V','papersize=a4','-V','geometry:left=15mm,right=15mm,top=20mm,bottom=20mm','-V','fontsize=10pt','-H',str(out/'header.tex')]
    else:cmd+=['--reference-doc='+str(out/'reference.docx')]
    r=subprocess.run(cmd,cwd=HERE,capture_output=True,text=True)
    (out/(ext+'.log')).write_text(r.stderr)
    builds.append(dict(format=ext,exit=r.returncode,warnings=r.stderr))
    if r.returncode:break
if all(b['exit']==0 for b in builds):
    p=out/(source.stem+'.docx');d=Document(p)
    for par in d.paragraphs:
        if par.text.startswith(('Fig. ','Extended Data','1. ','2. ')) or par._p.xpath('.//w:drawing'):
            par.paragraph_format.line_spacing=1
    for table in d.tables:
        for row in table.rows:
            for cell in row.cells:
                for par in cell.paragraphs:
                    par.paragraph_format.line_spacing=1
                    for run in par.runs:run.font.size=Pt(7);run.font.name='Arial'
    d.save(p)
result=dict(source=str(source),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),builds=builds,
    total_figure_files=len(resources),status='BUILT_FOR_REVIEW' if len(builds)==2 and all(x['exit']==0 for x in builds) else 'BUILD_FAILED',
    scientific_or_author_approval=False,format='Author-choice candidate A v73; double-spaced text and vector PDF figures')
(out/'BUILD_RESULTS.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
if result['status']=='BUILD_FAILED':raise SystemExit(1)
