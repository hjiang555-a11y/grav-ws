"""Editorial revision of A_v72; no changes to observations or estimators."""
from pathlib import Path
import json

O = Path(__file__).resolve().parents[1]
original = (O / 'original/manuscript_template_A_v72.md').read_text()
title = "Optical clocks distinguish neighbouring semidiurnal tides"
front = original.split('## Abstract')[0]
front = '# ' + title + '\n' + front.split('\n', 1)[1]
abstract = r'''Optical clocks can track changes in Earth's gravitational potential, but tides with similar periods are difficult to distinguish in short comparisons.[@mehlstaubler,voigt,stahl] Here we distinguish two semidiurnal responses between coastal Shanghai and inland Wuhan. The principal lunar tide takes about 25 minutes longer per cycle than the principal solar tide. Our 546 hours of observations, spread over 353 days, sample the tides at different relative phases. The measured frequency ratio shows distinct spectral peaks near both principal frequencies. Relative to the combined solid-Earth and ocean-loading prediction, fitted amplitude scales are $1.00\pm0.13$ for the lunar group and $0.93\pm0.36$ for the neighbouring group containing the principal solar tide (one statistical standard error). The changing lunar–solar phase provides a reference for comparing tidal signals across interruptions even when the frequency offsets between observing runs are unknown.'''
main = r'''Two tides can look similar during a short observation, and interruptions can leave an unknown frequency offset between runs. The principal lunar semidiurnal tide M₂ repeats every 12.42 h and the principal solar tide S₂ every 12 h. Observations at different lunar–solar phases can therefore distinguish their responses without joining the runs at a common frequency level.

We use this phase change in a comparison of a strontium clock in Shanghai and a ytterbium clock in Wuhan. The record contains 545.9 h of accepted observations on 43 UTC dates spread over 353 days. A joint model with an independent constant for every valid segment resolves two semidiurnal groups, M₂+N₂ and S₂+K₂. The observed spectrum also has a local peak near each principal frequency. K₂ contains both lunar and solar forcing; the neighbouring group therefore contains more than the purely solar S₂ tide. The group's internal phases and relative amplitudes follow the astronomical prediction. The approximately daily constituents K₁, O₁, P₁ and Q₁ are estimated together as a third group.

Optical clocks measure potential differences through their relative rates.[@ludlow,mehlstaubler] Clock comparisons have resolved laboratory height-dependent redshifts and enabled remote geodetic measurements.[@chou,mcgrew,grotti] Stabilized optical-fibre networks connect clocks without transporting them.[@lisdat,riehle] Time-dependent measurements must distinguish gravitational responses from changes in the clocks and transfer system. Astronomical tides supply frequencies and phases predicted independently of the clock observations.[@voigt,denker,schroder]

### Observing dates and the coastal–inland baseline

The two clocks are 692 km apart and connected through Hefei by a 1,350-km phase-stabilized fibre link (Fig. 1a).[@hou] Between September 2025 and August 2026 they supplied 3,299 ten-minute means in 54 valid segments and eight observing periods (Fig. 1c). Observations occur in eight calendar months, with actual UTC times and all missing intervals retained. The June–August periods contribute 273.9 h and sample different lunar–solar phases; the earlier periods add further phases and operating conditions (Fig. 1d). The placement of observations in the lunar–solar cycle supplies the separation between the nearby signals.

The earlier summer comparison reports a nominal white-frequency-noise trend of $5.4\times10^{-16}/\sqrt{\tau/\mathrm{s}}$, where $\tau$ is averaging time.[@hou] This describes the linked-clock system's technical performance, while the present amplitude errors are estimated from the observed record. The individual Sr and Yb systems are described in their clock evaluations.[@jia,zhu] Some summer observations overlap the absolute frequency-ratio measurement of Hou and colleagues; here the measured quantity is the time-dependent tidal response. A positive fractional ratio variation means Wuhan Yb runs faster relative to Shanghai Sr. In the geodetic potential convention, $y=-[\delta W_{\mathrm{Wuhan}}-\delta W_{\mathrm{Shanghai}}]/c^2$.

Tides alter the direct gravitational potential, deform the Earth and move the clocks. Ocean tides add the attraction of redistributed water, the Earth's induced potential and displacement of the clock. The prediction combines an IERS-based solid tide with FES2022 ocean elevations convolved with a kernel containing these three loading contributions (Methods).[@iers,fes,farrell,han] Shanghai lies beside the East China Sea and Wuhan inland, making their differential potential sensitive to ocean loading.

For M₂, the predicted solid contribution is $3.43\times10^{-18}$ and the loading contribution $1.42\times10^{-18}$ in fractional clock rate. Their phases differ by 19.8°, giving a combined amplitude of $4.78\times10^{-18}$ (Fig. 1b). After removing segment means, loading's weighted root-mean-square variation is 33.1% of the combined prediction on the sampled record. This model contribution is distinct from an observed loading coefficient. A separate filtered analysis allowing loading its own coefficient reported $0.89\pm0.55$; that coefficient remains unresolved (Methods).

The zero-point choice follows the available experimental records. Of the segment boundaries within the eight periods, 46 have no documented calibrated zero transfer. We therefore allow each of the 54 segments its own constant, retaining the changing tidal signal within each run. Physical responses are estimated jointly from the original ten-minute means with fixed noise weights. No empirical daily sinusoid is removed before this fit, and no fitted values fill the gaps.

### Two semidiurnal responses and two spectral peaks

The joint fit gives $A_L=1.00\pm0.13$ for M₂+N₂ and $A_S=0.93\pm0.36$ for S₂+K₂ (Fig. 2b). One denotes the combined solid-Earth and ocean-loading prediction. Errors are one statistical standard error, taken as the larger of residual-scaled least squares and UTC-day deletion; components and conditional coverage tests are given in Methods. The daily group is estimated in the same model as $A_D=0.58\pm0.54$. Its larger uncertainty is propagated through the joint fit, which still constrains both semidiurnal groups.

The same measured frequency-ratio record shows local spectral peaks at 22.361 and 23.147 µHz, close to the prescribed M₂ and S₂ frequencies of 22.364 and 23.148 µHz (Fig. 2a). The scan uses all 3,299 observed means at their actual UTC times, with 54 segment constants and equal weights. The peak separation exceeds the inverse calendar span, 0.0328 µHz. The left axis gives density in gravitational-potential units and the right the equivalent fractional-frequency density. A fractional variation of $10^{-18}$ corresponds to about $0.09\,\mathrm{m^2/s^2}$ in potential difference.

The observation window also produces sidelobes. Sampling a single tidal line only at the measured times spreads power towards neighbouring frequencies. Passing individual M₂ and S₂ predictions through this same sampling and scan gives 8.03% M₂-to-S₂ cross-power and 8.15% in the reverse direction. These are responses of the sampling window, not random noise generated by missing observations. A conditional scan retains a local feature near each principal frequency after projecting out the sine and cosine at the other (Extended Data Fig. 2).

These checks support assigning the two features to the principal lunar and solar semidiurnal neighbourhoods. The grouped amplitudes come from the simultaneous physical templates, with prescribed internal relationships and Allan-based noise weights; they do not treat N₂ or K₂ as individually resolved spectral lines. The spectrum, including its curve after subtracting the fixed unit prediction, displays the same observations and supplies no independent detection probability.

The phase of the recurring signal is also compatible with the prediction. Adding a lunar component one quarter-cycle from the predicted phase gives in-phase and quadrature responses of $1.00\pm0.13$ and $-0.10\pm0.20$ (Fig. 2c). Figure 3 orders the full record into twelve M₂ phase bins. The observations after subtracting the fixed minor remainder, and the unit lunar prediction, undergo identical projection against the segment constants and other fitted groups. Propagated errors retain nuisance-parameter uncertainty and covariance between phase means. All individual points and each bin's support remain visible, so the folded curve can be traced to the full record.

### Support across observing periods and instrument controls

The lunar response is supported on both sides of summer. With the same segment model it is $1.21\pm0.23$ before summer and $0.77\pm0.18$ in summer. Deleting one observing period at a time gives point estimates from 0.885 to 1.093 (Fig. 4a). These overlapping fits show how each period contributes to the full-record estimate.

As a same-data check, sharing one reference level within each of the eight periods gives a lunar coefficient of $0.987\pm0.123$ and a neighbouring coefficient of $1.129\pm0.288$. Only the intercept grouping changes in this comparison; observations, physical templates and weights are identical. Residual structure and deletion results are retained in Methods and Extended Data Fig. 1. The segment model is selected from the zero-transfer evidence, rather than the proximity of a coefficient to one.

A simultaneous fibre round-trip record tests the monitored transmission channel on 246.6 h of summer observations, from 29 June to 25 August 2026. Clock and monitor means contain matching valid members. Adding the monitor to the otherwise identical fit changes the lunar coefficient by $+0.0061\pm0.0063$ and the neighbouring coefficient by $+0.0059\pm0.0145$ (Fig. 4b). Its coverage is confined to that overlap and transmission route; other local transfer branches and clock effects require their own observations.

Temperature changes and operating schedules motivate checks at 24 h. A separate filtered analysis reports $0.98\pm0.13$ with two-site temperature regressors, whose sampling and supporting measurements are described in Methods. Adding a shared 24-h sine–cosine pair on the present observations gives $1.04\pm0.13$. The weakly constrained physical daily group is not a bound on laboratory disturbance. Freely phased 12-h terms, which compete with the astronomical semidiurnal groups within short runs, are retained only as sensitivity tests in Methods.

The astronomical phase continues across an interruption even when the measured frequency zero is not transferred. This phase reference allows a sparse clock comparison to distinguish nearby tidal responses across a 353-day span. Contemporaneous European clock-network observations by Stahl and colleagues track time-dependent potential on different baselines and with different tidal mixtures.[@stahl] They complement the grouped semidiurnal measurement on this coastal–inland link. Longer coastal records at lower noise, with phase coverage that distinguishes the solid and loading contributions and calibrated local transfer paths, could allow ocean loading to be tested separately.
'''

rest = original.split('## Figure legends', 1)[1]
# Move the old spectral/group figure ahead of the old phase-fold figure.
start2 = rest.index('![Figure 2]')
start3 = rest.index('![Figure 3]')
start4 = rest.index('![Figure 4]')
fold = rest[start2:start3].replace('![Figure 2](figures/figure2.png)', '![Figure 3](figures/figure3.png)').replace('**Fig. 2 |', '**Fig. 3 |')
new2 = r'''![Figure 2](figures/figure2.png)

**Fig. 2 | Two semidiurnal spectral peaks and their grouped responses.** **a,** Equal-weight scan of all 3,299 observed means at their true UTC times, with 54 segment constants. Peaks occur at 22.361 and 23.147 µHz, near M₂ and S₂. Blue is the observed scan; orange follows subtraction of the fixed unit total prediction. Gaps are retained. The two axes express the same nominal one-sided projection density per µHz, related by $S_W=c^4S_y$. The actual sampling yields about 8% bidirectional single-line M₂/S₂ cross-power. **b,** Joint physical-group amplitudes with one standard error, defined as the larger of scaled least-squares and UTC-day-jackknife errors. These estimates use the physical templates and Allan-based noise weights. **c,** Lunar in-phase and quadrature responses; the cross marks the unit prediction. Contours have scaled-least-squares covariance radii one and two, not separately calibrated joint confidence levels. The spectral peaks identify principal-frequency neighbourhoods, while **b** estimates prescribed constituent groups. All panels use the same observation rows and are not independent significance tests.

\clearpage

'''
rest = rest[:start2] + new2 + fold + rest[start4:]
rest = rest.replace('Figure 3c preserves', 'Figure 2a preserves')
rest = rest.replace('Figure 3c.', 'Figure 2a.')
rest = rest.replace('Independent QR replay reproduces the eight-period design on the same rows before changing only its intercept grouping. All comparisons therefore hold sampling, correction values, physical templates and weights fixed.', 'Independent QR replay reproduces the eight-period design before changing only its intercept grouping. Sampling, corrections, templates and weights are held fixed.')
rest = rest.replace(' These checks retain substantial lunar support under either reference-level assumption. They do not supply missing calibration logs. Coefficient proximity to one is not a model-selection rule.', '')
rest = rest.replace('**Fig. 1 | Geometry and changing lunar–solar phase.**', '**Fig. 1 | Observing geometry and lunar–solar phase coverage.**')
rest = rest.replace('**c,** Actual UTC sampling in eight observing periods, with accepted nominal member-hours.', '**c,** Actual UTC sampling on 43 dates over 353 days, in eight observing periods, with accepted nominal member-hours (545.9 h in total).')
instrument_marker = '### Instruments, environmental checks and the alternative reduction\n\n'
instrument_note = r'''The apparatus performance coefficient quoted in the main text describes the gap-concatenated summer record in the earlier frequency-ratio manuscript.[@hou] The present noise coefficients are estimated separately using only within-segment Allan windows, as defined above.

'''
rest = rest.replace(instrument_marker, instrument_marker + instrument_note)
text = front + '## Abstract\n\n' + abstract + '\n\n## Main text\n\n' + main + '\n\\clearpage\n\n## Figure legends' + rest
(O/'manuscript_template.md').write_text(text)
(O/'editorial'/'REVISION_SCOPE.json').write_text(json.dumps({
    'base':'A_v72 release', 'mode':'Polish plus user-authorized structural revision',
    'title':title, 'analysis_changes':False,
    'figure_mapping':{'old_1':'new_1','old_3c':'new_2a','old_3a':'new_2b','old_3b':'new_2c','old_2':'new_3','old_4':'new_4'},
    'new_performance_claim':'Historical manuscript-reported technical indicator; not independently verified clock stability at 4.6 days',
    'numbers':'Main coefficients and errors unchanged; 546 h and 353 d are rounded from archived totals',
}, indent=2))
print('Revised manuscript template; observations and fit results unchanged.')
