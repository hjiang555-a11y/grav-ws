"""Package the inspected editorial revision without publishing raw source PDFs."""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import shutil
import sys
import zipfile
import fitz
from docx import Document

O=Path(__file__).resolve().parents[1]
R=O/'release'
assert not any(R.iterdir()), 'Do not overwrite an existing release.'
assert json.loads((O/'verification/EDITORIAL_INTEGRITY.json').read_text())['status']=='PASS'
render=O/'render_A_v73_02'
assert all(not (render/name).read_text().strip() for name in ['pdf.log','docx.log'])
geometry=json.loads((O/'verification/PAGE_GEOMETRY_FINAL.json').read_text())
assert len(geometry)==16 and all(not p['outside'] and not p['replacement_glyph'] and p['chars']>400 for p in geometry)
align=[]
for p in sorted((O/'figures').glob('*.alignment.json')):
    d=json.loads(p.read_text());assert d['verdict']=='PASS'
    align.append({'file':str(p.relative_to(O)),'verdict':d['verdict']})
assert len(align)==6

for ext in ['pdf','docx','tex']:
    shutil.copy2(render/f'NATURE_ARTICLE_A_v73.{ext}',R/f'NATURE_ARTICLE_A_v73.{ext}')
for name in ['NATURE_ARTICLE_A_v73.md','REVISION_NOTE_ZH.md','COVER_LETTER.md','REPRODUCE.md']:
    shutil.copy2(O/name,R/name)

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pages=[]
for p in geometry:
    pages.append({'page':p['page'],'geometry':'PASS','visual':'REVIEWED','evidence':f"verification/final_pages/page_{p['page']:02d}.png",'checks':'Text and equations legible; figures, labels and legends complete; no clipping, orphan pages or replacement glyphs.'})
(O/'verification/PAGE_REVIEW.json').write_text(json.dumps(pages,indent=2))
doc=Document(R/'NATURE_ARTICLE_A_v73.docx')
assert len(doc.inline_shapes)==6 and len(doc.tables)==4
versions={'python':sys.version}
for package in ['numpy','scipy','pandas','matplotlib','cartopy','PyMuPDF','python-docx']:
    versions[package]=importlib.metadata.version(package)
(O/'verification/SOFTWARE.json').write_text(json.dumps(versions,indent=2))
result={'status':'PASS','scope':'Author-review editorial revision; no new fit, submission or author approval',
    'base':'A_v72','pdf_pages':16,'editable_word_images':6,'editable_word_tables':4,
    'unchanged_analysis_files':17,'unchanged_copied_sources':87,'original_A_v72_files_preserved':631,
    'figures_alignment':align,'visual_review':'All 16 rendered pages inspected',
    'primary':'S54, 3299 means, unchanged physical model, Allan weights and max LS/day-jackknife errors',
    'pending':['Author list, affiliations and contributor approval','Funding and competing-interest declarations','Permanent data/code access and related-manuscript status','Existing physical-model and reference-location decisions from A_v72'],
    'pdf_sha256':sha(R/'NATURE_ARTICLE_A_v73.pdf'),'md_sha256':sha(R/'NATURE_ARTICLE_A_v73.md')}
(O/'verification/FINAL_CHECK.json').write_text(json.dumps(result,indent=2))
shutil.copy2(O/'verification/FINAL_CHECK.json',R/'FINAL_CHECK.json')
bindings={
    'figure1':['data/RESULTS.json','data/primary_rows.csv','data/period_ledger.csv'],
    'figure2':['data/RESULTS.json','data/semidiurnal_spectrum.csv'],
    'figure3':['data/primary_rows.csv','data/phase_fold.csv','data/phase_covariance.csv'],
    'figure4':['data/RESULTS.json','data/leave_period_all_designs.csv'],
    'ed_figure1':['data/segment_residual_means.csv','data/leave_period_all_designs.csv'],
    'ed_figure2':['data/conditional_scans.csv','data/semidiurnal_spectrum.csv'],
}
(O/'verification/FIGURE_SOURCE_BINDINGS.json').write_text(json.dumps({k:[{'file':n,'sha256':sha(O/n)} for n in v] for k,v in bindings.items()},indent=2))
paths=[]
for dirname in ['scripts','vendor','data','figures','sources']:
    for p in (O/dirname).rglob('*'):
        if not p.is_file() or '__pycache__' in p.parts or p.suffix=='.pyc' or '.alignment.' in p.name:
            continue
        if dirname=='sources' and (p.suffix in ['.pdf','.docx','.html'] or 'upload' in p.name):
            continue
        paths.append(p)
for name in ['NATURE_ARTICLE_A_v73.md','manuscript_template.md','render_candidate.py','layout_working.lua','INPUT_MANIFEST.json','PLAN.md','REPRODUCE.md','REVISION_NOTE_ZH.md','COVER_LETTER.md','original/manuscript_template_A_v72.md','original/NATURE_ARTICLE_A_v72.md']:
    paths.append(O/name)
for dirname in ['editorial','verification']:
    paths.extend(p for p in (O/dirname).glob('*') if p.is_file() and p.suffix in ['.md','.json'] and not p.name.startswith('v72_'))
paths.extend((O/'verification').glob('humanizer_*.txt'))
paths=sorted(set(paths))
manifest=[{'file':str(p.relative_to(O)),'sha256':sha(p),'bytes':p.stat().st_size} for p in paths]
(R/'SOURCE_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile(R/'A_v73_SOURCE.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in paths:z.write(p,str(p.relative_to(O)))
    z.write(R/'SOURCE_MANIFEST.json','SOURCE_MANIFEST.json')
    for ext in ['pdf','docx','tex']:z.write(R/f'NATURE_ARTICLE_A_v73.{ext}',f'NATURE_ARTICLE_A_v73.{ext}')
with zipfile.ZipFile(R/'A_v73_SOURCE.zip') as z:assert z.testzip() is None
(R/'SHA256SUMS.txt').write_text(''.join(f'{sha(p)}  {p.name}\n' for p in sorted(R.iterdir()) if p.is_file()))
(O/'CURRENT_OUTPUT.json').write_text(json.dumps({'version':'A_v73','pdf':str(R/'NATURE_ARTICLE_A_v73.pdf'),'word':str(R/'NATURE_ARTICLE_A_v73.docx'),'source':str(R/'NATURE_ARTICLE_A_v73.md'),'status':'COMPLETE_FOR_AUTHOR_REVIEW','external_submission':False},indent=2))
print(json.dumps({'status':'PASS','pdf_pages':16,'archive_files':len(paths),'archive_bytes':(R/'A_v73_SOURCE.zip').stat().st_size,'pdf_sha256':result['pdf_sha256']},indent=2))
