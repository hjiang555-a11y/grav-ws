"""Independent numerical and integrity checks of the actual scientific changes."""
from pathlib import Path
import hashlib,json,sys
import numpy as np
import pandas as pd
from scipy.signal import periodogram
from recompute_candidate import fit,design
O=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(O/'vendor'))
from spectral_core import scan

def test_inputs_immutable():
    for f in json.loads((O/'INPUT_MANIFEST.json').read_text())['files']:
        assert hashlib.sha256((O/f['copy']).read_bytes()).hexdigest()==f['sha256']
        assert hashlib.sha256(Path(f['source']).read_bytes()).hexdigest()==f['sha256']

def test_independent_lstsq_and_zero_transfer():
    d=np.load(O/'data/design.npz');j=json.loads((O/'data/RESULTS.json').read_text())
    for name,lab in [('P8',d['period']),('S54',d['seg'])]:
        X=design(d['three'],lab);bb=np.linalg.lstsq(X/d['sigma'][:,None],d['y']/d['sigma'],rcond=None)[0]
        np.testing.assert_allclose(bb[:3],j['designs'][name]['A'],atol=1e-10,rtol=0)
    assert j['documented_zero_transfers']==0 and j['primary_design']=='S54'
    assert j['n_rows']==3299 and j['n_members']==1965327

def test_projection_and_phase_covariance():
    d=np.load(O/'data/design.npz');s=d['sigma'];X=design(d['three'][:,1:],d['seg'])
    Q=np.linalg.qr(X/s[:,None],mode='reduced')[0]
    r=pd.read_csv(O/'data/primary_rows.csv');f=pd.read_csv(O/'data/phase_fold.csv')
    np.testing.assert_allclose(Q.T@(r.projected_y/s),0,atol=2e-12)
    np.testing.assert_allclose(Q.T@(r.projected_unit/s),0,atol=2e-12)
    labels=(r.phase_deg//30).astype(int);B=np.zeros((12,len(s)));w=1/s**2
    B[labels,np.arange(len(s))]=w/np.bincount(labels,weights=w)[labels]
    # Independently evaluate the covariance via the full residual operator.
    M=np.eye(len(s))-Q@Q.T;G=B@(s[:,None]*M)
    scale=json.loads((O/'data/RESULTS.json').read_text())['primary']['scale']
    expected=scale*G@G.T;got=pd.read_csv(O/'data/phase_covariance.csv').to_numpy()
    np.testing.assert_allclose(got,expected,rtol=1e-11,atol=1e-11)
    assert (np.linalg.eigvalsh(got)>-1e-9).all() and f.n_rows.sum()==3299

def test_density_units_and_uniform_grid():
    rng=np.random.default_rng(351);y=rng.normal(size=512);t=np.arange(512)*600
    f,p=periodogram(y,fs=1/600,detrend='constant',scaling='density')
    a=scan(t,y,f[1:-1],np.zeros(len(t)))['nominal600_density'][:,0]
    np.testing.assert_allclose(a,p[1:-1],rtol=1e-9,atol=1e-8)
    src=pd.read_csv(O/'sources/v71/data/annual_spectrum_dual_units.csv')
    got=pd.read_csv(O/'data/semidiurnal_spectrum.csv')
    np.testing.assert_array_equal(src.to_numpy(),got.to_numpy())
    j=json.loads((O/'data/RESULTS.json').read_text())['spectrum']
    assert abs(j['peaks'][0]['peak_uHz']-22.3611111111)<1e-7
    assert abs(j['peaks'][1]['peak_uHz']-23.1471510419)<1e-7
    assert .075<j['cross_power']['M2_at_S2']<.085
    assert .075<j['cross_power']['S2_at_M2']<.085

def test_weight_definition():
    b=pd.read_csv(O/'sources/frozen_v72/bins.csv')
    for _,g in b.groupby('period'):
        a=g.sigma.to_numpy()*np.sqrt(g.n.to_numpy())
        np.testing.assert_allclose(a,a[0],rtol=1e-12,atol=1e-10)
