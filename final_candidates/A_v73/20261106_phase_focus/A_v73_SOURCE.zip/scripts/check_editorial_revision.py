"""Check editorial changes against frozen A_v72 evidence, without refitting."""
from pathlib import Path
import collections
import hashlib
import json
import re
import subprocess
import sys

O = Path(__file__).resolve().parents[1]
BASE = O.parent / 'A_v72'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

unchanged = []
for p in sorted((BASE/'data').glob('*')):
    if not p.is_file() or p.name == 'CLAIM_LEDGER.json':
        continue
    q=O/'data'/p.name
    assert q.is_file() and sha(q)==sha(p), p.name
    unchanged.append({'file':str(q.relative_to(O)), 'sha256':sha(q)})
source_files = []
for p in sorted((BASE/'sources').rglob('*')):
    if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':
        q=O/p.relative_to(BASE)
        assert q.is_file() and sha(q)==sha(p), str(p)
        source_files.append(str(q.relative_to(O)))
for row in json.loads((O/'verification/ORIGINAL_A_V72_HASHES.json').read_text()):
    assert sha(Path(row['path']))==row['sha256'], row['path']

a=(O/'original/manuscript_template_A_v72.md').read_text()
b=(O/'manuscript_template.md').read_text()
keys=lambda s:{k for hit in re.findall(r'\[@([a-z,]+)\]',s) for k in hit.split(',')}
assert keys(a)==keys(b)
old_math=collections.Counter(re.findall(r'\$(?!\$)(.+?)(?<!\$)\$',a))
new_math=collections.Counter(re.findall(r'\$(?!\$)(.+?)(?<!\$)\$',b))
removed=old_math-new_math; added=new_math-old_math
assert removed==collections.Counter({r'0.006\pm0.006':1,r'0.0061\pm0.0063':1,r'0.0059\pm0.0145':1}),removed
assert added==collections.Counter({r'5.4\times10^{-16}/\sqrt{\tau/\mathrm{s}}':1,r'\tau':1,r'+0.0061\pm0.0063':1,r'+0.0059\pm0.0145':1}),added

md=(O/'NATURE_ARTICLE_A_v73.md').read_text()
pre_refs=md.split('## References')[0]
citations=re.findall(r'\^([0-9]+(?:,[0-9]+)+|[0-9]+)\^',pre_refs.split('## Abstract')[1])
seen=[]
for c in citations:
    values=list(map(int,c.split(',')))
    assert values==sorted(set(values)),c
    for n in values:
        if n not in seen:seen.append(n)
assert seen==list(range(1,21)),seen
main=md.split('## Main text')[1].split('## Figure legends')[0]
fig_order=[]
for n in re.findall(r'(?<!Data )Fig(?:ure)?\.? ([1-4])',main):
    if n not in fig_order:fig_order.append(n)
assert fig_order==['1','2','3','4'],fig_order
assert '4.6' not in main

j=json.loads((O/'data/RESULTS.json').read_text())
assert j['primary_design']=='S54' and j['n_rows']==3299
assert round(j['sample_hours'])==546 and round(j['span_days'])==353
assert j['n_days']==43 and j['P8_within_period_boundaries']==46
assert f"{j['primary']['A'][0]:.2f}\\pm{j['primary']['u'][0]:.2f}" in md
assert f"{j['primary']['A'][1]:.2f}\\pm{j['primary']['u'][1]:.2f}" in md
assert f"{j['spectrum']['peaks'][0]['peak_uHz']:.3f}" in md
assert f"{j['spectrum']['peaks'][1]['peak_uHz']:.3f}" in md
assert f"{100*j['spectrum']['cross_power']['M2_at_S2']:.2f}%" in md
assert f"{100*j['spectrum']['cross_power']['S2_at_M2']:.2f}%" in md
assert '5.4\\times10^{-16}' in md

checker='/home/room115/.codex/skills/academic-humanizer/scripts/check_revision.py'
checker_results=[]
for name,args in [('humanizer_original',['audit',str(O/'original/NATURE_ARTICLE_A_v72.md')]),('humanizer_compare',['compare',str(O/'original/NATURE_ARTICLE_A_v72.md'),str(O/'NATURE_ARTICLE_A_v73.md'),'--changes']),('humanizer_final',['audit',str(O/'NATURE_ARTICLE_A_v73.md')])]:
    p=subprocess.run([sys.executable,checker,*args],capture_output=True,text=True,check=False)
    (O/'verification'/f'{name}.txt').write_text(p.stdout+p.stderr)
    checker_results.append({'check':name,'exit':p.returncode})
assert [x['exit'] for x in checker_results]==[0,1,0]

claims=[
    {'claim':'Lunar 1.00 ± 0.13','value':j['primary']['A'][0],'standard_error':j['primary']['u'][0],'source':'data/RESULTS.json#/primary','status':'VERIFIED_IN_A_V72_UNCHANGED'},
    {'claim':'Neighbouring 0.93 ± 0.36','value':j['primary']['A'][1],'standard_error':j['primary']['u'][1],'source':'data/RESULTS.json#/primary','status':'VERIFIED_IN_A_V72_UNCHANGED'},
    {'claim':'546 h over 353 d, on 43 UTC dates','hours':j['sample_hours'],'span_days':j['span_days'],'observed_dates':j['n_days'],'source':'data/RESULTS.json','status':'VERIFIED_ROUNDING'},
    {'claim':'22.361 and 23.147 µHz local peaks','values':j['spectrum']['peaks'],'source':'data/RESULTS.json#/spectrum; data/semidiurnal_spectrum.csv','status':'VERIFIED_IN_A_V72_UNCHANGED'},
    {'claim':'About 25 min extra per principal lunar cycle','minutes':(1/j['spectrum']['frequency_Hz']['M2']-1/j['spectrum']['frequency_Hz']['S2'])/60,'source':'data/RESULTS.json#/spectrum/frequency_Hz','status':'DERIVED_PERIOD_DIFFERENCE'},
    {'claim':'46 within-period boundaries without a documented calibrated transfer','boundaries':j['P8_within_period_boundaries'],'documented':j['documented_zero_transfers'],'source':'data/RESULTS.json; original A_v72 zero-transfer audit','status':'DOCUMENTATION_SCOPE_UNCHANGED'},
    {'claim':'5.4e-16/sqrt(tau/s) apparatus performance trend','source':'editorial/STABILITY_SOURCE.json; earlier summer comparison manuscript, paper/prl/main.tex lines 350–374','status':'MANUSCRIPT_REPORTED_TECHNICAL_INDICATOR_NOT_NEW_STABILITY_MEASUREMENT'},
]
(O/'data/CLAIM_LEDGER_V73.json').write_text(json.dumps(claims,indent=2,ensure_ascii=False))
result={'status':'PASS','scope':'Editorial integrity only; no new fit or noise calibration','unchanged_analysis_files':unchanged,'unchanged_source_files':len(source_files),'original_A_v72_files_preserved':len(json.loads((O/'verification/ORIGINAL_A_V72_HASHES.json').read_text())),'reference_keys_unchanged':sorted(keys(a)),'citation_order':seen,'figure_first_appearance':fig_order,'allowed_math_removals':dict(removed),'allowed_math_additions':dict(added),'humanizer':checker_results,'compare_exit_1_explanation':'Intentional abstract deletions, caption/references renumbering, supplied technical indicator and explicit plus signs; primary mathematics and source data unchanged.'}
(O/'verification/EDITORIAL_INTEGRITY.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ['unchanged_analysis_files','reference_keys_unchanged','allowed_math_removals','allowed_math_additions']},indent=2))
