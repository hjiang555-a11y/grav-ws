"""Convert the saved measured/residual spectra to equivalent potential units."""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.insert(0,'/home/room115/.codex/skills/nature-figure/scripts')
from audit_panel_alignment import require_matplotlib_panel_alignment

R=Path(__file__).resolve().parents[1]
A=R.parent/'annual_spectrum_20261106T0857Z'
(R/'figures').mkdir(exist_ok=True)
d=pd.read_csv(R/'data/diagnostic_spectra.csv');original=pd.read_csv(A/'data/spectra.csv')
info=json.loads((A/'data/RESULTS.json').read_text())
C=299792458.0
conversion=600*info['n_bins']*1e-36*C**4
observed=d.observed_power_1e36.to_numpy()*conversion
residual=d.after_fixed_unit_prediction_power_1e36.to_numpy()*conversion
predicted=d.unit_total_prediction_power_1e36.to_numpy()*conversion
assert np.allclose(observed,original.S54_equal_density_Hz_inv.to_numpy()*C**4,rtol=1e-12)
pd.DataFrame({'frequency_uHz':d.frequency_uHz,
 'observed_potential_PSD_m4_s4_per_Hz':observed,
 'unit_prediction_potential_PSD_m4_s4_per_Hz':predicted,
 'residual_potential_PSD_m4_s4_per_Hz':residual,
 'observed_potential_ASD_m2_s2_per_sqrtHz':np.sqrt(observed),
 'residual_potential_ASD_m2_s2_per_sqrtHz':np.sqrt(residual)}).to_csv(R/'data/potential_spectra.csv',index=False)
record={'c_m_per_s':C,'relation':'deltaW=-c^2*y',
 'PSD_multiplier_c4':C**4,'ASD_multiplier_c2':C**2,
 'PSD_unit':'(m^2 s^-2)^2 Hz^-1 = m^4 s^-4 Hz^-1',
 'ASD_unit':'m^2 s^-2 Hz^-1/2',
 'density_normalization':'Original nominal-600-second one-sided LS convention retained; no continuous-year variance-integral claim.',
 'residual_definition':'measured y minus saved full theoretical total with A=1; no re-estimation of tidal amplitude or phase',
 'description':'Model-subtracted residual measurement-noise spectrum, conditional on the specified theory. Includes possible model error and unmodelled signals; not a certified instrument floor.',
 'original_spectrum_unchanged':True}
(R/'verification/POTENTIAL_CONVERSION.json').write_text(json.dumps(record,indent=2))

plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans'],
 'font.size':8,'axes.labelsize':8,'xtick.labelsize':8,'ytick.labelsize':8,'legend.fontsize':8,
 'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.7,
 'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','legend.frameon':False})
fig,axes=plt.subplots(2,1,figsize=(178/25.4,126/25.4))
fig.subplots_adjust(left=.14,right=.975,top=.91,bottom=.11,hspace=.56)
fig.text(.14,.969,'Equivalent potential · 3,299 measured bins · No gap filling',fontsize=8,va='top')
f=d.frequency_uHz.to_numpy();blue='#126080';orange='#b75b19'
for ax,label in zip(axes,['a','b']):
 ax.text(-.12,1.035,label,transform=ax.transAxes,fontweight='bold',fontsize=9,va='bottom')
 ax.plot(f,observed/1e5,color=blue,lw=.8,label='Observed')
 ax.plot(f,residual/1e5,color=orange,lw=.65,label='Residual, fixed tide prediction')
 ax.set_ylim(0,2.4);ax.set_yticks([0,1,2]);ax.set_xlabel('Frequency (µHz)')
 ax.set_ylabel('Equivalent potential PSD\n(10⁵ m⁴ s⁻⁴ Hz⁻¹)')
axes[0].set_xlim(5,40);axes[0].set_xticks(np.arange(5,41,5))
axes[0].legend(loc='upper right',ncol=1,borderaxespad=.2,handlelength=2)
axes[1].set_xlim(21,24.5);axes[1].set_xticks(np.arange(21,24.51,.5))
for key,label in [('M2','M₂ · 12.42 h'),('S2','S₂ · 12 h')]:
 ff=info['frequency_Hz'][key]*1e6
 axes[1].axvline(ff,color='#888888',lw=.7,ls='--',ymax=.82)
 axes[1].text(ff,2.18,label,color=blue,ha='center',va='center',fontsize=8)
fig.canvas.draw()
name='potential_spectrum_and_residual'
require_matplotlib_panel_alignment(fig,json_out=R/f'figures/{name}.alignment.json',
 overlay_svg=R/f'figures/{name}.alignment.svg',tolerance_pt=1.5,strict=True)
fig.savefig(R/f'figures/{name}.pdf')
fig.savefig(R/f'figures/{name}.svg')
fig.savefig(R/f'figures/{name}.png',dpi=600)
plt.close(fig)
print(json.dumps(record,indent=2))
