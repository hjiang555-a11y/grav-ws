"""Frequency association and fixed-theory/alias checks, never new detections."""
from pathlib import Path
import json,hashlib,sys,platform
import numpy as np
import pandas as pd
from scipy.signal import find_peaks
import pyTMD

R=Path(__file__).resolve().parents[1];BASE=R.parent
A=BASE/'annual_spectrum_20261106T0857Z'
TREE=BASE/'sources/R7_tree';S=TREE/'paper/nature/opencode-period-offset-20261105/source-data'
sys.path.insert(0,str(A/'scripts'));from spectral_core import scan
sys.path.insert(0,str(TREE/'research/opencode-period-offset-20261105'));from pipeline import template
inputs=[A/'data/spectra.csv',A/'data/observed_input_rows.csv',A/'data/RESULTS.json',S/'template.csv',S/'constituents.csv',S/'bins.csv',A/'scripts/spectral_core.py']
h={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
d=pd.read_csv(A/'data/spectra.csv');b=pd.read_csv(A/'data/observed_input_rows.csv');old=json.loads((A/'data/RESULTS.json').read_text())
bt=pd.read_csv(S/'template.csv');bt=b[['t_utc']].merge(bt,on='t_utc',how='left',validate='many_to_one',sort=False)
assert len(bt)==len(b)==3299 and np.isfinite(bt.total).all()
t=pd.to_datetime(b.t_utc,utc=True).astype('int64').to_numpy()/1e9;y=b.observed_y_1e18.to_numpy();labels=b.seg.to_numpy()
f=d.frequency_Hz.to_numpy();rayleigh=old['rayleigh_uHz']*1e-6
original=d.S54_equal_power_1e36.to_numpy()
# Full physical prediction from the exact saved R7 table. No coefficient is fitted.
total=bt.total.to_numpy()
theory_scan=scan(t,np.column_stack([total,y-total]),f,labels)
pred=theory_scan['power'][:,0];resid=theory_scan['power'][:,1]
fm=old['frequency_Hz']['M2'];fs=old['frequency_Hz']['S2'];tt=t-t.min()
extra=np.column_stack([np.cos(2*np.pi*fm*tt),np.sin(2*np.pi*fm*tt),np.cos(2*np.pi*fs*tt),np.sin(2*np.pi*fs*tt)])
condmask=(abs(f-fm)>.3*rayleigh)&(abs(f-fs)>.3*rayleigh)
cond=np.full(len(f),np.nan);cond[condmask]=scan(t,y,f[condmask],labels,extra_nuisance=extra)['power'][:,0]
pd.DataFrame({'frequency_uHz':f*1e6,'observed_power_1e36':original,'unit_total_prediction_power_1e36':pred,
 'after_fixed_unit_prediction_power_1e36':resid,'conditioned_on_M2_S2_power_1e36':cond}).to_csv(R/'data/diagnostic_spectra.csv',index=False)
print('Computed fixed-theory and M2/S2-conditioned diagnostics',flush=True)

# Astronomical catalogue: model-supported constituents plus common neighbouring lines.
names=['m2','s2','n2','k2','mu2','nu2','l2','t2','r2','2n2','lambda2','eps2','eta2',
       'k1','o1','p1','q1','j1','m1','oo1','s1','2q1','rho1','m3']
fq=np.asarray(pyTMD.constituents.frequency(names,corrections='FES'))/(2*np.pi)
physroot=Path('/home/room115/gravitation-whsh/research/tidal-spring')
phasor=physroot/'gpu_otl_prem.json';jh=json.loads(phasor.read_text());model_names=list(jh['constituents'])
physical_inputs=[phasor,physroot/'data/solid/solid_tide_sop.csv',physroot/'data/otl/otl_prem_series.csv',physroot/'data/total/total_tide_prem.csv']
for p in physical_inputs:h[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
cat=pd.DataFrame({'name':names,'frequency_Hz':fq,'frequency_uHz':fq*1e6,'period_hours':1/fq/3600,'in_18_loading_constituents':[n in model_names for n in names]})
cat.to_csv(R/'data/constituent_catalogue.csv',index=False)
# Decompose only the existing theoretical sequence, with its unchanged 17-column list.
comp=template.load_components(data_dir=physroot/'data',phasor_file=phasor)
secs=template._template_utc_seconds(comp)
fit_names=template.CONSTITUENTS+template.ABSORBER_CONSTITUENTS
solid=template._fit_phasors(secs,comp.solid.to_numpy(),fit_names,1)
load=template._fit_phasors(secs,comp.loading.to_numpy(),fit_names,1)
coeff=solid+load
amplitudes=pd.DataFrame({'name':fit_names,'solid_amplitude_1e18':abs(solid),'loading_amplitude_1e18':abs(load),'total_amplitude_1e18':abs(coeff),'theory_only':True})
amplitudes.to_csv(R/'data/theoretical_constituent_amplitudes.csv',index=False)
pd.DataFrame({'name':fit_names,'solid_real':solid.real,'solid_imag':solid.imag,
              'loading_real':load.real,'loading_imag':load.imag}).to_csv(R/'data/theoretical_phasors.csv',index=False)
stored=pd.read_csv(S/'constituents.csv')
saved_complex=stored.solid_real.to_numpy()+stored.loading_real.to_numpy()+1j*(stored.solid_imag.to_numpy()+stored.loading_imag.to_numpy())
coefficient_error=float(np.max(abs(saved_complex-coeff[:8])))
assert coefficient_error<1e-10
phase,nodal=template._arguments(t,fit_names)
components=nodal*np.real(coeff[None,:]*np.exp(-1j*phase))
# Preserve coefficients for secondary constituents not in the theory decomposition.
load_table=template.loading_phasors(phasor_file=phasor) if hasattr(template,'loading_phasors') else None
load_table.to_csv(R/'data/loading_phasors_18.csv',index=False)

obs_ix,_=find_peaks(original)
chosen=set(obs_ix[np.argsort(original[obs_ix])[::-1][:20]].tolist())
for name in ['M2','S2','N2','K2','K1','O1','P1','Q1']:
    ff=old['frequency_Hz'][name];near=obs_ix[abs(f[obs_ix]-ff)<=rayleigh]
    if len(near):chosen.add(int(near[np.argmax(original[near])]))
chosen=np.array(sorted(chosen,key=lambda i:original[i],reverse=True))
single=scan(t,components,f[chosen],labels)['power']
single_df=pd.DataFrame(single,columns=fit_names)
single_df.insert(0,'frequency_uHz',f[chosen]*1e6)
single_df.to_csv(R/'data/single_constituent_power_at_observed_peaks.csv',index=False)
pred_ix,_=find_peaks(pred)
m2pow=d.predicted_M2_only_density_Hz_inv.to_numpy()/(600*len(b)*1e-36)
s2pow=d.predicted_S2_only_density_Hz_inv.to_numpy()/(600*len(b)*1e-36)
m2ix,_=find_peaks(m2pow);s2ix,_=find_peaks(s2pow)
rows=[]
for pos,ix in enumerate(chosen):
    dist=abs(fq-f[ix]);near=np.flatnonzero(dist<=rayleigh)
    order=np.argsort(single[pos])[::-1]
    q=pred_ix[abs(f[pred_ix]-f[ix])<=rayleigh]
    bestpred=int(q[np.argmax(pred[q])]) if len(q) else None
    row={'rank':pos+1,'observed_peak_uHz':float(f[ix]*1e6),'observed_power_1e36':float(original[ix]),
         'catalogue_within_rayleigh':';'.join(names[k] for k in near),
         'nearest_catalogue':names[np.argmin(dist)],'nearest_distance_rayleigh':float(dist.min()/rayleigh),
         'unit_prediction_power_at_peak_1e36':float(pred[ix]),
         'fixed_unit_subtraction_remaining_power_fraction':float(resid[ix]/original[ix]),
         'M2_S2_conditioned_remaining_power_fraction':float(cond[ix]/original[ix]) if np.isfinite(cond[ix]) else None,
         'nearest_theory_peak_uHz':float(f[bestpred]*1e6) if bestpred is not None else None,
         'M2_only_power_at_peak_1e36':float(m2pow[ix]),'S2_only_power_at_peak_1e36':float(s2pow[ix]),
         'largest_single_theory_response':fit_names[order[0]],'second_single_theory_response':fit_names[order[1]],
         'same_location_M2_window_max':bool(np.any(abs(f[m2ix]-f[ix])<=rayleigh)),
         'same_location_S2_window_max':bool(np.any(abs(f[s2ix]-f[ix])<=rayleigh))}
    rows.append(row)
pd.DataFrame(rows).to_csv(R/'data/peak_attribution.csv',index=False)

# Where does the unusually large mu2-neighbourhood peak occur in the record?
mu=next(x for x in rows if x['catalogue_within_rayleigh']=='mu2')
testf=np.array([mu['observed_peak_uHz']*1e-6]);periods=b.period.to_numpy();leave=[]
for p in np.unique(periods):
    keep=periods!=p;out=scan(t[keep],y[keep],testf,labels[keep])
    leave.append({'omit':p,'n':int(keep.sum()),'power_1e36':float(out['power'][0,0]),'amplitude_1e18':float(np.hypot(out['cos'][0,0],out['sin'][0,0]))})
pd.DataFrame(leave).to_csv(R/'data/mu2_neighbourhood_leave_period.csv',index=False)
for key,keep in [('early',~np.isin(periods,['P6','P7','P8'])),('summer',np.isin(periods,['P6','P7','P8']))]:
    out=scan(t[keep],y[keep],testf,labels[keep]);leave.append({'omit':key+'_only','n':int(keep.sum()),'power_1e36':float(out['power'][0,0]),'amplitude_1e18':float(np.hypot(out['cos'][0,0],out['sin'][0,0]))})
summary={'status':'EXPLORATORY_ASSOCIATION_NOT_PHYSICAL_IDENTIFICATION','n':len(b),'rayleigh_uHz':rayleigh*1e6,
 'observations_unchanged':True,'original_spectrum_unchanged':True,'filled_values':0,'source_reduction':'R7 observed bins; S54 equal-weight spectrum',
 'candidate_matching_rule':'All original top20 peaks plus local peaks within 1/T of eight principal constituents; catalogue association within 1/T only.',
 'unit_template_subtraction':'Fixed A=1 theory, no fit; diagnostic only, never replaces the main spectrum.',
 'conditional_scan':'S54 constants plus M2 and S2 sine/cosine nuisance columns. No detection probability inferred from reduction.',
 'theory_decomposition':'Original 17-constituent hourly decomposition of model series; no observations used to fit these coefficients.',
 'peaks':rows,'mu2_neighbourhood_temporal_checks':leave,
 'physical_identifications_confirmed':[],'environment':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'pyTMD':pyTMD.__version__}}
summary['saved_eight_theory_phasors_max_difference']=coefficient_error
for p in inputs+physical_inputs:assert hashlib.sha256(p.read_bytes()).hexdigest()==h[str(p)]
(R/'data/RESULTS.json').write_text(json.dumps(summary,indent=2))
(R/'verification/INPUTS.json').write_text(json.dumps({'sha256':h,'unchanged_after':True},indent=2))
print(pd.DataFrame(rows).head(15).to_string(index=False));print(amplitudes.to_string(index=False));print(json.dumps(leave,indent=2))
