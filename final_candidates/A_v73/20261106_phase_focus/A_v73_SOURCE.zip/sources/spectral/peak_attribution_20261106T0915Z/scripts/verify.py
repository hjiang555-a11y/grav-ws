from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd

R=Path(__file__).resolve().parents[1];A=R.parent/'annual_spectrum_20261106T0857Z'
d=pd.read_csv(R/'data/diagnostic_spectra.csv');o=pd.read_csv(A/'data/spectra.csv')
p=pd.read_csv(R/'data/potential_spectra.csv');b=pd.read_csv(A/'data/observed_input_rows.csv')
S=R.parent/'sources/R7_tree/paper/nature/opencode-period-offset-20261105/source-data'
tpl=b[['t_utc']].merge(pd.read_csv(S/'template.csv'),on='t_utc',how='left',validate='many_to_one',sort=False)
t=pd.to_datetime(b.t_utc,utc=True).astype('int64').to_numpy()/1e9;t-=t.min()
y=b.observed_y_1e18.to_numpy()-tpl.total.to_numpy()
labels=b.seg.to_numpy();Z=(labels[:,None]==np.unique(labels)[None,:]).astype(float)
z0=np.linalg.lstsq(Z,y,rcond=None)[0];rss0=np.sum((y-Z@z0)**2)
errors=[]
for target in [11.542,21.570,22.361,22.623,23.147]:
 i=int(np.argmin(abs(d.frequency_uHz-target)));f=d.frequency_uHz.iloc[i]*1e-6
 X=np.column_stack([Z,np.cos(2*np.pi*f*t),np.sin(2*np.pi*f*t)])
 beta=np.linalg.lstsq(X,y,rcond=None)[0]
 power=(rss0-np.sum((y-X@beta)**2))/len(y)
 errors.append(abs(power-d.after_fixed_unit_prediction_power_1e36.iloc[i]))
assert max(errors)<1e-9
serialization_error=float(np.max(abs(d.observed_power_1e36.to_numpy()-o.S54_equal_power_1e36.to_numpy())))
assert serialization_error<1e-14
assert np.allclose(p.observed_potential_PSD_m4_s4_per_Hz,o.S54_equal_density_Hz_inv*299792458.**4,rtol=1e-12)
assert np.allclose(p.residual_potential_ASD_m2_s2_per_sqrtHz**2,p.residual_potential_PSD_m4_s4_per_Hz,rtol=1e-12)
for path,h in json.loads((R/'verification/INPUTS.json').read_text())['sha256'].items():
 assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==h
checks={'status':'PASS','observed_spectrum_CSV_roundtrip_max_error':serialization_error,'all_input_hashes_unchanged':True,
 'residual_direct_QR_max_power_error':max(errors),'potential_PSD_c4_conversion':True,'ASD_squared_equals_PSD':True,
 'new_values_in_missing_intervals':0,'new_independent_constituent_detections':0,
 'residual_tidal_amplitude_refitted':False,'residual_tidal_phase_refitted':False}
for name,file in [('alignment',R/'figures/potential_spectrum_and_residual.alignment.json'),('collision',R/'verification/FIGURE_COLLISIONS.json')]:
 j=json.loads(file.read_text());assert j['verdict']=='PASS';checks[name]='PASS'
g=json.loads((R/'verification/FIGURE_GLYPHS.json').read_text());assert g['below_minimum_count']==0
checks['glyph_floor_pt']=g['minimum_found_pt']
checks['figure_source_QA']=json.loads((R/'verification/FIGURE_SOURCE_QA.json').read_text())['summary'];assert checks['figure_source_QA']['counts']['FAIL']==0
checks['source_warning_resolution']='PNG preview only, vector PDF/SVG supplied; no TIFF production claim.'
checks['visual_review']='Full figure and both panels inspected; observed and residual legend unambiguous; no clipped annotations.'
(R/'verification/FINAL_CHECK.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
