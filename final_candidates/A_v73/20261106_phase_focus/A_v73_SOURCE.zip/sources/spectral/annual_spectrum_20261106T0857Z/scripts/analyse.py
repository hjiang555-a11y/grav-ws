"""Exploratory full-calendar spectrum from measured accepted means, no infill."""
from pathlib import Path
import hashlib, json, sys, platform, datetime
import numpy as np
import pandas as pd
import scipy
from scipy.signal import find_peaks
import pyTMD
from spectral_core import scan, window

R=Path(__file__).resolve().parents[1]
BASE=R.parent
PEER=BASE.parent/'opencode'
TREE=BASE/'sources/R7_tree'
S=TREE/'paper/nature/opencode-period-offset-20261105/source-data'
sys.path.insert(0,str(TREE/'research/opencode-period-offset-20261105'))
from pipeline import template

paths=[S/'bins.csv',S/'constituents.csv',S/'evidence.json',
       PEER/'R7_HANDOFF.md',PEER/'data/raw_support/bin_ledger.csv',
       PEER/'data/raw_support/source_manifest.json',PEER/'data/raw_support/summary.json',
       TREE/'research/opencode-period-offset-20261105/pipeline/template.py']
digests={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
e=json.loads((S/'evidence.json').read_text())
assert digests[str(S/'bins.csv')]==e['table_sha256']['bins.csv']
b=pd.read_csv(S/'bins.csv');c=pd.read_csv(S/'constituents.csv').set_index('constituent')
ledger=pd.read_csv(PEER/'data/raw_support/bin_ledger.csv')
ledger=ledger[ledger.status=='accepted_R7'].sort_values('r7_row0')
assert np.array_equal(ledger.r7_row0,np.arange(len(b)))
assert np.array_equal(ledger.seg,b.seg) and np.array_equal(ledger.t_utc,b.t_utc)
assert np.array_equal(ledger.n,b.n) and len(b)==3299
# Rehash the actual raw observations behind the formal handoff.
raw=json.loads((PEER/'data/raw_support/source_manifest.json').read_text())['raw_files']
for rec in raw:
    p=Path(rec['path']);h=hashlib.sha256(p.read_bytes()).hexdigest()
    assert h==rec['sha256'],p
    digests[str(p)]=h
t=pd.to_datetime(b.t_utc,utc=True).astype('int64').to_numpy()/1e9
tm=ledger.mean_member_utc_s.to_numpy()
span=float(np.ptp(t));rayleigh=1/span;step=rayleigh/12
freq=np.arange(5e-6,40e-6+step/2,step)
names=['M2','S2','N2','K2','K1','O1','P1','Q1']
nom=np.asarray(pyTMD.constituents.frequency([n.lower() for n in names],corrections='FES'))/(2*np.pi)
freq=np.unique(np.r_[freq,nom]);fmap=dict(zip(names,nom.tolist()))
phase,nodal=template._arguments(t,names)
complex_coeff=np.array([complex(c.loc[n,'solid_real']+c.loc[n,'loading_real'],c.loc[n,'solid_imag']+c.loc[n,'loading_imag']) for n in names])
physical=nodal*np.real(complex_coeff[None,:]*np.exp(-1j*phase))
# Observations remain b.y, not projected_y, a fitted signal or synthetic data.
channels=np.column_stack([b.y.to_numpy(),physical[:,0],physical[:,1],physical.sum(axis=1)])
primary=scan(t,channels,freq,b.seg.to_numpy())
print('Computed primary S54 equal-weight scan',flush=True)
variants={
 'S54_equal':primary,
 'P8_equal':scan(t,b.y.to_numpy(),freq,b.period.to_numpy()),
 'P8_R7weight':scan(t,b.y.to_numpy(),freq,b.period.to_numpy(),1/b.sigma.to_numpy()**2),
 'S54_R7weight':scan(t,b.y.to_numpy(),freq,b.seg.to_numpy(),1/b.sigma.to_numpy()**2),
 'S54_equal_member_time':scan(tm,b.y.to_numpy(),freq,b.seg.to_numpy()),
}
out={'frequency_Hz':freq,'frequency_uHz':freq*1e6}
for name,a in variants.items():
    out[name+'_power_1e36']=a['power'][:,0]
    out[name+'_density_Hz_inv']=a['nominal600_density'][:,0]*1e-36
    out[name+'_amplitude_1e18']=np.hypot(a['cos'][:,0],a['sin'][:,0])
for k,name in enumerate(['predicted_M2_only','predicted_S2_only','predicted_eight_constituents'],1):
    out[name+'_density_Hz_inv']=primary['nominal600_density'][:,k]*1e-36
pd.DataFrame(out).to_csv(R/'data/spectra.csv',index=False)
# Sampling window; these are mask diagnostics, never measured spectra.
wf=np.arange(0,4e-6+step/2,step)
win=window(t,wf)
pd.DataFrame({'offset_Hz':wf,'offset_uHz':wf*1e6,'window_power':win}).to_csv(R/'data/sampling_window.csv',index=False)
rows=[]
for name,a in variants.items():
    power=a['power'][:,0];peaks,_=find_peaks(power)
    for target in ['M2','S2','N2','K2']:
        local=peaks[np.abs(freq[peaks]-fmap[target])<=rayleigh]
        ix=int(local[np.argmax(power[local])]) if len(local) else int(np.argmin(abs(freq-fmap[target])))
        exact=int(np.argmin(abs(freq-fmap[target])))
        rows.append({'variant':name,'target':target,'expected_uHz':fmap[target]*1e6,
          'has_local_max_within_rayleigh':bool(len(local)),'peak_uHz':freq[ix]*1e6,
          'peak_offset_rayleigh':(freq[ix]-fmap[target])/rayleigh,
          'peak_power_1e36':power[ix],'peak_nominal_density_Hz_inv':600*len(b)*power[ix]*1e-36,
          'at_target_power_1e36':power[exact],'scan_amplitude_at_target_1e18':float(np.hypot(a['cos'][exact,0],a['sin'][exact,0]))})
pd.DataFrame(rows).to_csv(R/'data/local_peaks.csv',index=False)
peakidx,_=find_peaks(primary['power'][:,0]);order=peakidx[np.argsort(primary['power'][peakidx,0])[::-1][:20]]
top=[{'uHz':float(freq[i]*1e6),'power_1e36':float(primary['power'][i,0]),'period_h':float(1/freq[i]/3600)} for i in order]
lo,hi=sorted([fmap['M2'],fmap['S2']]);mid=(freq>lo+rayleigh)&(freq<hi-rayleigh)
valleyi=np.flatnonzero(mid)[np.argmin(primary['power'][mid,0])]
ixm=np.argmin(abs(freq-fmap['M2']));ixs=np.argmin(abs(freq-fmap['S2']))
transfers={'M2_prediction_power_at_S2_relative_to_at_M2':float(primary['power'][ixs,1]/primary['power'][ixm,1]),
 'S2_prediction_power_at_M2_relative_to_at_S2':float(primary['power'][ixm,2]/primary['power'][ixs,2]),
 'plain_window_at_M2_S2_separation':float(window(t,np.array([hi-lo]))[0])}
summary={'scope':'Exploratory raw-supported R7 full-calendar spectrum; not v68, no filled observations',
 'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'n_bins':len(b),'unique_centres':int(b.t_utc.nunique()),'segments':int(b.seg.nunique()),'periods':int(b.period.nunique()),
 'sample_seconds':int(b.n.sum()),'nominal_sample_hours':float(b.n.sum()/3600),
 'sample_duration_caveat':'Nominal member-row seconds, not unique elapsed seconds; original duplicate labels retained.',
 'first_utc':b.t_utc.iloc[0],'last_utc':b.t_utc.iloc[-1],'calendar_span_days':span/86400,
 'rayleigh_uHz':rayleigh*1e6,'grid_step_uHz':step*1e6,'frequency_count':len(freq),'frequency_Hz':fmap,
 'M2_S2_separation_uHz':(hi-lo)*1e6,'separation_rayleigh':(hi-lo)/rayleigh,
 'primary':'S54_equal, unchanged observed y, no predicted signal subtracted',
 'spectrum_definition':'DeltaRSS/N; nominal one-sided LS density=600s*DeltaRSS*1e-36 Hz^-1; no Parseval/continuous-year variance claim for gapped data',
 'midband_valley_uHz':float(freq[valleyi]*1e6),'midband_valley_power_1e36':float(primary['power'][valleyi,0]),
 'top_peaks':top,'leakage_checks':transfers,'local_peaks':rows,
 'no_gap_fill':True,'no_time_compression':True,'no_tidal_fit_subtraction':True,'new_exclusions':0,
 'members_mean_time_max_difference_s':float(np.max(abs(tm-t))),
 'environment':{'python':platform.python_version(),'numpy':np.__version__,'pandas':pd.__version__,'scipy':scipy.__version__,'pyTMD':pyTMD.__version__},
 'independent_experiment':False,'p_values_calibrated':False}
pd.DataFrame({'original_row0':np.arange(len(b)),'t_utc':b.t_utc,'mean_member_utc_s':tm,'seg':b.seg,'period':b.period,'n':b.n,'observed_y_1e18':b.y,'R7_sigma_1e18':b.sigma}).to_csv(R/'data/observed_input_rows.csv',index=False)
(R/'data/RESULTS.json').write_text(json.dumps(summary,indent=2))
for p in paths:assert hashlib.sha256(p.read_bytes()).hexdigest()==digests[str(p)]
(R/'verification/INPUT_MANIFEST.json').write_text(json.dumps({'inputs_sha256':digests,'source_files_unchanged':True,'raw_files_rehashed':len(raw),'formal_R7_handoff_received':True},indent=2))
print(json.dumps({'span_days':span/86400,'separation_rayleigh':(hi-lo)/rayleigh,'top':top[:6],'primary_target_peaks':rows[:4],'leakage':transfers},indent=2))
