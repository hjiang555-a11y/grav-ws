"""Data-driven spectrum figures. All observed ordinates come from spectra.csv."""
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.path.insert(0,'/home/room115/.codex/skills/nature-figure/scripts')
from audit_panel_alignment import require_matplotlib_panel_alignment

R=Path(__file__).resolve().parents[1]
d=pd.read_csv(R/'data/spectra.csv');win=pd.read_csv(R/'data/sampling_window.csv')
s=json.loads((R/'data/RESULTS.json').read_text())
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans'],
 'font.size':8,'axes.labelsize':8,'xtick.labelsize':8,'ytick.labelsize':8,
 'legend.fontsize':7.5,'axes.spines.top':False,'axes.spines.right':False,
 'axes.linewidth':0.7,'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
 'savefig.dpi':400,'lines.linewidth':1.0,'legend.frameon':False})
blue='#126080';orange='#b75b19';gray='#777777'
f=d.frequency_uHz.to_numpy();density=d.S54_equal_density_Hz_inv.to_numpy()/1e-30
fm=s['frequency_Hz']['M2']*1e6;fs=s['frequency_Hz']['S2']*1e6

def finish(fig,name):
    fig.canvas.draw()
    require_matplotlib_panel_alignment(fig,json_out=R/f'figures/{name}.alignment.json',
       overlay_svg=R/f'figures/{name}.alignment.svg',tolerance_pt=1.5,strict=True)
    for ext in ['pdf','svg','png']:
        fig.savefig(R/f'figures/{name}.{ext}',dpi=400)
    plt.close(fig)

def label(ax,l):
    ax.text(-0.105,1.035,l,transform=ax.transAxes,fontweight='bold',fontsize=9,va='bottom')

fig,axes=plt.subplots(2,1,figsize=(178/25.4,126/25.4))
fig.subplots_adjust(left=.13,right=.975,top=.91,bottom=.11,hspace=.56)
fig.text(.13,.969,'353-day span · 3,299 observed bins · Missing intervals left empty',fontsize=8,va='top')
for ax,l in zip(axes,['a','b']):
    label(ax,l);ax.set_ylabel('Nominal LS density\n(10$^{-30}$ Hz$^{-1}$)')
    ax.set_ylim(0,29);ax.set_yticks([0,10,20]);ax.set_xlabel('Frequency (µHz)')
axes[0].axvspan(21,24.5,color='#e9eef1',zorder=0)
axes[0].plot(f,density,color=blue,lw=.75)
axes[0].set_xlim(5,40);axes[0].set_xticks(np.arange(5,41,5))
axes[0].text(.99,.91,'Full observed record',ha='right',transform=axes[0].transAxes,fontsize=8)
axes[1].plot(f,density,color=blue,lw=1.0)
axes[1].set_xlim(21,24.5);axes[1].set_xticks(np.arange(21,24.51,.5))
for target,ff,col,lab in [('M2',fm,blue,'M₂ · 12.42 h'),('S2',fs,orange,'S₂ · 12 h')]:
    axes[1].axvline(ff,color=col,lw=.8,ls='--',ymax=.83)
    axes[1].text(ff,26.2,lab,color=col,ha='center',va='center',fontsize=8)
    row=[p for p in s['local_peaks'] if p['variant']=='S54_equal' and p['target']==target][0]
    axes[1].plot(row['peak_uHz'],row['peak_nominal_density_Hz_inv']/1e-30,'o',ms=3,color=col)
finish(fig,'annual_spectrum_candidate')

fig,axes=plt.subplots(3,1,figsize=(178/25.4,163/25.4))
fig.subplots_adjust(left=.13,right=.975,top=.96,bottom=.09,hspace=.59)
for ax,l in zip(axes,['a','b','c']):label(ax,l)
axes[0].plot(win.offset_uHz,win.window_power,color=gray)
axes[0].axvline(fs-fm,color=orange,ls='--',lw=.8,ymax=.8)
axes[0].text(fs-fm,.91,'M₂–S₂ spacing',color=orange,ha='center',va='center')
axes[0].set(xlim=(0,1.2),ylim=(0,1.04),xlabel='Frequency offset (µHz)',ylabel='Sampling-window\npower')
for name,col,lab in [('predicted_M2_only',blue,'M₂ only: sampled prediction'),('predicted_S2_only',orange,'S₂ only: sampled prediction')]:
    p=d[name+'_density_Hz_inv'].to_numpy()
    axes[1].plot(f,p/p.max(),color=col,lw=.9,label=lab)
axes[1].set(xlim=(21,24.5),ylim=(0,1.3),xlabel='Frequency (µHz)',ylabel='Normalized response')
axes[1].legend(loc='upper left',ncol=2,borderaxespad=.2,handlelength=1.7)
for ff in [fm,fs]:axes[1].axvline(ff,color='#999999',lw=.55,ls=':',ymax=.75)
for name,col,style,lab in [('S54_equal',blue,'-','54 segment constants; equal weights'),
 ('P8_equal',orange,'-','8 period constants; equal weights'),
 ('S54_R7weight',blue,'--','54 segment constants; R7 weights'),
 ('P8_R7weight',orange,'--','8 period constants; R7 weights')]:
    axes[2].plot(f,d[name+'_power_1e36'],color=col,ls=style,lw=.8,label=lab)
axes[2].set(xlim=(21,24.5),ylim=(0,23),xlabel='Frequency (µHz)',ylabel='Scan power\n(10$^{-36}$)')
axes[2].legend(loc='upper left',ncol=2,borderaxespad=.2,handlelength=1.7,fontsize=6.8)
finish(fig,'sampling_and_robustness')
print('Rendered two figures from exported spectrum arrays; no data smoothing.')
