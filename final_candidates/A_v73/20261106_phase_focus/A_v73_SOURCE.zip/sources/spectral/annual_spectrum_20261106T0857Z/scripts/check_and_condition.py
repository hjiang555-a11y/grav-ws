from pathlib import Path
import json, sys
import numpy as np
import pandas as pd
from scipy.signal import periodogram, find_peaks
from spectral_core import scan, window

R=Path(__file__).resolve().parents[1]
b=pd.read_csv(R/'data/observed_input_rows.csv')
t=pd.to_datetime(b.t_utc,utc=True).astype('int64').to_numpy()/1e9
t-=t.min();y=b.observed_y_1e18.to_numpy();labels=b.seg.to_numpy()
results=json.loads((R/'data/RESULTS.json').read_text())
fmap=results['frequency_Hz'];f=pd.read_csv(R/'data/spectra.csv').frequency_Hz.to_numpy()
checks={}
# Exact uniform-grid one-sided density normalization, with no sampling gaps.
rng=np.random.default_rng(20261106);u=rng.normal(size=512)
fu,pu=periodogram(u,fs=1/600,detrend='constant',scaling='density')
got=scan(np.arange(512)*600,u,fu[1:-1],np.zeros(512))['nominal600_density'][:,0]
checks['uniform_FFT_max_relative_error']=float(np.max(abs(got-pu[1:-1]))/pu.max())
assert np.allclose(got,pu[1:-1],rtol=1e-9,atol=1e-8)
# Direct QR on actual unequal sampling, same constants, frequency and weights.
sel=np.array([6,9,15,20,22.364277963,23.148148148,25,31,39])*1e-6
w=1/b.R7_sigma_1e18.to_numpy()**2;w/=w.mean();sw=np.sqrt(w)
Z=(labels[:,None]==np.unique(labels)[None,:]).astype(float)
base=np.linalg.lstsq(Z*sw[:,None],y*sw,rcond=None)[0]
rss0=np.sum(((y-Z@base)*sw)**2)
qr=[]
for ff in sel:
    X=np.column_stack([Z,np.cos(2*np.pi*ff*t),np.sin(2*np.pi*ff*t)])
    bb=np.linalg.lstsq(X*sw[:,None],y*sw,rcond=None)[0]
    qr.append(rss0-np.sum(((y-X@bb)*sw)**2))
got=scan(t,y,sel,labels,w)['delta_rss'][:,0]
checks['actual_weighted_QR_max_absolute_deltaRSS_error']=float(np.max(abs(got-qr)))
assert np.allclose(got,qr,rtol=1e-8,atol=1e-7)
a=scan(t,y,sel,labels)['power'][:,0]
c=scan(t+9876543,y,sel,labels)['power'][:,0]
checks['time_origin_invariance_max_difference']=float(np.max(abs(a-c)));assert np.allclose(a,c,atol=1e-10)
checks['observed_rows_no_insertions']=len(b)==3299 and int(b.n.sum())==1965327
assert checks['observed_rows_no_insertions']
# Conditional scans are diagnostics only. The main observed spectrum is unchanged.
out=[]
for target,other in [('M2','S2'),('S2','M2')]:
    use=np.abs(f-fmap[target])<0.16e-6
    extra=np.column_stack([np.cos(2*np.pi*fmap[other]*t),np.sin(2*np.pi*fmap[other]*t)])
    result=scan(t,y,f[use],labels,extra_nuisance=extra)
    for ff,pp in zip(f[use],result['power'][:,0]):
        out.append({'target':target,'conditioning_frequency':other,'frequency_uHz':ff*1e6,'conditional_power_1e36':pp})
df=pd.DataFrame(out);df.to_csv(R/'data/conditional_scans.csv',index=False)
peaks=[]
for target in ['M2','S2']:
    sub=df[df.target==target].reset_index(drop=True)
    ix,_=find_peaks(sub.conditional_power_1e36)
    ix=ix[np.abs(sub.frequency_uHz.to_numpy()[ix]-fmap[target]*1e6)<=results['rayleigh_uHz']]
    assert len(ix)
    i=ix[np.argmax(sub.conditional_power_1e36.to_numpy()[ix])]
    peaks.append({'target':target,'peak_uHz':float(sub.frequency_uHz.iloc[i]),'power_1e36':float(sub.conditional_power_1e36.iloc[i])})
checks['status']='PASS'
checks['conditional_peaks']=peaks
checks['scope']='Numerical verification and leakage diagnostic; no detection probability calibration.'
(R/'verification/NUMERICAL_CHECKS.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
