"""Irregular-time sine scans with joint group constants; never fill a gap."""
import numpy as np


def projector(labels, weights):
    labels = np.asarray(labels)
    Z = (labels[:, None] == np.unique(labels)[None, :]).astype(float)
    A = Z * np.sqrt(weights)[:, None]
    return A / np.linalg.norm(A, axis=0)


def scan(t, y, frequencies, labels, weights=None, chunk=160, extra_nuisance=None):
    """Return weighted DeltaRSS, variance-equivalent power and scan coefficients.

    Weights are normalized to mean one. For equal weights, 600 * DeltaRSS
    is a nominal-600-s one-sided LS density (y squared per Hz). It is not an
    integral-calibrated continuous-record PSD for a gapped observation window.
    """
    t = np.asarray(t, float)
    t = t - t.min()
    Y = np.asarray(y, float)
    if Y.ndim == 1:
        Y = Y[:, None]
    n = len(t)
    assert Y.shape[0] == n and np.isfinite(Y).all()
    w = np.ones(n) if weights is None else np.asarray(weights, float)
    assert (w > 0).all()
    w = w / w.mean()
    sw = np.sqrt(w)
    Q = projector(labels, w)
    if extra_nuisance is not None:
        extra = np.asarray(extra_nuisance, float) * sw[:, None]
        Q = np.linalg.qr(np.column_stack([Q, extra]), mode='reduced')[0]
    Yw = Y * sw[:, None]
    Yw -= Q @ (Q.T @ Yw)
    delta = np.empty((len(frequencies), Y.shape[1]))
    beta_c = np.empty_like(delta)
    beta_s = np.empty_like(delta)
    cond = np.empty(len(frequencies))
    for lo in range(0, len(frequencies), chunk):
        sl = slice(lo, lo + chunk)
        a = 2 * np.pi * t[:, None] * frequencies[sl][None, :]
        C = np.cos(a) * sw[:, None]
        S = np.sin(a) * sw[:, None]
        C -= Q @ (Q.T @ C)
        S -= Q @ (Q.T @ S)
        cc = np.sum(C * C, axis=0)
        ss = np.sum(S * S, axis=0)
        cs = np.sum(C * S, axis=0)
        det = cc * ss - cs * cs
        assert (det > 1e-10).all()
        cy, sy = C.T @ Yw, S.T @ Yw
        bc = (ss[:, None] * cy - cs[:, None] * sy) / det[:, None]
        bs = (cc[:, None] * sy - cs[:, None] * cy) / det[:, None]
        beta_c[sl], beta_s[sl] = bc, bs
        delta[sl] = np.maximum(0, cy * bc + sy * bs)
        eigdiff = np.sqrt((cc-ss)**2 + 4*cs**2)
        cond[sl] = (cc+ss+eigdiff)/(cc+ss-eigdiff)
    return {'delta_rss': delta, 'power': delta/n,
            'nominal600_density': 600*delta,
            'cos': beta_c, 'sin': beta_s, 'condition': cond,
            'baseline_rss': np.sum(Yw**2, axis=0)}


def window(t, frequencies, weights=None, chunk=160):
    t = np.asarray(t, float); t = t - t.min()
    w = np.ones(len(t)) if weights is None else np.asarray(weights, float)
    out = np.empty(len(frequencies))
    for lo in range(0, len(frequencies), chunk):
        sl = slice(lo, lo+chunk)
        a = 2*np.pi*t[:, None]*frequencies[sl][None, :]
        re = w @ np.cos(a); im = w @ np.sin(a)
        out[sl] = (re**2+im**2)/w.sum()**2
    return out
