"""One saved-input estimator, independent QR replay, and matching-weight displays.

Inputs are frozen derived measurements, never fitted replacement observations.
The manuscript reproduces the selected R7 estimator, not an unavailable v68 chain.
"""
from pathlib import Path
import sys, json, hashlib
import numpy as np
import pandas as pd
from scipy.signal import find_peaks

O=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(O/'vendor'))
import template

def serial(v):
    if isinstance(v,np.ndarray): return v.tolist()
    if isinstance(v,np.generic): return v.item()
    raise TypeError(type(v).__name__)

def fit(X,y,sigma):
    A=X/sigma[:,None]
    assert np.linalg.matrix_rank(A/np.linalg.norm(A,axis=0))==A.shape[1]
    Q,R=np.linalg.qr(A,mode='reduced')
    H=np.linalg.solve(R,Q.T)/sigma[None,:]
    beta=H@y; residual=y-X@beta
    scale=np.sum((residual/sigma)**2)/(len(y)-X.shape[1])
    Ri=np.linalg.solve(R,np.eye(len(R)))
    return beta,scale*(Ri@Ri.T),residual,H,scale

def design(signal,labels):
    return np.column_stack([signal,labels[:,None]==np.unique(labels)[None,:]])

def estimate(signal,y,sigma,labels,days,periods):
    X=design(signal,labels);k=signal.shape[1]
    beta,cov,res,H,scale=fit(X,y,sigma)
    out=dict(A=beta[:k],scaled_ls=np.sqrt(np.diag(cov)[:k]),cov_scaled_ls=cov[:k,:k],n=len(y),rank=len(beta))
    for name,g in [('day',days),('period',periods)]:
        reps=[]
        for v in np.unique(g):
            ix=g!=v; xx=X[ix]; xx=xx[:,np.any(xx!=0,axis=0)]
            reps.append(fit(xx,y[ix],sigma[ix])[0][:k])
        reps=np.array(reps);dd=reps-reps.mean(axis=0)
        cv=(len(reps)-1)/len(reps)*(dd.T@dd)
        out[name+'_jackknife']=np.sqrt(np.diag(cv));out['cov_'+name+'_jackknife']=cv
    out['u']=np.maximum(out['scaled_ls'],out['day_jackknife'])
    out['corr']=cov[:k,:k]/np.sqrt(np.outer(np.diag(cov)[:k],np.diag(cov)[:k]))
    return out

def main():
    S=O/'sources';E=json.loads((S/'evidence.json').read_text())
    hashes={n:hashlib.sha256((S/n).read_bytes()).hexdigest() for n in ['bins.csv','template.csv','constituents.csv','evidence.json']}
    for n,h in E['table_sha256'].items(): assert hashes[n]==h
    b,t,c=[pd.read_csv(S/n) for n in ['bins.csv','template.csv','constituents.csv']]
    aligned=b[['t_utc']].merge(t,on='t_utc',how='left',validate='many_to_one',sort=False)
    two,three,fixed,secs=template.bands_at_bins(aligned,c)
    y=b.y.to_numpy()-fixed;sig=b.sigma.to_numpy();p=b.period.to_numpy()
    days=pd.to_datetime(b.t_utc,utc=True).dt.strftime('%Y-%m-%d').to_numpy()
    primary=estimate(three,y,sig,p,days,p)
    for key in ['A','u','scaled_ls','day_jackknife','period_jackknife','corr']:
        np.testing.assert_allclose(primary[key],E['primary']['three'][key],rtol=0,atol=1e-9)
    X=design(three,p);beta,cov,res,H,scale=fit(X,y,sig)
    # Phase displays and their covariance: full nuisance projection on both sides.
    N=design(three[:,1:],p);Q=np.linalg.qr(N/sig[:,None],mode='reduced')[0]
    def project(v):
        ss=sig if v.ndim==1 else sig[:,None]
        z=v/ss;return (z-Q@(Q.T@z))*ss
    phase,factor=template._arguments(secs,template.CONSTITUENTS)
    cs=c.set_index('constituent');C=np.array([complex(cs.loc[n,'solid_real']+cs.loc[n,'loading_real'],cs.loc[n,'solid_imag']+cs.loc[n,'loading_imag']) for n in template.CONSTITUENTS])
    crest=np.degrees((phase[:,0]-np.angle(C[0]))%(2*np.pi));g=(crest//30).astype(int)
    w=1/sig**2;sumw=np.bincount(g,weights=w,minlength=12)
    B=np.zeros((12,len(b)));B[g,np.arange(len(b))]=w/sumw[g]
    G=B*sig;G-=G@Q@Q.T;V=scale*(G@G.T)
    z=project(y);unit=project(three[:,0]);means=B@z;units=B@unit
    fold=pd.DataFrame(dict(phase_deg=np.arange(15,360,30),mean=means,unit=units,fitted=primary['A'][0]*units,se=np.sqrt(np.diag(V)),n_rows=np.bincount(g,minlength=12),n_seconds=np.bincount(g,weights=b.n,minlength=12)))
    fold.to_csv(O/'data/phase_fold.csv',index=False);pd.DataFrame(V).to_csv(O/'data/phase_covariance.csv',index=False)
    rows=b.copy();rows['phase_deg']=crest;rows['projected_y']=z;rows['projected_unit']=unit
    rows['relative_S2_M2_phase_deg']=np.degrees((phase[:,1]-phase[:,0])%(2*np.pi))
    for k,n in enumerate(['lunar','near12','diurnal']):rows[n]=three[:,k]
    rows['fixed_remainder']=fixed;rows['primary_residual']=res;rows.to_csv(O/'data/primary_rows.csv',index=False)
    old=pd.read_csv(O/'data/R7_phase_fold_recomputed.csv')
    np.testing.assert_allclose(fold['mean'],old['mean'],atol=1e-9,rtol=0)
    np.testing.assert_allclose(fold.se,old.se_propagated_working,atol=1e-9,rtol=0)
    inds=[0,2];quad=np.sum(factor[:,inds]*np.real(1j*C[inds]*np.exp(-1j*phase[:,inds])),axis=1)
    iq=estimate(np.column_stack([three[:,0],quad,three[:,1:]]),y,sig,p,days,p)
    s54=estimate(three,y,sig,b.seg.to_numpy(),days,p)
    g29=estimate(three,y,sig,b.group.to_numpy(),days,p)
    subsets={}
    for name,mask in [('early',~np.isin(p,['P6','P7','P8'])),('summer',np.isin(p,['P6','P7','P8']))]:
        subsets[name]=estimate(three[mask],y[mask],sig[mask],p[mask],days[mask],p[mask])
    leaves=[]
    for value in np.unique(p):
        keep=p!=value;a=estimate(three[keep],y[keep],sig[keep],p[keep],days[keep],p[keep])
        leaves.append(dict(omitted=value,A_L=a['A'][0],u_L=a['u'][0],A_S=a['A'][1],u_S=a['u'][1],n=int(keep.sum())))
    pd.DataFrame(leaves).to_csv(O/'data/leave_period.csv',index=False)
    # A bounded semidiurnal conversion-factor sensitivity, NOT a direct-potential replay.
    ratio=(1+.29801-.6078)/(1+.3010-.6078)
    c2=c.copy();sem=c2.constituent.isin(['M2','N2','S2','K2'])
    for col in ['solid_real','solid_imag']:c2.loc[sem,col]*=ratio
    _,snew,_,_=template.bands_at_bins(aligned,c2)
    conv=estimate(snew,y,sig,p,days,p) # fixed remainder deliberately held unchanged
    # Same-member monitor control, replayed on its saved matched observations.
    m=pd.read_csv(S/'monitor_monitor_rows.csv');m=m[m.included_in_fit].copy();ix=m.r7_row.to_numpy(int)
    sy=m.y.to_numpy()-fixed[ix];ss=m.sigma.to_numpy();pp=m.period.to_numpy();dd=days[ix]
    base=estimate(three[ix],sy,ss,pp,dd,pp)
    aug=estimate(np.column_stack([three[ix],m.monitor_e18.to_numpy()]),sy,ss,pp,dd,pp)
    oldm=json.loads((S/'monitor_fits.json').read_text())['monitor_pair'];delta=aug['A'][:3]-base['A']
    np.testing.assert_allclose(delta,oldm['delta_A'],atol=1e-9,rtol=0)
    reps=[]
    for day in np.unique(dd):
        kk=dd!=day
        b0=fit(design(three[ix][kk],pp[kk]),sy[kk],ss[kk])[0][:3]
        b1=fit(design(np.column_stack([three[ix],m.monitor_e18.to_numpy()])[kk],pp[kk]),sy[kk],ss[kk])[0][:3]
        reps.append(b1-b0)
    rr=np.array(reps);rr-=rr.mean(axis=0);dse=np.sqrt(np.diag((len(rr)-1)/len(rr)*rr.T@rr))
    np.testing.assert_allclose(dse,oldm['delta_day_jackknife'],atol=1e-9,rtol=0)
    monitor=dict(baseline=base,augmented=aug,delta=delta,paired_day_se=dse,support=oldm['support'])
    # Prediction-only norms, separately from observed coefficients.
    Z=(p[:,None]==np.unique(p)[None,:]).astype(float);Qp=np.linalg.qr(Z/sig[:,None],mode='reduced')[0]
    def rp(a):return a/sig-Qp@(Qp.T@(a/sig))
    rms={name:float(np.sqrt(np.sum(rp(aligned[name].to_numpy())**2)/w.sum())) for name in ['solid','loading','total']}
    ss=complex(c.iloc[0].solid_real,c.iloc[0].solid_imag);ll=complex(c.iloc[0].loading_real,c.iloc[0].loading_imag)
    phasors=dict(solid=abs(ss),loading=abs(ll),total=abs(ss+ll),angle_deg=np.degrees(np.angle(ll/ss)),rotated_loading=[(ll*np.exp(-1j*np.angle(ss))).real,(ll*np.exp(-1j*np.angle(ss))).imag])
    # Spectrum: identical rows, P8 constants and relative weights; no calendar filling.
    W=w/w.mean();sw=np.sqrt(W);Qw=np.linalg.qr(Z*sw[:,None],mode='reduced')[0]
    Y=np.column_stack([y,res,three@beta[:3]])*sw[:,None];Y-=Qw@(Qw.T@Y)
    from pyTMD.constituents import _constituent_parameters
    frequencies={n:_constituent_parameters(n.lower())[2]/(2*np.pi) for n in template.CONSTITUENTS}
    frequencies['24h']=1/86400
    span=float(secs.max()-secs.min());df=1/(12*span)
    fs=np.unique(np.r_[np.arange(9.5e-6,12.5e-6+df/2,df),np.arange(21e-6,24.5e-6+df/2,df),list(frequencies.values())])
    ps=[];cond=[];tt=secs-secs.min()
    for lo in range(0,len(fs),128):
        ff=fs[lo:lo+128];ang=2*np.pi*tt[:,None]*ff
        cc=np.cos(ang)*sw[:,None];sn=np.sin(ang)*sw[:,None]
        cc-=Qw@(Qw.T@cc);sn-=Qw@(Qw.T@sn)
        aa=(cc*cc).sum(axis=0);bb=(sn*sn).sum(axis=0);ab=(cc*sn).sum(axis=0)
        det=aa*bb-ab**2;assert np.all(det>0)
        yc=cc.T@Y;ys=sn.T@Y
        rss=(bb[:,None]*yc**2+aa[:,None]*ys**2-2*ab[:,None]*yc*ys)/det[:,None]
        ps.append(rss)
        for a0,b0,c0 in zip(aa,bb,ab):cond.append(np.linalg.cond([[a0,c0],[c0,b0]]))
    deltaRSS=np.vstack(ps);out=pd.DataFrame(dict(frequency_uHz=fs*1e6,condition=cond))
    for k,name in enumerate(['observed','residual','fitted_tide']):
        yy=600*deltaRSS[:,k]*1e-42
        out[name+'_fractional_PSD_per_uHz']=yy;out[name+'_potential_PSD_per_uHz']=299792458.0**4*yy
        out[name+'_potential_ASD_per_sqrt_uHz']=np.sqrt(299792458.0**4*yy)
    out.to_csv(O/'data/primary_spectra.csv',index=False)
    # Independent direct weighted least-squares verification in physical SI units.
    checks=[]
    for name,f in frequencies.items():
        hh=np.column_stack([np.cos(2*np.pi*f*tt),np.sin(2*np.pi*f*tt)])
        xx=np.column_stack([Z,hh]);u=np.sqrt(W)
        zsi=y*1e-18
        b0=np.linalg.lstsq(Z*u[:,None],zsi*u,rcond=None)[0]
        b1=np.linalg.lstsq(xx*u[:,None],zsi*u,rcond=None)[0]
        dr=float(np.sum(W*(zsi-Z@b0)**2)-np.sum(W*(zsi-xx@b1)**2))
        ii=np.flatnonzero(fs==f)[0];expected=600*1e-6*dr
        got=out.observed_fractional_PSD_per_uHz.iloc[ii]
        np.testing.assert_allclose(got,expected,rtol=1e-9,atol=1e-49)
        checks.append(dict(constituent=name,f_uHz=f*1e6,relative_difference=abs(got-expected)/got,observed_PSD=out.observed_potential_PSD_per_uHz.iloc[ii],residual_PSD=out.residual_potential_PSD_per_uHz.iloc[ii]))
    peaks=[]
    for name in ['M2','S2']:
        near=(abs(fs-frequencies[name])<.16e-6);ii=np.flatnonzero(near)[np.argmax(out.observed_potential_PSD_per_uHz[near])]
        peaks.append(dict(name=name,peak_uHz=fs[ii]*1e6,PSD=out.observed_potential_PSD_per_uHz.iloc[ii]))
    # Leakage of a sinusoid at one semidiurnal frequency into the other, same design.
    pairs=[]
    for name,other in [('M2','S2'),('S2','M2')]:
        def pair(f):
            h=np.column_stack([np.cos(2*np.pi*f*tt),np.sin(2*np.pi*f*tt)])*sw[:,None]
            return h-Qw@(Qw.T@h)
        a=pair(frequencies[name]);bb=pair(frequencies[other]);qa=np.linalg.qr(a,mode='reduced')[0];qb=np.linalg.qr(bb,mode='reduced')[0]
        pairs.append(dict(source=name,target=other,max_explained_power_fraction=float(np.linalg.svd(qb.T@qa,compute_uv=False)[0]**2)))
    result=dict(primary=primary,IQ=iq,subsets=subsets,S54=s54,G29=g29,monitor=monitor,
        phasors_M2=phasors,prediction_weighted_period_centred_rms=rms,loading_rms_fraction=rms['loading']/rms['total'],
        semidiurnal_conversion_check=dict(factor=ratio,result=conv,delta_A=conv['A']-primary['A'],scope='k22 change only, h2 and remainder fixed; NOT a full direct-potential reconstruction'),
        n_rows=len(b),n_segments=int(b.seg.nunique()),n_periods=len(np.unique(p)),n_days=len(np.unique(days)),sample_hours=float(b.n.sum()/3600),
        phase_covariance_rank=int(np.linalg.matrix_rank(V)),input_sha256=hashes,
        spectrum=dict(normalization='weights=(1/sigma^2)/mean(1/sigma^2); S_y_per_uHz=600s*delta_weighted_RSS_SI*1e-6',period_intercepts=8,gap_fill=False,grid_step_uHz=df*1e6,span_days=span/86400,peaks=peaks,unit_checks=checks,window_leakage=pairs,notes='Nominal weighted projection density; not a calibrated stationary PSD or independent detection test. Residual removes the fitted physical groups on these same observations.'))
    (O/'data/PRIMARY_RESULTS.json').write_text(json.dumps(result,default=serial,indent=2))
    pd.DataFrame(checks).to_csv(O/'data/nominal_spectrum.csv',index=False)
    np.savez_compressed(O/'data/primary_design.npz',three=three,fixed=fixed,seconds=secs,sigma=sig,y_minus_fixed=y,periods=p.astype(str),operator=H,beta=beta,residual=res)
    print(json.dumps({k:result[k] for k in ['primary','phasors_M2','loading_rms_fraction','semidiurnal_conversion_check']},default=serial,indent=2))

if __name__=='__main__':main()
