"""Build author text, references in first-citation order and measured-result tables."""
from pathlib import Path
import json,re,hashlib
import pandas as pd

O=Path(__file__).resolve().parents[1];B=O.parent
j=json.loads((O/'data/PRIMARY_RESULTS.json').read_text())
v68=(O/'sources/editorial_source_v68.md').read_text()
refsection=v68.split('## References\n',1)[1].split('\\clearpage',1)[0]
oldrefs={int(m.group(1)):m.group(2) for m in re.finditer(r'^(\d+)\. (.+)$',refsection,re.M)}
assert 'Ludlow' in oldrefs[1] and 'Stahl' in oldrefs[19]
keys=['ludlow','mehlstaubler','chou','mcgrew','bothwell','grotti','lisdat','riehle','voigt','denker','schroder','hou','jia','zhu','iers','fes','farrell','han','stahl']
refs={k:oldrefs[i+1] for i,k in enumerate(keys)}
refs['noaa']='NOAA. Harmonic constituents. *NOAA Tides and Currents*. [https://tidesandcurrents.noaa.gov/harcon.html?id=8577330](https://tidesandcurrents.noaa.gov/harcon.html?id=8577330) (accessed 6 November 2026).'
t=(O/'manuscript_template.md').read_text()
aff=v68.split('[Author list and order to be confirmed]')[1].split('\\clearpage')[0].strip()
t=t.replace('[Author list and affiliation assignments to be completed by the authors]','[Author list and affiliation assignments to be completed by the authors]\n\n'+aff)
errors=pd.DataFrame([dict(Group=n,Estimate=f'{j["primary"]["A"][i]:.4f}',Scaled_LS=f'{j["primary"]["scaled_ls"][i]:.4f}',Day_jackknife=f'{j["primary"]["day_jackknife"][i]:.4f}',Period_jackknife=f'{j["primary"]["period_jackknife"][i]:.4f}',Reported_SE=f'{j["primary"]["u"][i]:.4f}') for i,n in enumerate(['Lunar','Near-12 h','Diurnal'])])
offsets=pd.DataFrame([dict(Constants=n,Lunar=f'{a["A"][0]:.3f} ± {a["u"][0]:.3f}',Near_12h=f'{a["A"][1]:.3f} ± {a["u"][1]:.3f}',Diurnal=f'{a["A"][2]:.3f} ± {a["u"][2]:.3f}') for n,a in [('8 periods',j['primary']),('29 groups',j['G29']),('54 segments',j['S54'])]])
f=pd.read_csv(O/'data/nominal_spectrum.csv').set_index('constituent')
names=['M2','N2','S2','K2','K1','O1','P1','Q1']
meaning=['Principal lunar semidiurnal','Lunar elliptic semidiurnal','Principal solar semidiurnal','Lunisolar semidiurnal','Lunisolar diurnal','Principal lunar diurnal','Principal solar diurnal','Lunar elliptic diurnal']
table=pd.DataFrame([dict(Symbol=n,Period_h=f'{1e6/f.loc[n,"f_uHz"]/3600:.2f}',Meaning=d,Fit_group='Lunar' if n in ['M2','N2'] else ('Near-12 h' if n in ['S2','K2'] else 'Diurnal')) for n,d in zip(names,meaning)])
coverage=pd.read_csv(O/'data/R7_saved_simulation_recount.csv');coverage['Coverage_95_percent']=coverage.coverage_95_working.map(lambda x:f'{100*x:.2f}');coverage['Bias']=coverage.bias.map(lambda x:f'{x:+.4f}')
coverage=coverage[['scenario','n','Coverage_95_percent','Bias']]
for token,df in [('ERROR_TABLE',errors),('OFFSET_TABLE',offsets),('TIDE_TABLE',table),('COVERAGE_TABLE',coverage)]:
    t=t.replace('{{'+token+'}}',df.to_markdown(index=False));df.to_csv(O/'data'/(token.lower()+'.csv'),index=False)
order=[]
def cite(m):
    ks=m.group(1).split(',')
    for k in ks:
        assert k in refs,k
        if k not in order:order.append(k)
    return '^'+','.join(str(order.index(k)+1) for k in ks)+'^'
t=re.sub(r'\[@([a-z,]+)\]',cite,t)
t=t.replace('{{REFERENCES}}','\n'.join(f'{i+1}. {refs[k]}' for i,k in enumerate(order)))
out=O/'NATURE_ARTICLE_v72.md';out.write_text(t)
def wc(s):return len(re.findall(r"\b[\w]+(?:[’'−–-][\w]+)*\b",re.sub(r'\$.*?\$','FORMULA',s)))
abstract=t.split('## Abstract\n')[1].split('## Main text')[0]
main=t.split('## Main text\n')[1].split('## Methods')[0]
methods=t.split('## Methods\n')[1].split('## Author statements')[0]
captions=[(m.group(1),wc(m.group(2))) for m in re.finditer(r'\*\*((?:Fig\. \d|Extended Data Fig\. \d)[^*]+)\*\* (.+?)(?=\n\n|$)',t,re.S)]
assert wc(abstract)<=150
assert not re.search(r'\b(?:R7|v68|v71|v29)\b',main+abstract)
assert '0.97' not in abstract+main
counts=dict(abstract=wc(abstract),main=wc(main),methods_including_availability=wc(methods),legends=captions,references=len(order))
(O/'verification/TEXT_STRUCTURE.json').write_text(json.dumps(counts,indent=2))
(O/'sources/reference_map.json').write_text(json.dumps({k:dict(number=i+1,text=refs[k]) for i,k in enumerate(order)},indent=2))
claims=[dict(text='Lunar 0.99 ± 0.12',value=j['primary']['A'][0],se=j['primary']['u'][0],source='data/PRIMARY_RESULTS.json#/primary',estimator='P8/Allan/three-group'),dict(text='Near-12 h 1.13 ± 0.29',value=j['primary']['A'][1],se=j['primary']['u'][1],source='data/PRIMARY_RESULTS.json#/primary',estimator='same joint primary'),dict(text='545.9 hours across annual span',value=j['sample_hours'],source='sources/bins.csv:n.sum()/3600',estimator='all accepted measurement members'),dict(text='Loading roughly one third',value=j['loading_rms_fraction'],source='data/PRIMARY_RESULTS.json#/loading_rms_fraction',estimator='same-weight P8-centred prediction norms'),dict(text='Monitor summer overlap only',value=j['monitor']['support']['retained_member_hours'],source='data/PRIMARY_RESULTS.json#/monitor',estimator='identically paired summer subset; never full main sample')]
(O/'sources/ABSTRACT_CLAIMS.json').write_text(json.dumps(claims,indent=2))
print(json.dumps(counts,indent=2))
