# Nature readership and evidence review — A_v73

This is one editorial self-review, not an independent referee report or journal decision.

The opening now identifies a specific experimental problem: distinguish neighbouring semidiurnal responses with sparse sampling and unknown offsets between runs. The abstract states the duration and span, the two local spectral peaks and the two grouped amplitudes. It no longer ends on the lower-precision daily group. The shorter title retains the action “distinguish” without exceeding the formatting guide's indicative title length.

The reference-level decision precedes the estimates and remains based on missing transfer documentation. The record does not prove a jump at every boundary. The eight-period result is a same-data sensitivity check; neither its closeness to one nor its smaller uncertainty selects the primary model.

The spectral panel is moved to the top of Fig. 2. Its equal-weight scan is distinguished from the weighted physical-group estimator. The main text explains the observed sampling sidelobes, both injection ratios and conditional scans. No four-constituent detection, new independent significance, or intrinsic instrumental noise floor is inferred from the figure. Phase folding uses the same observations and propagated nuisance uncertainty.

Ocean loading's predicted norm contribution remains distinct from its unresolved separately reported coefficient. The fibre comparison retains its actual 246.6-h support. The new stability coefficient is explicitly a historical technical descriptor; it does not set the present weights or certify averaging through a 4.6-day gap-concatenated record. The author's clarification was to give apparatus specifications without making this a central issue.

The edits do not settle the remaining author decisions: physical-model approximation and clock reference locations, contributor and funding declarations, permanent data/code access and the related frequency-ratio manuscript's current status. These are retained in the author package rather than presented as completed approvals.

Nature's current [formatting guide](https://www.nature.com/nature/for-authors/formatting-guide), retrieved successfully on 2026-11-06, asks for accessible titles and summary paragraphs and normally places additional methods figures in Extended Data. This version keeps four main figures, two Extended Data figures, three tables, and the existing Methods. The supplied ChatGPT-library link returned a login page, so the changes use the detailed instructions pasted into the conversation; no access to the linked document is claimed.
