# A_v77b

Latest author-review manuscript, with the single contemporaneous European citation at the end of the main text. `NATURE_ARTICLE_A_v77b.md` and `render_A_v77b_01/NATURE_ARTICLE_A_v77b.pdf`. Science and figures unchanged from A_v77. No journal submission.
