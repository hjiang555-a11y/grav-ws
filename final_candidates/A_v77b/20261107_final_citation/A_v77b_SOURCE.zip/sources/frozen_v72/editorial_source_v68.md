# Lunar tidal potential measured on a coastal–inland optical-clock baseline

[Author list and order to be confirmed]

^1^ Hefei National Laboratory, University of Science and Technology of China, Hefei, China

^2^ Shanghai Research Center for Quantum Sciences and CAS Center for Excellence in Quantum Information and Quantum Physics, University of Science and Technology of China, Shanghai, China

^3^ Hefei National Research Center for Physical Sciences at the Microscale and School of Physical Sciences, University of Science and Technology of China, Hefei, China

^4^ Innovation Academy for Precision Measurement Science and Technology, Chinese Academy of Sciences, Wuhan, China

^5^ Jinan Institute of Quantum Technology and CAS Center for Excellence in Quantum Information and Quantum Physics, University of Science and Technology of China, Jinan, China

^6^ Time and Frequency Geodesy Center (TFGC), School of Geodesy and Geomatics, Wuhan University, Wuhan, China

\clearpage

## Abstract

Optical clocks measure gravitational potential through their relative rates. We compare strontium and ytterbium clocks in Shanghai and Wuhan, 692 km apart and connected by a 1,350-km fibre link, over five campaigns. Ocean loading contributes about one third of the predicted variation on this coastal–inland baseline. A summer campaign accumulating 274 h samples lunar phase across the solar day. With ephemeris-based tides and no empirical daily terms, the lunar amplitude relative to the solid Earth tide plus the full ocean-loading potential is $0.97\pm0.14$, with a residual-resampling standard deviation. A common-phase daily disturbance of amplitude $10^{-18}$ shifts this scale by at most 0.020. The whole-template scale is $0.90\pm0.12$. Independent reprocessing gives consistent scales; adding the fibre round-trip monitor changes the scales by less than 0.005 on matched observations.

## Main text

Optical clocks measure gravitational potential through the relative rates of atomic transitions.^1,2^ Static chronometric levelling has progressed from laboratory height comparisons to transportable clocks and fibre-linked stations.^3,4,5,6,7,8^ Measuring a changing potential requires an additional separation: the gravitational signal must be distinguished from changes in the clocks and the system that transfers their frequencies. Tides offer a physical prediction with specified astronomical frequencies and phases, coupled to the deformation of the Earth and the redistribution of ocean water.^9,10,11^ A comparison between a coastal station and an inland station makes the loading contribution substantial, connecting the measured frequency variation to both the solid Earth response and its oceanic environment.

The laboratory day complicates that separation. K1 and P1 lie within 0.3% of one cycle per solar day, while S2 has exactly two cycles per solar day. During a short campaign, these tidal components can resemble an environmental effect that repeats at a fixed local time. The lunar semidiurnal constituent M2 advances through that daily pattern: a corresponding maximum arrives about 50 min later each day. Measurements distributed over this phase drift provide a way to test a fixed lunar prediction while quantifying its coupling to daily disturbances. We use that separation in astronomical phase, without subtracting fitted empirical daily sinusoids before estimating the tide.

### A coastal–inland potential difference

We compare a strontium optical clock in Shanghai (31.130° N, 121.570° E) and a ytterbium optical clock in Wuhan (30.529° N, 114.357° E). The stations are 692 km apart and connected by a 1,350-km phase-stabilized fibre link through Hefei.^12^ Their evaluated systematic uncertainties are $9.2\times10^{-19}$ for Sr and $1.3\times10^{-18}$ for Yb.^13,14^ Shanghai lies near the East China Sea, whereas Wuhan lies inland (Fig. 1a). The measured observable is the fractional variation of the Yb/Sr frequency ratio; positive values indicate that the Wuhan clock runs faster relative to Shanghai. This fixes the sign used when combining the two stations' predicted potentials.

The prediction combines the IERS 2010 solid Earth tide with the full ocean-loading potential derived from FES2022.^15,16,17,18^ Ocean elevation enters a Green's-function convolution that includes direct attraction by redistributed seawater, the induced potential of the deformed Earth and the displacement of the clock. For differential M2, the solid and loading amplitudes are $3.41\times10^{-18}$ and $1.42\times10^{-18}$ in fractional frequency. Their phase difference is approximately 20°, giving a vector sum of $4.77\times10^{-18}$ (Fig. 1b). After segment means are removed, the solid, loading and combined predictions have root-mean-square values of 3.0, 1.35 and $4.1\times10^{-18}$ on the measurement sampling. Loading therefore contributes about one third of the predicted variation. These values describe the physical model and its sampling; the observations test the combined potential.

The differential prediction is constructed from the potential at each station before forming the clock-ratio signal. Ocean tides therefore enter through their spatial distribution and the response of the Earth, rather than through a single local sea-level value. The loading vectors need not have the same phase as the solid tide, so both the amplitude and phase of their sum matter to the comparison. This provides the physical basis for the coastal–inland design: the astronomical signal remains specified by the model, while the neighbouring ocean contributes appreciably to the potential variation that the clocks are asked to follow.

The record comprises five campaigns between September 2025 and August 2026, with 54 segments and approximately 544 h of retained data (Fig. 1c). The summer campaign supplies 274 h across June–August. Its observations sweep the full relative S2–M2 phase cycle, whereas each shorter campaign covers a narrower range (Fig. 1d). The accumulated hours quantify operation, while their distribution in relative phase governs the separation available to the fit. A measurement added at a new lunar–solar phase can change that separation even when it belongs to a different observing period. This makes the sampling pattern, alongside integration time, a central part of the measurement design.

Data and predictions are passed through the same 1,200-s triangular filter and evaluated every 600 s. The fit uses equal weights and assigns one constant to each segment. These constants absorb unknown static frequency levels; they do not connect the interrupted records into a calibrated absolute level. Within the resulting design, the lunar group (M2, N2), the near-12-h group (S2, K2) and the diurnal group have separate amplitudes. Astronomical phases and relative amplitudes within each group remain fixed, and the small remainder of the prediction enters once at its model value. All tidal amplitudes and segment constants are estimated jointly. The common amplitudes carry the comparison across campaigns through their within-segment variation.

### The lunar response

The lunar amplitude relative to the solid Earth tide plus the full ocean-loading potential is $0.97\pm0.14$. The uncertainty is the standard deviation obtained by circularly shifting residuals within continuous runs of the filtered record. The response lies 0.2 standard deviations from unity. Figure 2 displays the summer observations after removal of segment constants and the fitted non-lunar groups, as a fold on M2 phase and as a time series. The lunar prediction is evaluated on the same sampling. The folded presentation exposes the phase dependence of the response, while the time series retains its relation to the separate observing intervals. No empirical daily sinusoid is removed in either display.

The simultaneous near-12-h amplitude is $0.90\pm0.29$, with correlation $-0.32$ with the lunar amplitude (Fig. 3a,b). The diurnal group gives $0.35\pm0.51$. As checks on the same prediction and observations, a single whole-template scale is $0.90\pm0.12$, and a two-band analysis gives a semidiurnal scale of $0.96\pm0.12$. The primary inference is the lunar-group scale; the other parameterizations describe how the response is distributed among the specified astronomical components. The correlation in the joint lunar and near-12-h fit records their remaining competition on the actual sampling, rather than treating neighbouring semidiurnal signals as separately measured spectral lines.

Summer alone gives a lunar scale of $0.87\pm0.18$, while the other four campaigns together give $1.05\pm0.31$. The five separately estimated campaign amplitudes agree with $\chi^2=4.1$ for four degrees of freedom ($P=0.40$). Summer contributes 61% of the squared norm of the lunar template after the other fitted columns are projected out. This is a design quantity, not an information fraction valid under every noise model. Its larger contribution is consistent with the broad summer coverage of relative lunar–solar phase. The campaign-subset comparisons and deletion displays in Fig. 4a show the response on different parts of this same record.

The frequency-domain view provides a complementary display of the modulation (Fig. 3c). Sinusoidal power is concentrated in the diurnal and semidiurnal bands, and subtracting the fitted whole template reduces those peaks. The interrupted record does not resolve M2 from S2 in this spectrum. Its interpretation follows from the phase coverage in Fig. 1d and the simultaneous group fit, rather than from the apparent width or height of an individual peak. The spectrum, phase fold and campaign-deletion displays all reuse observations entering the amplitude fit; their role is to show the response and its dependence on sampling. The quoted lunar uncertainty comes from the residual-resampling analysis.

### Separation from the laboratory day

The lunar estimator's coupling to a prescribed daily disturbance can be calculated from its linear fit operator. For a 24-h or 12-h sinusoid of fractional-frequency amplitude $10^{-18}$, with one phase common to the record, the largest change in the lunar scale is 0.020. When each campaign has an independently chosen phase, the bounds become 0.032 at 24 h and 0.12 at 12 h (Fig. 4b). The corresponding coherent 12-h disturbance couples more strongly to the whole-template estimator, with a gain of 0.087. This contrast motivates choosing the lunar group as the principal observable: its astronomical phase moves relative to a disturbance tied to the solar day.

Additional daily-term fits explore the assumptions behind that separation. Campaign-specific 24-h terms at the phase of local air temperature give a lunar scale of $0.99\pm0.14$; regressors based on temperatures at both sites give $0.98\pm0.13$; and shared 24-h and 12-h terms give $1.00\pm0.13$. These alternatives describe coherent or environmentally constrained daily structure. A free-phase 12-h term in every campaign instead gives $0.82\pm0.17$. During a campaign lasting only a few days, such a term is nearly degenerate with the semidiurnal tides, and the remaining lunar separation comes predominantly from summer. This resetting case defines the daily-disturbance boundary of the measurement. The operator gains specify responses to assumed disturbance amplitudes, rather than measurements of environmental noise.

The distinction between a physical prediction and an empirical disturbance is maintained throughout the analysis. The lunar template is fixed by the astronomical and loading models; its amplitude is estimated jointly with the other physical groups. Daily terms are used to assess sensitivity or to characterize residual structure after the physical fit, with the primary amplitude retained. Because daily and tidal columns are correlated, a residual diagnostic must apply the same projection to its data and diagnostic basis. This ordering prevents a daily-cleaned series from silently becoming the input to the primary result and keeps the interpretation tied to a specified potential prediction.

### Controls and physical scope

Transient rejection is independent of the tidal residual: the six-robust-standard-deviation rule removes 0.4% of samples, its mask is unchanged when the prediction is added at factors of $-1$, 1 and 3, and retaining the excursions gives a lunar amplitude of $0.96\pm0.14$. In four specified null-resampling scenarios without a lunar signal, none of 20,000 simulated records reaches the measured amplitude. Adding the fibre round-trip record as a regressor over its matched 474-h overlap changes the lunar and whole-template amplitudes by less than 0.005. Independent reprocessing of the 2026 data gives a whole-template scale of $0.88\pm0.10$ and a lunar scale of $0.89\pm0.28$ when daily terms are included within ten-day blocks. The monitor constrains the recorded transfer channel; clock variations and unmonitored laboratory branches remain outside that control.

The coastal–inland geometry makes the response sensitive to including ocean loading in the prediction. Fitting the solid tide alone gives $1.19\pm0.20$, compared with 1.32 expected on the same sampling if the combined prediction is correct. A separate loading coefficient, $0.89\pm0.55$, is unresolved. The measured quantity is thus the lunar semidiurnal response to the specified combined potential, rather than a separate loading or Love-number measurement. The sizeable loading contribution supplies a physical motivation for this baseline while the component uncertainty defines the present experimental reach.

Hou et al. report the absolute Yb/Sr frequency ratio on the same fibre link, using overlapping summer observations.^12^ The present Article addresses the lunar component in the extended interrupted record; it does not update that absolute ratio or reuse the earlier tidal-correlation significance. Stahl et al. report independent, contemporaneous European clock-network observations on different baselines with a different mixture of diurnal and semidiurnal components.^19^ Those observations are complementary to the coastal–inland comparison. Here the geographic loading contribution and the lunar phase moving through the laboratory day together define the measurement's physical scope. Longer coastal records and calibrated transfer branches could turn this sensitivity into a separate test of ocean loading.

\clearpage

## References

1. Ludlow, A. D., Boyd, M. M., Ye, J., Peik, E. & Schmidt, P. O. Optical atomic clocks. *Rev. Mod. Phys.* **87**, 637–701 (2015). [https://doi.org/10.1103/revmodphys.87.637](https://doi.org/10.1103/revmodphys.87.637)
2. Mehlstäubler, T. E., Grosche, G., Lisdat, C., Schmidt, P. O. & Denker, H. Atomic clocks for geodesy. *Rep. Prog. Phys.* **81**, 064401 (2018). [https://doi.org/10.1088/1361-6633/aab409](https://doi.org/10.1088/1361-6633/aab409)
3. Chou, C. W., Hume, D. B., Rosenband, T. & Wineland, D. J. Optical Clocks and Relativity. *Science* **329**, 1630–1633 (2010). [https://doi.org/10.1126/science.1192720](https://doi.org/10.1126/science.1192720)
4. McGrew, W. F. et al. Atomic clock performance enabling geodesy below the centimetre level. *Nature* **564**, 87–90 (2018). [https://doi.org/10.1038/s41586-018-0738-2](https://doi.org/10.1038/s41586-018-0738-2)
5. Bothwell, T. et al. Resolving the gravitational redshift across a millimetre-scale atomic sample. *Nature* **602**, 420–424 (2022). [https://doi.org/10.1038/s41586-021-04349-7](https://doi.org/10.1038/s41586-021-04349-7)
6. Grotti, J. et al. Geodesy and metrology with a transportable optical clock. *Nat. Phys.* **14**, 437–441 (2018). [https://doi.org/10.1038/s41567-017-0042-3](https://doi.org/10.1038/s41567-017-0042-3)
7. Lisdat, C. et al. A clock network for geodesy and fundamental science. *Nat. Commun.* **7**, 12443 (2016). [https://doi.org/10.1038/ncomms12443](https://doi.org/10.1038/ncomms12443)
8. Riehle, F. Optical clock networks. *Nat. Photon.* **11**, 25–31 (2017). [https://doi.org/10.1038/nphoton.2016.235](https://doi.org/10.1038/nphoton.2016.235)
9. Voigt, C., Denker, H. & Timmen, L. Time-variable gravity potential components for optical clock comparisons and the definition of international time scales. *Metrologia* **53**, 1365–1383 (2016). [https://doi.org/10.1088/0026-1394/53/6/1365](https://doi.org/10.1088/0026-1394/53/6/1365)
10. Denker, H. et al. Geodetic methods to determine the relativistic redshift at the level of $10^{-18}$ in the context of international timescales: a review and practical results. *J. Geod.* **92**, 487–516 (2018). [https://doi.org/10.1007/s00190-017-1075-1](https://doi.org/10.1007/s00190-017-1075-1)
11. Schröder, S., Stellmer, S. & Kusche, J. Potential and scientific requirements of optical clock networks for validating satellite-derived time-variable gravity data. *Geophys. J. Int.* **226**, 764–779 (2021). [https://academic.oup.com/gji/article/226/2/764/6212226](https://academic.oup.com/gji/article/226/2/764/6212226)
12. Hou, L. et al. Yb/Sr optical clock comparison at $2.2\times10^{-18}$ uncertainty over a 1350-km fiber link. *arXiv*, 2610.34250v1 (2026). [https://arxiv.org/abs/2610.34250v1](https://arxiv.org/abs/2610.34250v1)
13. Jia, Z.-P. et al. Improved systematic evaluation of a strontium optical clock with uncertainty below $1\times10^{-18}$. *Metrologia* **63**, 025002 (2026). [https://doi.org/10.1088/1681-7575/ae449e](https://doi.org/10.1088/1681-7575/ae449e)
14. Zhu, Q. et al. Ytterbium lattice clock with systematic uncertainty of $1.3\times 10^{-18}$ and instability at the $10^{-19}$ level. *arXiv*, 2606.10514v2 (2026). [https://arxiv.org/abs/2606.10514v2](https://arxiv.org/abs/2606.10514v2)
15. Petit, G. & Luzum, B. (eds) IERS Conventions (2010). *IERS Technical Note* **36** (2010). [https://iers-conventions.obspm.fr/content/tn36.pdf](https://iers-conventions.obspm.fr/content/tn36.pdf)
16. CNES. FES2022 (Finite Element Solution) Tidal model (Version 2024). CNES [https://doi.org/10.24400/527896/A01-2024.004](https://doi.org/10.24400/527896/A01-2024.004) (2024).
17. Farrell, W. E. Deformation of the Earth by surface loads. *Rev. Geophys.* **10**, 761–797 (1972). [https://doi.org/10.1029/RG010i003p00761](https://doi.org/10.1029/RG010i003p00761)
18. Han, D. & Wahr, J. The viscoelastic relaxation of a realistically stratified earth, and a further analysis of postglacial rebound. *Geophys. J. Int.* **120**, 287–311 (1995). [https://doi.org/10.1111/j.1365-246x.1995.tb01819.x](https://doi.org/10.1111/j.1365-246x.1995.tb01819.x)
19. Stahl, K. et al. Optical clock network tracks tidal variations of the gravity potential. *arXiv*, 2610.39635v1 (2026). [https://arxiv.org/abs/2610.39635v1](https://arxiv.org/abs/2610.39635v1)

\clearpage

## Figure legends

![](figures/figure1.png){width=180mm}

**Fig. 1 | Coastal–inland prediction and lunar–solar phase coverage.** **a,** Shanghai Sr and Wuhan Yb clocks, their 692-km separation and the schematic 1,350-km fibre route through Hefei. Land colour shows predicted M2 clock potential, including solid tide and loading; sea colour shows FES2022 M2 ocean-tide amplitude. The Shanghai inset shows the loading contribution. **b,** Differential M2 phasors with the solid tide as phase reference: solid 3.41, loading 1.42, separation approximately 20°, and sum 4.77, in units of $10^{-18}$. **c,** Five campaigns and their reported integer-hour durations; the retained-sample total is approximately 544 h. **d,** Relative S2–M2 astronomical phase, including nodal corrections, at the filtered sample times. Only summer covers the full cycle. Panels a and b are predictions, and c and d describe sampling; these panels are not hypothesis tests.

\clearpage

![](figures/figure2.png){width=180mm}

**Fig. 2 | Lunar modulation in phase and time.** **a,** Summer observations in twelve 30° M2 phase bins after subtraction of jointly fitted segment constants and non-lunar tidal groups, with the M2+N2 prediction folded on the same sampling. Error bars are conditional delete-day jackknife errors with fitted non-lunar terms held fixed; they omit the uncertainty from re-estimating those terms. **[Full-record fold to be substituted after recomputation on the primary estimator.]** **b,** Three-hour display averages of the 16 summer segments after subtraction of the same components, with the lunar prediction. Gaps longer than 6 h are removed from the horizontal axis and marked by grey lines; some negative excursions extend below the displayed range. No empirical daily term is removed. Both panels visualize observations used in the amplitude fit, rather than an independent test; primary inference uses the residual-resampling standard deviation of 0.14.

\clearpage

![](figures/figure3.png){width=180mm}

**Fig. 3 | Astronomical-group responses and spectral modulation.** **a,** Whole-template and semidiurnal checks and the jointly estimated lunar, near-12-h and diurnal groups. Filled symbols and solid bars denote residual-resampling standard deviations; open squares and dashed bars denote the larger of scaled least-squares and delete-day jackknife errors. The filled diamond identifies the primary lunar result. **b,** Lunar–near-12-h covariance geometry, using correlation $-0.32$ scaled to the quoted marginal errors, at standardized radii of one and two; the cross is $(1,1)$. These curves are not separately calibrated joint confidence regions. **c,** Sinusoidal power of the full record after projection of segment constants, before and after subtraction of the fitted whole template. The dotted line is the 99% level of the maximum over 5–40 μHz from 200 residual resamples; short markers identify one and two cycles per solar day. Interrupted sampling does not resolve M2 from S2 in this display. Subtraction uses a template fitted to the same observations, so peak removal is not an independent significance test. Lunar–near-12-h separation comes from the phase coverage in Fig. 1d and simultaneous fitting, with the daily-disturbance response quantified in Fig. 4b.

\clearpage

![](figures/figure4.png){width=180mm}

**Fig. 4 | Sampling and daily-disturbance sensitivity.** **a,** The primary lunar result (filled diamond and shaded one-standard-deviation band), alternative operating-group or period offsets, daily and temperature terms, summer alone, deletion of each campaign, and selection variants. Bars show reported one-standard-deviation uncertainties: residual resampling for the primary result and the reported scaled least-squares/delete-day maximum for the daily-term fits. Subset and other variant errors retain their source definitions. The thin line below the primary result is the 95% operating-group-resampling interval. These fits share observations and are sensitivity displays, not independent confirmations. **b,** Largest change in lunar amplitude caused by a $10^{-18}$ sinusoid at 24 h or 12 h, for one phase common to the record or independently chosen phases in each campaign. The dashed line is 0.14. These gains are properties of the linear design and have no observation-error bars.

\clearpage

## Methods

### Frequency comparison and sampling

The apparatus and frequency-ratio measurement are described by Hou et al.; the clock evaluations provide the corresponding systematic uncertainty budgets.^12,13,14^ Related long field-fibre demonstrations give technical context.^20,21^ The Shanghai Sr reference is transferred on a 1,550-nm carrier and compared with the Wuhan Yb-referenced comb. Counters record the beat at nominal 1-s intervals. We analyse fractional variations in $R=f_{\mathrm{Yb,WUH}}/f_{\mathrm{Sr,SHA}}$. With positive Newtonian potential $W$, the prediction is

$$y(t)=-[\delta W_{\mathrm{Wuhan}}(t)-\delta W_{\mathrm{Shanghai}}(t)]/c^2.$$

A positive variation means Wuhan Yb runs faster relative to Shanghai Sr. In 2026, the magnitude of the conversion is $5.17\times10^{-15}$ per hertz of beat deviation. The 2025 counter records a divided-by-two beat; deviations receive the factor of two before conversion. September–October alone gives a scale of $1.28\pm0.31$. Segment constants accommodate static levels; no long-term stability is inferred from a fit-adjusted concatenation.

The 54 segments comprise 38 before June 2026 and 16 in summer. Samples more than 10 Hz from the segment median are excluded, the longest continuous run is retained, and ends differing from the median by more than 1% of the peak-to-peak range are trimmed. A second screen forms 300-s averages, subtracts a running median over $\pm30$ min and rejects deviations exceeding six robust standard deviations within a segment, together with neighbouring samples. This removes 0.4%, or 2.2 h, without using tidal residuals. Adding the prediction at factors of $-1$, 1 and 3 leaves the mask unchanged. Data and theoretical series receive the identical 1,200-s triangular filter at 600-s steps. Hours count retained nominal one-second samples, rather than independent filtered outputs. The five campaigns and eight periods used for period-level diagnostics are different groupings of the same observations.

### Solid Earth and loading potentials

The IERS 2010 prediction uses the direct tide-generating potential and the radial displacement,^15^

$$\delta W_{\mathrm{solid}}=\sum_m(1+k_{2m})V_{2m}+(1+k_3)V_3-gu_r.$$

Here $V_{2m}$ are lunar and solar degree-two components and $V_3$ is the lunar degree-three term. We use $k_{20}=0.29525$, $k_{22}=0.29801$ and $k_3=0.093$; $k_{21}$ follows the IERS resonance formula. The IERS displacement includes the frequency and latitude dependence of $h$.

FES2022 ocean elevation $\zeta$ enters the full loading-potential convolution,^16,17,18^

$$\delta W_{\mathrm{load}}(t)=\int_{\mathrm{ocean}}\rho_w\zeta(\mathbf r',t)G_W(\psi)\,\mathrm dA,\qquad G_W(\psi)=\frac{ga}{M_E}\sum_n(1+k'_n-h'_n)P_n(\cos\psi).$$

The three kernel terms represent water attraction, induced potential and clock displacement. We use $\rho_w=1{,}025\,\mathrm{kg\,m^{-3}}$ and PREM load Love numbers through degree 696 distributed with gravity-toolkit.^18,22^ The high-degree displacement response joins the Boussinesq limit $-6.22$, with Kummer summation to degree 40,000. The $1/30^\circ$ grid is retained within 3° of either station; distant $8\times8$ cell blocks are summed, changing differential M2 and K1 loading by at most 0.05%. Ocean means are removed for mass conservation. Eight constituents (Q1, O1, P1, K1, N2, M2, S2 and K2) use astronomical arguments and nodal corrections.

The comparison radial-load grid differs for S2 by 18% in amplitude and 54° in Wuhan phase between releases. Substituting that S2 loading changes the whole-template scale by 0.001 and leaves the lunar result unchanged at reported precision. Filling coastal masks of 0.3° and 0.6° near Shanghai lowers the lunar scale by 0.06 and 0.07. These are model sensitivities, not additional fitted corrections.

### Joint estimation and uncertainty

The primary equal-weight model is

$$y_i=c_{j(i)}+A_Ls_L(t_i)+A_Ss_S(t_i)+A_Ds_D(t_i)+r_0(t_i)+\epsilon_i,$$

where $j(i)$ is the segment. The three templates have fixed within-group phases and amplitude ratios. Their eight constituents explain 99.84% of the prediction variance; the remainder $r_0$, of RMS $0.18\times10^{-18}$, enters at unit amplitude. Omitting or doubling it gives lunar scales of 0.95–0.99. Least squares estimates the group amplitudes and segment constants together.

Residuals are shifted circularly within each continuous filtered run and added to the unit-response model. Two independent sets of 200 realizations give lunar standard deviations of 0.13 and 0.14; the scaled least-squares/delete-day maximum is 0.13. We report the largest, 0.14, with resampling bias $+0.01$. Four specified disturbance scenarios, each with 5,000 realizations, give 67–68% coverage for $\hat A_L\pm0.14$ and 94.5–95.2% for $\hat A_L\pm1.96(0.14)$. Coverage is conditional on those scenarios. Near-12-h, diurnal and daily-term errors use the larger of scaled least squares and delete-day jackknife.

The null simulations remove the lunar group and include four daily-disturbance cases: none, campaign-specific 24-h terms with temperature phases, common 24-h and 12-h terms, and the summer daily terms. None of 20,000 simulated estimates reaches the measured amplitude; this is not a zero probability. An eight-period restricted wild sign-flip test gives two-sided $P=0.008$, at its resolution limit $2/256$, under the specified null and period-level sign symmetry. It does not replace the residual-resampling uncertainty. The campaign norm share is computed after projecting the lunar template off every other fitted column.

### Daily sensitivity, controls and displays

If $h_L$ maps observations to lunar amplitude, the maximum response to a common-phase sinusoid of amplitude $B$ is

$$G(\omega)=B\left\|(h_L\cos\omega t,\,h_L\sin\omega t)\right\|_2.$$

Independent campaign phases give the sum of campaign-specific norms. The gains use $B=10^{-18}$ and the primary design. Temperature-phase tests use hourly ERA5 2-m temperatures; two-site regressors use anomalies relative to a 24-h running mean.^23^ Post-fit noise diagnostics retain the physical estimate and project both residual data and daily diagnostic bases through the same physical-fit residual operator. Uncertainty must propagate through both stages. The reported joint daily fits remain separate sensitivity checks.

The round-trip beat is normalized by the optical carrier without division by two, screened at 10 Hz and filtered like the ratio. Baseline and monitor-augmented regressions use the same 474-h support. The Sr chamber record averages 20 PT100 sensors over a 98-h overlap. Both clocks correct blackbody shifts in real time; the residual Sr correction-shaped coefficient is $0.92\pm0.74$, or $0.72\pm0.74$ with the chamber transient omitted.

Figure 2 retains the summer display: its delete-day error bars hold fitted non-lunar terms fixed. A full-record phase fold requires the primary data and unit lunar template to receive the same nuisance projection before twelve-bin averaging. Figure 3c retains the original 5–40 μHz full-record spectrum and its 200-resample maximum-power threshold. The 1,000-resample threshold described for the separate April spectrum concerns a different display. None of these views supplies another amplitude significance test.

### Separate reduction

A second reduction uses eight period constants, Allan-based weights and a displacement-based solid-tide implementation. It gives $0.99\pm0.12$ for the lunar group, and in-phase and quadrature coefficients of 0.99 and $-0.18$. Its early/summer projected-norm shares are 49.8/50.2%, compared with the primary summer share of 61%; the constant hierarchy and weights differ, and the shares are not combined. This is another reduction of overlapping observations, not an independent experiment or calibration of the primary uncertainty. Its phase-fold and deletion layouts inform presentation only. Historical loading-series fits are excluded from the primary estimate and error budget.

### AI-assisted preparation

OpenAI Codex assisted manuscript synthesis, citation checks, diagnostic-code preparation and figure assembly. [Author verification responsibilities and scope to be confirmed.]

### Data availability

The frequency records required to reproduce the primary analysis, segment definitions, matched tidal templates and figure source data will be deposited in [repository; DOI to be supplied]. Editorial and referee access: [review link to be supplied]. Third-party model products will be identified by their originating data citations and access terms.

### Code availability

The versioned primary reduction, residual-resampling implementation and figure-generation code will be deposited in [repository; DOI to be supplied], with the software environment and input manifest. Editorial and referee access: [review link to be supplied].

## Methods references

20. Chen, F.-X. et al. $10^{-21}$-Level optical frequency dissemination over 2067 km of noise-loaded field-deployed fiber network. *Light Sci. Appl.* **15**, 276 (2026). [https://doi.org/10.1038/s41377-026-02299-1](https://doi.org/10.1038/s41377-026-02299-1)
21. Schioppo, M. et al. Comparing ultrastable lasers at $7\times10^{-17}$ fractional frequency instability through a 2220 km optical fibre network. *Nat. Commun.* **13**, 212 (2022). [https://doi.org/10.1038/s41467-021-27884-3](https://doi.org/10.1038/s41467-021-27884-3)
22. Sutterley, T. C. et al. gravity-toolkit: Python tools for obtaining and working with data from the GRACE and GRACE Follow-On missions. Zenodo [https://doi.org/10.5281/zenodo.5156864](https://doi.org/10.5281/zenodo.5156864).
23. Hersbach, H. et al. The ERA5 global reanalysis. *Q. J. R. Meteorol. Soc.* **146**, 1999–2049 (2020). [https://doi.org/10.1002/qj.3803](https://doi.org/10.1002/qj.3803)

## Author statements

**Acknowledgements:** [To be supplied by the authors.]

**Funding:** [Applicable grants and funders to be confirmed.]

**Author contributions:** [To be confirmed for this Article.]

**Competing interests:** [Declaration to be supplied by all authors.]

**Correspondence:** [Names and email addresses of the corresponding authors.]


\clearpage

## Extended Data directory

1. **Campaign time series.** All five campaigns with matched predictions, retained-segment support and display conventions.
2. **Local-time and blackbody diagnostics.** Local-time folding, chamber-temperature support and the residual blackbody test.
3. **Campaign amplitudes.** Separate five-campaign estimates and their stated error definitions.
4. **Resampling calibration.** Estimator-specific bias, standard deviation and interval coverage, with scenarios, run grouping and seeds.
5. **Separate-reduction comparison.** Primary segment/equal-weight design versus the eight-period reduction; model, sampling, weights and projected-norm definitions identified separately.
