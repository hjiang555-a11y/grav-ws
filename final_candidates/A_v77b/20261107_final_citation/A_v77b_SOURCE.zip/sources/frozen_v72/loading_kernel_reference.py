#!/usr/bin/env python3
"""Rebuilt load Love number table + Green function per the
colleague's convention.

Source table: PREM load Love numbers n=0..696 (Han & Wahr 1995),
from GitHub tsutterley/gravity-toolkit data/love_numbers
(sha256 b460094121dc3e64b9ef3980deb91e8272a53d6931596ac5f8617d23f396d8cf).

Extension beyond n=696 (colleague's convention):
  - h' follows a power law to the Boussinesq limit -6.224
    (mu = 2.66e10, nu = 0.28), exponent from the 696 slope (p~1.77);
  - k' extends with n*k' constant;
  - sum to n = 40000, last 30% of orders get a cosine taper;
  - n=0 set to zero (global-mean removed before convolution,
    mass conservation);
  - n=1: CE frame h'_1 = -0.288, k'_1 = 0 (potential combination
    1+k'-h' is frame-independent; displacement comparisons vs FES
    load grids use CM frame h'_1 = -1.290).

Kummer: closed form sum_{n>=0} P_n = 1/(2 sin(psi/2)); with the
remainder starting at n=0 the closed form carries NO '-1'
(consistent with our fixed version).

Output: research/tidal-spring/love_prem.py (importable module) +
verification against the colleague's check values.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np

TABLE = Path("/home/room115/gravitation-whsh") / "research" / \
    "PREM_load_love_numbers_HanWahr_n0-696.txt"

NMAX = 40000
TAPER_START = int(0.7 * NMAX)  # last 30% tapered
H_BOUSS = -6.224
G = 9.81
A_EARTH = 6371000.0
M_EARTH = 5.9722e24


def load_table() -> tuple[dict[int, float], dict[int, float]]:
    h, k = {}, {}
    with open(TABLE) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith(("l", "*")):
                continue
            parts = line.split()
            n = int(parts[0])
            h[n] = float(parts[1].replace("D", "E"))
            k[n] = float(parts[2].replace("D", "E"))
    return h, k


def build_love_arrays() -> tuple[np.ndarray, np.ndarray]:
    """h', k' arrays for n = 0..NMAX with the colleague's extension."""
    h_tab, k_tab = load_table()
    h = np.zeros(NMAX + 1)
    k = np.zeros(NMAX + 1)
    for n in range(0, 697):
        h[n] = h_tab.get(n, 0.0)
        k[n] = k_tab.get(n, 0.0)
    # power-law extension for h' beyond 696
    # exponent from the local slope at 696
    p = 1.77  # colleague's value
    for n in range(697, NMAX + 1):
        h[n] = H_BOUSS + (h[696] - H_BOUSS) * (696.0 / n) ** p
    # k': n*k' constant extension
    nk_const = 696.0 * k[696]
    for n in range(697, NMAX + 1):
        k[n] = nk_const / n
    # n=0 zeroed (global mean removed)
    h[0] = 0.0
    k[0] = 0.0
    # n=1 CE frame
    h[1] = -0.288
    k[1] = 0.0
    # cosine taper on the last 30%
    taper = np.ones(NMAX + 1)
    for n in range(TAPER_START, NMAX + 1):
        frac = (n - TAPER_START) / (NMAX - TAPER_START)
        taper[n] = 0.5 * (1.0 + np.cos(np.pi * frac))
    h = h * taper
    k = k * taper
    return h, k


def green_full_psi(psi_deg: np.ndarray) -> np.ndarray:
    """Full-potential Green function (1+k'-h') with Kummer, per the
    colleague's convention."""
    h, k = build_love_arrays()
    a_n = 1.0 + k - h
    a_inf = 1.0 + 0.0 - H_BOUSS  # k'_inf = 0
    psi = np.deg2rad(psi_deg)
    cos_psi = np.cos(psi)
    P0 = np.ones_like(cos_psi)
    P1 = cos_psi.copy()
    series = np.zeros_like(cos_psi)
    for n in range(1, NMAX + 1):
        if n == 1:
            Pn = P1
        else:
            Pn = ((2 * n - 1) * cos_psi * P1 - (n - 1) * P0) / n
            P0, P1 = P1, Pn
        series += (a_n[n] - a_inf) * Pn
    series = series + a_inf / (2.0 * np.sin(psi / 2.0))
    return G * A_EARTH / M_EARTH * series


def main() -> int:
    h, k = build_love_arrays()
    print("check values (colleague):")
    print(f"  h[10] = {h[10]:.2f} (expect -1.42)")
    print(f"  h[100] = {h[100]:.2f} (expect -2.93)")
    print(f"  h[696] = {h[696]:.2f} (expect -5.20)")
    print(f"  k[10] = {k[10]:.4f} (expect -0.069)")
    print(f"  k[100] = {k[100]:.4f} (expect -0.014)")
    print(f"  k[696] = {k[696]:.4f} (expect -0.0031)")
    # Green function spot checks
    for psi in [0.05, 0.5, 5.0, 90.0]:
        g = green_full_psi(np.array([psi]))[0]
        print(f"  G_full({psi:5.2f} deg) = {g:.5e}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:  # noqa: BLE001
        print(f"ERROR: {error}")
        raise
