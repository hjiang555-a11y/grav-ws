# R7 → v68 editable handoff — 供合并 / FOR MERGE

**状态：已完成，供合并 / READY FOR CODEX MERGE。** 数值与稿件已独立核验；发现的Word/Markdown导出缺陷已修复并通过回归检查。最终归档身份见`DELIVERY_STATUS.json`与`DELIVERY_MANIFEST.json`。
**当前版本：Revision 2。题目为 Tidal potential measured with a coastal–inland clock comparison。**
按作者最新要求去掉题目中的Lunar，摘要并列两个半日组；新增D01/M13讨论稳定度、有效时长和全日灵敏度的预期限制。
**主笔：Codex。** 由Codex据此生成唯一英文主稿和PDF；本贡献不预先决定最终主估计器，不自动投稿或外部发布。

## 1. 可读取的绝对路径与固定版本

根目录：`/home/room115/gravitation-whsh/merge_v68_r7/opencode/`

| 材料 | 绝对路径（相对根目录展开） |
|---|---|
| 英文Word稿 | `/home/room115/gravitation-whsh/merge_v68_r7/opencode/drafts/R7_FOR_MERGE.docx` |
| 英文Markdown稿 | `/home/room115/gravitation-whsh/merge_v68_r7/opencode/drafts/R7_FOR_MERGE.md` |
| 合并预览PDF | `/home/room115/gravitation-whsh/merge_v68_r7/opencode/drafts/R7_FOR_MERGE.pdf` |
| 可编译LaTeX入口 | `/home/room115/gravitation-whsh/merge_v68_r7/opencode/working/paper/nature/opencode-period-offset-20261105/main.tex` |
| 主动修订文件 | 同目录`merge_abstract.tex`、`merge_results.tex`、`merge_captions.tex`、`merge_methods.tex`、`merge_extended.tex` |
| 推荐段落清单 | `/home/room115/gravitation-whsh/merge_v68_r7/opencode/ADOPTION_GUIDE.md` |
| 图2–4及来源索引 | `/home/room115/gravitation-whsh/merge_v68_r7/opencode/figures/`，其中`SOURCES.json`绑定数据路径和估计器 |

R7底稿固定提交：**`27de8630633648feea8fc874e1f629b741f19fe6`**。
原PDF SHA256：`c91dc625d4fb53704a7c4c315f5ef5bd1b8bd96745f5f87501748d2b0adaeca8`。
原源码ZIP SHA256：`4d5ea1ff13b86dbde0eeafa8cbe50751dba9bc990561c760180e520dca659eea`。
原件在`sources/R7.pdf`与`sources/R7_source.zip`保留。

v68采用本机发布稿：
`/data/AI_Research/projects/grav-ws/manuscript_48h/final_synthesis_v68_20261106T041750Z/`。
发布PDF SHA256：`1569191a9b7a664757ba9378c5f10e7c4304a0cf30de0015842038b8a6f9d607`；
英文MD SHA256：`92768ec209c23bba2794b9e885acf63c0f5430d4e7c26afc405a4beab9f6c320`。
与Codex的`../codex/INPUTS.json`一致。给定GitHubURL返回404，故不声称已核验远端当前v68。
所有复制源及哈希见`INPUTS.json`。Codex目录和原R7/原始数据均未编辑。

## 2. 可直接吸收的实质修订

本会话主代理亲自改写了英文摘要、Results、四幅主图图注、Methods及五张扩展表。
共有39个`ADOPT`段落/表图标识，详见`drafts/PARAGRAPH_INDEX.json`。
Word/Markdown保留可映射的引用key；正式LaTeX保留natbib引用及原参考文献。

- **P01–P05**：差分有效势、固体/负荷相位合成、沿海—内陆作用、12.42h/12h逐日相位漂移；K2日月共同作用；每组共同幅度与固定组内结构。
- **R01–R05/F02–F04**：R7的三组系数、LS相关、完整同投影相位图、同批IQ、八期删除/零点敏感性和条件信息分摊。
- **R06/M08/T01/T03**：本轮新增精确样本/估计器对账。
- **C01/M09/T04**：本轮从真实监测原文件得到的同成员支撑光纤回归。
- **R07/C02/M10**：来源明确的v68温度/监测/估计器结果，显式注明仅引用与缺项。
- **M04–M07/M11/T05**：时间合成、空间卷积、固体有效势和实际采样时间分层；历史1.26±0.18及+0.276保留，非系统SD。
- **D01/M13（Revision 2新增）**：相关时标稳定度与有效观测时间、相位覆盖、零点投影和谱窗的共同限制；白频噪声和相当相位覆盖下才采用平方根时长外推。全日较弱不被解释为没有全日引力潮汐。

## 3. 已复算与仅引用的项目

| 项目 | 本轮状态 | 主要结果/位置 |
|---|---|---|
| R7原始成员/观测/权重 | **已复算** |42文件；1966908掩膜成员/546.363333h；1965327入箱成员/545.924167h；3299行。`data/raw_support/` |
| R7保存估计器与图源 | **已回放** |9保存拟合、6诊断表、IQ/相位协方差；图2–4保留R7数值和估计器 |
| 同支撑时间/截距/权重桥接 | **已复算** |B0=0.986553±0.123086；B1成员时标=0.987214±0.123123；B2再逐段截距=1.001204±0.132003；B3再等权=0.947253±0.140793。`data/bridge/estimator_bridge.{csv,json}` |
| 真实光纤监测R7对照 | **已复算** |1482行、887882成员、246.633889h；AL从0.834837±0.182785到0.841245±0.182762；差+0.006408，配对dayJK=0.006086。`data/instrument_controls/` |
| v68的474h、差<0.005 | **仅引用v68** |不是本轮246.63h子集；缺精确原支撑及主链 |
| v68两站温度0.98±0.13、温度相位0.99±0.14 | **仅引用v68** |缺ERA5原数组、相位/24h异常处理；现有Meteostat不能替代；PT100也未定位 |
| v68负荷独立系数0.89±0.55及约1/3RMS比 | **仅引用v68** |与R7的M2联合相对固体幅度增幅39.6%分母不同 |
| v68主0.97±0.14、零假设/覆盖率 | **仅引用v68，完整原链阻断** |v68自己的checkpoint明确缺matchingv29inputs；不转移给R7 |
| R7既有条件模拟/旧序列比较 | **保存指标回放** |13情景130000draw指标、450旧序列指标通过；不是重新做全部原物理模型或实际噪声校准 |

各桥接步骤均给AL、AS、AD、scaledLS/dayJK/periodJK、LS相关与各自完整3×3协方差。
未建立R7/v68实际共同原始支撑；精确v68分箱/滤波、固体直接势和残差重采样三个步骤明确BLOCKED。
两稿共享观测，不作独立复现或加权平均。

## 4. 样本、校准与零点裁决

- 54有效段、29操作组、8时段完整映射在`data/raw_support/segment_ledger.csv`和`period_ledger.csv`。
- 五活动映射暂为C1=P1+P2，C2=P3，C3=P4，C4=P5，C5=P6–P8；这只是日期一致的候选，待v68逐行活动ID确认。
- 2025二分频×2已经原始数据复算；早期37.2mHz反馈与钟修正记录但未施加，夏季按组修正精确复现。
- 原注释把37.2mHz/429.228THz误写为约8.67e−14；量纲计算是约8.67e−17。由于该项早期未施加，不改变保存拟合；实际施加前仍须确认链符号/插入点。
- **没有从所检材料确认任何跨中断的校准零点连续证据。** `data/zero_point_boundaries.csv`逐一列出53个相邻段边界、P8/G29/S54各自是否共用截距以及所缺运行记录。
- 需实验负责人提供：锁定/重锁/干预日志、反馈与频率链状态、边界零点传递、早期增益及组修正协方差。
- 不依据较小±0.12选择P8。若跨中断连续性无法证实，应认真考虑segment/group自由度，并在对应物理输入和误差规则上完成主链。
- 本稿不重点报告全日上限。AD是有符号固定相位系数；目前没有相应单侧覆盖校准。半日外推全日须另立共同响应假设。

## 5. 图、数据与编辑接口

图2–4的精确来源见`figures/SOURCES.json`；脚本为`tools/render_figures_2_4.py`，调用随包冻结的R7绘图实现。
相位全部3299散点、12箱支持/协方差、IQ与删期完整数据在工作树的`source-data/r4/`。
新增四个可编辑表片段位于工作稿`tables/merge_bridge.tex`、`merge_sample.tex`、`merge_errors.tex`、`merge_monitor.tex`。
原始成员文件为`data/raw_support/membership.csv.gz`，含原文件/行号但不含beat观测值；索引哈希在`source_manifest.json`。

**若主笔选择v68估计器，不能只把图2–4的标注或曲线幅度替换成0.97。** 必须对v68实际数据和预测重新施加同一nuisance投影/相位分箱，重算协方差、IQ、信息和删期结果。

## 6. 共用观测、预印本与作者项

Hou等频率比稿共享夏季观测；本任务新增的是扩展断续记录中的分组潮汐响应、条件误差与真实控制对照，不更新其绝对频率比。精确共用观测/版本/作者状态待负责人确认。
Stahl等按研究内容及实际方法借鉴引用。Nature官方政策明确：预印本不是既往正式发表，评估在审研究进展时不计入预印本服务器稿件；不按arXiv日期决定编辑优先级。见`reports/PREPRINT_POLICY.md`及官方链接。
作者、单位、基金、贡献、利益冲突、数据开放条件和永久归档/DOI均待核实，未虚构。

## 7. 验证与交付封存

归算与首轮导出的27个局部测试通过；存在一条未改变源代码的上游pandas/NumPy弃用警告。Revision 2只修订题目、叙事和稳定度/时长讨论，相关4个可编辑导出回归检查通过，原数值和3299行谱输入均未改动。
独立数值核验确认全部10桥接拟合、成员/监测匹配和误差/协方差，没有数值阻断；稿件核验确认25页PDF与37个ID。其发现的两个导出问题（表格丢数和错误表号）已在本会话一次修订中通过RED→GREEN修复；六个可编辑表块逐格数值与规范源一致，引用按LaTeX的aux固定，图路径可用。
当前Revision 2 PDF：25页，SHA256 `b1d2dd05962037ea9116d89eff491a4ecc3a70ba544771bb8c06907e197f49f9`。
完整记录在`verification/INDEPENDENT_NUMERICAL.md`、`INDEPENDENT_MANUSCRIPT.md`、`REVIEW_RESPONSE.md`、`FINAL_CHECK.json`；前两份保留核验当时的版本哈希，修正后的版本由后两份记录。
四条保存数据回放通过；图2–4重新渲染PNG与原R7一致；LaTeX两遍编译零未定义引用、溢出或重复目标。
当前可移动归档为根目录`R7_FOR_CODEX_MERGE_v2.zip`；原`R7_FOR_CODEX_MERGE.zip`保留Revision 1，旧PDF SHA256为`667eb3893385b34139a5f98151363fcd0c65ae3df3b7fc0770d8c6c4014ee8e0`。两版分别保留校验文件，当前逐文件清单见交付记录。
Revision 2题目/段落/版面及旧版保全检查见`verification/TITLE_REVISION_2.json`；新增D01在当前PDF第4页，M13在第12页。新谱图的峰归属及显著性数值仍须绑定其实际分析产物，详见`reports/TITLE_STABILITY_REVISION_2.md`。
具体执行命令见README；原始输入不包含在可移动包中，其路径/哈希和访问依赖如实列出。
