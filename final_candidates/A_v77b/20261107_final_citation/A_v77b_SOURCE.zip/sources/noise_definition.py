"""Per-period white-noise levels from within-segment overlapping Allan deviations.

Values are in 1e-18 units; alpha is in 1e-18 sqrt(s). Raw rows retain the
counter's 1 s sampling convention, including jittered timestamp labels.
No averaging window crosses a segment boundary.
"""
import numpy as np

from . import bins

TAUS = (256, 512, 1024, 2048, 4096)


def oadev(x, m):
    x = np.asarray(x, dtype=float)
    if not isinstance(m, (int, np.integer)) or m < 1 or len(x) < 2 * m:
        raise ValueError("OADEV requires two positive-integer averaging windows")
    if x.ndim != 1 or not np.isfinite(x).all():
        raise ValueError("OADEV requires finite one-dimensional data")
    # Center before integration to limit cancellation from large period offsets.
    cs = np.r_[0., np.cumsum(x - x.mean())]
    averages = (cs[m:] - cs[:-m]) / m
    delta = averages[m:] - averages[:-m]
    return float(np.sqrt(np.mean(delta * delta) / 2))


def white_alpha(residual_segments, taus=TAUS):
    estimates = []
    for tau in taus:
        usable = [x for x in residual_segments if len(x) >= 2 * tau]
        if not usable:
            raise ValueError(f"No segment spans 2*tau at {tau} s")
        adev = np.average([oadev(x, tau) for x in usable], weights=[len(x) for x in usable])
        if adev <= 0 or not np.isfinite(adev):
            raise ValueError("Non-positive or non-finite white-noise estimate")
        estimates.append(np.log(adev) + .5 * np.log(tau))
    return float(np.exp(np.mean(estimates)))


def alpha_by_period(segments, periods, comp):
    grouped = bins._group_by_period(list(segments))
    dividers = periods.set_index("period").divider.to_dict()
    xp = comp.t_bjt.to_numpy().astype("datetime64[s]").astype("int64")
    total = comp.total.to_numpy(float)
    alphas = {}
    for period, segs in grouped.items():
        ref = bins.period_reference(segs)
        residuals = []
        for seg in segs:
            if len(seg.t) < 2 * max(TAUS):
                continue
            t = seg.t.astype("datetime64[s]").astype("int64")
            if t.min() < xp[0] or t.max() > xp[-1]:
                raise ValueError("template range for noise samples")
            tide = np.interp(t, xp, total)
            y = bins.to_relative(seg.beat, dividers[period], ref)
            residuals.append((y - y.mean()) - (tide - tide.mean()))
        if not residuals:
            raise ValueError(f"No eligible noise segment in {period}")
        alphas[period] = white_alpha(residuals)
    return alphas


def assign_sigma(bins_df, alpha):
    out = bins_df.copy()
    out["sigma"] = out.period.map(alpha) / np.sqrt(out.n)
    if not np.isfinite(out.sigma).all() or (out.sigma <= 0).any():
        raise ValueError("Bin sigma must be finite and positive")
    return out
