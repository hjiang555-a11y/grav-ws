"""One author-directed change: move the single European citation to the end."""
from pathlib import Path
O=Path(__file__).resolve().parents[1]
t=(O/'original/A_v77_manuscript_template.md').read_text()
sentence='Independent, contemporaneous European clock-network observations have tracked the overall tidal potential on different baselines.[@stahl]'
assert t.count(sentence)==1
t=t.replace(sentence+' ','')
anchor='Celestial phase therefore provides a practical reference for resolving adjacent tidal variations of the gravitational potential in interrupted optical-clock comparisons.'
assert t.count(anchor)==1
t=t.replace(anchor,anchor+' '+sentence)
(O/'manuscript_template.md').write_text(t)
