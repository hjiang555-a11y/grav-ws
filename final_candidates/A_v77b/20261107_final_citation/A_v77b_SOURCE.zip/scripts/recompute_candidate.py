"""Candidate A: paired P8/S54 replay, all observations frozen and read-only.

Numbers have units of 1e-18 unless explicitly specified. Model selection is
based on documented zero transfer, never closeness of a coefficient to unity.
"""
from pathlib import Path
import json, sys, hashlib, platform
import numpy as np
import pandas as pd
import scipy
from scipy.signal import find_peaks

O = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(O/'vendor'))
import template
from spectral_core import scan

def serial(v):
    if isinstance(v, np.ndarray): return v.tolist()
    if isinstance(v, np.generic): return v.item()
    raise TypeError(type(v).__name__)

def design(S, labels):
    return np.column_stack([S, labels[:, None] == np.unique(labels)[None, :]])

def fit(X, y, sigma):
    active=np.any(X!=0,axis=0)
    if not active.all():
        b,c,r,h,s=fit(X[:,active],y,sigma)
        bf=np.zeros(X.shape[1]);bf[active]=b
        cf=np.zeros((X.shape[1],X.shape[1]));cf[np.ix_(active,active)]=c
        hf=np.zeros((X.shape[1],len(y)));hf[active]=h
        return bf,cf,r,hf,s
    A = X/sigma[:, None]
    Q, R = np.linalg.qr(A, mode='reduced')
    H = np.linalg.solve(R, Q.T)/sigma[None, :]
    beta = H@y
    r = y-X@beta
    scale = np.sum((r/sigma)**2)/(len(y)-X.shape[1])
    Ri = np.linalg.solve(R, np.eye(len(R)))
    return beta, scale*(Ri@Ri.T), r, H, scale

def estimate(S, y, sigma, labels, days, periods):
    X = design(S, labels); k = S.shape[1]
    beta, cov, res, H, scale = fit(X, y, sigma)
    out = dict(A=beta[:k], scaled_ls=np.sqrt(np.diag(cov)[:k]),
               cov_scaled_ls=cov[:k, :k], n=len(y), rank=len(beta),
               weighted_rss=np.sum((res/sigma)**2), scale=scale,
               residual_rms=np.sqrt(np.mean(res**2)),
               condition=np.linalg.cond(X/sigma[:,None]/np.linalg.norm(X/sigma[:,None],axis=0)))
    for name, group in [('day', days), ('period', periods)]:
        reps=[]
        for g in np.unique(group):
            ix=group!=g
            reps.append(fit(design(S[ix],labels[ix]),y[ix],sigma[ix])[0][:k])
        reps=np.array(reps); z=reps-reps.mean(axis=0)
        V=(len(reps)-1)/len(reps)*z.T@z
        out[name+'_jackknife']=np.sqrt(np.diag(V));out['cov_'+name+'_jackknife']=V
    out['u']=np.maximum(out['scaled_ls'],out['day_jackknife'])
    out['corr']=cov[:k,:k]/np.sqrt(np.outer(np.diag(cov)[:k],np.diag(cov)[:k]))
    return out

def main():
    S=O/'sources/frozen_v72'; D=O/'data'; D.mkdir(exist_ok=True)
    b,t,c=[pd.read_csv(S/n) for n in ['bins.csv','template.csv','constituents.csv']]
    E=json.loads((S/'evidence.json').read_text())
    for name,h in E['table_sha256'].items():
        assert hashlib.sha256((S/name).read_bytes()).hexdigest()==h
    aligned=b[['t_utc']].merge(t,on='t_utc',how='left',validate='many_to_one',sort=False)
    two,three,fixed,secs=template.bands_at_bins(aligned,c)
    y=b.y.to_numpy()-fixed; sig=b.sigma.to_numpy(); p=b.period.to_numpy(); seg=b.seg.to_numpy()
    days=pd.to_datetime(b.t_utc,utc=True).dt.strftime('%Y-%m-%d').to_numpy()
    schemes={'P8':p,'S54':seg,'G29':b.group.to_numpy()}
    results={name:estimate(three,y,sig,labels,days,p) for name,labels in schemes.items()}
    for k in ['A','u','scaled_ls','day_jackknife','period_jackknife']:
        np.testing.assert_allclose(results['P8'][k],E['primary']['three'][k],atol=1e-9,rtol=0)
    bounds=pd.read_csv(S/'zero_point_boundaries.csv')
    assert bounds.documented_calibrated_continuity.str.startswith('NOT_ESTABLISHED').all()
    chosen='S54'; labels=schemes[chosen]; primary=results[chosen]
    beta,cov,res,H,scale=fit(design(three,labels),y,sig)
    leaves=[]; residual_rows=[]; residual_groups=[]
    for name,lab in schemes.items():
        _,_,rr,_,_=fit(design(three,lab),y,sig)
        z=rr/sig
        pairs=(seg[1:]==seg[:-1]) & (np.diff(secs)<=900)
        results[name]['within_segment_adjacent_corr']=np.corrcoef(z[:-1][pairs],z[1:][pairs])[0,1]
        for s in np.unique(seg):
            take=seg==s; w=1/sig[take]**2
            residual_groups.append(dict(design=name,seg=int(s),period=p[take][0],
              n=int(take.sum()),weighted_residual_mean=np.average(rr[take],weights=w),
              scaled_mean_se=np.sqrt(results[name]['scale']/w.sum())))
        for omitted in np.unique(p):
            keep=p!=omitted
            a=estimate(three[keep],y[keep],sig[keep],lab[keep],days[keep],p[keep])
            leaves.append(dict(design=name,omitted=omitted,A_L=a['A'][0],u_L=a['u'][0],
                          A_S=a['A'][1],u_S=a['u'][1],A_D=a['A'][2],u_D=a['u'][2],n=int(keep.sum())))
        residual_rows.append(rr)
    pd.DataFrame(leaves).to_csv(D/'leave_period_all_designs.csv',index=False)
    pd.DataFrame(residual_groups).to_csv(D/'segment_residual_means.csv',index=False)
    pd.DataFrame(dict(t_utc=b.t_utc,seg=seg,period=p,
        **{name:rr for name,rr in zip(schemes,residual_rows)})).to_csv(D/'residuals.csv',index=False)
    subsets={}
    for name,keep in [('early',~np.isin(p,['P6','P7','P8'])),('summer',np.isin(p,['P6','P7','P8']))]:
        subsets[name]=estimate(three[keep],y[keep],sig[keep],labels[keep],days[keep],p[keep])
    # Phase display: the same nuisance operator acts on data and unit prediction.
    Q=np.linalg.qr(design(three[:,1:],labels)/sig[:,None],mode='reduced')[0]
    def project(a):
        ss=sig if a.ndim==1 else sig[:,None]
        z=a/ss
        return (z-Q@(Q.T@z))*ss
    phase,nodal=template._arguments(secs,template.CONSTITUENTS)
    cs=c.set_index('constituent')
    C=np.array([complex(cs.loc[n,'solid_real']+cs.loc[n,'loading_real'],cs.loc[n,'solid_imag']+cs.loc[n,'loading_imag']) for n in template.CONSTITUENTS])
    crest=np.degrees((phase[:,0]-np.angle(C[0]))%(2*np.pi)); g=(crest//30).astype(int)
    w=1/sig**2; sums=np.bincount(g,weights=w,minlength=12)
    B=np.zeros((12,len(y)));B[g,np.arange(len(y))]=w/sums[g]
    G=B*sig;G-=G@Q@Q.T;V=scale*(G@G.T)
    z=project(y); unit=project(three[:,0])
    fold=pd.DataFrame(dict(phase_deg=np.arange(15,360,30),mean=B@z,unit=B@unit,
             fitted=primary['A'][0]*(B@unit),se=np.sqrt(np.diag(V)),n_rows=np.bincount(g,minlength=12),
             n_seconds=np.bincount(g,weights=b.n,minlength=12)))
    fold.to_csv(D/'phase_fold.csv',index=False);pd.DataFrame(V).to_csv(D/'phase_covariance.csv',index=False)
    rows=b.copy();rows['phase_deg']=crest;rows['projected_y']=z;rows['projected_unit']=unit
    rows['relative_S2_M2_phase_deg']=np.degrees((phase[:,1]-phase[:,0])%(2*np.pi))
    rows['fixed_remainder']=fixed;rows['primary_residual']=res
    for k,n in enumerate(['lunar','near12','diurnal']):rows[n]=three[:,k]
    rows.to_csv(D/'primary_rows.csv',index=False)
    quad=np.sum(nodal[:,[0,2]]*np.real(1j*C[[0,2]]*np.exp(-1j*phase[:,[0,2]])),axis=1)
    iq=estimate(np.column_stack([three[:,0],quad,three[:,1:]]),y,sig,labels,days,p)
    # Physically assigned 24h and deliberately unconstrained 12h diagnostics.
    daily={}
    for hours in [24,12]:
        trig=np.column_stack([np.cos(2*np.pi*secs/(hours*3600)),np.sin(2*np.pi*secs/(hours*3600))])
        for mode in ['common','per_period']:
            extra=trig if mode=='common' else np.column_stack([trig*(p==pp)[:,None] for pp in np.unique(p)])
            daily[f'{hours}h_{mode}']=estimate(np.column_stack([three,extra]),y,sig,labels,days,p)
    # Monitoring: same observed members on both sides; no full-year implication.
    m=pd.read_csv(S/'monitor_monitor_rows.csv');m=m[m.included_in_fit].copy();ix=m.r7_row.to_numpy(int)
    ym=m.y.to_numpy()-fixed[ix];ss=m.sigma.to_numpy();ls=labels[ix];pp=p[ix];dd=days[ix]
    aug=np.column_stack([three[ix],m.monitor_e18.to_numpy()])
    base=estimate(three[ix],ym,ss,ls,dd,pp);added=estimate(aug,ym,ss,ls,dd,pp)
    delta=added['A'][:3]-base['A'];reps=[]
    for d in np.unique(dd):
        kk=dd!=d
        aa=fit(design(three[ix][kk],ls[kk]),ym[kk],ss[kk])[0][:3]
        bb=fit(design(aug[kk],ls[kk]),ym[kk],ss[kk])[0][:3]
        reps.append(bb-aa)
    dr=np.array(reps);dr-=dr.mean(axis=0)
    monitor=dict(baseline=base,augmented=added,delta=delta,
        paired_day_se=np.sqrt(np.diag((len(dr)-1)/len(dr)*dr.T@dr)),
        support=json.loads((S/'monitor_fits.json').read_text())['monitor_pair']['support'])
    # Prediction-only phasors and RMS, never an independently measured load.
    Z=(labels[:,None]==np.unique(labels)[None,:]).astype(float)
    Qz=np.linalg.qr(Z/sig[:,None],mode='reduced')[0]
    rms={}
    for name in ['solid','loading','total']:
        a=aligned[name].to_numpy()/sig;a-=Qz@(Qz.T@a)
        rms[name]=np.sqrt(np.sum(a*a)/w.sum())
    solid=complex(c.iloc[0].solid_real,c.iloc[0].solid_imag)
    load=complex(c.iloc[0].loading_real,c.iloc[0].loading_imag)
    phasors=dict(solid=abs(solid),loading=abs(load),total=abs(solid+load),angle_deg=np.degrees(np.angle(load/solid)),
                 rotated_loading=[(load*np.exp(-1j*np.angle(solid))).real,(load*np.exp(-1j*np.angle(solid))).imag])
    ledger=b.groupby('period').agg(n_rows=('n','size'),n_members=('n','sum'),start=('t_utc','min'),end=('t_utc','max')).reset_index()
    ledger['accepted_hours']=ledger.n_members/3600;ledger.to_csv(D/'period_ledger.csv',index=False)
    month=b.assign(month=pd.to_datetime(b.t_utc).dt.strftime('%Y-%m')).groupby('month').n.sum().reset_index()
    month['hours']=month.n/3600;month.to_csv(D/'month_support.csv',index=False)
    # v71 spectral panel: exact original observed scan and fixed unit prediction.
    A=O/'sources/spectral/annual_spectrum_20261106T0857Z'
    spec=pd.read_csv(O/'sources/v71/data/annual_spectrum_dual_units.csv')
    old=json.loads((A/'data/RESULTS.json').read_text());f=spec.frequency_uHz.to_numpy()*1e-6
    spectral=scan(secs,np.column_stack([b.y, b.y-aligned.total]),f,seg)
    psd=spectral['nominal600_density']*1e-42
    np.testing.assert_allclose(psd[:,0],spec.observed_potential_PSD_m4_sminus4_per_uHz/299792458.0**4,atol=1e-46,rtol=2e-7)
    np.testing.assert_allclose(psd[:,1],spec.residual_potential_PSD_m4_sminus4_per_uHz/299792458.0**4,atol=1e-46,rtol=2e-7)
    # Preserve the exact v71 source bytes after numerical verification.
    (D/'semidiurnal_spectrum.csv').write_bytes((O/'sources/v71/data/annual_spectrum_dual_units.csv').read_bytes())
    peaks=[]; fm=old['frequency_Hz'];nom=np.array([fm[n] for n in ['M2','S2']])
    # The injections are astronomical M2/S2 signals with actual nodal factors.
    comp=nodal*np.real(C[None,:]*np.exp(-1j*phase))
    inj=scan(secs,comp[:,:2],nom,seg)['power']
    cross=dict(M2_at_S2=inj[1,0]/inj[0,0],S2_at_M2=inj[0,1]/inj[1,1])
    condrows=[]
    for target,other in [('M2','S2'),('S2','M2')]:
        pk,_=find_peaks(spectral['power'][:,0]);pk=pk[np.abs(f[pk]-fm[target])<=old['rayleigh_uHz']*1e-6]
        i=pk[np.argmax(spectral['power'][pk,0])]
        peaks.append(dict(target=target,peak_uHz=f[i]*1e6,potential_PSD=psd[i,0]*299792458.0**4))
        use=np.abs(f-fm[target])<.16e-6
        nuisance=np.column_stack([np.cos(2*np.pi*fm[other]*(secs-secs.min())),np.sin(2*np.pi*fm[other]*(secs-secs.min()))])
        con=scan(secs,b.y.to_numpy(),f[use],seg,extra_nuisance=nuisance)
        for ff,ppow in zip(f[use],con['nominal600_density'][:,0]):
            condrows.append(dict(target=target,conditioned_on=other,frequency_uHz=ff*1e6,potential_PSD=ppow*1e-42*299792458.0**4))
    pd.DataFrame(condrows).to_csv(D/'conditional_scans.csv',index=False)
    np.savez(D/'design.npz',three=three,fixed=fixed,seconds=secs,y=y,sigma=sig,period=p.astype(str),seg=seg,days=days.astype(str),beta=beta,quad=quad)
    out=dict(primary_design=chosen,primary=primary,designs=results,subsets=subsets,iq=iq,monitor=monitor,
        daily_sensitivity=daily,phasors_M2=phasors,rms=rms,loading_rms_fraction=rms['loading']/rms['total'],
        n_rows=len(b),sample_hours=b.n.sum()/3600,n_members=int(b.n.sum()),n_days=len(np.unique(days)),
        span_days=np.ptp(secs)/86400,n_unique_times=b.t_utc.nunique(),
        documented_zero_transfers=0,P8_within_period_boundaries=int(bounds.P8_shares_offset.sum()),
        spectrum=dict(peaks=peaks,cross_power=cross,frequency_Hz=fm,rayleigh_uHz=old['rayleigh_uHz'],
            grid_step_uHz=old['grid_step_uHz'],normalization='600 s * DeltaRSS, equal weight S54; per microhertz'),
        software=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__))
    (D/'RESULTS.json').write_text(json.dumps(out,indent=2,default=serial))
    print(json.dumps({k:out[k] for k in ['primary_design','primary','subsets','monitor','spectrum']},default=serial,indent=2))

if __name__=='__main__': main()
