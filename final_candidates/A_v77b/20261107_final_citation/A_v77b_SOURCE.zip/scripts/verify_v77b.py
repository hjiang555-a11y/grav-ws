"""Read-only editorial and Nature-preparation checks; no statistical refit."""
from pathlib import Path
import json,re,hashlib
import pandas as pd
import numpy as np
import fitz
from PIL import Image
O=Path(__file__).resolve().parents[1];B=O.with_name('A_v76')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
t=(O/'NATURE_ARTICLE_A_v77b.md').read_text();keyed=(O/'manuscript_template.md').read_text();old=(O/'original/A_v76.md').read_text()
j=json.loads((O/'data/RESULTS.json').read_text());checks=[]
def check(label,passed,detail):checks.append(dict(check=label,passed=bool(passed),detail=detail))
frozen=json.loads((O/'verification/FROZEN_V76_COMPARISON.json').read_text())
check('Frozen data/template/results unchanged',all(x['same'] and sha(O/x['file'])==x['sha256'] for x in frozen),f'{len(frozen)} files; observed members, times, weights, errors, spectral tables unchanged')
original=json.loads((O/'original/A_v76_FROZEN_FILES.json').read_text())
check('Original A_v76 untouched',all(sha(B/x['file'])==x['sha256'] for x in original),f'{len(original)} original input/component files')
check('Joint model equations preserved',re.findall(r'\$\$(.*?)\$\$',t,re.S)==re.findall(r'\$\$(.*?)\$\$',old,re.S),'54 intercepts, three coefficients, fixed remainder, same potential kernels')
abstract=keyed.split('## Abstract\n')[1].split('## Main text')[0]
main=keyed.split('## Main text\n')[1].split('## References')[0]
methods=keyed.split('## Methods\n')[1].split('## Data availability')[0]
check('Requested title and Nature length',t.splitlines()[0]=='# Resolving lunar and solar tidal responses with an optical clock baseline' and len(t.splitlines()[0][2:])<=75,'72 characters, no numerical/acronym title')
check('Both main semidiurnal values retained',all(v in abstract and v in main for v in ['1.00\\pm0.13','0.93\\pm0.36']),'Separate coefficients in one joint model, not independent experiments')
check('Daily result moved to auxiliary Methods','0.58\\pm0.54' not in abstract+main and '0.58\\pm0.54' in methods,'Original coefficient and uncertainty also remain in ED Table 2')
check('No daily-deficit narrative',not re.search(r'Improved daily|Improving the daily|daily response remains poorly|daily response does not provide',abstract+main,re.I),'No new auxiliary sine fits or parameter changes')
check('K2 mixed forcing retained','K₂ contains lunar and solar forcing' in main,'S2+K2 not claimed to be a pure solar constituent; fixed within-group structure retained')
check('Spectral and conditional evidence retained','22.361' in main and '23.147' in main and 'Conditional scans' in main and '8.03%' in main,'Same data and exact original scan; no independent significance multiplied')
check('Summary unheaded and bold','## Abstract' not in t and '**Optical clocks measure' in t,'Nature summary paragraph, 138 words')
order=['## References','## Figure legends','## Methods\n','## Data availability','## Code availability','## Methods references','## Acknowledgements','## Funding statement','## Author contributions','## Competing interests','## Additional information','## Extended Data']
positions=[t.index(x) for x in order];check('Nature manuscript section order',positions==sorted(positions),'Main refs, figures+legends, Methods, availability, Methods refs, end notes, ED')
check('AI disclosure in Methods','### AI-assisted preparation' in methods,'Substantive assistance retained; no invented author approval')
check('Methods has no figures or tables','![' not in methods and not re.search(r'^\|',methods,re.M),'Essential displays in main figures or Extended Data')
refs=json.loads((O/'editorial/REFERENCE_ORDER.json').read_text());check('Continuous references',list(x['number'] for x in refs.values())==list(range(1,24)),'21 main and 2 Methods references, first-appearance order')
counts=json.loads((O/'verification/TEXT_STRUCTURE.json').read_text());check('Article lengths and legends',counts['abstract']<=200 and counts['methods']<=3000 and all(n<250 for name,n in counts['legends'] if name.startswith('Fig.')),counts)
check('Four main and seven ED items',len(re.findall(r'!\[Figure [1-4]\]',t))==4 and len(re.findall(r'!\[Extended Data Figure',t))==3 and len(re.findall(r'\*\*Extended Data Table \d \|',t))==4,'4 main figures; 3 ED figures and 4 ED tables, under 10-item limit')
check('No unexpanded template tokens',not re.search(r'\{\{[A-Z_]+\}\}',t),'Author declarations/access remain explicit author tasks')
assets=json.loads((O/'submission_assets/ASSET_MANIFEST.json').read_text())['files']
check('Extended Data accepted file exports',all((O/f'submission_assets/Extended_Data_{kind}_{i}.tiff').exists() for kind,n in [('Figure',3),('Table',4)] for i in range(1,n+1)),'RGB TIFF/JPEG, 300 ppi, under 10 MB each; editable vector originals retained')
check('Export dimensions and resolution',all(x.get('mode')=='RGB' and len(x.get('dpi',[]))==2 and all(abs(d-300)<.1 for d in x['dpi']) and x['bytes']<10_000_000 for x in assets if x['file'].endswith(('.tiff','.jpg'))),'Every ED raster export checked')
workbook=O/'submission_assets/Source_Data_A_v77b.xlsx'
q=pd.read_excel(workbook,sheet_name='Fig3_joint_coefficients')
check('Source Data actual coefficients',np.allclose(q.coefficient,j['primary']['A'],rtol=0,atol=1e-14) and np.allclose(q.standard_error,j['primary']['u'],rtol=0,atol=1e-14),'All three joint coefficients preserved; daily marked auxiliary')
q=pd.read_excel(workbook,sheet_name='Fig1_sampling');check('All observed means exported',len(q)==3299 and q.n.sum()==1965327,'Derived Source Data; raw counters are not modified/exported')
build=json.loads((O/'render_A_v77b_01/BUILD_RESULTS.json').read_text());check('PDF and Word compile',all(x['exit']==0 and not x['warnings'] for x in build['builds']),'No compiler warnings; vector PDF and native editable Word')
pdf=O/'render_A_v77b_01/NATURE_ARTICLE_A_v77b.pdf';check('Single initial manuscript under 30 MB',pdf.stat().st_size<30_000_000,dict(bytes=pdf.stat().st_size,pages=len(fitz.open(pdf))))
check('Explicit required author items retained','[Author list' in t and '[Corresponding author' in t and 'editor-accessible' in t,'Technical preparation is complete; full external-submission readiness is NOT claimed')
payload=dict(status='PASS' if all(x['passed'] for x in checks) else 'FAIL',scope='Editorial invariance and Nature technical preparation; no new fits',checks=checks,ready_for_external_submission=False,pending='Author approval/list/declarations and editor-accessible data/code routes',manuscript_sha256=sha(O/'NATURE_ARTICLE_A_v77b.md'),pdf_sha256=sha(pdf),result_sha256=sha(O/'data/RESULTS.json'))
(O/'verification/INVARIANCE_AND_FORMAT_A_v77b.json').write_text(json.dumps(payload,indent=2,ensure_ascii=False))
print(json.dumps({'status':payload['status'],'checks':len(checks),'failed':[x['check'] for x in checks if not x['passed']]}));assert payload['status']=='PASS'
