"""Export saved source data and Nature display formats; no estimation."""
from pathlib import Path
import json,hashlib,re,shutil
import pandas as pd
from copy import copy
import numpy as np
import fitz
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.platypus import Table,TableStyle,Paragraph,Spacer
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from matplotlib import font_manager

O=Path(__file__).resolve().parents[1];A=O/'submission_assets';A.mkdir(exist_ok=True)
D=O/'data';F=O/'figures';j=json.loads((D/'RESULTS.json').read_text())
pdfmetrics.registerFont(TTFont('DejaVuSans',font_manager.findfont('DejaVu Sans')))
pdfmetrics.registerFont(TTFont('DejaVuSans-Bold',font_manager.findfont(font_manager.FontProperties(family='DejaVu Sans',weight='bold'))))
style=ParagraphStyle('cell',fontName='DejaVuSans',fontSize=7,leading=8.5)
bold=ParagraphStyle('bold',parent=style,fontName='DejaVuSans-Bold')
def plain(s):
    return str(s).replace('$','').replace('\\pm','±').replace('\\times','×').replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
def make_table(df,width=180*mm,widths=None):
    cw=[width/len(df.columns)]*len(df.columns) if widths is None else [x*width for x in widths]
    rows=[[Paragraph(plain(x),bold) for x in df.columns]]+[[Paragraph(plain(x),style) for x in row] for row in df.itertuples(index=False,name=None)]
    table=Table(rows,colWidths=cw)
    table.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),3),('RIGHTPADDING',(0,0),(-1,-1),3),('TOPPADDING',(0,0),(-1,-1),3),('BOTTOMPADDING',(0,0),(-1,-1),3),('LINEABOVE',(0,0),(-1,0),.4,colors.black),('LINEBELOW',(0,0),(-1,0),.4,colors.black),('LINEBELOW',(0,-1),(-1,-1),.4,colors.black)]))
    return table
def table_pdf(number,tables):
    heights=[x.wrap(180*mm,170*mm)[1] for x in tables];gap=7*mm
    height=sum(heights)+gap*(len(tables)-1)+4*mm
    assert height<170*mm,(number,height/mm)
    p=A/f'Extended_Data_Table_{number}.pdf';c=canvas.Canvas(str(p),pagesize=(180*mm,height))
    y=height-2*mm
    for tab,h in zip(tables,heights):tab.drawOn(c,0,y-h);y-=h+gap
    c.save();doc=fitz.open(p);pix=doc[0].get_pixmap(dpi=300,alpha=False)
    im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
    im.save(p.with_suffix('.tiff'),compression='tiff_lzw',dpi=(300,300))
    im.save(p.with_suffix('.jpg'),quality=95,dpi=(300,300))

guide=pd.read_csv(D/'tide_table.csv').rename(columns={'Period_h':'Period (h)'})
table_pdf(1,[make_table(guide,widths=[.1,.12,.55,.23])])
design=pd.read_csv(D/'design_table.csv').rename(columns={'Near_12h':'Near-12 h'})
errors=pd.read_csv(D/'error_table.csv').rename(columns={'Scaled_LS':'Scaled LS','Day_JK':'Day jackknife','Period_JK':'Period jackknife','Reported_SE':'Reported SE'})
table_pdf(2,[make_table(design,widths=[.23,.17,.17,.17,.26]),make_table(errors)])
coverage=pd.read_csv(D/'coverage_table.csv').rename(columns={'scenario':'Scenario','design':'Design','Near12h':'Near-12 h'})
table_pdf(3,[make_table(coverage,widths=[.42,.13,.15,.15,.15])])
text=(O/'NATURE_ARTICLE_A_v77b.md').read_text();section=text.split('**Extended Data Table 4 |')[1]
lines=[x.strip() for x in section.splitlines() if x.strip().startswith('|')]
rows=[[x.strip() for x in line.strip('|').split('|')] for line in lines if not re.match(r'^\|[\s:|\-]+\|$',line)]
archive=pd.DataFrame(rows[1:],columns=rows[0]);table_pdf(4,[make_table(archive,widths=[.20,.39,.41])])

for n in range(1,5):
    for ext in ['pdf','svg']:shutil.copy2(F/f'figure{n}.{ext}',A/f'Figure_{n}.{ext}')
for n,src in [(1,'ed_figure2'),(2,'ed_figure1'),(3,'ed_figure3')]:
    shutil.copy2(F/(src+'.pdf'),A/f'Extended_Data_Figure_{n}.pdf')
    doc=fitz.open(F/(src+'.pdf'));page=doc[0];assert page.rect.width<=180*mm+.1 and page.rect.height<=170*mm+.1
    pix=page.get_pixmap(dpi=300,alpha=False);im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
    im.save(A/f'Extended_Data_Figure_{n}.tiff',compression='tiff_lzw',dpi=(300,300));im.save(A/f'Extended_Data_Figure_{n}.jpg',quality=95,dpi=(300,300))

with pd.ExcelWriter(A/'Source_Data_A_v77b.xlsx',engine='openpyxl') as writer:
    mapping={'Fig1_sampling':'primary_rows.csv','Fig1_periods':'period_ledger.csv','Fig2_phase_means':'phase_fold.csv','Fig2_phase_covariance':'phase_covariance.csv','Fig3_spectrum':'semidiurnal_spectrum.csv','Fig4_delete_period':'leave_period_all_designs.csv','ED1_conditional_scans':'conditional_scans.csv','ED2_residual_levels':'segment_residual_means.csv','EDT1_constituents':'tide_table.csv','EDT2_designs':'design_table.csv','EDT2_errors':'error_table.csv','EDT3_coverage':'coverage_table.csv'}
    for sheet,name in mapping.items():pd.read_csv(D/name).to_excel(writer,sheet_name=sheet,index=False)
    pd.DataFrame({'group':['M2+N2','S2+K2','K1+O1+P1+Q1'],'role':['primary','primary','auxiliary'],'coefficient':j['primary']['A'],'standard_error':j['primary']['u']}).to_excel(writer,sheet_name='Fig3_joint_coefficients',index=False)
    ph=j['phasors_M2'];x,y=ph['rotated_loading']
    pd.DataFrame([{'component':'Solid','in_phase_1e18':ph['solid'],'quadrature_1e18':0},{'component':'Loading','in_phase_1e18':x,'quadrature_1e18':y},{'component':'Sum','in_phase_1e18':ph['solid']+x,'quadrature_1e18':y}]).to_excel(writer,sheet_name='Fig1_M2_phasors',index=False)
    pd.DataFrame({'coordinate':['In phase','Quadrature'],'coefficient':j['iq']['A'][:2]}).to_excel(writer,sheet_name='Fig3_phase_coordinates',index=False)
    pd.DataFrame(np.array(j['iq']['cov_scaled_ls'])[:2,:2],columns=['In phase','Quadrature']).to_excel(writer,sheet_name='Fig3_phase_covariance',index=False)
    pd.DataFrame([dict(subset=key,group=group,coefficient=val['A'][i],standard_error=val['u'][i],n=val['n']) for key,val in [('Full',j['primary']),('Before summer',j['subsets']['early']),('Summer',j['subsets']['summer'])] for i,group in enumerate(['Lunar','Near-12 h','Diurnal'])]).to_excel(writer,sheet_name='Fig4_temporal_subsets',index=False)
    pd.DataFrame([dict(design=key,group=group,coefficient=val['A'][i],standard_error=val['u'][i],n=val['n']) for key,val in j['designs'].items() for i,group in enumerate(['Lunar','Near-12 h','Diurnal'])]).to_excel(writer,sheet_name='Fig4_designs_full_precision',index=False)
    pd.DataFrame({'group':['Lunar','Near-12 h','Diurnal'],'paired_change':j['monitor']['delta'],'paired_day_jackknife':j['monitor']['paired_day_se']}).to_excel(writer,sheet_name='ED3_monitor',index=False)
    archive.to_excel(writer,sheet_name='EDT4_archive',index=False)
    pd.DataFrame([{'item':'All graphical observations','source':'data/primary_rows.csv','rows':3299,'role':'Repeated observations of one clock comparison; no gap filling'},{'item':'Fig3 scan','source':'data/semidiurnal_spectrum.csv','role':'Equal weights with 54 segment constants; primary amplitudes use Allan weights'},{'item':'Data availability','role':'This workbook contains derived figure source data; controlled raw counters and source memberships remain in the author archive'}]).to_excel(writer,sheet_name='Read_me',index=False)
    for ws in writer.book.worksheets:
        ws.freeze_panes='A2'
        for cell in ws[1]:font=copy(cell.font);font.bold=True;cell.font=font

legend=re.findall(r'(\*\*(?:Fig\. \d|Extended Data Fig\. \d|Extended Data Table \d)[^\n]+)',text)
(A/'FIGURE_AND_TABLE_LEGENDS.md').write_text('# Figure and Extended Data legends\n\n'+'\n\n'.join(legend)+'\n')
manifest=[]
for p in sorted(A.iterdir()):
    if not p.is_file() or p.name=='ASSET_MANIFEST.json':continue
    row=dict(file=p.name,bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    if p.suffix in ['.tiff','.jpg']:
        im=Image.open(p);row.update(mode=im.mode,pixels=list(im.size),dpi=[float(x) for x in im.info.get('dpi',[])]);assert im.mode=='RGB' and p.stat().st_size<10_000_000
    manifest.append(row)
(A/'ASSET_MANIFEST.json').write_text(json.dumps({'scope':'Saved-data exports for Nature; 4 main figures and 7 Extended Data items','files':manifest},indent=2))
print(json.dumps({'assets':len(manifest),'extended_data_items':7,'new_fits':0}))
