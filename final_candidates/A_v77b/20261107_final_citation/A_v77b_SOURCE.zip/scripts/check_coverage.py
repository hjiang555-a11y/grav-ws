"""Exploratory conditional simulation, not observed data or universal coverage.

Common fixed inputs and noise realizations compare P8 with S54. Each 95% interval
is beta +/- 1.96 max(scaled LS, UTC-day jackknife). No scenario is tuned to a
preferred amplitude. All group response coefficients have truth 1.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from recompute_candidate import design, fit

O=Path(__file__).resolve().parents[1]
d=np.load(O/'data/design.npz')
S=d['three'];sig=d['sigma'];p=d['period'];seg=d['seg'];days=d['days'];t=d['seconds']
N=len(sig);M=1000;seed=2026110617;rng=np.random.default_rng(seed)
scale=json.loads((O/'data/RESULTS.json').read_text())['primary']['scale']
operators={}
for name,labels in [('P8',p),('S54',seg)]:
    X=design(S,labels);_,cov,_,H,_=fit(X,d['y'],sig)
    Ri=np.linalg.inv((X/sig[:,None]).T@(X/sig[:,None]))
    J=[]
    for day in np.unique(days):
        ix=days!=day; xx=design(S[ix],labels[ix]); hh=fit(xx,d['y'][ix],sig[ix])[3][:3]
        h=np.zeros((3,N));h[:,ix]=hh;J.append(h)
    operators[name]=(X,H,Ri,np.array(J))

def ou(tau,labels):
    z=np.empty((N,M))
    for i in range(N):
        if i==0 or labels[i]!=labels[i-1]:z[i]=rng.standard_normal(M)
        else:
            a=np.exp(-max(0,t[i]-t[i-1])/tau)
            z[i]=a*z[i-1]+np.sqrt(1-a*a)*rng.standard_normal(M)
    return z

rows=[]
for scenario in ['white','half_OU6h_segment','half_OU24h_period','student_t5']:
    if scenario=='white':u=rng.standard_normal((N,M))
    elif scenario=='student_t5':u=rng.standard_t(5,(N,M))/np.sqrt(5/3)
    else:
        z=ou(6*3600,seg) if '6h' in scenario else ou(24*3600,p)
        u=(rng.standard_normal((N,M))+z)/np.sqrt(2)
    noise=u*sig[:,None]*np.sqrt(scale)
    for name,(X,H,Ri,J) in operators.items():
        be=H@noise;res=noise-X@be
        variance=np.sum((res/sig[:,None])**2,axis=0)/(N-X.shape[1])
        ls=np.sqrt(np.diag(Ri)[:3,None]*variance[None,:])
        jk=np.einsum('gkn,nm->gkm',J,noise,optimize=True)
        jk-=jk.mean(axis=0)
        jd=np.sqrt((len(J)-1)/len(J)*np.sum(jk*jk,axis=0))
        se=np.maximum(ls,jd)
        for k,group in enumerate(['Lunar','Near12h','Diurnal']):
            coverage=np.mean(np.abs(be[k])<=1.96*se[k])
            rows.append(dict(scenario=scenario,design=name,group=group,n=M,bias=be[k].mean(),
                empirical_sd=be[k].std(ddof=1),mean_scaled_LS=ls[k].mean(),mean_day_JK=jd[k].mean(),
                mean_reported_SE=se[k].mean(),coverage_95=coverage,MC_SE=np.sqrt(coverage*(1-coverage)/M)))
df=pd.DataFrame(rows);df.to_csv(O/'data/conditional_coverage.csv',index=False)
(O/'verification/COVERAGE_PROTOCOL.json').write_text(json.dumps(dict(seed=seed,simulations_per_scenario=M,
    scenarios=['independent Gaussian','50% variance independent Gaussian + 50% OU6h within segment',
    '50% variance independent Gaussian + 50% OU24h within period','independent standardized Student t, df=5'],
    noise_sigma='saved heteroscedastic sigma times sqrt(observed S54 residual scale)',
    confidence_multiplier=1.96,main_estimator_choice='not determined by observed coefficient or simulation outcome',
    scope='Conditional scenarios, not validation of the true noise law, physical model or zero-point continuity'),indent=2))
print(df.to_string(index=False))
