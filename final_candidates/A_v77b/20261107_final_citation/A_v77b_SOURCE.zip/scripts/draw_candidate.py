"""All main marks bind to one S54/Allan observation and template chain."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.patches import Ellipse
from cartopy.io import shapereader
from shapely.geometry import box
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from audit_panel_alignment import require_matplotlib_panel_alignment

O=Path(__file__).resolve().parents[1];F=O/'figures'
j=json.loads((O/'data/RESULTS.json').read_text())
r=pd.read_csv(O/'data/primary_rows.csv');f=pd.read_csv(O/'data/phase_fold.csv')
s=pd.read_csv(O/'data/semidiurnal_spectrum.csv');l=pd.read_csv(O/'data/leave_period_all_designs.csv');l=l[l.design=='S54']
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans'],'font.size':7,'axes.labelsize':7,'axes.titlesize':7,
 'xtick.labelsize':6.5,'ytick.labelsize':6.5,'legend.fontsize':6.5,'pdf.fonttype':42,'svg.fonttype':'none',
 'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.7,'legend.frameon':False})
blue='#126080';orange='#bc651f';grey='#666666';green='#50816c';provenance=[]
def letter(a,t):
    a.annotate(t,(0,1),xycoords='axes fraction',xytext=(-11,7),textcoords='offset points',fontsize=8,fontweight='bold',va='bottom')
def save(fig,name,axes,ids,**kw):
    fig.canvas.draw()
    if len(axes)>1:
        require_matplotlib_panel_alignment(fig,json_out=F/(name+'.alignment.json'),overlay_svg=F/(name+'.alignment.svg'),axes=axes,panel_ids=ids,strict=True,**kw)
    else:
        (F/(name+'.alignment.json')).write_text(json.dumps({'status':'NOT_APPLICABLE_SINGLE_PANEL','axes':ids}))
    # Standard editable sans-serif text; series colour is encoded in marks/keys.
    from matplotlib.text import Text
    for obj in fig.findobj(Text):
        obj.set_color('black')
        if obj.get_text() not in ids and obj.get_fontsize()>7:obj.set_fontsize(7)
    fig.savefig(F/(name+'.pdf'))
    fig.savefig(F/(name+'.svg'))
    fig.savefig(F/(name+'.png'),dpi=600 if name.startswith('figure') else 300)
    plt.close(fig)
    provenance.append(dict(figure=name,estimator='S54/Allan; saved current physical template',pdf_sha256=hashlib.sha256((F/(name+'.pdf')).read_bytes()).hexdigest()))

# Fig 1: geographic baseline, physical phasors, actual dates, relative phase.
fig=plt.figure(figsize=(180/25.4,137/25.4))
a=fig.add_axes([.09,.60,.37,.30]);b=fig.add_axes([.60,.60,.34,.30])
c=fig.add_axes([.09,.13,.37,.31]);d=fig.add_axes([.60,.13,.34,.31])
shp=O/'sources/frozen_v72/basemap/ne_110m_land.shp'
a.set_facecolor('#eaf2f5')
for geom in shapereader.Reader(shp).geometries():
    for poly in getattr(geom,'geoms',[geom]):
        if poly.bounds[2]<111 or poly.bounds[0]>125 or poly.bounds[3]<28 or poly.bounds[1]>34:continue
        clipped=poly.intersection(box(111,28,125,34))
        for pp in getattr(clipped,'geoms',[clipped]):
            if pp.is_empty or not hasattr(pp,'exterior'):continue
            xx,yy=pp.exterior.xy;a.fill(xx,yy,color='#eee8dc',ec='#969183',lw=.5)
sites={'Wuhan':(114.357,30.529),'Hefei':(117.28,31.86),'Shanghai':(121.570,31.130)}
xy=np.array([sites[x] for x in ['Wuhan','Hefei','Shanghai']]);a.plot(xy[:,0],xy[:,1],color=blue,lw=1.5)
for name,(x,y) in sites.items():
    a.plot(x,y,'o',ms=4 if name!='Hefei' else 2.5,color=blue)
    offset=(8,-3) if name=='Shanghai' else (0,8 if name!='Wuhan' else -14)
    a.annotate(name,(x,y),xytext=offset,textcoords='offset points',ha='left' if name=='Shanghai' else 'center',fontsize=7)
a.text(123.6,28.65,'East China\nSea',ha='center',color=blue,fontsize=6.5)
a.text(111.8,33.1,'1,350-km fibre link',fontsize=7)
a.set(xlim=(111,125),ylim=(28,34),xticks=[112,116,120,124],yticks=[28,30,32,34],xlabel='Longitude (° E)',ylabel='Latitude (° N)')
a.set_title('Coastal–inland clock comparison',loc='left',pad=12)
ph=j['phasors_M2'];u=ph['solid'];v=np.array(ph['rotated_loading']);summ=np.r_[u,0]+v
for start,end,color in [(np.zeros(2),[u,0],orange),([u,0],summ,green),(np.zeros(2),summ,blue)]:
    b.annotate('',end,xytext=start,arrowprops={'arrowstyle':'-|>','color':color,'lw':1.6})
b.text(u/2,-.35,f'Solid {u:.2f}',color=orange,ha='center');b.text(4.05,.95,f'Loading {ph["loading"]:.2f}',color=green,ha='center')
b.text(2.1,.56,f'Combined {ph["total"]:.2f}',color=blue,ha='center');b.text(3.55,-.37,f'{ph["angle_deg"]:.1f}°',fontsize=6.5)
b.set(xlim=(-.2,5.3),ylim=(-.8,1.3),xlabel='In phase (10⁻¹⁸)',ylabel='Quadrature (10⁻¹⁸)',yticks=[-.5,0,.5,1])
b.set_title('Predicted differential M₂',loc='left',pad=12)
dates=pd.to_datetime(r.t_utc,utc=True).dt.tz_convert(None)
per=list(sorted(r.period.unique()));ledger=pd.read_csv(O/'data/period_ledger.csv').set_index('period')
for k,p in enumerate(per):
    take=r.period==p;y0=7-k;color=blue if k<5 else orange
    c.plot(dates[take],np.full(take.sum(),y0),'|',color=color,ms=4,alpha=.5)
    d.scatter(r.loc[take,'relative_S2_M2_phase_deg'],np.full(take.sum(),y0),s=3,alpha=.18,color=color,linewidths=0,rasterized=True)
c.set_yticks(range(8),[f'{p} · {ledger.loc[p,"accepted_hours"]:.1f} h' for p in per[::-1]])
c.set_ylim(-.6,7.6);c.xaxis.set_major_locator(mdates.MonthLocator(interval=3));c.xaxis.set_major_formatter(mdates.DateFormatter('%b\n%Y'))
c.set_title('545.9 h across eight observing periods',loc='left',pad=12)
d.set(ylim=(-.6,7.6),yticks=range(8),yticklabels=per[::-1],xlim=(0,360),xticks=[0,90,180,270,360],xlabel='S₂ − M₂ astronomical phase (degrees)')
d.set_title('Observed lunar–solar phase coverage',loc='left',pad=12)
for ax,n in zip([a,b,c,d],'abcd'):letter(ax,n)
save(fig,'figure1',[a,b,c,d],list('abcd'),row_groups=[['a','b'],['c','d']],column_groups=[['a','c'],['b','d']])

# Fig 2: complete, covariance-propagated full-record fold and all single rows.
fig=plt.figure(figsize=(180/25.4,136/25.4));gs=fig.add_gridspec(3,1,height_ratios=[1.65,.85,.5],left=.15,right=.97,bottom=.10,top=.91,hspace=.52)
a,b,c=[fig.add_subplot(gs[i]) for i in range(3)]
a.errorbar(f.phase_deg,f['mean'],yerr=f.se,fmt='o',ms=3.5,capsize=2,color=blue,label='Observed phase means')
a.plot(f.phase_deg,f.unit,color=grey,lw=1.1,label='Unit prediction');a.plot(f.phase_deg,f.fitted,color=orange,lw=.9,ls='--',label='Fitted response')
a.set(ylabel='Phase mean (10⁻¹⁸)',ylim=(-8,8),yticks=[-8,-4,0,4,8]);a.legend(loc='lower left',bbox_to_anchor=(.02,1.03),ncol=3)
b.scatter(r.phase_deg,r.projected_y,s=2,alpha=.17,color=grey,rasterized=True,linewidths=0)
b.axhline(0,color='.6',lw=.5,zorder=0)
lo,hi=r.projected_y.min(),r.projected_y.max();b.set_ylim(lo-.04*(hi-lo),hi+.04*(hi-lo));b.set_ylabel('All observations (10⁻¹⁸)')
c.bar(f.phase_deg,f.n_rows,width=22,color='#aabdc5')
for x,n in zip(f.phase_deg,f.n_rows):c.annotate(str(n),(x,n),xytext=(0,3),textcoords='offset points',ha='center',fontsize=6)
c.set(ylim=(0,390),ylabel='Row count',xlabel='Model M₂ crest phase (degrees)')
for ax,n in zip([a,b,c],'abc'):ax.set(xlim=(0,360),xticks=np.arange(0,361,60));letter(ax,n)
save(fig,'figure2',[a,b,c],list('abc'),column_groups=[list('abc')])

def spectrum(ax,lo,hi,legend=True):
    take=s.frequency_uHz.between(lo,hi);z=s[take]
    ax.plot(z.frequency_uHz,z.observed_potential_PSD_m4_sminus4_per_uHz,color=blue,lw=.8,label='Observed')
    ax.plot(z.frequency_uHz,z.residual_potential_PSD_m4_sminus4_per_uHz,color=orange,lw=.9,ls='--',label='After unit physical prediction')
    ym=max(z.observed_potential_PSD_m4_sminus4_per_uHz.max(),z.residual_potential_PSD_m4_sminus4_per_uHz.max())*1.20
    ax.set(xlim=(lo,hi),ylim=(0,ym),xlabel='Frequency (µHz)',ylabel='Potential power density\n[(m²/s²)²/µHz]')
    sec=ax.secondary_yaxis('right',functions=(lambda x:x/299792458.0**4/1e-35,lambda x:x*1e-35*299792458.0**4))
    sec.set_ylabel('Fractional-frequency power density\n(10⁻³⁵/µHz)',labelpad=6);sec.spines['right'].set_visible(True)
    if legend:ax.legend(loc='lower left',bbox_to_anchor=(0,1.08),ncol=2)
    return ym

# Fig 3: S54/Allan amplitudes and phase; frozen v71 S54/equal spectral panel.
fig=plt.figure(figsize=(180/25.4,137/25.4));a=fig.add_axes([.19,.59,.25,.28]);b=fig.add_axes([.63,.59,.22,.28]);c=fig.add_axes([.19,.12,.66,.29])
aa=np.array(j['primary']['A']);uu=np.array(j['primary']['u']);yy=[1,0]
a.axvline(1,color='.55',ls='--',lw=.7);a.axvline(0,color='.8',lw=.5)
for i,color in enumerate([blue,orange]):a.errorbar(aa[i],yy[i],xerr=uu[i],fmt='o',color=color,capsize=3,ms=4)
a.set(yticks=yy,yticklabels=['Lunar M₂ + N₂','Neighbouring S₂ + K₂'],ylim=(-.5,1.5),xlim=(-.1,1.65),xticks=[0,.5,1,1.5],xlabel='Response coefficient')
a.set_title('Joint semidiurnal responses',loc='left',pad=12)
iq=np.array(j['iq']['A'][:2]);cov=np.array(j['iq']['cov_scaled_ls'])[:2,:2]
ev,ve=np.linalg.eigh(cov);ii=np.argsort(ev)[::-1];ev,ve=ev[ii],ve[:,ii];ang=np.degrees(np.arctan2(ve[1,0],ve[0,0]))
for radius,alpha in [(2,.4),(1,1)]:b.add_patch(Ellipse(iq,2*radius*np.sqrt(ev[0]),2*radius*np.sqrt(ev[1]),angle=ang,fill=False,color=blue,alpha=alpha,lw=1))
b.plot(*iq,'o',color=blue,ms=4);b.plot(1,0,'+',color='black',ms=7)
b.axhline(0,color='.8',lw=.5);b.axvline(1,color='.8',lw=.5)
b.set(xlim=(.60,1.40),ylim=(-.6,.4),xlabel='Lunar in-phase response',ylabel='Lunar quadrature response');b.set_title('Phase relative to prediction',loc='left',pad=12)
ym=spectrum(c,21,24.5);c.set_xticks(np.arange(21,24.51,.5))
for freq,label,col in [(22.3642775328,'M₂ · 12.42 h',blue),(23.1481474586,'S₂ · 12.00 h',orange)]:
    c.axvline(freq,color=col,ls=':',lw=.9,ymax=.87);c.text(freq,.93*ym,label,ha='center',fontsize=7,color='black',fontweight='bold')
for ax,n in zip([a,b,c],'abc'):letter(ax,n)
save(fig,'figure3',[a,b,c],list('abc'),row_groups=[['a','b']])

# Fig 4: display-only reuse of frozen temporal and same-data intercept results.
fig=plt.figure(figsize=(180/25.4,104/25.4));a=fig.add_axes([.19,.16,.29,.72]);b=fig.add_axes([.74,.16,.22,.72])
labels=['Full record','Before summer','Summer']+['Omit '+p for p in l.omitted]
vals=[aa[0],j['subsets']['early']['A'][0],j['subsets']['summer']['A'][0]]+l.A_L.tolist()
errs=[uu[0],j['subsets']['early']['u'][0],j['subsets']['summer']['u'][0]]+l.u_L.tolist()
ys=np.arange(len(vals))[::-1];a.axvline(1,color='.65',ls='--',lw=.7);a.axvspan(aa[0]-uu[0],aa[0]+uu[0],color=blue,alpha=.07)
a.axhline(7.5,color='.8',lw=.6);a.errorbar(vals,ys,xerr=errs,fmt='o',ms=3,color=blue,capsize=2)
a.set(yticks=ys,yticklabels=labels,xlim=(.45,1.60),ylim=(-.7,len(vals)-.3),xlabel='Lunar response coefficient')
a.set_title('Support across the full record',loc='left',pad=12)
b.axvline(1,color='.65',ls='--',lw=.7)
b.axvspan(aa[0]-uu[0],aa[0]+uu[0],color=blue,alpha=.07)
for design,y0,color in [('S54',2,blue),('G29',1,grey),('P8',0,orange)]:
    v=j['designs'][design]
    b.errorbar(v['A'][0],y0,xerr=v['u'][0],fmt='o',color=color,ms=4,capsize=3)
b.set(yticks=[2,1,0],yticklabels=['54 segments','29 groups','8 periods'],xlim=(.75,1.25),ylim=(-.6,2.6),xticks=[.8,1,1.2],xlabel='Lunar response coefficient')
b.set_title('Reference-level grouping\nSame observations and weights',loc='left',pad=12)
letter(a,'a');letter(b,'b');save(fig,'figure4',[a,b],['a','b'],row_groups=[['a','b']])


# Extended Data 1: same rows, same weights, alternative intercept granularity.
fig=plt.figure(figsize=(180/25.4,88/25.4));a=fig.add_axes([.12,.19,.35,.62]);b=fig.add_axes([.62,.19,.34,.62])
rr=pd.read_csv(O/'data/segment_residual_means.csv');v=rr[rr.design=='P8']
a.axhline(0,color='.7',lw=.6);a.scatter(v.seg,v.weighted_residual_mean,s=13,color=orange)
a.set(xlabel='Recorded segment number',ylabel='P8 residual segment mean (10⁻¹⁸)',title='Residual levels with period constants')
ll=pd.read_csv(O/'data/leave_period_all_designs.csv')
for name,color,dx in [('P8',orange,-.10),('S54',blue,.10)]:
    q=ll[ll.design==name];b.plot(np.arange(1,9)+dx,q.A_L,'o-',ms=3,lw=.65,color=color,label=name)
b.axhline(1,color='.7',ls='--',lw=.6);b.set(xlabel='Omitted observing period',ylabel='Lunar point estimate',xticks=range(1,9),ylim=(.82,1.13));b.legend(ncol=2,loc='upper right')
letter(a,'a');letter(b,'b');save(fig,'ed_figure1',[a,b],['a','b'],row_groups=[['a','b']])

# Extended Data 2: observed conditional scans, not newly estimated amplitudes.
fig=plt.figure(figsize=(180/25.4,87/25.4));a=fig.add_axes([.13,.21,.35,.57]);b=fig.add_axes([.62,.21,.35,.57])
cs=pd.read_csv(O/'data/conditional_scans.csv')
for ax,target,other in [(a,'M2','S2'),(b,'S2','M2')]:
    q=cs[cs.target==target];lo=q.frequency_uHz.min();hi=q.frequency_uHz.max();u=s[s.frequency_uHz.between(lo,hi)]
    ax.plot(u.frequency_uHz,u.observed_potential_PSD_m4_sminus4_per_uHz,color=blue,lw=.9,label='Observed')
    ax.plot(q.frequency_uHz,q.potential_PSD,color=orange,lw=.9,label='Conditioned on '+other[0]+'₂')
    ax.axvline(j['spectrum']['frequency_Hz'][target]*1e6,ls=':',color='.5',lw=.7)
    ax.set(xlim=(lo,hi),xlabel='Frequency (µHz)',ylabel='Potential power density\n[(m²/s²)²/µHz]',ylim=(0,.22))
    ax.legend(loc='lower left',bbox_to_anchor=(0,1.04),fontsize=6.3)
letter(a,'a');letter(b,'b');save(fig,'ed_figure2',[a,b],['a','b'],row_groups=[['a','b']])

# Extended Data 3: original Fig. 4b monitor values and paired errors, unchanged.
fig=plt.figure(figsize=(130/25.4,80/25.4));a=fig.add_axes([.22,.23,.72,.57])
m=j['monitor'];a.axvline(0,color='.65',ls='--',lw=.7)
a.errorbar(m['delta'],[2,1,0],xerr=m['paired_day_se'],fmt='o',color=green,ms=4,capsize=3)
a.set(yticks=[2,1,0],yticklabels=['Lunar','Near-12 h','Diurnal'],xlim=(-.025,.025),ylim=(-.6,2.6),xticks=[-.02,0,.02],xlabel='Change in response coefficient')
a.set_title('Matched fibre round-trip control: 246.6 h in summer',loc='left',pad=14)
save(fig,'ed_figure3',[a],['monitor'])
provenance[-1]['scope']='Original A_v75 Figure 4b; identical paired support, coefficients and errors; moved to Extended Data.'
provenance[3]['scope']='Temporal panel unchanged; reference-level panel reads frozen S54/G29/P8 results, lunar coordinate only.'
provenance[2]['spectral_panel']='Frozen v71 Fig. 3c: S54/equal, observed y and residual after fixed unit total prediction; fully replayed'
(F/'PROVENANCE.json').write_text(json.dumps(provenance,indent=2))
