"""Targeted scientific-positioning and Nature-layout edit; no new fit."""
from pathlib import Path
import json,re
O=Path(__file__).resolve().parents[1]
t=(O/'original/A_v76_manuscript_template.md').read_text();ops=[]
def swap(a,b,why):
    global t
    assert t.count(a)==1,a[:100]
    t=t.replace(a,b);ops.append(dict(old=a,new=b,reason=why))
swap('# Tidal potential measured on a coastal–inland optical-clock baseline','# Resolving lunar and solar tidal responses with an optical clock baseline','User title steering; 72 characters; group definitions retained in summary and main text.')
swap('We jointly estimate complete physical templates for the lunar semidiurnal group M₂+N₂, the neighbouring group S₂+K₂ and the approximately daily group K₁+O₁+P₁+Q₁. Internal amplitude ratios and phases remain fixed by the astronomical model. K₂ contains lunar and solar forcing.', 'The two target responses are represented by complete physical templates for the lunar semidiurnal group M₂+N₂ and the neighbouring group S₂+K₂. The joint model also retains the approximately daily tides as an auxiliary physical component. Internal amplitude ratios and phases remain fixed by the astronomical model. K₂ contains lunar and solar forcing.', 'Make two semidiurnal groups the scientific targets; auxiliary daily model stays in joint estimation.')
swap('Fitting the three physical groups together gives $A_L=1.00\\pm0.13$ for M₂+N₂. The neighbouring group S₂+K₂ gives $A_S=0.93\\pm0.36$, with lower precision (Fig. 3a).', 'Joint estimation gives $A_L=1.00\\pm0.13$ for M₂+N₂ and $A_S=0.93\\pm0.36$ for S₂+K₂ (Fig. 3a). Each semidiurnal group has its own response coefficient within the same physical model.', 'Both semidiurnal coefficients are core results, with their actual different error bars unchanged.')
swap(' The jointly fitted daily group has $A_D=0.58\\pm0.54$. Its lower precision is accounted for in the joint covariance and does not negate the semidiurnal responses. Improved daily sensitivity requires longer uninterrupted clock operation and sustained link comparisons with data-quality rules independent of the tidal fit.', '', 'Remove daily non-detection/upgrade discussion from main Results; retain value and covariance in Methods/ED.')
swap('The lunar group supplies the strongest quantitative constraint, while the less precise neighbouring group and the two local spectral peaks identify structure around the principal solar and lunar frequencies.', 'The two semidiurnal groups have separately estimated response coefficients, supported by local peaks near M₂ and S₂ and by the conditional scans. Together they resolve neighbouring lunar and solar-driven tidal responses within the specified physical grouping.', 'Discussion centres both core semidiurnal results, jointly supported by estimates, spectrum and conditional scans; no independence claim.')
swap('**a,** Joint group amplitudes with one standard error, defined as the larger of scaled least-squares and UTC-day jackknife errors.', '**a,** The two semidiurnal coefficients from the three-group joint model, using all 3,299 means. Error bars are one standard error, defined as the larger of scaled least-squares and UTC-day jackknife errors. The daily group remains in the fit and is reported in Methods and Extended Data Table 2.', 'Fig. 3a displays the two target groups; the auxiliary coefficient remains in the unchanged numerical fit.')
swap('The inspected interval and correction records contain no documented calibrated zero transfer', 'The daily group is an auxiliary physical component, fitted simultaneously to propagate its covariance with the semidiurnal responses. Its coefficient is $A_D=0.58\\pm0.54$ (Extended Data Table 2). Its predicted variation is smaller on this baseline, and its longer period supplies fewer cycles within short segments, increasing overlap with segment reference levels and slow variations. This auxiliary estimate is not a separate measurement objective.\n\nThe inspected interval and correction records contain no documented calibrated zero transfer', 'Retain daily result and physical rationale once in Methods. Template RMS checked from frozen columns only, without refitting observations.')
swap('The phase-relaxed model adds the lunar quadrature while retaining the prescribed M₂/N₂ relationship. Covariance contours use scaled least squares. Subset and deletion fits refit the same model on their retained rows. No shared-data estimates are averaged, and no half-daily coefficient is converted into a daily upper limit.', 'The phase-relaxed model adds the lunar quadrature while retaining the prescribed M₂/N₂ relationship. Covariance contours use scaled least squares. Subset and deletion fits refit the same model on their retained rows. Shared-data estimates are not averaged. The simulation coverage refers to two-sided intervals; the reported $\\pm$ values are standard errors.', 'Clarify actual statistical reporting for Nature; remove irrelevant daily-upper-limit discussion.')
swap('The archived single-bin influence does not account for the weak daily constraint or justify tide-dependent selection. The daily coefficient is not used as an upper bound on an unmeasured laboratory disturbance.', 'The archived influence diagnostic is retained for provenance; the current observation membership is unchanged.', 'Keep archived measurement and diagnostic in ED without making daily precision a scientific limitation.')

# Exact n for plotted subsets, from already frozen deletion/subset results.
import pandas as pd
j=json.loads((O/'data/RESULTS.json').read_text())
deletions=pd.read_csv(O/'data/leave_period_all_designs.csv');q=deletions[deletions.design=='S54']
ns=', '.join(f'{int(n):,}' for n in q.n)
swap('Each fit uses segment constants and the primary noise weights, with errors recalculated on its retained rows.', f'Each fit uses segment constants and the primary noise weights, with errors recalculated on its retained rows. The full, pre-summer and summer fits contain 3,299, {j["subsets"]["early"]["n"]:,} and {j["subsets"]["summer"]["n"]:,} means. Deleting P1–P8 retains {ns} means, respectively.', 'Report exact observation counts for every plotted estimate, as requested by Nature statistical reporting guidance.')

# Nature Article order: summary/main; main references; figures+legends; Methods;
# data/code; Methods references; end notes; individual Extended Data displays.
front,rest=t.split('## Abstract\n',1)
title,author=front.split('\n',1)
front=title+'\n\n::: affiliations\n'+author.strip()+'\n:::\n\n'
t=front+'## Abstract\n'+rest
main_and_fig,remaining=t.split('## Methods\n',1)
before_fig,figures=main_and_fig.split('## Figure legends\n',1)
methods_and_end,ed=remaining.split('## Extended Data\n',1)
methods,author_and_refs=methods_and_end.split('## Author statements\n',1)
ai='OpenAI Codex assisted English drafting, numerical replay and figure preparation. [Authors to confirm their verification of the analyses, citations and final text, and responsibility for the submitted work.]'
assert ai in author_and_refs
methods=methods.replace('## Data availability', '### AI-assisted preparation\n\n'+ai+'\n\n## Data availability')
notes='''## Acknowledgements

[To be completed by the authors.]

## Funding statement

[Funding sources and grant identifiers to be completed by the authors.]

## Author contributions

[To be completed and approved by all authors.]

## Competing interests

[Declaration to be supplied by the authors.]

## Additional information

**Correspondence:** [Corresponding author names and email addresses to be supplied; mark them with an asterisk in the author list.]
'''
methods=methods.rstrip().removesuffix('\\clearpage').rstrip()
t=before_fig+'## References\n\n{{MAIN_REFERENCES}}\n\n\\clearpage\n\n## Figure legends\n'+figures+'## Methods\n'+methods+'\n\n## Methods references\n\n{{METHOD_REFERENCES}}\n\n\\clearpage\n\n'+notes+'\n\\clearpage\n\n## Extended Data\n'+ed
# Each ED item starts on its own page; no Methods display items.
t=t.replace('![Extended Data Figure 2]','\\clearpage\n\n![Extended Data Figure 2]')
for n in [2,3]:t=t.replace(f'**Extended Data Table {n} |',f'\\clearpage\n\n**Extended Data Table {n} |')
ops.append(dict(reason='Nature order and summary formatting; split main/Methods references; AI disclosure in Methods; author end notes; one ED item per page. No author details invented.'))
(O/'manuscript_template.md').write_text(t)
(O/'review/EDIT_OPERATIONS_A_v77.json').write_text(json.dumps(ops,indent=2,ensure_ascii=False))
print(json.dumps({'targeted_edits':len(ops),'title_characters':len(title.removeprefix('# ')),'daily_display':'Methods + ED Table 2','observation_fit_rerun':False}))
