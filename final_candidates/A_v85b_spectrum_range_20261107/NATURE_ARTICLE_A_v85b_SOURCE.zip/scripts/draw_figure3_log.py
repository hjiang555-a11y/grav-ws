"""Display-only logarithmic-axis revision of the existing Figure 3.
Reads frozen plotting results, not counters or fitting inputs. No spectrum,
fit, noise estimation, or statistical validation is run. Panel c converts
stored potential PSD to equivalent-height PSD in cm^2/uHz using g0.
Panels a and b use their existing coefficients/covariance for drawing only.
"""
from pathlib import Path
import json, argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
parser=argparse.ArgumentParser()
parser.add_argument('--source',type=Path,default=Path('/home/room115/gravitation-whsh/final_candidates/A_v81_integration'))
args=parser.parse_args()
SOURCE=args.source
OUT=Path(__file__).resolve().parents[1]
F=OUT/'figures'
G0=9.80665
HEIGHT_FACTOR=10000.0/G0**2
j=json.loads((SOURCE/'data/RESULTS.json').read_text())
full=json.loads((SOURCE/'segment_reduction/FULL_TIDE.json').read_text())
def letter(ax,label):
    ax.annotate(label,(0,1),xycoords='axes fraction',xytext=(-12,7),textcoords='offset points',fontsize=8,fontweight='bold',va='bottom')
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans'],'font.size':7,
 'axes.labelsize':7,'axes.titlesize':7,'xtick.labelsize':6,'ytick.labelsize':6,'legend.fontsize':6,
 'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False,
 'axes.linewidth':.7,'legend.frameon':False})
blue='#126080';orange='#bc651f';green='#50816c';purple='#80619b';grey='#737373'
factor=299792458.0**2*1e-18
# The overall one-template response precedes the two group coefficients.
spec=pd.read_csv(SOURCE/'data/semidiurnal_spectrum.csv')
fig=plt.figure(figsize=(180/25.4,137/25.4))
a=fig.add_axes([.19,.59,.25,.28]);b=fig.add_axes([.63,.59,.22,.28]);c=fig.add_axes([.19,.12,.66,.29])
a.axvline(1,color='.55',ls='--',lw=.7)
for value,error,y0,color in [(full['A'],full['SE'],2,green),(j['primary']['A'][0],j['primary']['u'][0],1,blue),(j['primary']['A'][1],j['primary']['u'][1],0,orange)]:
    a.errorbar(value,y0,xerr=error,fmt='o',color=color,capsize=3,ms=4)
a.set(yticks=[2,1,0],yticklabels=['Full tide','Lunar M₂ + N₂','Neighbouring S₂ + K₂'],ylim=(-.5,2.5),xlim=(-.1,1.65),xticks=[0,.5,1,1.5],xlabel='Response coefficient')
a.set_title('Overall and grouped responses',loc='left',pad=12)
iq=np.array(j['iq']['A'][:2]);cov=np.array(j['iq']['cov_scaled_ls'])[:2,:2]
ev,ve=np.linalg.eigh(cov);order=np.argsort(ev)[::-1];ev=ev[order];ve=ve[:,order]
angle=np.degrees(np.arctan2(ve[1,0],ve[0,0]))
for radius,alpha in [(2,.4),(1,1)]:b.add_patch(Ellipse(iq,2*radius*np.sqrt(ev[0]),2*radius*np.sqrt(ev[1]),angle=angle,fill=False,color=blue,alpha=alpha,lw=1))
b.plot(*iq,'o',color=blue,ms=4);b.plot(1,0,'+',color='black',ms=7)
b.axhline(0,color='.8',lw=.5);b.axvline(1,color='.8',lw=.5)
b.set(xlim=(.60,1.40),ylim=(-.6,.4),xlabel='Lunar in-phase response',ylabel='Lunar quadrature response')
b.set_title('Phase relative to prediction',loc='left',pad=12)
use=spec.frequency_uHz.between(21,24.5);z=spec[use]
c.plot(z.frequency_uHz,z.observed_potential_PSD_m4_sminus4_per_uHz*HEIGHT_FACTOR,color=blue,lw=.8,label='Observed')
c.plot(z.frequency_uHz,z.residual_potential_PSD_m4_sminus4_per_uHz*HEIGHT_FACTOR,color=orange,lw=.9,ls='--',label='After unit physical prediction')
values=np.r_[z.observed_potential_PSD_m4_sminus4_per_uHz.to_numpy(),z.residual_potential_PSD_m4_sminus4_per_uHz.to_numpy()]*HEIGHT_FACTOR
if not np.all(values>0):
    raise ValueError('Log display requires positive stored powers; no artificial floor is added.')
ymin=1e-1  # Display lower limit only; stored spectral values remain unchanged.
ymax=10**np.ceil(np.log10(values.max()))
c.set_yscale('log')
c.set(xlim=(21,24.5),ylim=(ymin,ymax),xticks=np.arange(21,24.51,.5),xlabel='Frequency (µHz)',ylabel='Equivalent-height power density\n(cm²/µHz)')
twin=c.secondary_yaxis('right',functions=(lambda x:x/HEIGHT_FACTOR/299792458.0**4/1e-35,lambda x:x*1e-35*299792458.0**4*HEIGHT_FACTOR))
twin.set_ylabel('Fractional-frequency power density\n(10⁻³⁵/µHz)',labelpad=6);twin.spines['right'].set_visible(True)
c.legend(loc='lower left',bbox_to_anchor=(0,1.08),ncol=2)
for frequency,label,color in [(22.3642775328,'M₂ · 12.42 h',blue),(23.1481474586,'S₂ · 12.00 h',orange)]:
    c.axvline(frequency,color=color,ls=':',lw=.9,ymax=.87)
    c.text(frequency,.92,label,transform=c.get_xaxis_transform(),ha='center',fontsize=7,color='black',fontweight='bold',bbox=dict(facecolor='white',edgecolor='none',pad=1))
for ax,label in zip([a,b,c],'abc'):letter(ax,label)
for ext in ('pdf','svg','png'):
    fig.savefig(F/('figure3.'+ext),dpi=450)
plt.close(fig)
