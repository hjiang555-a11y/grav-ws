"""Package the current A_v75 manuscript and review using an explicit allowlist."""
from pathlib import Path
import hashlib,json,shutil,zipfile

O=Path(__file__).resolve().parents[1]
assert json.loads((O/'verification/FINAL_CHECK_A_v75.json').read_text())['status']=='PASS'
stage=O/'verification/export_A_v75';stage.mkdir()
paths=set()
for folder in ['data','figures','vendor','sources/frozen_v72','editorial/network_research','verification/baseline_A_v72']:
    paths.update(p.relative_to(O) for p in (O/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
for name in ['assemble_candidate.py','revise_for_nature.py','verify_nature_revision.py','recompute_candidate.py','check_coverage.py','draw_candidate.py','package_review.py']:
    paths.add(Path('scripts')/name)
names=['NATURE_ARTICLE_A_v75.md','manuscript_template.md','render_candidate.py','layout_working.lua',
       'REPRODUCE.md','PLAN.md','INPUT_MANIFEST.json','COVER_LETTER.md','REVISION_NOTE_ZH.md',
       'ANALYSIS_REPORT_ZH.md','NATURE_REVIEW_REPORT_ZH.md','NETWORK_SIGNIFICANCE_RESEARCH_ZH.md',
       'review/ROUND1_NATURE_REVIEW_ZH.md','review/ROUND2_NATURE_REVIEW_ZH.md','review/HUMANIZER_CHANGELOG.md',
       'original/A_v74_manuscript_template.md','original/A_v74_NATURE_ARTICLE_A_v74.md',
       'original/A_v74_COVER_LETTER.md','original/manuscript_template_A_v72.md',
       'sources/v72/NATURE_ARTICLE_v72.md','sources/v68.md','sources/noise_definition.py',
       'sources/prior_single_bin_integration.json','sources/v71/data/annual_spectrum_dual_units.csv',
       'sources/spectral/annual_spectrum_20261106T0857Z/data/RESULTS.json',
       'editorial/REFERENCE_ORDER.json','editorial/POSITIONING_EVIDENCE.json',
       'verification/ORIGINAL_A_V72_HASHES.json','verification/ORIGINAL_A_V74_HASHES.json',
       'verification/NATURE_REVISION_CHECK.json','verification/FINAL_CHECK_A_v75.json',
       'verification/VISUAL_REVIEW_A_v75.json','verification/PDF_PAGE_CHECK.json',
       'verification/TEXT_STRUCTURE.json','verification/SOFTWARE.json',
       'verification/humanizer_compare_A_v75.txt','verification/humanizer_audit_A_v75.txt']
paths.update(Path(n) for n in names)
for rel in sorted(paths):
    src=O/rel;assert src.is_file() and not src.is_symlink(),str(src)
    dst=stage/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
shutil.copy2(O/'render_A_v75_01/NATURE_ARTICLE_A_v75.tex',stage/'NATURE_ARTICLE_A_v75.tex')
manifest=[dict(path=str(p.relative_to(stage)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(stage.rglob('*')) if p.is_file()]
(stage/'EXPORT_MANIFEST.json').write_text(json.dumps(dict(scope='Author-review manuscript, frozen derived observations, physical templates, figures and reproduction scripts',excluded='Raw counters, author-uploaded or previous manuscript PDFs, draft renders, credentials and unrelated worktrees',files=manifest),indent=2))
release=O/'release';assert not list(release.iterdir())
for ext in ['pdf','docx','tex']:shutil.copy2(O/f'render_A_v75_01/NATURE_ARTICLE_A_v75.{ext}',release/f'NATURE_ARTICLE_A_v75.{ext}')
for name in ['NATURE_ARTICLE_A_v75.md','COVER_LETTER.md','REVISION_NOTE_ZH.md','REVISION_NOTE_ZH.pdf','ANALYSIS_REPORT_ZH.md','NATURE_REVIEW_REPORT_ZH.md','REPRODUCE.md']:
    shutil.copy2(O/name,release/name)
shutil.copy2(O/'verification/FINAL_CHECK_A_v75.json',release/'FINAL_CHECK.json')
shutil.copy2(stage/'EXPORT_MANIFEST.json',release/'EXPORT_MANIFEST.json')
with zipfile.ZipFile(release/'A_v75_SOURCE.zip','x',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(stage.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(stage))
rows=[f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}' for p in sorted(release.iterdir()) if p.is_file()]
(release/'SHA256SUMS.txt').write_text('\n'.join(rows)+'\n')
print(json.dumps(dict(source_files=len(manifest),release_files=len(rows)+1)))
