"""Check A_v75's editorial change against the frozen A_v74 and A_v72 evidence."""
from pathlib import Path
from collections import Counter
import hashlib,json,re,sys

O=Path(__file__).resolve().parents[1]
B=O.parent/'A_v74'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
def record(name,passed,detail):
    checks.append(dict(check=name,passed=bool(passed),detail=detail))

manifest=json.loads((O/'verification/ORIGINAL_A_V74_HASHES.json').read_text())
bad=[r['path'] for r in manifest if sha(Path(r['path']))!=r['sha256']]
record('Original A_v74 preserved',not bad,dict(files=len(manifest),changed=bad))
base72=json.loads((O/'verification/ORIGINAL_A_V72_HASHES.json').read_text())
bad=[r['path'] for r in base72 if sha(Path(r['path']))!=r['sha256']]
record('Original A_v72 preserved',not bad,dict(files=len(base72),changed=bad))
for folder in ['data','figures','vendor']:
    files=[p for p in (O/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    bad=[str(p.relative_to(O)) for p in files if sha(p)!=sha(B/p.relative_to(O))]
    record(folder+' unchanged',not bad,dict(files=len(files),changed=bad))
inputs=json.loads((O/'INPUT_MANIFEST.json').read_text())['files']
bad=[r['copy'] for r in inputs if sha(O/r['copy'])!=r['sha256']]
record('Frozen input hashes',not bad,dict(files=len(inputs),changed=bad))

old=(O/'original/A_v74_manuscript_template.md').read_text()
new=(O/'manuscript_template.md').read_text()
formula=r'\$\$[\s\S]*?\$\$|(?<!\$)\$(?!\$)[^\n$]+\$(?!\$)'
record('All equations and mathematical results unchanged',Counter(re.findall(formula,old))==Counter(re.findall(formula,new)),'Exact multiset of mathematical expressions')
numbers=lambda t:Counter(re.findall(r'(?<![A-Za-z_])[-+−]?\d+(?:[.,]\d+)*(?:[eE][-+]?\d+)?',re.sub(r'\[@[a-z,]+\]','',t)))
record('Numerical tokens unchanged',numbers(old)==numbers(new),dict(removed=dict(numbers(old)-numbers(new)),added=dict(numbers(new)-numbers(old))))
getkeys=lambda t:list(dict.fromkeys(k for group in re.findall(r'\[@([a-z,]+)\]',t) for k in group.split(',')))
oldkeys,newkeys=getkeys(old),getkeys(new)
mapping=json.loads((O/'editorial/REFERENCE_ORDER.json').read_text())
basemap=json.loads((B/'editorial/REFERENCE_ORDER.json').read_text())
record('Same sources, reordered by first appearance',set(oldkeys)==set(newkeys) and all(mapping[k]['number']==i+1 for i,k in enumerate(newkeys)),dict(references=len(newkeys)))
record('Bibliographic entries unchanged',all(mapping[k]['text']==v['text'] for k,v in basemap.items()),'Same 24 references')
record('Methods and figure captions unchanged',old.split('## Figure legends',1)[1]==new.split('## Figure legends',1)[1],'All text from Figure legends onward is byte-identical in the keyed template')
main=new.split('## Main text',1)[1].split('## Figure legends',1)[0]
record('Physical background before spectral technical terms',main.index('mass redistribution')<main.index('0.78 µHz'),'First two paragraphs explain the physical observable and its significance')
record('Measurement and resolution stated',all(x in new for x in ['Here we measure tidal variations','high spectral resolution','0.78 µHz']),'Scientific measurement plus demonstrated spectral capability')
record('Independent contemporary citation',new.count('[@stahl]')==1 and 'Independent, contemporaneous measurements' in new,'No following/priority/misconduct claim introduced')
build=json.loads((O/'render_A_v75_01/BUILD_RESULTS.json').read_text())
record('PDF and Word compile',all(r['exit']==0 and not r['warnings'] for r in build['builds']) and build['source_sha256']==sha(O/'NATURE_ARTICLE_A_v75.md'),build)
out=dict(status='PASS' if all(x['passed'] for x in checks) else 'FAIL',scope='Editorial evidence-preservation checks; no new numerical fit or author approval',checks=checks)
(O/'verification/NATURE_REVISION_CHECK.json').write_text(json.dumps(out,indent=2,ensure_ascii=False))
print(json.dumps(dict(status=out['status'],checks=len(checks),failed=[x['check'] for x in checks if not x['passed']]),ensure_ascii=False))
sys.exit(0 if out['status']=='PASS' else 1)
