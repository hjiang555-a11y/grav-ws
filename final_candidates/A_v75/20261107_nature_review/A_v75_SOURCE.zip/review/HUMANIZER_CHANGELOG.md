# A_v75 expression audit

Mode: Polish, with the author's explicit authorization to revise the scientific framing and introductory structure. The original is retained under `original/`. The latest instruction requires basic physical context before spectral methods, and measurement of tides together with demonstrated high spectral resolution.

Rule 5: unchanged numerical claims are connected to their existing amplitude, phase and spectral evidence. No new sigma, P value, physical coefficient or observation is introduced. The demonstrated frequency spacing remains 0.78 µHz under the actual sampling.

Rule 7: the abstract, contribution paragraph and discussion state tidal measurement directly. This is an explicit author-requested emphasis supported by the already reported observations; no qualifier on statistical error, model specification, loading separation or control coverage was removed.

Rules 8–9: the original introductory paragraph is developed into physical context and the static-to-dynamic measurement question, before the neighbouring tidal frequencies. The remaining experiment, figures and Methods retain their structure. The European comparison becomes one normal contemporaneous citation, followed by the geophysical implication of the combined results.

Comparison: 181 number tokens and 74 mathematical segments unchanged. The checker records 19 sentence-change groups: ten rewritten, four merged/split, three added, two removed. These changes implement the physical-context and measured-result revisions above. Voigt and Dimarcq each acquire one additional citation occurrence; the source set and all 24 bibliographic entries remain unchanged. No engineering-detail number was deleted. Full output: `verification/humanizer_compare_A_v75.txt`.

The remaining audit flags concern existing technical terms, figure captions and tables. Apparent very long sentences often join text across Markdown citation markers; each new sentence was read directly. Genuine qualifications are retained. Author statements and data/code access placeholders are still author tasks, so this editing check is not submission authorization.
