# v85 calculations

Scripts, dependencies, output tables and input hashes accompany the report. Inputs are the frozen A_v81 derived data already named by SOURCE_MAP.json. Original counters and per-row observations are not included in this sharing bundle. Restore the mapped inputs locally to reproduce. The DE430 file and unchanged solid series are referenced by absolute paths and SHA256 in POTENTIAL_RESULTS.json.

Run in the existing /home/room115/pytorch_env with OPENBLAS_NUM_THREADS=1, in order: scripts/noise_check.py; scripts/potential_check.py; scripts/empirical_noise.py; scripts/verify_and_plot.py.

Main coefficients remain those of v85b. Variants are sensitivity checks, not averaged.
