from pathlib import Path
import pandas as pd,json,hashlib,platform,shutil
O=Path(__file__).resolve().parents[1];P=Path('/home/room115/gravitation-whsh/final_candidates/A_v86_physics_noise_20261107')
f=pd.read_csv(O/'results/potential_fit_comparison.csv');n=pd.read_csv(O/'results/replay_and_years.csv');h=pd.read_csv(O/'results/HAC_sensitivity.csv');b=pd.read_csv(O/'results/block_bootstrap.csv');c=pd.read_csv(O/'results/MA1_conditional_coverage.csv')
lines=['# v85 物理模板与相关噪声核验','', '本轮结果支持保留论文主线：远距离光钟检出潮汐势差变化，月球半日潮响应最清楚；邻近半日组作为联合模型中的分量估计。所检查的固体潮近似没有显著移动半日潮结果，相关噪声敏感性也没有要求推翻现有误差量级。','', '## 本轮实际完成什么','', '经用户重新授权计算，使用 v85b 所继承的冻结派生包：3,299 个十分钟均值、54 段、8 期、原始 UTC 和 Allan 权重。没有增加或删除观测，没有改动原始计数、旧稿或其他 AI 工作树。这是冻结派生输入到统计结果的重新计算，不冒称重新完成原始计数的全部筛选与补偿。','', '实验单位是一对沪汉光钟；十分钟均值是重复观测。所有模型共享观测，不能合并显著性。','', '## 1. 主结果复现及物理模板影响','', '两个独立线性代数实现（分段投影/SVD 与完整截距 QR）一致，复现既有系数与误差。下表使用同一采样、权重、54 段零点和海洋负荷，只改变固体潮计算。','', '| 固体潮实现 | 总体 AT | 月潮 AL | 邻近 AS |','|---|---:|---:|---:|']
labels={'inherited_conversion':'当前位移换势','direct_uniform_n23':'直接势，恒定二/三阶响应','direct_k_nominal_retained_displacement':'直接势+名义k，保留位移','direct_k_frequency_retained_displacement':'直接势+频率k，保留位移','direct_hk_frequency_n23':'直接势+频率h、k'}
for key,lab in labels.items():
 vals=[]
 for par in ['AT','AL','AS']:
  a=f[(f.variant==key)&(f.parameter==par)&(f.model!='phase')].iloc[0];vals.append(f'{a.A:.4f} ± {a.SE:.4f}')
 lines.append('| '+lab+' | '+' | '.join(vals)+' |')
lines += ['', '误差仍用原规则 max(残差标度 LS, 删 UTC 日 jackknife)。两种分频实现的 AT 约为 0.944，而 AL 约为 1.002，AS 约为 0.925。所有控制中，AT、AL、AS 的移动分别小于 0.0141、0.0036、0.0013；月潮正交系数在 −0.097 至 −0.094，误差约 0.20。','', '**判断：K₁ 模板差异确实存在，但不能直接当成半日潮的同等比例误差。本次在当前窗口上量化了其传递影响，半日结果基本不变。**','', '![同观测、同海洋负荷、同估计器的模板比较](figures/template_sensitivity.png){width=100%}', '', '计算从 DE430 几何天体位置生成二、三阶直接潮汐势；分频 k/h 取 pyTMD 3.0.9 的 IERS 2010 共振表达式。第一分频分支保留现有 pysolid 位移，第二分支直接应用频率相关 1+k−h。基函数采用与现稿相同的天文相位、结点因子和 exp(−iφ) 约定。先在原共同 90 秒网格的小时子样本上分解，再在相同 UTC 箱中心生成模板。','', '共同网格不包含 solid 文件比 loading/total 多出的最后一个 90 秒点；8 个重复 UTC 箱中心保留各自观测行，不合并。这两处是输入对齐规则，没有改变实验样本。','', '这是有限分潮、二/三阶受控比较：UT1 近似 UTC、极移设零、没有完整 IERS 四阶感应项认证；保留海洋负荷，未重算其他海潮模型。因此结果可以关闭“尚未在当前采样检验固体潮近似影响”这一问题，不能改称所有物理系统误差已认证。','', '物理依据：[IERS 2010 第6章](https://iers-conventions.obspm.fr/content/chapter6/icc6.pdf)、[pyTMD Earth 响应接口](https://pytmd.readthedocs.io/en/latest/api_reference/earth.html)。实际运行版本与源代码 SHA256 见 POTENTIAL_RESULTS.json。','', '## 2. 实测残差与误差条','', '真实连续 600 秒邻接下，残差 lag1/lag2/lag3 相关分别为 −0.148、0.011、0.028；8 期 lag1 均为负。没有把缺测压缩成相邻时间，也没有把拟合后残差稳定度当成原装置长期稳定度。','', '| 方法 | AT 标准误 | AL 标准误 | AS 标准误 |','|---|---:|---:|---:|','| 现稿 | 0.108 | 0.132 | 0.365 |']
for dat,filtercol,lab in [(h,h.bandwidth_hours>0,'真实时间 Bartlett HAC（1–24 h）'),(b,b.block_hours>0,'连续段内循环移动块（1–12 h）')]:
 vals=[]
 for par in ['AT','AL','AS']:
  z=dat[(dat.parameter==par)&filtercol].SE;vals.append(f'{z.min():.3f}–{z.max():.3f}')
 lines.append('| '+lab+' | '+' | '.join(vals)+' |')
lines += ['| 删观测期 jackknife | 0.122 | 0.147 | 0.353 |', '', 'HAC 保留真实时间差，1/3/6/12/24 小时带宽全部报告；移动块采用 HC2 标准化残差，1/3/6/12 小时各 2,000 次，块受连续运行长度限制。所有方法保持原 WLS 点估计；不因某种方法误差较小而换主结果。这里的范围是敏感性结果，不是把多个误差求平均。','', '![残差相关性与误差敏感性](figures/noise_sensitivity.png){width=100%}', '', '补充拟合了逐期方差、相邻负协方差的 MA(1) 经验噪声基准；2,000 次条件模拟重新计算原 max-SE 规则，95% 区间覆盖如下：','', '| 参数 | 条件经验标准误 | max-SE 的95%覆盖 |','|---|---:|---:|']
for _,a in c.iterrows():lines.append(f'| {a.parameter} | {a.empirical_SE:.3f} | {a.coverage_max95*100:.2f}% |')
lines += ['', '该基准改善了 lag1 的匹配，但 lag3 略超出模拟95%范围，实测三倍标准差外点比例为0.758%，高于模拟的0.121%–0.455%。故不能宣布已识别唯一真实噪声；这些模拟也不承担独立探测显著性的角色。保留真实残差分布的块检验和协方差敏感性才是本轮主要补证。负相关可能与差分/计数链有关，但没有独立运行证据时不把该机制写成已证实。','', '## 3. 跨年度检验','', '| 年份 | 行数 | AT | AL | AS |','|---|---:|---:|---:|---:|']
for yr in ['2025','2026']:
 vals=[]
 for par in ['AT','AL','AS']:
  a=n[(n.scope==yr)&(n.parameter==par)].iloc[0];vals.append(f'{a.A:.3f} ± {a.SE_reported:.3f}')
 lines.append('| '+yr+' | '+str(a.rows)+' | '+' | '.join(vals)+' |')
lines += ['', '2026 单独保留约1的月潮响应；2025 只有366箱、6个观测日，分组约束明显较弱。此表没有证明早期数据错误，也没有据此剔除它。两个年度均使用各段自己的零点，不传递跨年绝对水平。','', '## 4. 写作取舍：把验证做实，正文保持简洁','', '- 保留总潮汐探测作为第一层结论，月球幅度与相位作为最强分量证据。','- 两个半日组来自同一联合拟合；不写独立、稳健确认纯太阳潮。自由12h项是可辨识性边界，不是污染存在的证明。','- 本轮验证在 Results 只增加一个简短段落；模型、残差、年度表进入 Methods 和独立报告。','- Discussion 收束为测量结果、跨中断相位积累、下一步物理贡献分离；不逐段重复免责声明。','- 题目、已确认摘要、Introduction、Results1 和四张主图保持原文/原图；摘要术语修订另附具体提案，未擅改。','- 欧洲仍只在 Discussion 最后一句引用。遵守此前不引 Hou 的稿件安排；若作者后续正式投稿，样本重叠仍应由作者向编辑如实披露，不能靠删引文消除事实。','', '## 5. 验证状态与仍需确认','', '已通过：主估计重放、完整 QR 对照、任意54零点不变性、无噪声注入恢复、原设计复现、输入哈希不变、MA(1) 可行性与条件模拟偏差检查。所有结果均来自本轮真实运行。','', '尚未完成的范围明确保留：原始计数到筛选/补偿的端到端重建；完整 IERS 和替代海洋模型的不确定度预算；同频钟效应的独立测量约束；作者/基金/访问地址。它们不被本次有限核验冒名覆盖，也不在正文扩成泛泛疑虑。','', '报告路径与复算入口：', '', '```bash','cd '+str(O),'OPENBLAS_NUM_THREADS=1 /home/room115/pytorch_env/bin/python scripts/noise_check.py','OPENBLAS_NUM_THREADS=1 /home/room115/pytorch_env/bin/python scripts/potential_check.py','OPENBLAS_NUM_THREADS=1 /home/room115/pytorch_env/bin/python scripts/empirical_noise.py','OPENBLAS_NUM_THREADS=1 /home/room115/pytorch_env/bin/python scripts/verify_and_plot.py','```','', '默认 sci 环境缺少天文依赖，因此使用已有 pytorch_env，不安装/更换共享环境。版本见软件清单。脚本只向本分支 results/figures/verification 写入；首次输出完整保留。', '', '主要结果表：potential_fit_comparison.csv、solid_harmonic_comparison.csv、replay_and_years.csv、HAC_sensitivity.csv、block_bootstrap.csv、MA1_conditional_coverage.csv、MA1_residual_adequacy.csv。正文新数字均可映射到这些文件。']
(O/'CALCULATION_REPORT_ZH.md').write_text('\n'.join(lines)+'\n')
shutil.copy2(O/'CALCULATION_REPORT_ZH.md',P/'CALCULATION_REPORT_ZH.md')
(P/'CHANGE_NOTE_ZH.md').write_text('''# v86 修改说明\n\n以 v85b 为底稿，完成新授权的受控模板对比、相关噪声敏感性和年度子集检验。\n\n- 新计算支持总体和月潮主要结论，未换主估计器、样本、权重或主图。\n- Results 加一段验证与年度结果；Discussion 收为三段，移除重复的自我解释。\n- Methods 将“当前采样尚未核验”替换为实际结果；新增实测残差依赖评估。\n- 既定摘要、Introduction、Results1 与题目逐字保留；摘要修正见独立提案，等待作者确认。\n- 四主图、四扩展图和五扩展表均保留，包括 Fig.3c 的10^-1左轴下限和 Fig.4 八期单独点。\n- 此为作者审阅版本，署名、访问和冻结摘要术语仍须作者处理；未投稿。\n''')
source=Path('/home/room115/gravitation-whsh/final_candidates/A_v81_integration')
mapfiles={'design.npz':'data/design.npz','primary_rows.csv':'data/primary_rows.csv','RESULTS.json':'data/RESULTS.json','template.csv':'sources/frozen_v72/template.csv','constituents.csv':'sources/frozen_v72/constituents.csv','FULL_TIDE.json':'segment_reduction/FULL_TIDE.json'}
manifest=[]
for name,rel in mapfiles.items():
 src=source/rel;dst=O/'inputs'/name
 assert src.read_bytes()==dst.read_bytes()
 manifest.append({'source':str(src),'copy':str(dst.relative_to(O)),'sha256':hashlib.sha256(src.read_bytes()).hexdigest()})
(O/'SOURCE_MAP.json').write_text(json.dumps(manifest,indent=2))
import numpy,scipy,pyTMD,astropy,jplephem,erfa,matplotlib
(O/'SOFTWARE.json').write_text(json.dumps({k:v for k,v in [('python',platform.python_version()),('numpy',numpy.__version__),('pandas',pd.__version__),('scipy',scipy.__version__),('pyTMD',pyTMD.__version__),('astropy',astropy.__version__),('jplephem',jplephem.__version__),('pyerfa',erfa.__version__),('matplotlib',matplotlib.__version__)]},indent=2))
print('report written')
