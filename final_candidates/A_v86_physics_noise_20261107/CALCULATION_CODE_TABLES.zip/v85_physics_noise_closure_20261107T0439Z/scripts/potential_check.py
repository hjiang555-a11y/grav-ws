"""Independent DE430 tide-generating potential; controlled frozen-window comparisons.

This is not a declaration of complete IERS implementation. Existing displacement
is retained in one branch; harmonic frequency response is an explicit sensitivity.
"""
from pathlib import Path
import sys,json,hashlib,platform
import numpy as np
import pandas as pd
from scipy import special
from astropy.time import Time
from astropy.coordinates import EarthLocation
from astropy.utils import iers
iers.conf.auto_download=False
from jplephem.spk import SPK
import erfa,pyTMD
from pyTMD import earth,constituents
O=Path(__file__).resolve().parents[1];sys.path.insert(0,str(O/'vendor'))
import template
from core import estimate,serial,centred
R=Path('/home/room115/gravitation-whsh')
ephem=Path('/data/AI_Research/projects/gravitation-whsh/r3_template_fix_20261104T074117Z/research/nature-v17-reproduction/local/r3b_inputs/de430_20250801_20261001.bsp')
solid_path=R/'research/tidal-spring/data/solid/solid_tide_sop.csv'
assert hashlib.sha256(ephem.read_bytes()).hexdigest()=='4af7e3876011e8706fbac16fe36c69f71ed1d8eb1674b98bff57c1bbe082b33c'
df=pd.read_csv(solid_path,dtype={'timestamp_bjt':str})
grid=(pd.to_datetime(df.timestamp_bjt,format='%Y%m%d%H%M%S').to_numpy().astype('datetime64[s]').astype('int64')-28800).astype(float)
old=df.solid_tide_wuh_sha.to_numpy()*1e18
# Inherited constituent extraction uses common solid/loading/total extent.
# Solid source has one extra trailing 90-s point outside that common range.
grid=grid[:-1];old=old[:-1]
assert np.all(np.diff(grid)>0)
d=np.load(O/'inputs/design.npz');t=d['seconds'];rows=pd.read_csv(O/'inputs/primary_rows.csv');b=pd.read_csv(O/'inputs/template.csv');c=pd.read_csv(O/'inputs/constituents.csv')
b=rows[['t_utc']].merge(b,on='t_utc',how='left',validate='many_to_one',sort=False)
np.testing.assert_allclose(np.interp(t,grid,old),b.solid,atol=2e-12,rtol=0)
# Exact same sparse hourly harmonic grid and eight + nine absorber columns as inherited design.
names=template.CONSTITUENTS+template.ABSORBER_CONSTITUENTS
ix=np.arange(0,len(grid),40);tg=grid[ix]
B=template._design(tg,names);pinv=np.linalg.pinv(B)
oldcoef=pinv@old[ix];oldC=oldcoef[1:].reshape(-1,2)[:,0]+1j*oldcoef[1:].reshape(-1,2)[:,1]
np.testing.assert_allclose(oldC[:8].real,c.solid_real,atol=2e-8,rtol=0)
np.testing.assert_allclose(oldC[:8].imag,c.solid_imag,atol=2e-8,rtol=0)
C_LIGHT=299792458.;gms={'moon':4.902800118e12,'sun':1.32712440018e20}
sites={n:np.array([v.to_value('m') for v in EarthLocation(lat=lat,lon=lon,height=h).geocentric]) for n,lat,lon,h in [('wuhan',30.529,114.357,50.),('shanghai',31.130,121.570,20.)]}
kernel=SPK.open(str(ephem));ext={2:np.zeros(len(grid)),3:np.zeros(len(grid))};orth=0.
for lo in range(0,len(grid),12000):
 hi=min(lo+12000,len(grid));utc=Time(grid[lo:hi],format='unix',scale='utc');tt=utc.tt;tdb=utc.tdb
 rot=erfa.c2t06a(tt.jd1,tt.jd2,utc.jd1,utc.jd2,np.zeros(hi-lo),np.zeros(hi-lo))
 orth=max(orth,float(abs(np.einsum('nij,nkj->nik',rot,rot)-np.eye(3)).max()))
 earthpos=kernel[3,399].compute(tdb.jd1,tdb.jd2).T*1000
 xyz={'moon':kernel[3,301].compute(tdb.jd1,tdb.jd2).T*1000-earthpos,'sun':(kernel[0,10].compute(tdb.jd1,tdb.jd2)-kernel[0,3].compute(tdb.jd1,tdb.jd2)).T*1000-earthpos}
 for body,vec in xyz.items():
  vec=np.einsum('nij,nj->ni',rot,vec);dist=np.linalg.norm(vec,axis=1);u=vec/dist[:,None]
  for site,pos in sites.items():
   rad=np.linalg.norm(pos);cosz=u@(pos/rad);sign=1 if site=='wuhan' else -1
   for n in [2,3]:ext[n][lo:hi]+=-sign*gms[body]*rad**n/dist**(n+1)*special.eval_legendre(n,cosz)/C_LIGHT**2*1e18
 print('direct potential rows',hi,flush=True)
assert orth<1e-12
# Complex k has exp(+i omega t) convention: conjugate for inherited exp(-i phi).
# k-frequency correction to nominal induced potential, displacement retained exactly.
knom=.3010;gamma=1+knom-.6078
allnames=names+['sa','ssa']
BX=template._design(tg,allnames);bc=np.linalg.lstsq(BX,ext[2][ix],rcond=None)[0];EC=bc[1:].reshape(-1,2);EC=EC[:,0]+1j*EC[:,1]
response=[];corrk=np.zeros(len(grid));corrg=np.zeros(len(grid))
phase,factor=template._arguments(grid,allnames)
for j,n in enumerate(allnames):
 omega=constituents._constituent_parameters(n.lower())[2]
 h,k,l=earth.complex_love_numbers(omega)
 ck=np.conj(k)-knom;cg=np.conj(1+k-h)-gamma
 corrk+=factor[:,j]*np.real(ck*EC[j]*np.exp(-1j*phase[:,j]))
 corrg+=factor[:,j]*np.real(cg*EC[j]*np.exp(-1j*phase[:,j]))
 response.append(dict(name=n,omega_rad_s=omega,h_real=h.real,h_imag=h.imag,k_real=k.real,k_imag=k.imag))
variants={'inherited_conversion':old,
 'direct_uniform_n23':gamma*ext[2]+(1+.093-.292)*ext[3],
 'direct_k_nominal_retained_displacement':(1+knom)*ext[2]+(1+.093)*ext[3]-old*.6078/gamma,
 'direct_k_frequency_retained_displacement':(1+knom)*ext[2]+(1+.093)*ext[3]+corrk-old*.6078/gamma,
 'direct_hk_frequency_n23':gamma*ext[2]+(1+.093-.292)*ext[3]+corrg}
pd.DataFrame(response).to_csv(O/'results/love_response.csv',index=False)
pd.DataFrame({'t_utc':rows.t_utc,**{k:np.interp(t,grid,v) for k,v in variants.items()}}).to_csv(O/'results/solid_variants_at_bins.csv',index=False)
res={};tab=[];ph=[];designs={};harm=[]
for name,solid in variants.items():
 sc=pinv@solid[ix];C=sc[1:].reshape(-1,2);C=C[:,0]+1j*C[:,1]
 cc=c.copy();cc.solid_real=C[:8].real;cc.solid_imag=C[:8].imag
 aligned=b.copy();aligned.solid=np.interp(t,grid,solid);aligned.total=aligned.solid+aligned.loading
 # Avoid pandas-version timestamp resolution ambiguity: construct using explicit UTC seconds.
 pp,ff=template._arguments(t,template.CONSTITUENTS);combined=C[:8]+c.loading_real.to_numpy()+1j*c.loading_imag.to_numpy()
 wave=ff*np.real(combined[None,:]*np.exp(-1j*pp));three=np.c_[wave[:,[0,2]].sum(1),wave[:,[1,3]].sum(1),wave[:,4:].sum(1)]
 fixed=aligned.total.to_numpy()-three.sum(1);quad=np.sum(ff[:,[0,2]]*np.real(1j*combined[[0,2]]*np.exp(-1j*pp[:,[0,2]])),axis=1)
 if name=='inherited_conversion':
  np.testing.assert_allclose(three,d['three'],atol=5e-8,rtol=0);np.testing.assert_allclose(fixed,d['fixed'],atol=5e-8,rtol=0)
 args=[d['sigma'],d['seg'],d['days'],d['period']]
 full=estimate(aligned.total.to_numpy()[:,None],rows.y.to_numpy(),*args)
 group=estimate(three,rows.y.to_numpy()-fixed,*args)
 iq=estimate(np.c_[three[:,0],quad,three[:,1:]],rows.y.to_numpy()-fixed,*args)
 res[name]=dict(full=full,group=group,phase=iq)
 for model,e,labels in [('full',full,['AT']),('groups',group,['AL','AS','AD']),('phase',iq,['I','Q','AS','AD'])]:
  for j,label in enumerate(labels):tab.append(dict(variant=name,model=model,parameter=label,A=e['A'][j],SE=e['reported_SE'][j],SE_day=e['day_JK'][j],SE_period=e['period_JK'][j]))
 for j,n in enumerate(names):harm.append(dict(variant=name,constituent=n,amplitude=abs(C[j]),ratio_to_inherited=abs(C[j]/oldC[j]),phase_relative_degrees=np.angle(C[j]/oldC[j],deg=True)))
 designs[name+'_three']=three;designs[name+'_fixed']=fixed
 print(name,'AT',full['A'],'groups',group['A'],flush=True)
np.savez_compressed(O/'results/template_designs.npz',**designs)
pd.DataFrame(tab).to_csv(O/'results/potential_fit_comparison.csv',index=False);pd.DataFrame(harm).to_csv(O/'results/solid_harmonic_comparison.csv',index=False)
source=[ephem,solid_path,R/'research/tidal-spring/make_sop_template.py',Path(earth.__file__),Path(__file__)]
result=dict(status='CONTROLLED_SAME_SUPPORT_POTENTIAL_COMPARISON',fits=res,reference_paths=[{'path':str(f),'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in source],sites_ITRS_m=sites,pyTMD=pyTMD.__version__,earth_rotation='ERFA c2t06a; UT1 approximated UTC; polar motion zero',harmonic_frequencies=allnames,reference_equations='IERS 2010 ch6 6.9-6.12; ch7 response and existing pysolid displacements',limitations=['Finite harmonic k/h frequency correction, not complete IERS implementation certification','Ocean loading held fixed, not recomputed','Retained-displacement branch shares the original pysolid displacement; independent of its conversion to potential','50/20 m site heights for direct potential; pysolid original does not use site heights','Uniform degree3 response; no degree4 induced potential; no observed UT1/polar motion'],rotation_orthogonality_error=orth)
(O/'results/POTENTIAL_RESULTS.json').write_text(json.dumps(result,indent=2,default=serial))
