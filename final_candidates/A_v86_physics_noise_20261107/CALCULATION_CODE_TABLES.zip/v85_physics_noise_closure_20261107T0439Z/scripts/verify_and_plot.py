from pathlib import Path
import sys,json,hashlib
import numpy as np,pandas as pd
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=Path(__file__).resolve().parents[1];sys.path.insert(0,str(O/'vendor'))
from core import fit,centred
D=np.load(O/'inputs/design.npz');S=D['three'];sig=D['sigma'];seg=D['seg'];tests=[]
def check(n,v):
 assert v,n;tests.append({'test':n,'passed':True})
f=fit(S,D['y'],sig,seg);rng=np.random.default_rng(312)
# Recover a joint physical injection plus arbitrary nuisance levels exactly.
labels,ix=np.unique(seg,return_inverse=True);b=np.array([.62,1.31,-.48]);yy=S@b+rng.normal(0,100,len(labels))[ix]
check('noiseless physical coefficients with arbitrary 54 levels',np.max(abs(fit(S,yy,sig,seg)['beta']-b))<1e-11)
check('54 level shifts annihilated',np.max(abs(fit(S,D['y']+rng.normal(0,100,len(labels))[ix],sig,seg)['beta']-f['beta']))<1e-11)
check('analytic covariance agrees with explicit full QR',np.max(abs(f['cov']-np.linalg.inv((np.c_[S,seg[:,None]==labels]/sig[:,None]).T@(np.c_[S,seg[:,None]==labels]/sig[:,None]))[:3,:3]*f['scale']))<1e-10)
manifest=json.loads((O/'INPUT_MANIFEST.json').read_text());check('copied inputs unchanged',all(hashlib.sha256(Path(a['path']).read_bytes()).hexdigest()==a['sha256'] for a in manifest))
t=np.load(O/'results/template_designs.npz');check('reference template exactly replays frozen design',np.max(abs(t['inherited_conversion_three']-S))<5e-8)
# Correlation/PSD test of actual nonstationary MA1 construction, no empirical re-selection.
p=pd.read_csv(O/'results/empirical_MA1_parameters.csv');check('MA1 implied correlations feasible',np.max(abs(p.lag1_HC2))<.5)
c=pd.read_csv(O/'results/MA1_conditional_coverage.csv');check('simulation point bias below 0.1 standard error',np.max(abs(c.simulated_bias)/c.empirical_SE)<.1)
(O/'verification/TEST_RESULTS.json').write_text(json.dumps(tests,indent=2))
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
fits=pd.read_csv(O/'results/potential_fit_comparison.csv');keys=list(fits.variant.unique());short=['Inherited conversion','Direct, uniform response','Direct + retained displacement','Frequency k + displacement','Frequency h and k']
fig,axs=plt.subplots(1,3,figsize=(11,3.6),sharey=True)
for ax,par in zip(axs,['AT','AL','AS']):
 a=fits[(fits.parameter==par)&(fits.model!='phase')].set_index('variant').loc[keys]
 ax.errorbar(a.A,np.arange(5),xerr=a.SE,fmt='o',capsize=3,color='#2166ac');ax.axvline(1,color='.65',lw=1)
 ax.set_title({'AT':'Full tidal response','AL':'Lunar semidiurnal group','AS':'Neighbouring semidiurnal group'}[par]);ax.set_xlabel('Response coefficient (one reported SE)')
axs[0].set_yticks(range(5),short);axs[0].invert_yaxis();fig.tight_layout()
for ext in ['png','pdf','svg']:fig.savefig(O/f'figures/template_sensitivity.{ext}',dpi=180,bbox_inches='tight')
plt.close(fig)
a=pd.read_csv(O/'results/residual_acf.csv');h=pd.read_csv(O/'results/HAC_sensitivity.csv');bb=pd.read_csv(O/'results/block_bootstrap.csv');fig,axs=plt.subplots(1,2,figsize=(10.5,3.7))
for pp,color in [('all','black'),('P1','#b2182b'),('P8','#2166ac')]:
 z=a[a.period==pp];axs[0].plot(z.lag_s/3600,z.correlation,'o-',ms=3,label=pp,color=color)
axs[0].set_xscale('log');axs[0].axhline(0,color='.6',lw=.7);axs[0].set_xlabel('True within-run lag (h)');axs[0].set_ylabel('Residual correlation');axs[0].legend(frameon=False)
for par,col in [('AT','#2166ac'),('AL','#d6604d'),('AS','#4d9221')]:
 z=h[(h.parameter==par)&(h.bandwidth_hours>0)];b=bb[bb.parameter==par]
 axs[1].plot(z.bandwidth_hours,z.SE,'o-',color=col,label=par+' time-HAC');axs[1].plot(b.block_hours,b.SE,'s--',color=col,label=par+' run bootstrap')
axs[1].set_xlabel('Bandwidth or requested block duration (h)');axs[1].set_ylabel('Coefficient standard error');axs[1].legend(ncol=2,fontsize=8,frameon=False);fig.tight_layout()
for ext in ['png','pdf','svg']:fig.savefig(O/f'figures/noise_sensitivity.{ext}',dpi=180,bbox_inches='tight')
print(json.dumps(tests))
