"""Frozen-bin WLS replay and residual dependence sensitivity; no raw-data changes."""
from pathlib import Path
import json,sys,platform,hashlib
import numpy as np
import pandas as pd
import scipy
O=Path(__file__).resolve().parents[1];sys.path.insert(0,str(O/'vendor'))
from core import fit,estimate,serial
D=np.load(O/'inputs/design.npz');R=pd.read_csv(O/'inputs/primary_rows.csv')
t=D['seconds'];sig=D['sigma'];seg=D['seg'];days=D['days'];period=D['period'];three=D['three']
y=R.y.to_numpy(); fixed=D['fixed'];full=(three.sum(1)+fixed)[:,None]
assert len(y)==3299 and len(np.unique(seg))==54
# Exact 600 s links inside an original segment define uninterrupted runs.
breaks=np.r_[True,(seg[1:]!=seg[:-1]) | (abs(np.diff(t)-600)>1e-5)]
run=np.cumsum(breaks); runs=[np.flatnonzero(run==r) for r in np.unique(run)]
records=[];fitters={};base={}
for name,S,yy in [('full',full,y),('groups',three,y-fixed)]:
 f=fit(S,yy,sig,seg);fitters[name]=f;base[name]=estimate(S,yy,sig,seg,days,period)
 for scope,k in [('all',np.ones(len(y),bool)),('2025',pd.to_datetime(R.t_utc,utc=True).dt.year.to_numpy()==2025),('2026',pd.to_datetime(R.t_utc,utc=True).dt.year.to_numpy()==2026)]:
  e=estimate(S[k],yy[k],sig[k],seg[k],days[k],period[k]);
  for j,lab in enumerate(['AT'] if name=='full' else ['AL','AS','AD']):
   records.append(dict(model=name,scope=scope,parameter=lab,A=e['A'][j],SE_LS=e['scaled_LS'][j],SE_day_JK=e['day_JK'][j],SE_period_JK=e['period_JK'][j],SE_reported=e['reported_SE'][j],rows=e['n'],days=e['n_days']))
pd.DataFrame(records).to_csv(O/'results/replay_and_years.csv',index=False)
old=json.loads((O/'inputs/RESULTS.json').read_text());oldf=json.loads((O/'inputs/FULL_TIDE.json').read_text())
np.testing.assert_allclose(base['groups']['A'],old['primary']['A'],atol=1e-10,rtol=0)
np.testing.assert_allclose(base['groups']['reported_SE'],old['primary']['u'],atol=1e-10,rtol=0)
np.testing.assert_allclose(base['full']['A'],[oldf['A']],atol=1e-10,rtol=0)
# Full-column QR independently verifies the eliminated-intercept implementation.
Z=(seg[:,None]==np.unique(seg)[None,:]).astype(float)
for name,S,yy in [('full',full,y),('groups',three,y-fixed)]:
 X=np.c_[S,Z]/sig[:,None];Q,RR=np.linalg.qr(X,mode='reduced');b=np.linalg.solve(RR,Q.T@(yy/sig))
 np.testing.assert_allclose(b[:S.shape[1]],fitters[name]['beta'],atol=1e-10,rtol=0)
# Correlation at exact lags and a residual Allan-type statistic, never joined data.
acf=[];adev=[];f=fitters['groups'];z=f['residual']/sig
for pp in ['all']+list(np.unique(period)):
 for lag in [1,2,3,6,12,18,36,72]:
  i=np.arange(len(z)-lag);j=i+lag;valid=(run[i]==run[j]) & (abs(t[j]-t[i]-600*lag)<1e-5)
  if pp!='all':valid &= period[i]==pp
  a,b=z[i[valid]],z[j[valid]]
  acf.append(dict(period=pp,lag_s=600*lag,pairs=len(a),correlation=np.corrcoef(a,b)[0,1] if len(a)>3 else np.nan,structure_function=np.mean((b-a)**2)/2 if len(a) else np.nan))
 for m in [1,2,3,6,12,18,36,72]:
  diffs=[]
  for ids in runs:
   if pp!='all' and period[ids[0]]!=pp:continue
   if len(ids)<2*m:continue
   a=f['residual'][ids];s=np.r_[0,np.cumsum(a)];means=(s[m:]-s[:-m])/m;diffs.extend(means[m:]-means[:-m])
  adev.append(dict(period=pp,tau_s=m*600,pairs=len(diffs),residual_allan_e18=np.sqrt(np.mean(np.asarray(diffs)**2)/2) if len(diffs) else np.nan))
pd.DataFrame(acf).to_csv(O/'results/residual_acf.csv',index=False);pd.DataFrame(adev).to_csv(O/'results/residual_allan.csv',index=False)
# Sandwich covariance: real-time Bartlett kernel inside each operating period.
hac=[];boot=[];rng=np.random.default_rng(2026110744);B=2000
for name,f in fitters.items():
 S=full if name=='full' else three;p=S.shape[1];H=f['H'];res=f['residual'];scores=H*res[None,:]
 for hours in [0,1,3,6,12,24]:
  C=scores@scores.T
  if hours:
   for ids in [np.flatnonzero(period==pp) for pp in np.unique(period)]:
    for ii,i in enumerate(ids):
     js=ids[ii+1:];js=js[t[js]-t[i]<hours*3600]
     if len(js):
      a=scores[:,i];b=scores[:,js]@(1-(t[js]-t[i])/(hours*3600));C+=np.outer(a,b)+np.outer(b,a)
  C*=len(y)/f['df'];assert np.linalg.eigvalsh(C).min()>-1e-8
  for j,lab in enumerate(['AT'] if name=='full' else ['AL','AS','AD']):hac.append(dict(model=name,parameter=lab,bandwidth_hours=hours,SE=np.sqrt(C[j,j])))
 # HC2 residuals: removes diagonal shrinkage only, not a physical noise model.
 wc=1/sig**2;h=np.sum(H.T*S,axis=1) # H*S not valid for intercept leverage, use centered S instead.
 from core import centred
 Sc=centred(S,sig,seg);h=np.sum(H.T*Sc,axis=1)
 for ids in [np.flatnonzero(seg==ss) for ss in np.unique(seg)]:h[ids]+=wc[ids]/wc[ids].sum()
 assert np.all((h>=0)&(h<1))
 e=res/sig/np.sqrt(1-h)
 for hours in [1,3,6,12]:
  L=int(hours*6);errs=np.zeros((len(y),B));effective=[]
  for ids in runs:
   n=len(ids);l=min(L,n);effective.append(l)
   # Circular blocks stay inside their actual continuous run. Repetition is only synthetic.
   starts=rng.integers(0,n,size=(int(np.ceil(n/l)),B));ix=((starts[:,None,:]+np.arange(l)[None,:,None])%n).reshape(-1,B)[:n]
   errs[ids]=e[ids[ix]]*sig[ids,None]
  delta=H@errs
  for j,lab in enumerate(['AT'] if name=='full' else ['AL','AS','AD']):
   centered=delta[j]-delta[j].mean();q=np.quantile(centered,[.025,.975]);bhat=f['beta'][j]
   boot.append(dict(model=name,parameter=lab,block_hours=hours,draws=B,SE=np.std(delta[j],ddof=1),mean_delta=np.mean(delta[j]),basic_low=bhat-q[1],basic_high=bhat-q[0],requested_block_bins=L,median_effective_block_bins=np.median(effective)))
  print(name,hours,'bootstrap completed',flush=True)
pd.DataFrame(hac).to_csv(O/'results/HAC_sensitivity.csv',index=False);pd.DataFrame(boot).to_csv(O/'results/block_bootstrap.csv',index=False)
R[['t_utc','seg','period','n']].assign(residual_e18=f['residual'],standardized_residual=f['residual']/sig,run=run).to_csv(O/'results/residual_rows.csv',index=False)
summary=dict(status='EXECUTED_FROZEN_BIN_REPLAY_AND_DEPENDENCE_SENSITIVITY',n=3299,continuous_runs=len(runs),seed=2026110744,bootstrap_draws=B,software=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__),base=base,limitations=['No raw-counter reconstruction in this test','HAC and residual-block intervals are dependence sensitivities, not externally calibrated total uncertainties','Finite run lengths truncate blocks; no missing observations filled','Post-fit residual stability is not absolute-clock or joined-level long-term stability'])
(O/'results/NOISE_RESULTS.json').write_text(json.dumps(summary,indent=2,default=serial))
print(pd.DataFrame(records).to_string(index=False));print(pd.DataFrame(hac).to_string(index=False))
