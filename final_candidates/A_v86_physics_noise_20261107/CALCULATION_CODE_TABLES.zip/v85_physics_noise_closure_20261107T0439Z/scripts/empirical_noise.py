"""A data-matched MA(1) residual benchmark, with parameters frozen before simulation.
Not proof of an instrumental mechanism; keep primary estimator unchanged.
"""
from pathlib import Path
import sys,json
import numpy as np,pandas as pd
from scipy.linalg import cholesky_banded
O=Path(__file__).resolve().parents[1];sys.path.insert(0,str(O/'vendor'))
from core import fit,centred,serial
D=np.load(O/'inputs/design.npz');R=pd.read_csv(O/'inputs/primary_rows.csv')
t=D['seconds'];sig=D['sigma'];seg=D['seg'];days=D['days'];period=D['period'];S=D['three'];y=D['y'];N=len(y)
continuous=np.r_[False,(seg[1:]==seg[:-1]) & (abs(np.diff(t)-600)<1e-5)]
f=fit(S,y,sig,seg);Sc=centred(S,sig,seg);h=(f['H'].T*Sc).sum(1);w=1/sig**2
for ss in np.unique(seg):
 ids=np.flatnonzero(seg==ss);h[ids]+=w[ids]/w[ids].sum()
e=f['residual']/sig/np.sqrt(1-h)
parameters=[];rho=np.zeros(N);scale=np.zeros(N)
for pp in np.unique(period):
 ix=np.flatnonzero(period==pp);a=ix[continuous[ix]];corr=np.corrcoef(e[a-1],e[a])[0,1];v=np.mean(e[ix]**2)
 assert abs(corr)<.49
 rho[ix]=corr;scale[ix]=np.sqrt(v)
 parameters.append(dict(period=pp,lag1_HC2=corr,scale_std=np.sqrt(v),n=len(ix),pairs=len(a),MA1_theta=(1-np.sqrt(1-4*corr*corr))/(2*corr)))
pd.DataFrame(parameters).to_csv(O/'results/empirical_MA1_parameters.csv',index=False)
# Unit diagonal, adjacent covariance rho only within true 600-s runs.
cb=np.zeros((2,N));cb[0]=1;cb[1,:-1]=np.where(continuous[1:],rho[1:],0)
L=cholesky_banded(cb,lower=True)
B=2000;rng=np.random.default_rng(2026110745);u=rng.standard_normal((N,B));z=L[0,:,None]*u;z[1:]+=L[1,:-1,None]*u[:-1];eps=z*scale[:,None]*sig[:,None]
allout={};checks=[]
for name,T,obs in [('full',(S.sum(1)+D['fixed'])[:,None],R.y.to_numpy()),('groups',S,y)]:
 ff=fit(T,obs,sig,seg);H=ff['H'];beta=ff['beta'];error=H@eps
 # Residual projection including original 54 intercepts.
 noise=eps-T@error
 for ss in np.unique(seg):
  ii=np.flatnonzero(seg==ss);noise[ii]-=np.average(noise[ii],axis=0,weights=w[ii])
 scatter=np.sum((noise/sig[:,None])**2,axis=0)/ff['df']
 ls=np.sqrt(np.diag(ff['C0'])[:,None]*scatter)
 operators=[]
 for day in np.unique(days):
  keep=days!=day;hh=fit(T[keep],obs[keep],sig[keep],seg[keep])['H'];hhfull=np.zeros_like(H);hhfull[:,keep]=hh;operators.append(hhfull)
 delete=(np.asarray(operators).reshape(-1,N)@eps).reshape(len(operators),T.shape[1],B)
 delete-=delete.mean(0);jk=np.sqrt((len(operators)-1)/len(operators)*np.sum(delete**2,axis=0));mx=np.maximum(ls,jk)
 labels=['AT'] if name=='full' else ['AL','AS','AD']
 for j,label in enumerate(labels):
  q=np.quantile(error[j],[.025,.975]);checks.append(dict(model=name,parameter=label,simulated_bias=np.mean(error[j]),empirical_SE=np.std(error[j],ddof=1),mean_LS_SE=np.mean(ls[j]),mean_day_JK_SE=np.mean(jk[j]),mean_max_SE=np.mean(mx[j]),coverage_LS95=np.mean(abs(error[j])<=1.96*ls[j]),coverage_dayJK95=np.mean(abs(error[j])<=1.96*jk[j]),coverage_max95=np.mean(abs(error[j])<=1.96*mx[j]),conditional_interval_low=beta[j]-q[1],conditional_interval_high=beta[j]-q[0]))
 if name=='groups':
  ac=[];zz=noise/sig[:,None]
  for lag in [1,2,3,6]:
   ii=np.arange(N-lag);jj=ii+lag;ok=(seg[ii]==seg[jj]) & (abs(t[jj]-t[ii]-lag*600)<1e-5)
   a=zz[ii[ok]];b=zz[jj[ok]];a-=a.mean(0);b-=b.mean(0);corr=np.sum(a*b,axis=0)/np.sqrt(np.sum(a*a,axis=0)*np.sum(b*b,axis=0))
   oa=f['residual'][ii[ok]]/sig[ii[ok]];ob=f['residual'][jj[ok]]/sig[jj[ok]];observed=np.corrcoef(oa,ob)[0,1]
   ac.append(dict(lag_bins=lag,observed=observed,simulation_median=np.median(corr),q025=np.quantile(corr,.025),q975=np.quantile(corr,.975)))
  pd.DataFrame(ac).to_csv(O/'results/MA1_residual_adequacy.csv',index=False)
  # Studentization and tail adequacy, independent of coefficient significance.
  zobs=f['residual']/sig;obs_tail=np.mean(abs(zobs)>3*np.std(zobs));sim_tail=np.mean(abs(zz)>3*np.std(zz,axis=0),axis=0)
  allout['tail_diagnostic']=dict(observed_fraction_over3sd=obs_tail,q025=np.quantile(sim_tail,.025),q975=np.quantile(sim_tail,.975))
 print(name,'MA1 conditional calibration complete',flush=True)
pd.DataFrame(checks).to_csv(O/'results/MA1_conditional_coverage.csv',index=False)
allout.update(seed=2026110745,draws=B,parameters=parameters,scope='Fitted empirical period-specific MA1 benchmark; zero correlation beyond lag one before projection, Gaussian innovations. Parameters estimated from HC2 group residuals. Simulation coverage is conditional, not a validation of the true physical noise model.',coverage=checks)
(O/'results/EMPIRICAL_MA1.json').write_text(json.dumps(allout,indent=2,default=serial))
print(pd.DataFrame(checks).to_string(index=False))
