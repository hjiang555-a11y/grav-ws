from pathlib import Path
import shutil,re,json,hashlib,difflib
R=Path('/home/room115/gravitation-whsh');O=Path(__file__).resolve().parents[1]
B=R/'final_candidates/A_v85b_spectrum_range_20261107';P=R/'final_candidates/A_v86_physics_noise_20261107';P.mkdir()
for n in ['figures','notes']: (P/n).mkdir()
for f in (B/'figures').iterdir():
 if f.suffix in ['.png','.pdf','.svg']:shutil.copy2(f,P/'figures'/f.name)
for n in ['render_candidate.py','layout_working.lua']:shutil.copy2(R/'final_candidates/A_v85_formal_20261107'/n,P/n)
src=B/'NATURE_ARTICLE_A_v85b.md';old=src.read_text();s=old
# Frozen title, summary, Introduction and Results1 are preserved exactly.
oldp="""The overall tidal waveform contains nearby astronomical components whose relative phase changes across the observing dates. We jointly estimate three physical groups, retaining the predicted phases and relative amplitudes within each group. The lunar semidiurnal group contains M₂ and N₂. The neighbouring semidiurnal group contains S₂, the principal solar tide, and K₂, which has both lunar and solar forcing. The approximately daily constituents form an auxiliary group, allowing their correlations with the semidiurnal terms to remain in the joint estimate."""
newp="""The tidal waveform contains nearby astronomical components whose relative phase changes across the observing dates. We estimate their responses in three physical groups, retaining the predicted phases and relative amplitudes within each group. M₂ and N₂ form the lunar semidiurnal group; S₂, the principal solar tide, and the lunisolar constituent K₂ form the neighbouring group. The approximately daily constituents remain as an auxiliary group in the joint model."""
assert oldp in s;s=s.replace(oldp,newp)
oldp="""The lunar and neighbouring responses are $A_L=1.00\\pm0.13$ and $A_S=0.93\\pm0.36$, respectively (Fig. 3a). Their scaled least-squares correlation is −0.30. These two coefficients describe separate responses of the prescribed groups, with the lunar amplitude more tightly constrained. The full-template and grouped estimates use the same observations but answer different questions. The former scales the entire prediction, including minor constituents; the latter holds the minor remainder fixed and estimates the three group responses simultaneously. We keep these estimates separate."""
newp="""The lunar and neighbouring responses are $A_L=1.00\\pm0.13$ and $A_S=0.93\\pm0.36$, respectively (Fig. 3a), with a scaled least-squares correlation of −0.30. The lunar response provides the more precise component measurement. Both are estimated from the same record as the overall response, using a grouped model that fixes the minor-constituent remainder rather than scaling the entire waveform."""
assert oldp in s;s=s.replace(oldp,newp)
oldp="""Each of the eight observing periods provides a separate estimate of the lunar and neighbouring responses (Fig. 4). All periods are shown with their full error ranges. The broad intervals in shorter records expose the limited information available when only part of the relative tidal phase is observed. Combining the periods uses their actual timing and noise weights in one common physical fit; it is not a simple average of the eight plotted coefficients. The differing intervals also show why elapsed calendar time and accumulated observing time describe different aspects of the measurement."""
newp="""The eight observing periods sample different lunar–solar phases and provide individual estimates of both semidiurnal responses (Fig. 4). The intervals show their differing precision; all periods contribute to the common fit through their actual observation times and noise weights. Restricting the analysis to 2026 gives a lunar response of $1.00\\pm0.14$ and a full-template response of $0.90\\pm0.10$. The separately analysed 2025 record is less precise: its full-template response is $1.37\\pm0.53$ (Methods)."""
assert oldp in s;s=s.replace(oldp,newp)
anchor="Reference levels are retained at the segment scale because the operating records do not establish calibrated zero transfer across all relevant interruptions. The same-data comparison with eight period offsets is reported in Methods; residual patterns and period-deletion results are retained in Extended Data Fig. 3 and Table 2."
new="""The response estimates also survive checks of the solid-tide calculation and correlated errors. Replacing the displacement-derived solid template with a direct-potential calculation and frequency-dependent response gives $A_T=0.94\\pm0.11$ and $A_L=1.00\\pm0.13$, with the neighbouring coefficient unchanged at the reported precision. Residual-block and time-covariance checks give standard errors close to the reported values (Methods). Segment reference levels remain independent because calibrated zero transfer is not established across all interruptions; the alternative period-level comparison is retained in Extended Data Table 2."""
assert anchor in s;s=s.replace(anchor,new)
a=s.index('## Discussion\n');b=s.index('\\clearpage',a)
s=s[:a]+'''## Discussion

The comparison detects tidal changes in the gravitational potential difference between two fixed laboratories 692 km apart. The response to the full waveform is consistent with the combined solid-Earth and ocean-loading prediction. Within that signal, the lunar semidiurnal response agrees with the predicted amplitude and phase. The spectrum places the observed variation near the expected principal frequencies, while the joint fit estimates the responses of the two neighbouring semidiurnal groups. Together, these observations demonstrate a dynamic potential measurement through relative clock rates.

Predictable astronomical phase allows this measurement to accumulate across interruptions. Each segment records a changing rate even when its absolute frequency level is unknown. Different observing dates sample different lunar–solar phases, so the segments jointly constrain the physical waveforms without being joined by fitted level shifts. Dividing a record into shorter pieces nevertheless removes more of the slow variation when a separate mean is subtracted. The same-data reference-level comparison shows this effect most clearly for the neighbouring group. The sampling window and segment projection also shape spectral sidelobes; neither effect is equivalent to additional random instrument noise. Longer stable runs and broader astronomical phase coverage can retain more useful signal, although the present periods do not isolate their separate contributions. For an unanticipated transient, sufficient precision would instead have to be reached during the event itself.

The coastal–inland geometry makes ocean loading a substantial part of the tested waveform. Its segment-centred amplitude norm is about one-third of the combined prediction, but its near alignment with the solid contribution at M₂ limits separate estimation from this baseline. A second baseline with a different loading phase or relative amplitude would provide a more distinct geophysical signature. Independent measurements of variations near 12 hours would strengthen attribution of the neighbouring semidiurnal response. These are specific extensions of the demonstrated ability to recover periodic potential changes from distant clocks. An independent European optical-clock network has reported related tidal-potential measurements in a contemporaneous arXiv preprint.^24^

'''+s[b:]
# Replace the now-completed same-sampling caveat with executed, reproducible comparison.
a=s.index('with $h_2=0.6078$');b=s.index('\n\nFor loading,',a)
s=s[:a]+'''with $h_2=0.6078$, $k_2=0.3010$ and $g=9.794\\,\\mathrm{m/s^2}$. This approximation applies one conversion to all displacement contributions. We assessed its effect on the estimates by replacing only the solid prediction, retaining the 3,299 observations, timestamps, 54 offsets, original weights and ocean-loading series.

The comparison computes the Moon's and Sun's tide-generating potential directly from geometric DE430 positions, through spherical-harmonic degrees two and three. It uses the stated station coordinates and an ERFA terrestrial rotation. UTC is used in place of UT1 and polar motion is set to zero for this controlled comparison. Two frequency-dependent realizations distinguish the induced potential from displacement: one retains the original displacement and replaces the direct and induced potentials; the other applies frequency-dependent $1+k-h$ to the degree-two forcing. The Love-number response follows the IERS resonance prescription implemented in pyTMD 3.0.9.^22^ A constant degree-three response is retained. The common 90-s template interval is decomposed on the same hourly astronomical basis as the primary calculation; the resulting groups and minor remainder are evaluated at the unchanged bin times. Complex responses are conjugated to match the $\\exp(-i\\phi)$ convention. This finite-harmonic comparison tests the consequence of the conversion approximation; it is not a separate determination of Love numbers.

The frequency-dependent realization retaining displacement gives $(A_T,A_L,A_S)=(0.9442,1.0028,0.9249)$, with reported errors $(0.1107,0.1318,0.3656)$. The independent frequency-dependent $h,k$ realization gives $(0.9440,1.0019,0.9250)$, with errors $(0.1107,0.1317,0.3657)$. Across these and two constant-response controls, the changes from the primary estimates remain below 0.0141, 0.0036 and 0.0013, respectively. The lunar quadrature coefficient remains between $-0.097$ and $-0.094$, with an error of about 0.20. Although the alternative K₁ solid amplitude is appreciably larger, its effect on the jointly estimated semidiurnal groups is small on this sampling. The loading series is held fixed throughout; these differences therefore quantify the tested solid-template choices rather than a complete physical-model uncertainty budget.'''+s[b:]
# Add a compact executed noise and annual check; source tables in analysis archive.
anchor='Extended Data Fig. 1 gives conditional two-group regions:'
pos=s.index(anchor)
insert='''### Empirical residual dependence and annual checks

We evaluated residual dependence using true 600-s adjacency within original segments, never treating a gap as an elapsed sample. The standardized residual correlations at lags of 600, 1,200 and 1,800 s are $-0.148$, 0.011 and 0.028. Lag-one correlations are negative in all eight periods. These measurements motivate a negative short-lag covariance benchmark without assigning a specific instrumental cause.

The primary WLS coefficients remain fixed for the following uncertainty comparisons. A Bartlett time-kernel sandwich, calculated within each period using actual time differences and bandwidths of 1, 3, 6, 12 and 24 h, gives standard errors of 0.095–0.109 for $A_T$, 0.122–0.130 for $A_L$ and 0.271–0.312 for $A_S$. We also resampled HC2-adjusted standardized residuals in circular moving blocks confined to each uninterrupted 600-s run, restoring the original bin scales afterwards. Requested block lengths of 1, 3, 6 and 12 h give errors of 0.089–0.113, 0.117–0.142 and 0.262–0.299, respectively (2,000 realizations per length; seed 2026110744). Blocks are capped by run length; these resamplings test local dependence and retain the measured residual distribution.

A period-specific MA(1) benchmark sets adjacent covariance and variance from the HC2 residuals and uses Gaussian innovations. On 2,000 simulated records, the two-sided $1.96\\max(u_{\\mathrm{LS}},u_{\\mathrm{day}})$ intervals cover the generating values in 97.7%, 97.8% and 98.3% of cases for $A_T$, $A_L$ and $A_S$ (seed 2026110745). This benchmark reproduces the sign and approximate magnitude of the observed lag-one correlation, but underrepresents the residual tails and slightly misses the third-lag correlation. Its coverage is conditional on that empirical model. The block and covariance checks provide the principal assessment of sensitivity to dependence; no simulation is added to the observations or used to select points.

Separate fits to 2025 and 2026 retain each year's original segments and weights. The 366 means from 2025 give $(A_T,A_L,A_S)=(1.37,-0.18,4.25)$ with working errors $(0.53,0.84,1.97)$; the 2,933 means from 2026 give $(0.90,1.00,0.77)$ with errors $(0.10,0.14,0.35)$. The early record therefore gives a much weaker group separation, while the full-record lunar result is retained in 2026 alone. These are subset estimates, not independent replications of the full record.

'''
s=s[:pos]+insert+s[pos:]
# Update AI/reproduction version record only when present; do not claim raw replay.
s=s.replace('This narrative revision did not rerun numerical analyses.', 'The current revision includes frozen-bin numerical replay, a controlled solid-potential comparison and residual-dependence checks; it does not reconstruct the original counter reduction.')
s=s.replace('OpenAI Codex assisted English drafting, code preparation and checking, earlier numerical replay, and plotting from derived experimental tables using Python.', 'OpenAI Codex assisted English drafting, code preparation and checking, numerical replay, controlled template and noise-sensitivity calculations, and plotting from derived experimental tables using Python.').replace('This manuscript revision reorganized the existing narrative and displays without rerunning fits or data validation.', 'This revision re-estimated the tidal responses from frozen derived inputs, compared solid-potential realizations and evaluated residual dependence. Original counter selection and corrections were not reconstructed in these checks.')
# Frozen sections and unchanged figure bytes are separately checked.
assert s[:s.index('### Tidal variation in the clock record')]==old[:old.index('### Tidal variation in the clock record')]
(P/'NATURE_ARTICLE_A_v86.md').write_text(s)
(P/'notes/CHANGE.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='v85b',tofile='v86')))
(P/'STATE.json').write_text(json.dumps(dict(status='AUTHOR_REVIEW_COMPUTATION_INTEGRATED',base=str(B),analysis=str(O),abstract='Previously approved text retained verbatim; correction proposal supplied separately for author decision',frozen_sections=['title','abstract','introduction','Results1'],new_fits=True,raw_data_modified=False,submitted=False),indent=2))
proposal='''# 摘要最小修订建议（未写入冻结稿）

以下只替换现有摘要的三处结果句及最后一句；标题、背景和观测信息不改。此文件供作者确认，v86 PDF 的既定摘要仍保持原文。

1. 将 consistency 改为定义明确的响应系数：

> The measured response to the combined solid-Earth and ocean-loading prediction is 0.96 ± 0.11, where unity denotes agreement and the uncertainty is one statistical standard error.

2. 将频谱所示事实与组拟合分开，保留直接、有力的物理表述：

> The measured spectrum has peaks near the principal lunar and solar semidiurnal frequencies, at 22.361 and 23.147 μHz. A joint fit gives a lunar-group response of 1.00 ± 0.13, with phase consistent with the astronomical prediction.

3. 两个 dB 数保留在 Results/Fig.3，称为 before-and-after spectral power ratios；不在摘要中当独立仪器噪声的 SNR。

4. 结句落在已实现的测量能力：

> These measurements demonstrate the recovery of tidal changes in gravitational potential from an interrupted comparison of distant optical clocks.

不把摘要改成审稿答辩。近12小时归因边界在正文一段说明即可。
'''
(P/'ABSTRACT_CORRECTIONS_FOR_APPROVAL.md').write_text(proposal)
print(P)
