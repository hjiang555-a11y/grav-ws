# ECC verification

- Build: three numerical modules and plots executed; manuscript PDF/Word built without warnings.
- Numerical tests: 7 focused checks passed; separate complete-column QR replay passed.
- Reproduction: clean directory reran all four analysis stages; 8 result tables byte-identical.
- Input integrity: original frozen input copies and old manuscript unchanged.
- No raw observation deletion, fitting-based stitching or fabricated gap filling.
- Software environment: existing pytorch_env; recorded in SOFTWARE.json.
- Scientific scope: same frozen-bin support; full raw-counter and complete geophysical uncertainty certification are not claimed.
- Visual: all 36 manuscript pages inspected in contact sheets; new Methods pages and both new report figures inspected at larger size. Three-page report inspected.
- Target: local author-review package; no journal submission.
