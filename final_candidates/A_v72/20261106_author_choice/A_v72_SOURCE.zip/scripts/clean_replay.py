"""Run the whole numerical and text chain in a new isolated directory."""
from pathlib import Path
import shutil,subprocess,os,hashlib,json,argparse
O=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--name',default='clean_replay')
args=parser.parse_args();assert '/' not in args.name and '..' not in args.name
T=O/'verification'/args.name
T.mkdir(exist_ok=False)
for name in ['scripts','vendor','sources']:
    shutil.copytree(O/name,T/name,ignore=shutil.ignore_patterns('__pycache__'))
for name in ['manuscript_template.md','INPUT_MANIFEST.json']:shutil.copy2(O/name,T/name)
for name in ['data','verification','figures','editorial']:(T/name).mkdir()
env={**os.environ,'OPENBLAS_NUM_THREADS':'1','OMP_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
results=[]
for script in ['recompute_candidate.py','check_coverage.py','draw_candidate.py','assemble_candidate.py']:
    r=subprocess.run(['/home/room115/pytorch_env/bin/python','-B',str(T/'scripts'/script)],cwd=T,env=env,capture_output=True,text=True)
    (T/'verification'/(script+'.log')).write_text(r.stdout+r.stderr)
    assert r.returncode==0,(script,r.stderr[-2000:])
    results.append(dict(script=script,exit=0))
files=[*sorted((O/'data').glob('*.csv')),O/'data/RESULTS.json',O/'NATURE_ARTICLE_A_v72.md']
checks=[]
for f in files:
    rel=f.relative_to(O);other=T/rel
    h=hashlib.sha256(f.read_bytes()).hexdigest();h2=hashlib.sha256(other.read_bytes()).hexdigest()
    assert h==h2,str(rel)
    checks.append(dict(file=str(rel),sha256=h,byte_exact=True))
# PDF metadata timestamps differ; compare plotted SVG data geometry separately
# through the verified tables, and retain the independently regenerated figures.
out=dict(status='PASS',steps=results,files=checks,
    scope='New-directory execution; exact data, results and manuscript text replay; figures also regenerated; PDF bytes may contain new timestamps')
(O/'verification/CLEAN_REPLAY.json').write_text(json.dumps(out,indent=2))
print(json.dumps({'status':out['status'],'files':len(checks)}))
