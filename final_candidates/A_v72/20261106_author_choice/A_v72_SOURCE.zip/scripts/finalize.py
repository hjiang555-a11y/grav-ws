"""Freeze reviewed outputs and a minimal, traceable author-review package."""
from pathlib import Path
import json,hashlib,shutil,zipfile,ast,re
import fitz
O=Path(__file__).resolve().parents[1]
R=O/'release';R.mkdir(exist_ok=False)
for suffix in ['pdf','docx','tex']:
    shutil.copy2(O/'render_A_release'/('NATURE_ARTICLE_A_v72.'+suffix),R/('NATURE_ARTICLE_A_v72.'+suffix))
for name in ['NATURE_ARTICLE_A_v72.md','SELECTION_NOTE_ZH.md','COVER_LETTER.md','ANALYSIS_REPORT_ZH.md','REPRODUCE.md']:
    shutil.copy2(O/name,R/name)
shutil.copy2(O/'SELECTION_NOTE_ZH_FINAL.pdf',R/'SELECTION_NOTE_ZH.pdf')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for rec in json.loads((O/'INPUT_MANIFEST.json').read_text())['files']:
    assert sha(O/rec['copy'])==rec['sha256'] and sha(Path(rec['source']))==rec['sha256']
assert json.loads((O/'verification/CLEAN_REPLAY.json').read_text())['status']=='PASS'
assert '5 passed' in (O/'verification/pytest_final.log').read_text()
for name in ['pdf.log','docx.log']:assert not (O/'render_A_release'/name).read_text().strip()
assert not (O/'verification/selection_note_final.log').read_text().strip()
for p in (O/'scripts').glob('*.py'):ast.parse(p.read_text())
checks=json.loads((O/'verification/FIGURE_AUDIT_EXITS.json').read_text());assert all(x['exit']==0 for x in checks)
pdf=fitz.open(R/'NATURE_ARTICLE_A_v72.pdf');assert len(pdf)==17
assert len(fitz.open(R/'SELECTION_NOTE_ZH.pdf'))==1
pagechecks=[]
for i,p in enumerate(pdf):
    outside=[b[:4] for b in p.get_text('blocks') if b[0]<-1 or b[1]<-1 or b[2]>p.rect.width+1 or b[3]>p.rect.height+1]
    assert not outside and len(p.get_text())>400
    assert not re.search(r'Figure [1-6]:',p.get_text())
    pagechecks.append(dict(page=i+1,geometry='PASS',visual='REVIEWED',
        evidence='verification/release_pages/page_%02d.png'%(i+1),
        checks='readable text/math, complete figure and legend, no clipping or duplicate automatic caption'))
out=dict(status='PASS',scope='Author-choice candidate, numerical and document delivery validation; not scientific author approval',
    pages=len(pdf),chinese_note_pages=1,tests_passed=5,figure_audits=checks,
    source_preservation='90 frozen originals and copies rehashed unchanged',
    selected='S54; P8 numerical replay passes but zero-transfer evidence is absent',
    pending=['physical approximation and clock coordinates','zero-transfer/relock records if P8 is preferred',
             'v68 control membership','author and funding declarations','editor-accessible data/code location','Hou overlap and submission status'],
    static_checks={'Python_AST':'PASS','ruff':'NOT_INSTALLED_NOT_RUN','pyright':'NOT_INSTALLED_NOT_RUN','test_coverage':'NOT_MEASURED'},
    public_submission=False,B_candidate_read_or_merged=False,
    final_pdf_sha256=sha(R/'NATURE_ARTICLE_A_v72.pdf'),final_md_sha256=sha(R/'NATURE_ARTICLE_A_v72.md'))
(O/'verification/FINAL_CHECK.json').write_text(json.dumps(out,indent=2))
(O/'verification/PAGE_REVIEW.json').write_text(json.dumps(pagechecks,indent=2))
shutil.copy2(O/'verification/FINAL_CHECK.json',R/'FINAL_CHECK.json')
# No downloaded full publisher text, raw counters, duplicate replay folders,
# preliminary renders, auth material or old manuscripts in the clean source ZIP.
paths=[]
for root in ['scripts','vendor','data','figures']:
    paths.extend(p for p in (O/root).rglob('*') if p.is_file() and '__pycache__' not in str(p) and '.alignment.' not in p.name)
paths.extend([O/n for n in ['manuscript_template.md','NATURE_ARTICLE_A_v72.md','render_candidate.py','layout_working.lua','INPUT_MANIFEST.json','PLAN.md','REPRODUCE.md','ANALYSIS_REPORT_ZH.md','SELECTION_NOTE_ZH.md','COVER_LETTER.md']])
paths.extend(p for p in (O/'sources').rglob('*') if p.is_file())
paths.extend(p for p in (O/'editorial').glob('*.md'))
paths.extend(p for p in (O/'editorial').glob('*.json'))
paths.extend(p for p in (O/'verification').glob('*.json'))
paths.extend([O/'verification/pytest_final.log',O/'verification/selection_note_final.log',O/'verification/render_A_release.log'])
paths=sorted(set(paths))
manifest=[dict(file=str(p.relative_to(O)),sha256=sha(p),bytes=p.stat().st_size) for p in paths]
(R/'SOURCE_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile(R/'A_v72_SOURCE.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in paths:z.write(p,str(p.relative_to(O)))
    z.write(R/'SOURCE_MANIFEST.json','SOURCE_MANIFEST.json')
    for name in ['NATURE_ARTICLE_A_v72.pdf','NATURE_ARTICLE_A_v72.docx','NATURE_ARTICLE_A_v72.tex','SELECTION_NOTE_ZH.pdf']:
        z.write(R/name,name)
hashes={p.name:sha(p) for p in sorted(R.iterdir()) if p.is_file()}
(R/'SHA256SUMS.txt').write_text(''.join(f'{h}  {n}\n' for n,h in hashes.items()))
(O/'CURRENT_OUTPUT.json').write_text(json.dumps(dict(candidate='A_v72',pdf=str(R/'NATURE_ARTICLE_A_v72.pdf'),
    source=str(O/'NATURE_ARTICLE_A_v72.md'),editable_word=str(R/'NATURE_ARTICLE_A_v72.docx'),
    latex=str(R/'NATURE_ARTICLE_A_v72.tex'),note=str(R/'SELECTION_NOTE_ZH.pdf'),package=str(R/'A_v72_SOURCE.zip'),
    sha256=out['final_pdf_sha256'],status='COMPLETE_FOR_AUTHOR_CHOICE_NOT_SUBMITTED'),indent=2))
print(json.dumps(dict(status='PASS',pdf_pages=17,source_files=len(paths),zip_bytes=(R/'A_v72_SOURCE.zip').stat().st_size,
                     sha256=out['final_pdf_sha256']),indent=2))
