# Nature 政策及同期研究背景核验

2026-11-06 核对 Nature 官网。浏览工具遇到站点身份重定向后，使用普通 HTTPS 请求成功读取预印本政策、格式指南和两篇核光钟正式论文；本目录保留读取文本，未上传实验数据。

- **预印本与创新性**：Nature Portfolio 不把预印本发布视为既往正式发表；评估在审工作的进展时不计入预印本服务器稿件。这不免除准确引用相关研究的责任，也不按 arXiv 日期排序创新性。[官方预印本政策](https://www.nature.com/nature/editorial-policies/preprints-conference-proceedings)
- **观察样本重叠**：Nature 要求披露相关稿件，其他在审或待刊论文不能与来稿有实质性内容重叠。正文用一句说明与 Hou 的夏季观测重叠及不同研究对象；投稿信说明新问题、未重报绝对比值、不沿用原显著性，并随投稿提供相关稿和状态。仅把重叠藏在投稿信里不利于读者理解，因此本稿正文也保留一句。[Nature 编辑政策](https://www.nature.com/nature/editorial-policies)
- **Methods 与图表**：当前指南通常以 3,000 词为 Methods 的指导长度；必需时可更长，并非无条件不限长。Methods 本身不放图表，额外图表作为 Extended Data。A 稿使用四幅主图、两幅扩展图和三张扩展表。[格式指南](https://www.nature.com/nature/for-authors/formatting-guide)、[初次投稿要求](https://www.nature.com/nature/for-authors/initial-submission)

## 用户提及的欧洲和中国核光钟论文

两篇确实均于 **2026-10-07** 正式上线，并在同一期相邻刊出：

1. Toscani De Col, L. et al. *A thorium-229 optical nuclear clock with feedback loop*. **Nature 658**, 897–902 (2026). [DOI: 10.1038/s41586-026-11084-4](https://doi.org/10.1038/s41586-026-11084-4)。主要研究机构在奥地利。
2. Huang, B. et al. *A nuclear clock synchronized to 229Th*. **Nature 658**, 903–908 (2026). [DOI: 10.1038/s41586-026-11122-1](https://doi.org/10.1038/s41586-026-11122-1)。主要研究机构在中国。

这说明同期独立工作可以由编辑安排相邻刊发；它不是本潮汐稿的接收保证，也不能替代本稿的物理贡献与证据。为保持正文围绕半日潮问题，这一编辑背景留在选稿说明，不给正文添加无直接论证作用的核光钟段落。
