# Candidate A: reproduction

This package starts from immutable, archived **derived observations**. It does not fabricate missing seconds or rerun the entire counter-to-clock preprocessing chain. The raw membership audit and upstream filenames/hashes remain in `sources/frozen_v72/`; original counters are held separately. The selected estimator is S54 on the frozen R7 physical model and Allan weights. P8 is a same-input sensitivity check. The equal-weight spectrum deliberately retains the v71 design.

Use the existing scientific environment, whose versions are recorded in `verification/SOFTWARE.json`. Required programs include Pandoc and XeLaTeX; Python dependencies include NumPy, SciPy, pandas, pyTMD, matplotlib, cartopy, shapely, python-docx, tabulate, PyMuPDF and pytest. The bundled basemap avoids a network download.

Run in a fresh copy so existing review artifacts remain preserved:

```bash
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
export PYTHONDONTWRITEBYTECODE=1
/home/room115/pytorch_env/bin/python -B scripts/recompute_candidate.py
/home/room115/pytorch_env/bin/python -B scripts/check_coverage.py
/home/room115/pytorch_env/bin/python -B scripts/draw_candidate.py
/home/room115/pytorch_env/bin/python -B scripts/assemble_candidate.py
/home/room115/pytorch_env/bin/python -B -m pytest -q scripts/test_candidate.py
/home/room115/pytorch_env/bin/python -B render_candidate.py NATURE_ARTICLE_A_v72.md render_reproduced
```

`render_reproduced` must not already exist. The renderer supplies PDF, DOCX and a complete editable LaTeX source. The LaTeX file references `figures/*.pdf` relative to this project root; compile from this root, or use the included renderer. The Markdown template contains citation keys; `assemble_candidate.py` assigns references in first-appearance order and inserts computed tables.

The input-integrity test also checks the original absolute paths recorded in `INPUT_MANIFEST.json`; outside this workstation, compare the packaged copies to their hashes instead of assuming those absolute paths exist. This limitation affects the origin check, not the numerical computation.

For a second isolated full replay on this workstation:

```bash
/home/room115/pytorch_env/bin/python -B scripts/clean_replay.py --name clean_replay_new
```

The simulation seed is 2026110617. Synthetic realizations are used only for conditional coverage and are never inserted into the observed table. The spectral axis is per microhertz: multiply per-hertz density by 10⁻⁶, then potential density is c⁴ times fractional-frequency density.

The Chinese one-page selection note can be compiled with Pandoc/XeLaTeX using Noto Serif CJK SC at 11 pt and A4 margins 15 mm horizontally, 12 mm vertically. Public data/code identifiers and author declarations remain for the authors to confirm. No submission command is part of this workflow.
