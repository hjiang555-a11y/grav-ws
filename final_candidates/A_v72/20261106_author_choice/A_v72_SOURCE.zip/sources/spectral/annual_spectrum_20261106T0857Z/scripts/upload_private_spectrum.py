"""Standing user authorization: versioned manuscript/reports to private grav-ws."""
from pathlib import Path
import os,json,hashlib,subprocess,base64,datetime
O=Path(__file__).resolve().parents[1];R=O/'figures'
assert json.loads((O/'verification/FINAL_CHECK.json').read_text())['status']=='PASS_NUMERICAL_AND_FIGURE_QA'
repo='hjiang555-a11y/grav-ws';prefix='reports/annual_spectrum_codex_20261106T0857Z/'
r=subprocess.run(['gh','auth','token','--hostname','github.com','--user','hjiang555-a11y'],capture_output=True,text=True,timeout=30)
if r.returncode:raise RuntimeError('Owner authentication unavailable')
env={**os.environ,'GH_TOKEN':r.stdout.strip()}
def api(path,method='GET',body=None,raw=False):
 cmd=['gh','api',path,'--method',method]
 if body is not None:cmd+=['--input','-']
 if raw:cmd+=['-H','Accept: application/vnd.github.raw+json']
 return subprocess.run(cmd,input=None if body is None else json.dumps(body).encode(),capture_output=True,env=env,timeout=55)
r=api('repos/'+repo)
if r.returncode:raise RuntimeError('Repository query failed')
info=json.loads(r.stdout);assert info['private'] and info['full_name']==repo
branch=info['default_branch'];receipts=[]
for p in [R/'annual_spectrum_candidate.pdf',R/'annual_spectrum_candidate.png',R/'sampling_and_robustness.pdf',R/'sampling_and_robustness.png',O/'ANNUAL_SPECTRUM_REPORT.md',O/'FIGURE_CAPTIONS.md']:
 content=p.read_bytes();dest=prefix+p.name;endpoint='repos/'+repo+'/contents/'+dest;h=hashlib.sha256(content).hexdigest()
 r=api(endpoint+'?ref='+branch)
 if r.returncode==0:obj=json.loads(r.stdout);commit=None
 elif b'404' in r.stderr:
  r=api(endpoint,'PUT',{'message':'docs: add no-infill annual spectrum '+p.name,'branch':branch,'content':base64.b64encode(content).decode()})
  if r.returncode:raise RuntimeError('Upload uncertain; inspect path before retry: '+dest)
  d=json.loads(r.stdout);obj=d['content'];commit=d['commit']['sha']
 else:raise RuntimeError('Remote path query failed')
 assert obj['sha']==hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest(),'Remote differs; no overwrite'
 r=api('repos/'+repo+'/git/blobs/'+obj['sha'],raw=True)
 if r.returncode:raise RuntimeError('Readback incomplete; inspect remote: '+dest)
 raw=r.stdout
 if raw[:1]==b'{':
  d=json.loads(raw)
  if d.get('encoding')=='base64':raw=base64.b64decode(d['content'])
 assert hashlib.sha256(raw).hexdigest()==h
 receipts.append({'file':str(p.relative_to(O)),'sha256':h,'readback_sha256':h,'commit':commit,'url':f'https://github.com/{repo}/blob/{branch}/{dest}'})
 (O/'PRIVATE_DELIVERY_PROGRESS.json').write_text(json.dumps(receipts,indent=2));print('Verified private file: '+p.name,flush=True)
(O/'PRIVATE_DELIVERY.json').write_text(json.dumps({'status':'PRIVATE_SPECTRUM_REVIEW_DELIVERED','private':True,'external_submission':False,'R7_round_handoff_received':True,'primary_estimator_selected':False,'files':receipts},indent=2))
