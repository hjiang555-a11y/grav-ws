"""Check editorial scope, frozen files, references, builds and page layout."""
from pathlib import Path
import argparse
import hashlib
import json
import re

import fitz
from PIL import Image, ImageDraw
from docx import Document

O = Path(__file__).resolve().parents[1]
ap = argparse.ArgumentParser()
ap.add_argument('--render', default='render_A_v78_02')
args = ap.parse_args()
render = O / args.render
original = (O/'original/NATURE_ARTICLE_A_v77b.md').read_text()
current = (O/'NATURE_ARTICLE_A_v78.md').read_text()
baseline = json.loads((O/'original/BASELINE_MANIFEST.json').read_text())
checks = {}

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

base = Path(baseline['base'])
checks['live_originals_unchanged'] = (all(sha(base/f) == h for f,h in baseline['sha256'].items())
                                     if base.exists() else 'NOT_AVAILABLE_IN_EXTRACTED_PACKAGE')
checks['frozen_data_and_figures_byte_identical'] = all(
    sha(O/f) == h for f,h in baseline['sha256'].items() if f.startswith(('data/','figures/')))
checks['preserved_input_manuscript'] = sha(O/'original/NATURE_ARTICLE_A_v77b.md') == baseline['sha256']['NATURE_ARTICLE_A_v77b.md']
checks['preserved_input_template'] = sha(O/'original/A_v77b_manuscript_template.md') == baseline['sha256']['manuscript_template.md']
checks['results_verbatim'] = original.split('### A coastal–inland prediction')[1].split('The Shanghai–Wuhan comparison measures tidal variations')[0] == current.split('### A coastal–inland prediction')[1].split('The Shanghai–Wuhan comparison measures tidal variations')[0]
checks['references_captions_methods_endnotes_verbatim'] = original.split('## References',1)[1] == current.split('## References',1)[1]
checks['title_unchanged'] = original.splitlines()[0] == current.splitlines()[0]
checks['reference_order_unchanged'] = (json.loads((O/'editorial/REFERENCE_ORDER.json').read_text()) == json.loads((base/'editorial/REFERENCE_ORDER.json').read_text()) if base.exists() else 'BASELINE_ORDER_RETAINED_IN_UNCHANGED_REFERENCES')
checks['single_Europe_citation_at_Discussion_end'] = current.count('Independent, contemporaneous European') == 1 and current.split('## References')[0].strip().endswith('different baselines.^21^\n\n\\clearpage')
checks['two_primary_values_retained'] = r'$1.00\pm0.13$' in current.split('\\clearpage')[0] and r'$0.93\pm0.36$' in current.split('\\clearpage')[0]
counts = json.loads((O/'verification/TEXT_STRUCTURE.json').read_text())
checks['summary_and_Methods_lengths'] = counts['abstract'] <= 200 and counts['methods'] <= 3000
build = json.loads((render/'BUILD_RESULTS.json').read_text())
checks['PDF_Word_build_without_warnings'] = len(build['builds']) == 2 and all(b['exit']==0 and not b['warnings'] for b in build['builds'])
checks['no_unexpanded_numeric_tokens'] = not re.search(r'\{\{[A-Z_]+\}\}',current)

pdf = render/'NATURE_ARTICLE_A_v78.pdf'
doc = fitz.open(pdf)
checks['no_replacement_glyphs'] = all('\ufffd' not in p.get_text() for p in doc)
checks['PDF_below_initial_submission_limit'] = pdf.stat().st_size < 30_000_000
word = Document(render/'NATURE_ARTICLE_A_v78.docx')
summary = next(p for p in word.paragraphs if p.text.startswith('Gravity changes the rate'))
checks['Word_summary_double_spaced'] = (summary.paragraph_format.line_spacing or summary.style.paragraph_format.line_spacing or word.styles['Normal'].paragraph_format.line_spacing) == 2

pages = O/'verification/pages_final'
pages.mkdir(exist_ok=True)
thumbs = []
for i,page in enumerate(doc):
    pix = page.get_pixmap(matrix=fitz.Matrix(.55,.55),alpha=False)
    image = Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
    thumb = Image.new('RGB',(350,510),'#e5e5e5')
    thumb.paste(image,((350-image.width)//2,25))
    ImageDraw.Draw(thumb).text((8,6),f'Page {i+1}',fill='black')
    thumbs.append(thumb)
    if i < 7:
        page.get_pixmap(matrix=fitz.Matrix(1.25,1.25),alpha=False).save(pages/f'page_{i+1:02}.png')
canvas = Image.new('RGB',(1400,510*((len(thumbs)+3)//4)),'#bdbdbd')
for i,image in enumerate(thumbs):
    canvas.paste(image,((i%4)*350,(i//4)*510))
canvas.save(O/'verification/contact_sheet_final.png')

abstract = re.search(r'\*\*(Gravity changes.*?)\*\*',current,re.S).group(1)
intro = current.split('\\clearpage',1)[1].split('### A coastal–inland prediction')[0].strip()
discussion = current.split('The Shanghai–Wuhan comparison measures tidal variations',1)[1].split('\\clearpage',1)[0]
discussion = 'The Shanghai–Wuhan comparison measures tidal variations' + discussion.strip()
# Preserve the space after the shared opening when extracting the prose.
discussion = discussion.replace('variationsof','variations of',1)
(O/'EDITED_SECTIONS_A_v78_EN.md').write_text('## Abstract\n\n'+abstract+'\n\n## Introduction\n\n'+intro+'\n\n## Discussion\n\n'+discussion.strip()+'\n')
result = dict(status='PASS' if all(v is not False for v in checks.values()) else 'FAIL',
              scope='Editorial invariance and document build; no fits rerun',checks=checks,
              counts=counts,PDF_pages=len(doc),PDF_bytes=pdf.stat().st_size,
              manuscript_sha256=sha(O/'NATURE_ARTICLE_A_v78.md'),PDF_sha256=sha(pdf),
              results_sha256=sha(O/'data/RESULTS.json'),ready_for_external_submission=False)
(O/'verification/CONTENT_INVARIANCE.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':result['status'],'checks':len(checks),'pages':len(doc),'PDF_bytes':pdf.stat().st_size,'failed':[k for k,v in checks.items() if v is False]}))
assert result['status'] == 'PASS'
