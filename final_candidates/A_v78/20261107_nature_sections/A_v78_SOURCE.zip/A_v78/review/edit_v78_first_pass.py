"""Revise three narrative sections; keep the frozen scientific record intact."""
from pathlib import Path
import difflib
import json
import re

O = Path(__file__).resolve().parents[1]
old = (O/'original/A_v77b_manuscript_template.md').read_text()

abstract = r"""Gravity changes the rate at which clocks tick, making optical clocks probes of Earth's changing gravitational potential.[@ludlow,mehlstaubler] Resolving nearby tidal signals is difficult when clock comparisons are interrupted and restart at unknown frequency levels. Here we measure and separate neighbouring semidiurnal tidal responses using clocks in coastal Shanghai and inland Wuhan. The changing lunar–solar phase provides a reference across 545.9 hours of observations spread over 353 days. The measured spectrum shows local peaks near the principal lunar and solar frequencies, separated by 0.78 µHz. Relative to the combined solid-Earth and ocean-loading prediction, response scales are $1.00\pm0.13$ for M₂+N₂ and $0.93\pm0.36$ for S₂+K₂ (one statistical standard error). Optical-clock baselines can therefore distinguish neighbouring tidal contributions across interruptions without transferring a common frequency reference level between observing segments."""

introduction = r"""Earth's gravity field changes as oceans, atmosphere and the solid Earth respond to forces from the Moon and Sun. These variations carry information about mass redistribution and deformation, and enter the height and time references used to compare measurements between locations.[@voigt,denker,schroder] Optical clocks make this field observable through time itself: clocks at different gravitational potentials accumulate time at different rates.[@ludlow,mehlstaubler] Phase-stabilized fibre links now connect optical clocks across hundreds of kilometres, bringing direct, repeated comparisons of potential differences within reach.[@lisdat,riehle]

Laboratory redshift tests and remote clock comparisons have established measurements of static potential differences.[@chou,mcgrew,grotti] Following the changing Earth also requires the clocks to distinguish physical signals that evolve over hours. Tides provide a predictable test of this capability. Their astronomical frequencies and phases are known, while their effects on clock rates include direct forcing, Earth's deformation and ocean loading.[@voigt] Resolving these variations matters both for geophysical measurements and for the time-dependent redshift corrections used in coordinated clock comparisons and common time scales.[@voigt,dimarcq,lindvall]

The principal lunar and solar semidiurnal tides provide a demanding pair of nearby signals. M₂ repeats every 12.42 h and S₂ every 12 h, giving a frequency separation of only 0.78 µHz. Over a short comparison, their variations can look much alike. Interruptions add a further difficulty because a new run may start at an unknown frequency level. Yet the lunar peaks arrive about 50 minutes later in solar time each day. Observations on different dates therefore sample different combinations of lunar and solar tidal phase, even when their frequency levels cannot be directly compared.

The astronomical phase remains defined at every actual observation time, including after an interruption. Independent segment constants can accommodate unknown reference levels, while the changes within each segment constrain common tidal responses at their known phases. Here we apply this reference to the strontium–ytterbium comparison between coastal Shanghai and inland Wuhan, spanning 353 days. The coastal–inland geometry makes ocean loading an appreciable contribution to the predicted potential difference. Using the actual UTC times, we jointly estimate the lunar semidiurnal group M₂+N₂ and the neighbouring S₂+K₂ group. K₂ contains both lunar and solar forcing; the approximately daily tides remain an auxiliary physical component. Group phases and internal amplitude ratios are fixed by the astronomical model. The measured spectrum and the joint response estimates test whether neighbouring semidiurnal tides can be distinguished across the interrupted record."""

discussion = r"""The Shanghai–Wuhan comparison measures tidal variations of the gravitational potential and separates neighbouring semidiurnal responses in an interrupted record. The principal-frequency peaks, conditional spectra and jointly estimated group amplitudes connect the observed modulation to the specified astronomical signals. Together, these views of the same observations relate the resolved frequency structure to the clocks' response to the predicted tidal potential.

The measurement uses two references with different roles: each observing segment has its own frequency level, whereas the tidal forcing retains a common astronomical phase. That phase links the variations recorded within separate runs and allows their contributions to be estimated together. The observation window supplies separation through its phase coverage as well as its duration. Scheduling comparisons at different lunar–solar phases is therefore part of the measurement design, alongside clock stability and accumulated observing time.

On this coastal–inland baseline, the resolved response tests a joint prediction with a substantial ocean-loading contribution. Separately determining that contribution will require observations that better distinguish its amplitude and phase from the solid-Earth response. For developing clock networks, the present result provides a route to measuring distinct tidal contributions during intermittent operation. Independent, contemporaneous European clock-network observations have tracked the overall tidal potential on different baselines.[@stahl]"""

start = old.index('## Abstract\n') + len('## Abstract\n')
end = old.index('## Main text\n')
old_abstract = old[start:end].strip()
intro_start = end + len('## Main text\n')
intro_end = old.index('### A coastal–inland prediction')
old_intro = old[intro_start:intro_end].strip()
discussion_start = old.index('The Shanghai–Wuhan comparison measures tidal variations of the gravitational potential and separates neighbouring semidiurnal responses across an interrupted record.')
discussion_end = old.index('\\clearpage\n\n## References', discussion_start)
old_discussion = old[discussion_start:discussion_end].strip()

new = old[:start] + '\n' + abstract + '\n\n' + old[end:intro_start] + '\n' + introduction + '\n\n' + old[intro_end:discussion_start] + discussion + '\n\n' + old[discussion_end:]
assert new.split('### A coastal–inland prediction')[1].split(discussion)[0] == old.split('### A coastal–inland prediction')[1].split(old_discussion)[0]
assert new.split('## References', 1)[1] == old.split('## References', 1)[1]
assert new.count('[@stahl]') == 1
assert new.split('## References')[0].strip().endswith('\\clearpage')

def wc(text):
    text = re.sub(r'\[@[^]]+\]', '', text)
    return len(re.findall(r"\b[\w]+(?:[’'−–-][\w]+)*\b", re.sub(r'\$.*?\$', 'FORMULA', text)))

assert wc(abstract) <= 150, wc(abstract)
counts = {key: {'before': wc(before), 'after': wc(after)} for key,before,after in [
    ('abstract', old_abstract, abstract), ('introduction', old_intro, introduction), ('discussion', old_discussion, discussion)]}
(O/'manuscript_template.md').write_text(new)
(O/'review/SECTION_COUNTS.json').write_text(json.dumps(counts, indent=2)+'\n')
(O/'review/A_v77b_to_A_v78.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='A_v77b/manuscript_template.md',tofile='A_v78/manuscript_template.md')))
(O/'review/EDITED_SECTIONS_KEYED.md').write_text('## Abstract\n\n'+abstract+'\n\n## Introduction\n\n'+introduction+'\n\n## Discussion\n\n'+discussion+'\n')
print(json.dumps(counts, indent=2))
