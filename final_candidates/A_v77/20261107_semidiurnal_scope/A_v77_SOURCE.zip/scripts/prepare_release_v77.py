"""Prepare versioned author-review artifacts; never fit or publish observations."""
from pathlib import Path
import hashlib, json, shutil, zipfile

O=Path(__file__).resolve().parents[1]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,text): (O/name).write_text(text.strip()+'\n')
v=json.loads((O/'verification/INVARIANCE_AND_FORMAT_A_v77.json').read_text())
assert v['status']=='PASS'
write('REVISION_RECORD_A_v77_ZH.md',r'''
# A_v77 修改记录

底稿为 A_v76。本轮完成叙事定位与 Nature 技术组稿，没有重拟合、重新挑点或修改物理模板。题目按作者指示改为 **Resolving lunar and solar tidal responses with an optical clock baseline**。

| 项目 | 已完成修改 | 数值边界 |
|---|---|---|
| 摘要及主结果 | 两个半日潮组同时处于核心位置 | M₂+N₂ 为 1.00±0.13，S₂+K₂ 为 0.93±0.36 |
| 日潮组 | 移到 Methods 和 ED Table 2，作为联合拟合的辅助物理分量 | 0.58±0.54 及全部协方差保留；未新增自由日项 |
| 图 3a | 突出两个半日潮系数，辅助日潮不再作为主图结果 | 原点值和误差不变；同一三组联合拟合 |
| 图 3c、条件谱、相位图 | 保留真实 UTC、缺测空档、54 段投影和既有曲线 | 谱与估计同源，未包装为多个独立发现 |
| 图 4 | 图注补齐各删期和子集的样本数 | 由冻结结果读取，未新算删期结果 |
| Discussion | 聚焦间断观测下的相邻半日潮分离 | 删除日潮低精度作为主局限性的叙事 |
| 文件结构 | 加粗无标题摘要；主文参考文献、主图、Methods、声明和逐页 ED | 参考文献 21+2 连续编号；四主图、七个 ED 项 |
| 投稿图源 | 矢量 PDF/SVG，ED RGB TIFF/JPEG，逐图 Source Data 工作簿 | 所有显示来自保存的数据/结果，不填充缺测 |

学术语言检查使用 academic-humanizer；本轮为定向编辑，用户明确授权的结构、标题、数值位置调整按记录执行。比较工具报告的数字移位、标题变化和格式差异不解释为新分析。可审计逐项文本操作见 `review/EDIT_OPERATIONS_A_v77.json`。

24 项保真及格式检查通过；45 个冻结输入/结果文件逐字节不变，原 A_v76 的 51 个登记文件仍不变。PDF 共 27 页，138 词摘要、1,659 词主文、1,743 词 Methods，主图图注均少于 250 词。页数增加主要来自 12 pt 双倍行距与每个 ED 单独占页。

全部页已检查标题、正文、公式、图、表、换页和缺字。作者名单、经费、利益声明、通讯方式和编辑可访问地址仍由作者补充，不以排版完成冒充可直接投稿。下一项海洋负荷可辨识性研究单独建立研究目录，不回填本轮结果。
''')
write('NATURE_REQUIREMENTS_A_v77_ZH.md',r'''
# Nature Article 组稿核对

核对日期：2026-11-07。按官方作者指南及其可检索正文核对；部分 nature.com 页面直接访问会跳转身份验证，未将该跳转当作文章内容。以下区分作者审阅稿技术准备与投稿必须由作者完成的事项。

- 标题 72 字符；加粗摘要 138 词；主文 1,659 词、四幅图；Methods 1,743 词。双倍行距、行号、正文 12 pt；主文和 Methods 参考文献依首次出现连续编号。[Formatting guide](https://www.nature.com/nature/for-authors/formatting-guide)
- 初投稿提供含图和图注的单一 PDF 及 Word；四幅主图图注均不足 250 词。原观测是同一钟对的重复测量，误差类型、实际 n、数据处理与模拟条件保留。[Initial submission](https://www.nature.com/nature/for-authors/initial-submission)
- Methods 保留必要方程和可复现定义，图表集中于主图与 Extended Data。Methods 并非无限制扩展；官方指南仍给出约 3,000 词的常规指导长度。[Formatting guide](https://www.nature.com/nature/for-authors/formatting-guide)
- 三幅扩展图与四张扩展表分别成页；另导出 RGB、300 ppi、单文件小于 10 MB 的 TIFF/JPEG，宽不超过 180 mm、高不超过 170 mm；表体与图注分开保存。[Extended Data specifications](https://research-figure-guide.nature.com/figures/extended-data-formatting-guidelines/)
- 主图提供可编辑文字的矢量 PDF/SVG，标准嵌入无衬线字体。正文标签 5–7 pt、面板字母 8 pt；当前环境使用 DejaVu Sans，未声称使用不可用的 Arial/Helvetica。[Figure specifications](https://research-figure-guide.nature.com/figures/preparing-figures-our-specifications/)
- 逐图 Source Data 工作簿已备妥；原始计数器仍只读保留。作者需确定编辑可访问数据和代码的位置、长期保存及许可安排。私有交付库不是公开 DOI；不将所有物理数据一概说成必须已有 DOI。[Reporting standards](https://www.nature.com/nature/editorial-policies/reporting-standards)
- AI 辅助工作写入 Methods；作者复核、署名、贡献、经费和利益声明待本人认可。[AI policy](https://www.nature.com/nature-portfolio/editorial-policies/ai)
- Hou 重叠观测在投稿信披露；Stahl 按研究内容正常引用，不依上线日期排序创新性。[Preprint policy](https://www.nature.com/nature/editorial-policies/preprints-conference-proceedings)

技术准备：通过。完整外部投稿准备：尚缺真实作者信息、声明及编辑访问安排，未代为投稿。
''')
author=(O/'AUTHOR_CHECKS_ZH.md').read_text().replace('v76','v77').replace('与 v75 相同','与 v76 相同')
write('AUTHOR_CHECKS_A_v77_ZH.md',author)
write('ANALYSIS_REPORT_A_v77_ZH.md',r'''
# A_v77 作者审阅交付报告

研究问题：沪汉光钟间断记录能否分别约束相邻半日潮组。实验单位是一个上海 Sr—武汉 Yb 钟对；3,299 个均值、54 段、8 期是重复观测结构，并非 3,299 次独立实验。有效成员 1,965,327 个名义秒，545.924 h，日历跨度 353.389 天。

本轮处理：沿用 A_v76 的数据成员、UTC、物理模板、54 段常数和 Allan 噪声权重，仅修改叙事、图 3a 展示范围、稿件顺序及投稿文件导出。原始计数器和全部拟合产物只读；没有重新拟合或模拟。

主要结果：M₂+N₂ 为 1.00±0.13，S₂+K₂ 为 0.93±0.36；辅助日潮组 0.58±0.54。± 是缩放最小二乘和 UTC 日删除刀切标准误中较大者。两个主要系数来自一个联合模型，K₂ 含日月强迫。谱图用同一 3,299 个均值、等权和段常数投影；22.361 与 23.147 μHz 的局部峰和约 8% 交叉功率保持原结果。

科学边界：测量检验固体潮与海洋负荷的联合势预测。负荷 33.1% 是预测的采样 RMS 比值；历史 0.89±0.55 仍标为另一归算的作者报告值，不是本轮独立负荷测量。新授权的固体潮/负荷可辨识性研究单独保存。

产物：`render_A_v77_02/NATURE_ARTICLE_A_v77.pdf`、同名 Word/TeX；根目录 Markdown；`figures/` 图源；`submission_assets/Source_Data_A_v77.xlsx`；`data/CLAIM_LEDGER.json` 数字来源。运行入口见 `REPRODUCE_A_v77.md`。Python 3.12.3、NumPy 2.5.3、Matplotlib 3.11.2、Pandoc 3.1.3、XeLaTeX；完整版本见 `verification/SOFTWARE.json`。

验收：24 项数值保真/格式检查通过；27 页逐页视觉检查通过。检查范围是本轮编辑与交付；未宣称重做全部原始计数器归算。作者信息、审稿访问地址及历史替代分析的完整成员仍见 `AUTHOR_CHECKS_A_v77_ZH.md`。
''')
write('REPRODUCE_A_v77.md',r'''
# Rebuild A_v77

This version changes positioning and presentation, preserving the A_v76 numerical data and estimator outputs. In a fresh extraction of `A_v77_SOURCE.zip`, using the recorded Python environment, Pandoc and XeLaTeX:

```bash
python -B scripts/edit_v77.py
python -B scripts/draw_candidate.py
python -B scripts/assemble_candidate.py
python -B scripts/export_nature_assets.py
python -B render_candidate.py NATURE_ARTICLE_A_v77.md render_rebuilt
```

`render_rebuilt` must not exist. These commands read frozen results and do not fit observations, change masks, fill gaps or run simulations. The original A_v76 keyed template is included. Figure source numbering is historical: `ed_figure2` supplies ED Fig. 1, `ed_figure1` ED Fig. 2, and `ed_figure3` ED Fig. 3.

The workstation uses `/home/room115/pytorch_env/bin/python`. Exact versions are in `verification/SOFTWARE.json`. `scripts/verify_v77.py` requires the original sibling A_v76 and the locally named final render directory; its local preservation result is included. Legacy numerical scripts and result provenance are included for traceability, not invoked by the editorial build.

The separate submission-assets archive contains vector main figures, Extended Data raster formats, legends and the Source Data workbook. Raw counters, colleague PDFs, full reference articles and credentials are excluded. No command above uploads or submits the paper.
''')
letter=(O/'COVER_LETTER_v76.md').read_text().replace('Tidal potential measured on a coastal–inland optical-clock baseline','Resolving lunar and solar tidal responses with an optical clock baseline')
write('COVER_LETTER_A_v77.md',letter)
write('PLAN_A_v77.md','''# A_v77 scope\n\nCompleted targeted editorial revision of A_v76: two core semidiurnal groups, daily group auxiliary, author-requested title, Nature Article preparation. Frozen observations, fits, masks and errors retained. Separate subsequent research branch will assess solid/ocean identifiability; it does not alter this release. No submission.''')
write('README.md','''# A_v77\n\nCurrent author-review version: **Resolving lunar and solar tidal responses with an optical clock baseline**.\n\n- `render_A_v77_02/NATURE_ARTICLE_A_v77.pdf` and `.docx`: reviewed manuscript.\n- `NATURE_ARTICLE_A_v77.md` and `manuscript_template.md`: editable sources.\n- `release/`: clean delivery package.\n- `REVISION_RECORD_A_v77_ZH.md`: changes and preservation checks.\n- `AUTHOR_CHECKS_A_v77_ZH.md`: genuine pending author items.\n\nThe v77 revision adds no fits. The ocean-loading identifiability study requested afterwards is a separate research output.''')

visual=dict(status='PASS',pdf='render_A_v77_02/NATURE_ARTICLE_A_v77.pdf',pages=27,
            pdf_sha256=sha(O/'render_A_v77_02/NATURE_ARTICLE_A_v77.pdf'),
            reviewed=list(range(1,28)),checks=['text and equation readability','figure and table bounds','captions and panel labels','no replacement glyphs','section order and page breaks'],
            pending='Author placeholders retained intentionally; not a submission approval')
(O/'verification/VISUAL_REVIEW_A_v77.json').write_text(json.dumps(visual,indent=2))
manifest=dict(baseline='A_v76',title=O.joinpath('NATURE_ARTICLE_A_v77.md').read_text().splitlines()[0][2:],
              numerical_scope='Frozen S54/Allan results; no new fit',frozen=json.loads((O/'verification/FROZEN_V76_COMPARISON.json').read_text()))
(O/'INPUT_MANIFEST_A_v77.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False))

# New outputs only. Existing baseline files copied into this directory remain archived.
archive=O/'original/inherited_A_v76_package';archive.mkdir(exist_ok=True)
for name in ['ANALYSIS_REPORT_v76_ZH.md','AUTHOR_CHECKS_ZH.md','CHANGELOG_V75_V76_ZH.md','COVER_LETTER_v76.md','EXPORT_MANIFEST.json','INPUT_MANIFEST_v76.json','NARRATIVE_CHANGES_ZH.md','NATURE_ARTICLE_A_v76.md','NATURE_ARTICLE_A_v76.tex','PLAN_v76.md','REPRODUCE_v76.md','REVISION_RECORD_ZH.md','SCIENTIFIC_INVARIANCE_CHECK_ZH.md']:
    p=O/name
    if p.exists():
        assert not (archive/name).exists();shutil.move(p,archive/name)

release=O/'release';release.mkdir(exist_ok=True)
for ext in ['pdf','docx','tex']:
    shutil.copy2(O/f'render_A_v77_02/NATURE_ARTICLE_A_v77.{ext}',release/f'NATURE_ARTICLE_A_v77.{ext}')
for name in ['NATURE_ARTICLE_A_v77.md','REVISION_RECORD_A_v77_ZH.md','NATURE_REQUIREMENTS_A_v77_ZH.md','AUTHOR_CHECKS_A_v77_ZH.md','ANALYSIS_REPORT_A_v77_ZH.md','REPRODUCE_A_v77.md','COVER_LETTER_A_v77.md']:
    shutil.copy2(O/name,release/name)
shutil.copy2(O/'submission_assets/Source_Data_A_v77.xlsx',release/'Source_Data_A_v77.xlsx')
for name in ['INVARIANCE_AND_FORMAT_A_v77.json','VISUAL_REVIEW_A_v77.json']:
    shutil.copy2(O/'verification'/name,release/name)
with zipfile.ZipFile(release/'A_v77_SUBMISSION_ASSETS.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted((O/'submission_assets').iterdir()):z.write(p,p.relative_to(O))

include=[]
for folder in ['data','sources','vendor','figures','editorial','scripts']:
    include += [p for p in (O/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and not p.name.startswith(('upload_','package_v76'))]
include += [O/x for x in ['manuscript_template.md','NATURE_ARTICLE_A_v77.md','render_candidate.py','layout_working.lua','README.md','REPRODUCE_A_v77.md','PLAN_A_v77.md','INPUT_MANIFEST_A_v77.json','REVISION_RECORD_A_v77_ZH.md','NATURE_REQUIREMENTS_A_v77_ZH.md','AUTHOR_CHECKS_A_v77_ZH.md','ANALYSIS_REPORT_A_v77_ZH.md','COVER_LETTER_A_v77.md','original/A_v76_manuscript_template.md','original/A_v76.md','original/A_v76_FROZEN_FILES.json']]
include += [O/'verification'/x for x in ['SOFTWARE.json','FROZEN_V76_COMPARISON.json','INVARIANCE_AND_FORMAT_A_v77.json','VISUAL_REVIEW_A_v77.json','TEXT_STRUCTURE.json','PDF_PAGE_CHECK.json']]
include += [O/'review/EDIT_OPERATIONS_A_v77.json']
include=sorted(set(include))
assert all(p.exists() and not p.is_symlink() for p in include)
assert not any(p.suffix=='.pdf' and 'figures' not in p.parts for p in include)
with zipfile.ZipFile(release/'A_v77_SOURCE.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in include:z.write(p,p.relative_to(O))
exp=[dict(file=str(p.relative_to(O)),bytes=p.stat().st_size,sha256=sha(p)) for p in include]
(O/'EXPORT_MANIFEST_A_v77.json').write_text(json.dumps(exp,indent=2))
shutil.copy2(O/'EXPORT_MANIFEST_A_v77.json',release/'EXPORT_MANIFEST_A_v77.json')
print(json.dumps(dict(status='PACKAGED',source_files=len(include),release_files=len(list(release.iterdir())),numerical_fits=0)))
