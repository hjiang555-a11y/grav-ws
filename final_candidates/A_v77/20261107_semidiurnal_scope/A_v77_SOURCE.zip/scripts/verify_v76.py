"""Editorial invariants only; never runs a scientific estimator."""
from pathlib import Path
import hashlib, json, re
import numpy as np
import pandas as pd

O=Path(__file__).resolve().parents[1]; B=O.with_name('A_v75')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
t=(O/'NATURE_ARTICLE_A_v76.md').read_text()
base=(O/'original/A_v75.md').read_text()
j=json.loads((O/'data/RESULTS.json').read_text())
out=[]
def check(name,ok,evidence):
    out.append(dict(check=name,pass_=bool(ok),evidence=evidence))

check('Title unchanged',t.splitlines()[0]==base.splitlines()[0],t.splitlines()[0])
files=json.loads((O/'verification/FROZEN_INPUT_COMPARISON.json').read_text())
check('Frozen numerical inputs unchanged',all(x['same'] for x in files),f'{len(files)} files compared byte-for-byte: data, frozen_v72, vendor')
oldman=json.loads((O/'original/A_v75_FROZEN_FILES.json').read_text())
check('Original v75 sources/data remain intact',all(sha(B/x['file'])==x['sha256'] for x in oldman),f'{len(oldman)} original files rechecked')
check('Original manuscript retained',sha(B/'NATURE_ARTICLE_A_v75.md')==sha(O/'original/A_v75.md') and sha(B/'manuscript_template.md')==sha(O/'original/A_v75_manuscript_template.md'),'Saved original keyed and rendered text')
check('All display equations unchanged',re.findall(r'\$\$(.*?)\$\$',t,re.S)==re.findall(r'\$\$(.*?)\$\$',base,re.S),'Joint physical estimator, solid conversion and loading kernel')
r=pd.read_csv(O/'data/primary_rows.csv'); f=pd.read_csv(O/'data/phase_fold.csv')
check('All 3299 observations and 12 phase bins retained',len(r)==3299 and len(f)==12 and int(f.n_rows.sum())==3299,'Unchanged primary_rows.csv and phase_fold.csv hashes; 12 support counts sum to 3299')
check('Primary amplitudes and statistical errors unchanged',j['primary']==json.loads((B/'data/RESULTS.json').read_text())['primary'],'S54/Allan; max(scaled LS, UTC-day jackknife)')
check('Abstract values match frozen results',all(f'{a:.2f}\\pm{u:.2f}' in t.split('## Abstract')[1].split('## Main text')[0] for a,u in zip(j['primary']['A'][:2],j['primary']['u'][:2])),'1.00 ± 0.13; 0.93 ± 0.36; same group definitions')
check('Original numerical programs unchanged',all(sha(O/'scripts'/n)==sha(B/'scripts'/n) for n in ['recompute_candidate.py','check_coverage.py']),'Programs archived but NOT executed this round')
check('No unfinished sequential diagnostic instruction','A sequential residual diagnostic must' not in t,'Removed instruction only; diagnostic is not part of current estimator or result chain')
main=t.split('## Main text')[1].split('## Figure legends')[0]
check('Four targeted Results headings',len(re.findall(r'^### ',main,re.M))==4 and '### Consistency across observing periods' in main,'Existing four scientific sections retained')
check('Discussion has three focused paragraphs',len(main[main.index('The Shanghai–Wuhan comparison measures'):].replace('\\clearpage','').strip().split('\n\n'))==3,'Measurement; phase-reference advance; interrupted networks')
check('No generic resolution/European dependence claim',not re.search(r'high spectral resolution|following Stahl|complementary|complementarity',main,re.I),'Specific neighbouring-response separation; normal contemporaneous citation')
check('Loading-only estimate moved out of main','0.89\\pm0.55' not in main and '0.89\\pm0.55' in t,'Unchanged alternative result retained in Methods and ED Table 4')
check('Fibre panel retained in Extended Data','figures/ed_figure3.png' in t and '0.00606\\pm0.00627' in t,'1482 paired means; 246.634 h; same paired jackknife')
check('No falsely independent temperature claim','0.98\\pm0.13' not in main and 'author-reported' in t,'ERA5 proxy result retained and distinguished from chamber thermometer in ED Table 4')
refs=json.loads((O/'editorial/REFERENCE_ORDER.json').read_text())
keyed=(O/'manuscript_template.md').read_text();order=[]
for grp in re.findall(r'\[@([a-z,]+)\]',keyed):
    for k in grp.split(','):
        if k not in order:order.append(k)
check('References in first-mention order',order==list(refs) and list(v['number'] for v in refs.values())==list(range(1,len(refs)+1)),f'{len(refs)} references; Light primary PDF checked; two unneeded outlook references omitted')
pre=t.split('## Figure legends')[0]
first=[]
for m in re.finditer(r'(?<!Data )Fig\. ([1-4])',pre):
    if m[1] not in first:first.append(m[1])
check('Main figures first mentioned in order',first==list('1234'),first)
check('No unresolved template tokens',not re.search(r'\{\{[A-Z_]+\}\}',t),'Author approval/access declarations intentionally retained for completion')
for item in json.loads((O/'figures/PROVENANCE.json').read_text()):
    check('Figure exists: '+item['figure'],(O/'figures'/(item['figure']+'.pdf')).is_file(),item.get('scope',item.get('estimator')))
payload={'scope':'Editorial/scientific-definition invariance; no new fit or raw-counter replay','status':'PASS' if all(x['pass_'] for x in out) else 'FAIL','checks':out,'results_sha256':sha(O/'data/RESULTS.json')}
(O/'verification/INVARIANCE_A_v76.json').write_text(json.dumps(payload,indent=2,ensure_ascii=False))
print(json.dumps({'status':payload['status'],'checks':len(out),'failed':[x['check'] for x in out if not x['pass_']]}))
assert payload['status']=='PASS'
