# A_v77

Current author-review version: **Resolving lunar and solar tidal responses with an optical clock baseline**.

- `render_A_v77_02/NATURE_ARTICLE_A_v77.pdf` and `.docx`: reviewed manuscript.
- `NATURE_ARTICLE_A_v77.md` and `manuscript_template.md`: editable sources.
- `release/`: clean delivery package.
- `REVISION_RECORD_A_v77_ZH.md`: changes and preservation checks.
- `AUTHOR_CHECKS_A_v77_ZH.md`: genuine pending author items.

The v77 revision adds no fits. The ocean-loading identifiability study requested afterwards is a separate research output.
