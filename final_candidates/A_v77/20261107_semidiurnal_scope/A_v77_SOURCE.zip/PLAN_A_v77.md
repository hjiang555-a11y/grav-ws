# A_v77 scope

Completed targeted editorial revision of A_v76: two core semidiurnal groups, daily group auxiliary, author-requested title, Nature Article preparation. Frozen observations, fits, masks and errors retained. Separate subsequent research branch will assess solid/ocean identifiability; it does not alter this release. No submission.
