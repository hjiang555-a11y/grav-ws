"""v80 is the sole manuscript base; add the independently verified full-template table."""
from pathlib import Path
import json,re
import pandas as pd
O=Path(__file__).resolve().parents[1]
t=(O/'baseline_v80/manuscript_template.md').read_text()
t=t.replace(t.splitlines()[0],'# Tidal potential measured on a coastal–inland optical-clock baseline',1)
abstract=r'''Tides change the gravitational potential difference between distant sites and thereby the relative rates of clocks.[@ludlow,mehlstaubler] Here we detect tidal variations in the gravitational potential difference between coastal Shanghai and inland Wuhan by comparing a strontium clock and a ytterbium clock 692 km apart. The measurements extend a fixed-site clock comparison from static potential differences to changes over hours. We accumulated 545.9 hours of observations across 353 days. The response to the complete solid-Earth and ocean-loading prediction is $0.96\pm0.11$ (one statistical standard error). A joint fit of physical tidal groups gives a lunar M₂+N₂ response of $1.00\pm0.13$, with group-internal amplitude ratios and phases fixed. Its measured phase and spectral structure agree with the lunar prediction. Each observing segment retains its own frequency reference level, while the actual observation times preserve the astronomical phase across interruptions. The neighbouring S₂+K₂ group is less precisely constrained and more sensitive to disturbances at 12 hours. Together, these measurements resolve tidal potential variation on this coastal–inland optical-clock baseline.'''
main=r'''Earth's gravitational potential changes as the Moon and Sun move, the solid Earth deforms and ocean water is redistributed. Optical clocks sense a potential difference through the gravitational shift of their relative rates.[@ludlow,mehlstaubler] Laboratory redshift tests and remote clock comparisons have measured static potential differences, while chronometric-levelling experiments have calculated the tidal perturbation during a comparison.[@chou,mcgrew,grotti,takano] This raises an experimental question: can two clocks at fixed, distant sites detect changes in their potential difference over hours through their relative ticking rates?

Fibre networks allow repeated comparisons between clocks hundreds of kilometres apart.[@lisdat,riehle] Measuring time-dependent potential differences would provide direct constraints on mass redistribution and deformation, while accounting for changing redshifts is also necessary for consistent clock comparisons and time references.[@voigt,denker,schroder,dimarcq,lindvall] We address this question with the Shanghai strontium and Wuhan ytterbium clocks, taking the tidal variation itself as the measured signal.

The comparison also tests how well the observed variation can be assigned to neighbouring tidal components. The principal lunar semidiurnal tide M₂ repeats every 12.42 h, close to the 12-h solar tide S₂. A corresponding lunar maximum arrives about 50 minutes later on successive solar days, so their relative phase changes with date. Observations on different dates sample different combinations of the two waveforms. Even when the frequency offset between runs is unknown, the variation within each run can be compared with the astronomical phase at its actual observation times. We first estimate one response to the complete prediction, then jointly estimate the responses of two semidiurnal groups.

### A coastal–inland baseline and its predicted signal

The two clocks are 692 km apart and connected through Hefei by a 1,350-km phase-stabilized fibre path (Fig. 1a). The apparatus and frequency-comparison chain are described by Hou and colleagues; clock evaluations and field-fibre experiments provide the metrological basis.[@hou,jia,zhu,chenlink] Hou et al. used 16 overlapping summer segments for an absolute frequency-ratio measurement and reported a combined-template tidal response of $0.87\pm0.15$. Here we use the record spanning 353 days to estimate both the full-template and grouped responses. The overlapping observations make these related analyses, rather than independent repetitions.

Shanghai's proximity to the East China Sea and Wuhan's inland location give the two sites different responses to ocean mass redistribution. The differential prediction combines direct astronomical forcing, the potential induced by Earth's deformation and clock displacement, together with the attraction and deformation caused by ocean loading. We use the IERS-based solid prediction and FES2022 ocean elevations with an effective-potential loading kernel (Methods).[@iers,fes,farrell,han]

The model predicts M₂ fractional-rate amplitudes of $3.43\times10^{-18}$ from the solid response and $1.42\times10^{-18}$ from loading. Their 19.8° phase difference gives a vector sum of $4.78\times10^{-18}$, equivalent to a potential-difference amplitude of about $0.43\,\mathrm{m^2/s^2}$ (Fig. 1b). Loading is about 30% of this combined M₂ phasor amplitude. On the actual weighted, segment-centred sampling, its root-mean-square variation is 33.1% of the combined prediction. Both ratios describe model contributions; the clock comparison tests their sum.

The September 2025–August 2026 record contains 3,299 accepted ten-minute means in 54 segments and eight observing periods, representing 545.9 nominal member-hours (Fig. 1c). Observations fall on 43 UTC dates in eight calendar months within the 353-day span. Summer contributes 273.9 h, and the earlier periods add different lunar–solar phases (Fig. 1d). A positive fractional-rate variation denotes Wuhan Yb running faster relative to Shanghai Sr. With the geodetic potential convention used here, $y=-[\delta W_{\mathrm{Wuhan}}-\delta W_{\mathrm{Shanghai}}]/c^2$.

### Detection in the full clock record

The response to the complete tidal prediction is $A_T=0.96\pm0.11$ (Fig. 3a). One scale multiplies the full solid-Earth and ocean-loading waveform, including the minor-constituent remainder. The fit uses all 3,299 ten-minute means with the statistical-error rule in Methods. The coefficient agrees with the predicted amplitude of the potential variation between the sites.

Each segment retains its own frequency level. We subtract the weighted mean separately from the measurements and from each prediction column, then estimate common physical coefficients from the remaining variations. This reduction is equivalent to fitting a separate constant for every segment. It preserves the comparison of observation and astronomical phase without joining frequency levels across interruptions or filling missing intervals.

The full record reveals recurring modulation when arranged by M₂ phase (Fig. 2a). For this display, the observations and unit lunar template undergo the same projection against segment constants and the non-lunar groups before averaging in twelve phase bins. The error bars propagate uncertainty from that operation. The display exposes the lunar variation contained in the joint fit.

Figure 2b,c shows the observations on a real UTC axis. The displayed 42.5-hour segment has the largest accepted member count, an objective selection independent of its agreement with the tide. Fixed three-hour means make the variation easier to see, with identical averaging applied to measurements and prediction. All 255 ten-minute means in that interval remain visible below. Parameter estimates use the ten-minute means from the full record, rather than the display averages or this one interval.

### Amplitude, phase and semidiurnal structure

We jointly estimate the lunar group M₂+N₂, the neighbouring group S₂+K₂ and an auxiliary diurnal group, keeping relative amplitudes and phases fixed within each group. M₂ and N₂ arise from lunar forcing. S₂ is the principal solar semidiurnal tide, whereas K₂ includes both lunar and solar forcing. The fitted responses are $A_L=1.00\pm0.13$ and $A_S=0.93\pm0.36$ (Fig. 3a), with a scaled least-squares correlation of −0.30. The lunar group gives the stronger component constraint. The separate diurnal coefficient carries its covariance with the semidiurnal responses through the joint model.

Allowing a lunar component in quadrature with the prediction gives in-phase and quadrature coefficients of $1.00\pm0.13$ and $-0.10\pm0.20$ (Fig. 3b). This supports agreement with the predicted lunar phase. These coordinates differ from the joint $(A_L,A_S)$ uncertainty regions in Extended Data Fig. 4, which describe the two groups' amplitude estimates.

The measured semidiurnal spectrum has local maxima at 22.361 and 23.147 µHz, near the principal M₂ and S₂ frequencies (Fig. 3c). The known astronomical frequency spacing is approximately 0.78 µHz; the reported scan maxima are 0.786 µHz apart. Single-line injections through the actual observation window give about 8% cross-power at the other principal frequency. Conditional scans account for the competing principal sinusoid (Extended Data Fig. 1). These window tests help distinguish the observed frequency structure from sampling sidelobes. The spectrum, phase fold and template fit describe the same observations and their probabilities are not combined. The spectrum displays frequency structure, while the physical coefficients come from the simultaneous group fit.

### Across observing periods and instrumental checks

Figure 4 shows the two semidiurnal groups fitted separately in each of the eight observing periods, retaining the original segment reference levels. The differing durations and phase coverage give unequal precision, including broad intervals in the shorter records. The full-record result comes from fitting common physical coefficients to all observations, rather than averaging these eight points. Same-data comparisons of reference-level choices are retained in Extended Data Fig. 2.

To test sensitivity to daily operation or environmental variation, a shared 24-h sine–cosine pair gives a lunar coefficient of $1.04\pm0.13$ and a full-template coefficient of $1.03\pm0.10$. Allowing a separate freely phased 12-h pair in every period gives $A_T=0.72\pm0.22$ in the full-template fit, and $A_L=0.75\pm0.24$ and $A_S=-5.10\pm15.01$ in the grouped fit. These are two distinct parameterizations on the same observations. The broad neighbouring interval reflects direct competition with a same-frequency free term. Such terms are sensitivity tests, not independently measured laboratory disturbances. The grouped and full-template results are listed separately in Extended Data Tables 4 and 5.

The simultaneous fibre round-trip monitor covers 246.6 member-hours during summer. Adding it on identical clock/monitor support changes the lunar coefficient by $0.0061\pm0.0063$ and the neighbouring coefficient by $0.00594\pm0.01453$ (Extended Data Fig. 3). This control constrains the monitored transmission route during those observations. It does not constrain same-frequency environmental effects in the two clocks.

### Discussion

The relative rates of the Shanghai and Wuhan clocks contain the predicted tidal variation of their gravitational potential difference. Agreement in the full waveform response, the lunar phase and the observed semidiurnal structure supports detection on this fixed coastal–inland baseline. The lunar component provides the clearest constraint; attribution within the neighbouring group is more sensitive to 12-h disturbances.

Astronomical phase makes interrupted observations useful without a calibrated frequency-level transfer between runs. A segment's unknown constant leaves its time-dependent tidal variation available for estimation, and later observations sample new lunar–solar phase combinations. The measurement therefore uses both the changes within runs and their known forcing phase across dates. This provides a practical way for intermittently operating clock comparisons to measure changing potential differences.

The loading contribution changes the amplitude and phase of the combined prediction on this baseline, but is not separately measured here. Separating it from the solid response requires observations that distinguish their patterns more strongly. More continuous operation and independent records of instrumental variation near 12 h would strengthen attribution of the neighbouring response. Related results have been reported independently by a European optical-clock network in a contemporaneous arXiv preprint.[@stahl]
'''
t=re.sub(r'(?<=## Abstract\n).*?(?=## Main text)',lambda m:'\n'+abstract+'\n\n',t,flags=re.S)
t=re.sub(r'(?<=## Main text\n).*?(?=## References)',lambda m:'\n'+main+'\n\n\\clearpage\n\n',t,flags=re.S)
# Adjacent explicit equations make the remainder conventions unambiguous.
old='For the full-response estimate, $y$ is the observed fractional rate and $T=s_L+s_S+s_D+r_0$ is the complete frozen prediction. A single coefficient $A_T$ multiplies that entire column. The comparison is between 54 segment constants alone and the same constants plus this one template. For component estimation, we instead subtract the fixed minor remainder once and fit'
new=r'''For the full-response estimate, $y$ is the observed fractional rate before removal of the minor remainder. We fit

$$y_i=c_{s(i)}+A_TT_i+\epsilon_i,\qquad T_i=s_{L,i}+s_{S,i}+s_{D,i}+r_{0,i}.$$

The single coefficient multiplies the complete prediction. The restricted comparison retains only the 54 segment constants. For component estimation, we subtract the fixed minor remainder once and fit'''
assert old in t;t=t.replace(old,new)
anchor='### AI-assisted preparation'
addition='The full-template sensitivity fits add either one shared 24-h sine–cosine pair or a separate 12-h pair in each of the eight periods. The basis functions are evaluated at the actual UTC mean times. All 3,299 observations, 54 segment constants, original weights and the full minor remainder are retained. Each model recomputes scaled least-squares and 43-day-deletion errors; Extended Data Table 5 lists both components. These scalar-response fits are distinct from the grouped models in Extended Data Table 4.\n\n'
t=t.replace(anchor,addition+anchor)
t=t.replace('The new full-template coefficient uses','The full-template coefficient uses')
t=t.replace('**a,** Full-template and jointly estimated lunar and neighbouring responses.', '**a,** Full-template and jointly estimated lunar and neighbouring responses.')
# Add an explicit model distinction to the preserved Figure 3 legend.
pattern=r'(\*\*Fig\. 3 \|[^\n]+)'
m=re.search(pattern,t);assert m
legend=m.group(1)
legend+=' The full-template and three-group coefficients come from two fits to the same observations; they are not averaged.'
t=t[:m.start()]+legend+t[m.end():]
df=pd.read_csv(O/'full_sensitivity/table.csv')
df.columns=['Model','Response','Scaled LS','Day jackknife','Reported SE']
for c in df.columns[1:]:df[c]=df[c].map(lambda x:f'{x:.4f}')
t+='\n\\clearpage\n\n**Extended Data Table 5 | Full-template response and sensitivity.** Each fit uses the same 3,299 ten-minute means, 54 segment constants and Allan-based weights. The scalar response multiplies the complete solid-Earth and ocean-loading waveform, including the minor remainder. Standard errors are statistical; the reported value is the larger of scaled least squares and UTC-day-deletion jackknife. The grouped-model sensitivities remain in Extended Data Table 4.\n\n'+df.to_markdown(index=False)+'\n'
(O/'manuscript_template.md').write_text(t)
print('Integrated v81; verified additional scalar models only; original figures retained.')
