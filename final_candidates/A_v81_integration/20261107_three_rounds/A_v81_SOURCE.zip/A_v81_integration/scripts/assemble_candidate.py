"""Render manuscript numbers and first-appearance reference order from replay."""
from pathlib import Path
import json,re
import numpy as np
import pandas as pd

O=Path(__file__).resolve().parents[1]
j=json.loads((O/'data/RESULTS.json').read_text())
t=(O/'manuscript_template.md').read_text()
v72=(O/'sources/v72/NATURE_ARTICLE_v72.md').read_text()
aff=v72.split('[Author list and affiliation assignments to be completed by the authors]')[1].split('## Abstract')[0].strip()
t=t.replace('{{AFFILIATIONS}}',aff)
refs={k:v['text'] for k,v in json.loads((O/'sources/frozen_v72/reference_map.json').read_text()).items()}
refs.update({k:v['text'] for k,v in json.loads((O/'editorial/network_research/additional_references.json').read_text()).items()})
refs.update({k:v['text'] for k,v in json.loads((O/'editorial/added_references_v76.json').read_text()).items()})
refs['vanderplas']='VanderPlas, J. T. Understanding the Lomb–Scargle periodogram. *Astrophys. J. Suppl. Ser.* **236**, 16 (2018). https://doi.org/10.3847/1538-4365/aab766'
main_keys=[]
for group in re.findall(r'\[@([a-z,]+)\]',t.split('## Methods\n')[0]):
    for key in group.split(','):
        if key not in main_keys:main_keys.append(key)
orders=[]
def cite(m):
    keys=m.group(1).split(',')
    for k in keys:
        assert k in refs,k
        if k not in orders:orders.append(k)
    return '^'+','.join(str(n) for n in sorted({orders.index(k)+1 for k in keys}))+'^'
t=re.sub(r'\[@([a-z,]+)\]',cite,t)
def reference_display(value):
    # Explicit autolinks permit line breaks in long DOIs; leave existing links intact.
    return re.sub(r'(?<![\[<(])https?://[^\s>)]+',lambda m:'<'+m.group(0)+'>',value)
t=t.replace('{{MAIN_REFERENCES}}','\n'.join(f'{i+1}. {reference_display(refs[k])}' for i,k in enumerate(orders) if k in main_keys))
t=t.replace('{{METHOD_REFERENCES}}','\n'.join(f'{i+1}. {reference_display(refs[k])}' for i,k in enumerate(orders) if k not in main_keys))
tab=[]
for name in ['S54','G29','P8']:
    a=j['designs'][name]
    tab.append(dict(Design=name,Lunar=f"{a['A'][0]:.3f} ± {a['u'][0]:.3f}",Near_12h=f"{a['A'][1]:.3f} ± {a['u'][1]:.3f}",Diurnal=f"{a['A'][2]:.3f} ± {a['u'][2]:.3f}",Status='Replayed'))
dt=pd.DataFrame(tab)
err=pd.DataFrame([dict(Group=n,Estimate=f"{j['primary']['A'][i]:.4f}",Scaled_LS=f"{j['primary']['scaled_ls'][i]:.4f}",Day_JK=f"{j['primary']['day_jackknife'][i]:.4f}",Period_JK=f"{j['primary']['period_jackknife'][i]:.4f}",Reported_SE=f"{j['primary']['u'][i]:.4f}") for i,n in enumerate(['Lunar','Near-12 h','Diurnal'])])
cv=pd.read_csv(O/'data/conditional_coverage.csv')
cov=cv.pivot(index=['scenario','design'],columns='group',values='coverage_95').reset_index()
for col in ['Lunar','Near12h','Diurnal']:cov[col]=cov[col].map(lambda x:f'{100*x:.1f}')
cov.scenario=cov.scenario.replace({'white':'Gaussian','half_OU6h_segment':'50% OU 6 h, segment','half_OU24h_period':'50% OU 24 h, period','student_t5':'Student t (df 5)'})
fm=j['spectrum']['frequency_Hz'];names=['M2','N2','S2','K2','K1','O1','P1','Q1']
meanings=['Principal lunar semidiurnal','Lunar elliptic semidiurnal','Principal solar semidiurnal','Lunisolar semidiurnal','Lunisolar diurnal','Principal lunar diurnal','Principal solar diurnal','Lunar elliptic diurnal']
td=pd.DataFrame([dict(Symbol=n,Period_h=f'{1/fm[n]/3600:.3f}',Meaning=m,Group='Lunar' if n in ['M2','N2'] else ('Near-12 h' if n in ['S2','K2'] else 'Diurnal')) for n,m in zip(names,meanings)])
for token,df in [('DESIGN_TABLE',dt),('ERROR_TABLE',err),('COVERAGE_TABLE',cov),('TIDE_TABLE',td)]:
    t=t.replace('{{'+token+'}}',df.to_markdown(index=False));df.to_csv(O/'data'/(token.lower()+'.csv'),index=False)
t=t.replace('{{REDUCED_RSS}}',f"{j['designs']['P8']['scale']:.4f} and {j['primary']['scale']:.4f}")
assert not re.search(r'\{\{[A-Z_]+\}\}',t)
assert '[@' not in t, 'Unresolved reference key'
def wc(x):return len(re.findall(r"\b[\w]+(?:[’'−–-][\w]+)*\b",re.sub(r'\$.*?\$','FORMULA',x)))
abstract=t.split('## Abstract\n')[1].split('## Main text')[0]
main=t.split('## Main text\n')[1].split('## References')[0]
methods=t.split('## Methods\n')[1].split('## Data availability')[0]
captions=[(m.group(1),wc(m.group(2))) for m in re.finditer(r'\*\*((?:Fig\. \d|Extended Data Fig\. \d)[^*]+)\*\* (.+?)(?=\n\n|$)',t,re.S)]
counts=dict(abstract=wc(abstract),main=wc(main),methods=wc(methods),legends=captions,references=len(orders),main_references=len(main_keys),methods_references=len(orders)-len(main_keys),title_characters=len(t.splitlines()[0].removeprefix('# ')))
assert counts['abstract']<=200,counts
assert all(n<300 for _,n in captions),captions
assert not re.search(r'\b(?:v68|v71|v72|R7|P8|S54)\b',main)
assert counts['title_characters']<=75
assert all(n<250 for label,n in captions if label.startswith('Fig.'))
# Article summary paragraph is bold and unheaded; structure markers remain in
# the editable template so preservation checks can identify the scientific parts.
t=t.replace('## Abstract\n'+abstract,'**'+abstract.strip()+'**\n\n')
t=t.replace('## Main text\n','\\clearpage\n\n')
(O/'NATURE_ARTICLE_A_v81.md').write_text(t)
(O/'verification/TEXT_STRUCTURE.json').write_text(json.dumps(counts,indent=2))
(O/'editorial/REFERENCE_ORDER.json').write_text(json.dumps({k:dict(number=i+1,text=refs[k]) for i,k in enumerate(orders)},indent=2))
print(json.dumps(counts,indent=2))
