"""Embed the unchanged author-supplied map; retain traceable numerical panels."""
from pathlib import Path
import json,sys,hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

O=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(O/'vendor'))
from audit_panel_alignment import require_matplotlib_panel_alignment
j=json.loads((O/'data/RESULTS.json').read_text());r=pd.read_csv(O/'data/primary_rows.csv')
ledger=pd.read_csv(O/'data/period_ledger.csv').set_index('period')
asset=O/'assets/author_figure1a/1a.png';record=json.loads((asset.parent/'PROVENANCE.json').read_text())
assert hashlib.sha256(asset.read_bytes()).hexdigest()==record['sha256']
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans'],'font.size':7,
 'axes.labelsize':7,'axes.titlesize':7,'xtick.labelsize':6,'ytick.labelsize':6,
 'legend.fontsize':6,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,
 'axes.spines.right':False,'axes.linewidth':.7,'legend.frameon':False})
blue='#126080';orange='#bc651f';green='#50816c'
fig=plt.figure(figsize=(180/25.4,168/25.4))
# The embedded panel already includes its letter, coast, route and field labels.
a=fig.add_axes([.01,.39,.65,.57]);a.imshow(plt.imread(asset),interpolation='none',resample=False);a.set_axis_off()
b=fig.add_axes([.73,.57,.24,.24])
ph=j['phasors_M2'];solid=ph['solid'];loading=np.array(ph['rotated_loading']);total=np.r_[solid,0]+loading
for start,end,color in [(np.zeros(2),[solid,0],orange),([solid,0],total,green),(np.zeros(2),total,blue)]:
    b.annotate('',end,xytext=start,arrowprops={'arrowstyle':'-|>','color':color,'lw':1.5})
b.text(solid/2,-.48,f'Solid {solid:.2f}',ha='center')
b.text(4.2,1.02,f'Load {ph["loading"]:.2f}',ha='center')
b.text(2.15,.50,f'Sum {ph["total"]:.2f}',ha='center')
b.text(3.50,-.98,f'{ph["angle_deg"]:.1f}°')
b.set(xlim=(-.2,5.4),ylim=(-1.25,1.45),xlabel='In phase (10⁻¹⁸)',ylabel='Quadrature (10⁻¹⁸)',xticks=[0,2,4],yticks=[-1,0,1])
b.set_aspect('equal',adjustable='box')
b.set_title('Differential M₂ prediction',loc='left',pad=13)
c=fig.add_axes([.13,.10,.34,.23]);d=fig.add_axes([.62,.10,.34,.23])
dates=pd.to_datetime(r.t_utc,utc=True).dt.tz_convert(None)
periods=sorted(r.period.unique())
for k,p in enumerate(periods):
    take=r.period==p;y0=7-k;color=blue if k<5 else orange
    c.plot(dates[take],np.full(take.sum(),y0),'|',color=color,ms=4,alpha=.55)
    d.scatter(r.loc[take,'relative_S2_M2_phase_deg'],np.full(take.sum(),y0),s=3,alpha=.18,color=color,linewidths=0,rasterized=True)
c.set(yticks=range(8),yticklabels=[f'{p} · {ledger.loc[p,"accepted_hours"]:.1f} h' for p in periods[::-1]],ylim=(-.6,7.6))
c.xaxis.set_major_locator(mdates.MonthLocator(interval=3));c.xaxis.set_major_formatter(mdates.DateFormatter('%b\n%Y'))
c.set_title('545.9 h across eight periods',loc='left',pad=14)
d.set(ylim=(-.6,7.6),yticks=range(8),yticklabels=periods[::-1],xlim=(0,360),xticks=[0,90,180,270,360],xlabel='S₂ − M₂ phase (degrees)')
d.set_title('Observed astronomical phase',loc='left',pad=14)
for ax,label in [(b,'b'),(c,'c'),(d,'d')]:
    ax.annotate(label,(0,1),xycoords='axes fraction',xytext=(-12,7),textcoords='offset points',fontsize=8,fontweight='bold',va='bottom')
fig.canvas.draw()
# Only the lower quantitative pair is geometrically comparable. The author map
# and equal-aspect phasors intentionally use different, content-specific spans.
require_matplotlib_panel_alignment(fig,json_out=O/'figures/figure1.alignment.json',
    overlay_svg=O/'figures/figure1.alignment.svg',axes=[c,d],panel_ids=['c','d'],row_groups=[['c','d']],strict=True)
for ext in ['pdf','svg','png']:
    fig.savefig(O/f'figures/figure1.{ext}',**({'dpi':450} if ext=='png' else {}))
plt.close(fig)
record.update(figure='figures/figure1.pdf',reuse='Exact PNG embedding without alteration',
              raster_panel='a',vector_panels=['b','c','d'],
              initial_review='Author-supplied raster accepted for review; background-grid source remains an author provenance item.',
              numerical_panels='Frozen v78 phasors, UTC sampling and astronomical phases',
              phasor_aspect='Equal data-axis aspect; loading phase is not visually stretched.')
(O/'verification/FIGURE1_ASSET_USE.json').write_text(json.dumps(record,indent=2)+'\n')
print('Embedded unchanged author map into Figure 1; numerical panels from frozen inputs.')
