from pathlib import Path
import shutil,json,hashlib
import pandas as pd
import openpyxl
O=Path(__file__).resolve().parents[1];R=O/'release';R.mkdir(exist_ok=True)
B=O.parent/'A_v80_periods/release'
for ext in ['pdf','docx','tex']:shutil.copy2(O/'render_final'/f'NATURE_ARTICLE_A_v81.{ext}',R/f'NATURE_ARTICLE_A_v81.{ext}')
for name in ['NATURE_ARTICLE_A_v81.md','manuscript_template.md','REVISION_V81_ZH.md','REVISION_V81_ZH.pdf','REPRODUCE_V81.md','DATA_DICTIONARY.md','AUTHOR_SUBMISSION_CHECKLIST.md','COVER_LETTER_DRAFT.md']:shutil.copy2(O/name,R/name)
for i in [1,2,3]:shutil.copy2(O/f'render_round{i}/NATURE_ARTICLE_A_v81.pdf',R/f'A_v81_ROUND{i}_REVIEW_COPY.pdf')
review=['# v81 三轮AI模拟评审与回应\n\nNature Skills辅助稿件准备，共九个独立上下文。各轮评审互盲，先冻结后综合。不是人类期刊外审；未发现Blocking Yes不等于Major均已关闭或Nature接受。\n']
for i in [1,2,3]:
 review.append(f'\n# 第{i}轮\n')
 for n in [1,2,3]:review.append((O/f'rounds/round{i}/r{n}/REVIEW.md').read_text())
 review.append((O/f'rounds/round{i}/SYNTHESIS_AND_RESPONSE_ZH.md').read_text())
(O/'THREE_ROUND_REVIEWS.md').write_text('\n\n'.join(review));shutil.copy2(O/'THREE_ROUND_REVIEWS.md',R/'THREE_ROUND_REVIEWS.md')
w=openpyxl.load_workbook(B/'Source_Data_A_v80.xlsx')
for sheet,path in [('EDT5_full_sensitivity','full_sensitivity/table.csv'),('EDT5_day_JK','full_sensitivity/day_replicates.csv'),('Noise_period_alpha','noise_weights/period_coefficients.csv'),('Bin_weight_reconstruction','noise_weights/bin_weights.csv')]:
 s=w.create_sheet(sheet);df=pd.read_csv(O/path);s.append(list(df.columns))
 for row in df.itertuples(index=False,name=None):s.append(list(row))
 s.freeze_panes='A2';s.auto_filter.ref=s.dimensions
w['Read_me'].append(['v81 revision','v80 observations and figures unchanged; added independent scalar-response sensitivity as EDT5. Original 12h_sensitivity is grouped EDT4.'])
w['Read_me'].append(['Bin weights','sigma_i = alpha_p/sqrt(n_i); see Noise_period_alpha and Bin_weight_reconstruction. Source algorithm is sources/noise_definition.py.'])
w['Read_me'].append(['y convention','CSV y precedes fixed remainder; NPZ y = CSV.y - fixed. Full-template response uses CSV.y and sum(three)+fixed.'])
w['Read_me'].append(['Apparatus stability','5.4e-16/sqrt(tau/s) is prior reported comparison scale; current weights are separately period-resolved.'])
w.save(R/'Source_Data_A_v81.xlsx')
for src,name in [('full_sensitivity/table.csv','Full_template_sensitivity.csv'),('noise_weights/period_coefficients.csv','Period_noise_coefficients.csv')]:shutil.copy2(O/src,R/name)
shutil.copy2(B/'NATURE_ARTICLE_A_v80.pdf',O/'baseline_v80/NATURE_ARTICLE_A_v80.pdf')
print('Prepared PDF, Word, source, one-page note, reviewer archive and source-data workbook')
