"""Figure 4: eight individual periods, with complete one-SE intervals."""
from pathlib import Path
import sys, json, hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

O=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(O/'vendor'))
from audit_panel_alignment import require_matplotlib_panel_alignment
t=pd.read_csv(O/'period_estimates/period_estimates.csv')
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans'],
 'font.size':7,'axes.labelsize':7,'axes.titlesize':8,'xtick.labelsize':6.5,
 'ytick.labelsize':7,'pdf.fonttype':42,'svg.fonttype':'none',
 'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.6})
fig=plt.figure(figsize=(180/25.4,108/25.4))
axes=[fig.add_axes([.15,.16,.27,.70]),fig.add_axes([.61,.16,.27,.70])]
months=['Sep 2025','Oct 2025','Jan 2026','Apr 2026','May 2026','Jun–Jul 2026','Aug 2026','Aug 2026']
for k,(ax,g,color,title) in enumerate(zip(axes,['L','S'],['#126080','#bc651f'],['Lunar group M₂ + N₂','Neighbouring group S₂ + K₂'])):
    values=t['A_'+g].to_numpy();errors=t['u_'+g].to_numpy();y=np.arange(8)[::-1]
    ax.axvline(0,color='.85',lw=.6,zorder=0)
    ax.axvline(1,color='.5',lw=.7,ls='--',zorder=0)
    ax.errorbar(values,y,xerr=errors,fmt='o',ms=4,color=color,lw=1,capsize=2,zorder=3)
    lo=np.min(values-errors);hi=np.max(values+errors);pad=.08*(hi-lo)
    ax.set(xlim=(lo-pad,hi+pad),ylim=(-.6,7.6),yticks=y,
           yticklabels=[f'{p}  {m}' for p,m in zip(t.period,months)] if k==0 else t.period,
           xlabel='Response coefficient')
    ax.set_title(title,loc='left',pad=14)
    ax.tick_params(axis='y',length=0,pad=5)
    ax.set_xticks([-2,0,1,2,4] if k==0 else [-15,-10,-5,0,5,10,15])
    for yy,v,e in zip(y,values,errors):
        ax.text(1.035,yy,f'{v:.2f} ± {e:.2f}',transform=ax.get_yaxis_transform(),
                ha='left',va='center',fontsize=6.3,color=color)
    ax.annotate('ab'[k],(0,1),xycoords='axes fraction',xytext=(-12,8),
                textcoords='offset points',fontsize=9,fontweight='bold',va='bottom')
fig.canvas.draw()
require_matplotlib_panel_alignment(fig,axes=axes,panel_ids=['a','b'],
    row_groups=[['a','b']],json_out=str(O/'verification/figure4_alignment.json'),
    overlay_svg=str(O/'verification/figure4_alignment.svg'),strict=True)
fig.savefig(O/'figures/figure4.pdf')
fig.savefig(O/'figures/figure4.svg')
fig.savefig(O/'figures/figure4.png',dpi=600)
record=dict(figure='figure4',source='period_estimates/period_estimates.csv',
            source_SHA256=hashlib.sha256((O/'period_estimates/period_estimates.csv').read_bytes()).hexdigest(),
            panels=['M2+N2 per period','S2+K2 per period'],points_per_panel=8,
            x_axes='Linear; different ranges; every error bar shown in full',
            error='One statistical standard error, max(scaled LS, day jackknife)',
            excluded_periods=[],deleted_period_estimates_displayed=False,
            width_mm=180,height_mm=108)
(O/'verification/FIGURE4_PROVENANCE.json').write_text(json.dumps(record,indent=2))
print('Figure 4: two panels, eight individual periods each; no omitted-period estimates.')
