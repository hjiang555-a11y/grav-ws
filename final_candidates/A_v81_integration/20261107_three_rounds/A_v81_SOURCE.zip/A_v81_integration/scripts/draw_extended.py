"""All main marks bind to one S54/Allan observation and template chain."""
from pathlib import Path
import sys,json,hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.patches import Ellipse
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'vendor'))
from audit_panel_alignment import require_matplotlib_panel_alignment

O=Path(__file__).resolve().parents[1];F=O/'figures'
j=json.loads((O/'data/RESULTS.json').read_text())
r=pd.read_csv(O/'data/primary_rows.csv');f=pd.read_csv(O/'data/phase_fold.csv')
s=pd.read_csv(O/'data/semidiurnal_spectrum.csv');l=pd.read_csv(O/'data/leave_period_all_designs.csv');l=l[l.design=='S54']
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['DejaVu Sans'],'font.size':7,'axes.labelsize':7,'axes.titlesize':7,
 'xtick.labelsize':6.5,'ytick.labelsize':6.5,'legend.fontsize':6.5,'pdf.fonttype':42,'svg.fonttype':'none',
 'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.7,'legend.frameon':False})
blue='#126080';orange='#bc651f';grey='#666666';green='#50816c';provenance=[]
def letter(a,t):
    a.annotate(t,(0,1),xycoords='axes fraction',xytext=(-11,7),textcoords='offset points',fontsize=8,fontweight='bold',va='bottom')
def save(fig,name,axes,ids,**kw):
    fig.canvas.draw()
    if len(axes)>1:
        require_matplotlib_panel_alignment(fig,json_out=F/(name+'.alignment.json'),overlay_svg=F/(name+'.alignment.svg'),axes=axes,panel_ids=ids,strict=True,**kw)
    else:
        (F/(name+'.alignment.json')).write_text(json.dumps({'status':'NOT_APPLICABLE_SINGLE_PANEL','axes':ids}))
    # Standard editable sans-serif text; series colour is encoded in marks/keys.
    from matplotlib.text import Text
    for obj in fig.findobj(Text):
        obj.set_color('black')
        if obj.get_text() not in ids and obj.get_fontsize()>7:obj.set_fontsize(7)
    fig.savefig(F/(name+'.pdf'))
    fig.savefig(F/(name+'.svg'))
    fig.savefig(F/(name+'.png'),dpi=600 if name.startswith('figure') else 300)
    plt.close(fig)
    provenance.append(dict(figure=name,estimator='S54/Allan; saved current physical template',pdf_sha256=hashlib.sha256((F/(name+'.pdf')).read_bytes()).hexdigest()))

# Original filenames retained; manuscript places ed_figure2 as ED1 and ed_figure1 as ED2.
# Same archived plot code, separated to avoid replacing main figures.
# Same rows, same weights, alternative intercept granularity.
fig=plt.figure(figsize=(180/25.4,88/25.4));a=fig.add_axes([.12,.19,.35,.62]);b=fig.add_axes([.62,.19,.34,.62])
rr=pd.read_csv(O/'data/segment_residual_means.csv');v=rr[rr.design=='P8']
a.axhline(0,color='.7',lw=.6);a.scatter(v.seg,v.weighted_residual_mean,s=13,color=orange)
a.set(xlabel='Recorded segment number',ylabel='P8 residual segment mean (10⁻¹⁸)',title='Residual levels with period constants')
ll=pd.read_csv(O/'data/leave_period_all_designs.csv')
for name,color,dx in [('P8',orange,-.10),('S54',blue,.10)]:
    q=ll[ll.design==name];b.plot(np.arange(1,9)+dx,q.A_L,'o-',ms=3,lw=.65,color=color,label=name)
b.axhline(1,color='.7',ls='--',lw=.6);b.set(xlabel='Omitted observing period',ylabel='Lunar point estimate',xticks=range(1,9),ylim=(.82,1.13));b.legend(ncol=2,loc='upper right')
letter(a,'a');letter(b,'b');save(fig,'ed_figure1',[a,b],['a','b'],row_groups=[['a','b']])

# Extended Data 2: observed conditional scans, not newly estimated amplitudes.
fig=plt.figure(figsize=(180/25.4,87/25.4));a=fig.add_axes([.13,.21,.35,.57]);b=fig.add_axes([.62,.21,.35,.57])
cs=pd.read_csv(O/'data/conditional_scans.csv')
for ax,target,other in [(a,'M2','S2'),(b,'S2','M2')]:
    q=cs[cs.target==target];lo=q.frequency_uHz.min();hi=q.frequency_uHz.max();u=s[s.frequency_uHz.between(lo,hi)]
    ax.plot(u.frequency_uHz,u.observed_potential_PSD_m4_sminus4_per_uHz,color=blue,lw=.9,label='Observed')
    ax.plot(q.frequency_uHz,q.potential_PSD,color=orange,lw=.9,label='Conditioned on '+other[0]+'₂')
    ax.axvline(j['spectrum']['frequency_Hz'][target]*1e6,ls=':',color='.5',lw=.7)
    ax.set(xlim=(lo,hi),xlabel='Frequency (µHz)',ylabel='Potential power density\n[(m²/s²)²/µHz]',ylim=(0,.22))
    ax.legend(loc='lower left',bbox_to_anchor=(0,1.04),fontsize=6.3)
letter(a,'a');letter(b,'b');save(fig,'ed_figure2',[a,b],['a','b'],row_groups=[['a','b']])

# Extended Data 3: original Fig. 4b monitor values and paired errors, unchanged.
fig=plt.figure(figsize=(130/25.4,80/25.4));a=fig.add_axes([.22,.23,.72,.57])
m=j['monitor'];a.axvline(0,color='.65',ls='--',lw=.7)
a.errorbar(m['delta'],[2,1,0],xerr=m['paired_day_se'],fmt='o',color=green,ms=4,capsize=3)
a.set(yticks=[2,1,0],yticklabels=['Lunar','Near-12 h','Diurnal'],xlim=(-.025,.025),ylim=(-.6,2.6),xticks=[-.02,0,.02],xlabel='Change in response coefficient')
a.set_title('Matched fibre round-trip control: 246.6 h in summer',loc='left',pad=14)
save(fig,'ed_figure3',[a],['monitor'])

(F/'ED_REPLAY_PROVENANCE.json').write_text(json.dumps(provenance,indent=2))
