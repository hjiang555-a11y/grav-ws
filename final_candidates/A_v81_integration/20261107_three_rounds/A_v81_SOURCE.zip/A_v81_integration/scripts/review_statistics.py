"""Frozen-design reviewer-requested inference; simulations are not observations."""
from pathlib import Path
import hashlib
import json
import platform

import numpy as np
import pandas as pd
import scipy
from scipy.stats import norm

O = Path(__file__).resolve().parents[1]
D = O/'review_diagnostics'
INPUT = O/'data'
SEED, M, BATCH = 2026110709, 20000, 1000
SCENARIOS = ['white', 'half_OU6h_segment', 'half_OU24h_period', 'student_t5']


def serial(x):
    if isinstance(x, np.ndarray): return x.tolist()
    if isinstance(x, np.generic): return x.item()
    raise TypeError(type(x).__name__)


def design(signals, labels):
    return np.column_stack([signals, labels[:, None] == np.unique(labels)[None, :]])


def solve(X, y, sigma):
    active=np.any(X!=0,axis=0)
    if not active.all():
        result=solve(X[:,active],y,sigma)
        beta=np.zeros(X.shape[1]);beta[active]=result['beta']
        H=np.zeros((X.shape[1],len(y)));H[active]=result['H']
        cov=np.zeros((X.shape[1],X.shape[1]));cov[np.ix_(active,active)]=result['covariance']
        result.update(beta=beta,H=H,covariance=cov)
        return result
    A = X/sigma[:, None]
    scales = np.linalg.norm(A, axis=0)
    assert np.all(scales > 0)
    U, singular, Vt = np.linalg.svd(A/scales, full_matrices=False)
    rank = np.sum(singular > singular[0]*1e-12)
    assert rank == X.shape[1], (rank, X.shape, singular[-1])
    H = ((Vt.T/singular) @ U.T) / scales[:, None] / sigma[None, :]
    beta = H@y
    residual = y-X@beta
    rss = np.sum((residual/sigma)**2)
    variance = rss/(len(y)-rank)
    h = H*sigma
    cov = variance*(h@h.T)
    return dict(beta=beta, residual=residual, weighted_RSS=rss, scale=variance,
                covariance=cov, H=H, rank=int(rank), normalized_condition=singular[0]/singular[-1])


def estimate(signals, y, sigma, labels, days, periods):
    result = solve(design(signals, labels), y, sigma)
    k = signals.shape[1]
    result['A'] = result['beta'][:3]
    result['scaled_LS'] = np.sqrt(np.diag(result['covariance'])[:3])
    for key,groups in [('day',days),('period',periods)]:
        replicates=[]
        for g in np.unique(groups):
            keep = groups != g
            replicates.append(solve(design(signals[keep],labels[keep]),y[keep],sigma[keep])['beta'][:3])
        replicates=np.array(replicates)
        centered=replicates-replicates.mean(axis=0)
        cov=(len(replicates)-1)/len(replicates)*centered.T@centered
        result[key+'_JK']=np.sqrt(np.diag(cov))
        result[key+'_covariance']=cov
    result['SE'] = np.maximum(result['scaled_LS'],result['day_JK'])
    result['working_95'] = np.column_stack([result['A']-1.96*result['SE'],result['A']+1.96*result['SE']])
    result['signals_columns'] = k
    return result


def compact(result):
    return {k:v for k,v in result.items() if k not in ['H','residual','beta']}


def wilson(k,n):
    z=norm.ppf(.975);a=k/n;den=1+z*z/n
    midpoint=(a+z*z/(2*n))/den
    radius=z*np.sqrt(a*(1-a)/n+z*z/(4*n*n))/den
    return [max(0,midpoint-radius),min(1,midpoint+radius)]


def main():
    saved=json.loads((INPUT/'RESULTS.json').read_text())
    a=np.load(INPUT/'design.npz')
    S,y,sigma,t,seg,period,days=[a[n] for n in ['three','y','sigma','seconds','seg','period','days']]
    assert len(y)==3299 and len(np.unique(seg))==54 and len(np.unique(period))==8
    models={}
    models['primary']=estimate(S,y,sigma,seg,days,period)
    baseline=models['primary']
    for field,old in [('A','A'),('SE','u'),('scaled_LS','scaled_ls'),('day_JK','day_jackknife')]:
        np.testing.assert_allclose(baseline[field],saved['primary'][old],atol=1e-9,rtol=0)
    trig=np.column_stack([np.cos(2*np.pi*t/(12*3600)),np.sin(2*np.pi*t/(12*3600))])
    for mode in ['common','per_period']:
        extra=trig if mode=='common' else np.column_stack([trig*(period==p)[:,None] for p in np.unique(period)])
        result=estimate(np.column_stack([S,extra]),y,sigma,seg,days,period)
        models['12h_'+mode]=result
        np.testing.assert_allclose(result['A'],saved['daily_sensitivity']['12h_'+mode]['A'][:3],atol=1e-8,rtol=0)
        np.testing.assert_allclose(result['SE'],saved['daily_sensitivity']['12h_'+mode]['u'][:3],atol=1e-8,rtol=0)

    X=design(S,seg)
    X0=np.delete(X,1,axis=1)
    restricted=solve(X0,y,sigma)
    Q0=np.linalg.qr(X0/sigma[:,None],mode='reduced')[0]
    partial=S[:,1]/sigma-Q0@(Q0.T@(S[:,1]/sigma))
    norm_partial=np.linalg.norm(partial)
    g=partial/norm_partial
    statistic=(g@(y/sigma))**2
    np.testing.assert_allclose(statistic,restricted['weighted_RSS']-baseline['weighted_RSS'],atol=1e-8,rtol=0)
    qr=np.linalg.lstsq(X/sigma[:,None],y/sigma,rcond=None)[0]
    np.testing.assert_allclose(qr,baseline['beta'],atol=1e-9,rtol=0)
    H=baseline['H'][:2]
    noise_scale=np.sqrt(saved['primary']['scale'])

    distributions=[];records=[];joint=[];direct_checks=[]
    sequences=np.random.SeedSequence(SEED).spawn(len(SCENARIOS))
    for scenario,sequence in zip(SCENARIOS,sequences):
        rng=np.random.default_rng(sequence)
        null_statistics=[];error_draws=[]
        for offset in range(0,M,BATCH):
            count=min(BATCH,M-offset)
            if scenario=='white':z=rng.standard_normal((len(y),count))
            elif scenario=='student_t5':z=rng.standard_t(5,(len(y),count))/np.sqrt(5/3)
            else:
                labels,tau=(seg,6*3600) if '6h' in scenario else (period,24*3600)
                ou=np.empty((len(y),count))
                for i in range(len(y)):
                    if i==0 or labels[i]!=labels[i-1]:ou[i]=rng.standard_normal(count)
                    else:
                        rho=np.exp(-max(0,t[i]-t[i-1])/tau)
                        ou[i]=rho*ou[i-1]+np.sqrt(1-rho*rho)*rng.standard_normal(count)
                z=(rng.standard_normal((len(y),count))+ou)/np.sqrt(2)
            noise=z*sigma[:,None]*noise_scale
            delta=(g@(noise/sigma[:,None]))**2
            null_statistics.append(delta)
            error_draws.append((H@noise).T)
            # A direct refit validates the exact projection formula for every law.
            if offset==0:
                for i in range(3):
                    simulated=X0@restricted['beta']+noise[:,i]
                    actual=solve(X0,simulated,sigma)['weighted_RSS']-solve(X,simulated,sigma)['weighted_RSS']
                    np.testing.assert_allclose(actual,delta[i],atol=2e-8,rtol=0)
                    direct_checks.append(dict(scenario=scenario,draw=i,absolute_difference=abs(actual-delta[i])))
        delta=np.concatenate(null_statistics)
        errors=np.concatenate(error_draws)
        k=int(np.sum(delta>=statistic))
        records.append(dict(scenario=scenario,simulations=M,exceedances=k,
                            p_plus_one=(k+1)/(M+1),null_tail_probability_Wilson95=wilson(k,M),
                            delta_RSS_observed=statistic,delta_RSS_null95=float(np.quantile(delta,.95)),
                            delta_RSS_null99=float(np.quantile(delta,.99))))
        train,test=errors[:M//2],errors[M//2:]
        cov=np.cov(train,rowvar=False);inv=np.linalg.inv(cov)
        qtrain=np.einsum('bi,ij,bj->b',train,inv,train)
        qtest=np.einsum('bi,ij,bj->b',test,inv,test)
        q95=float(np.quantile(qtrain,.95))
        coverage=float(np.mean(qtest<=q95))
        center=baseline['A'][:2]
        extent=np.sqrt(q95*np.diag(cov))
        joint.append(dict(scenario=scenario,calibration_n=M//2,validation_n=M//2,
                          error_covariance=cov,mahalanobis_95=q95,
                          validation_coverage=coverage,coverage_MC_SE=np.sqrt(coverage*(1-coverage)/(M//2)),
                          projected_95_bounds=np.column_stack([center-extent,center+extent]),
                          intersects_A_S_zero=bool(center[1]-extent[1]<=0),
                          error_mean=train.mean(axis=0)))
        distributions.append(pd.DataFrame(dict(scenario=scenario,draw=np.arange(M),delta_RSS=delta,
                                               error_A_L=errors[:,0],error_A_S=errors[:,1])))
        print(json.dumps(records[-1],default=serial),flush=True)

    # Paired monitor contrast, using exactly the existing common observed members.
    monitor=pd.read_csv(O/'sources/frozen_v72/monitor_monitor_rows.csv')
    monitor=monitor[monitor.included_in_fit]
    ix=monitor.r7_row.to_numpy(int)
    target=monitor.y.to_numpy()-a['fixed'][ix]
    sigm=monitor.sigma.to_numpy();labs=seg[ix];dm=days[ix]
    aug=np.column_stack([S[ix],monitor.monitor_e18.to_numpy()])
    old=solve(design(S[ix],labs),target,sigm)['beta'][:3]
    new=solve(design(aug,labs),target,sigm)['beta'][:3]
    contrasts=[]
    for day in np.unique(dm):
        keep=dm!=day
        contrasts.append(solve(design(aug[keep],labs[keep]),target[keep],sigm[keep])['beta'][:3]-
                         solve(design(S[ix][keep],labs[keep]),target[keep],sigm[keep])['beta'][:3])
    cc=np.array(contrasts);cc-=cc.mean(axis=0)
    paired_SE=np.sqrt(np.diag((len(cc)-1)/len(cc)*cc.T@cc))
    np.testing.assert_allclose(new-old,saved['monitor']['delta'],atol=1e-10,rtol=0)
    np.testing.assert_allclose(paired_SE,saved['monitor']['paired_day_se'],atol=1e-10,rtol=0)

    rows=[]
    for name,result in models.items():
        for k,group in enumerate(['M2+N2','S2+K2','Diurnal']):
            rows.append(dict(model=name,group=group,estimate=result['A'][k],SE=result['SE'][k],
                             scaled_LS=result['scaled_LS'][k],day_JK=result['day_JK'][k],
                             lower_1_96_SE=result['working_95'][k,0],upper_1_96_SE=result['working_95'][k,1],
                             normalized_condition=result['normalized_condition'],rank=result['rank']))
    pd.DataFrame(rows).to_csv(D/'twelve_hour_sensitivity.csv',index=False)
    pd.DataFrame(records).to_csv(D/'weak_group_null_tests.csv',index=False)
    pd.concat(distributions,ignore_index=True).to_csv(D/'simulation_draws.csv',index=False)
    result=dict(protocol=dict(seed=SEED,simulations_per_scenario=M,scenarios=SCENARIOS,
                              noise_scale='Original full-model residual scale',
                              test='Nested weighted RSS improvement for the one S2+K2 coefficient; two-sided amplitude alternative',
                              null='A_S=0, other physical groups and 54 intercepts retained at restricted-fit values',
                              scope='Conditional on frozen sampling, templates, weights and declared noise laws; no nuisance daily signal in the null.'),
                models={k:compact(v) for k,v in models.items()},
                nested=dict(delta_RSS=statistic,RSS_full=baseline['weighted_RSS'],RSS_restricted=restricted['weighted_RSS'],
                            residual_df_full=len(y)-X.shape[1],added_parameters=1,
                            restricted_other_group_coefficients=restricted['beta'][:2],
                            partial_template_norm=norm_partial),
                null_tests=records,joint_regions=joint,direct_refit_checks=direct_checks,
                monitor=dict(delta=new-old,paired_day_SE=paired_SE,rows=len(monitor),support=saved['monitor']['support']),
                sample=dict(rows=len(y),segments=len(np.unique(seg)),periods=len(np.unique(period)),days=len(np.unique(days))),
                software=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__,scipy=scipy.__version__),
                input_hashes={n:hashlib.sha256((INPUT/n).read_bytes()).hexdigest() for n in ['design.npz','RESULTS.json']})
    (D/'REVIEW_RESULTS.json').write_text(json.dumps(result,indent=2,default=serial)+'\n')
    print('REVIEW_STATISTICS_COMPLETE',flush=True)


if __name__=='__main__':main()
