from pathlib import Path
import json,hashlib
O=Path(__file__).resolve().parents[1];R=O/'rounds/round2'
for n,h in json.loads((R/'FROZEN_REVIEWS.json').read_text()).items():assert hashlib.sha256((R/n).read_bytes()).hexdigest()==h
p=O/'manuscript_template.md';s=p.read_text();(R/'before_response.md').write_text(s)
edits={
'The measurements extend a fixed-site clock comparison from static potential differences to changes over hours.':'This extends static clock-based potential measurements to changes over hours.',
'Each observing segment retains its own frequency reference level, while the actual observation times preserve the astronomical phase across interruptions.':'Separate frequency levels accommodate interrupted operation, while recorded times fix the astronomical phase.',
'The apparatus and frequency-comparison chain are described by Hou and colleagues.[@hou]':'The apparatus and frequency-comparison chain are described by Hou and colleagues.[@hou] The reported clock-comparison instability follows the characteristic white-frequency-noise scale $5.4\\times10^{-16}/\\sqrt{\\tau/(1\\,\\mathrm{s})}$, where $\\tau$ is averaging time.',
'This links variation within runs to the known forcing phase across dates, allowing interrupted clock comparisons to constrain time-dependent components of the potential.':'This links variation within runs to the known forcing phase across dates, allowing interrupted clock comparisons to constrain time-dependent components of the potential. The accumulation relies on a predicted phase; an unanticipated transient would require sufficient precision during the event itself.',
'Both use $W_{ii}=1/\\sigma_i^2$ with the frozen Allan-based weights. The period noise coefficients are estimated from within-segment overlapping Allan deviations at 256–4,096 s after removal of the fixed unit tide. No Allan window crosses a segment boundary. This does not use stability calculated after joining fit-adjusted segment levels.':'Both use $W_{ii}=1/\\sigma_i^2$ with the period-dependent Allan-based uncertainties defined below.',
'The basis functions are evaluated at the actual UTC mean times.':'The basis functions are evaluated at the recorded UTC bin centres.',
'OpenAI Codex assisted English drafting, numerical replay and figure preparation. [Authors to confirm their verification of the analyses, citations and final text, and responsibility for the submitted work.]':'OpenAI Codex assisted English drafting, code preparation and checking, numerical replay, and plotting from derived experimental tables using Python. The geographical map in Fig. 1a was supplied by the authors and retained unchanged. No observations were generated to replace or fill the experimental record. [Authors to confirm the tool and version details, their verification of the code, source data, statistics, figures and citations, and responsibility for the final work.]',
}
for a,b in edits.items():assert a in s,a;s=s.replace(a,b)
noise=r'''### Construction of bin uncertainties

For ten-minute bin $i$, the assigned uncertainty is

$$\sigma_i=\frac{\alpha_{p(i)}}{\sqrt{n_i}},$$

where $n_i$ counts retained nominal one-second members and $\alpha_p$ is the one-second fractional-frequency noise level of period $p$. In this convention the corresponding white-frequency instability is $\alpha_p/\sqrt{\tau/(1\,\mathrm{s})}$. The eight coefficients and all reconstructed bin uncertainties are supplied in the machine-readable source data.

The noise calculation uses original segments containing at least 8,192 retained members. The fixed unit tidal prediction is evaluated at member timestamps and subtracted after centring within each segment. Overlapping Allan deviations are calculated at 256, 512, 1,024, 2,048 and 4,096 nominal seconds, using the acquisition's one-second member convention. At each averaging time the deviations are averaged across eligible segments, weighted by their member counts. The geometric mean of these averaged deviations multiplied by $\sqrt{\tau/(1\,\mathrm{s})}$ gives $\alpha_p$. No Allan window crosses a segment boundary. These coefficients determine relative fitting weights; residual scaling and day deletion determine the reported statistical errors.

The apparatus instability benchmark quoted with Fig. 1a comes from the previously reported spliced summer comparison.[@hou] It is not used to assign the present weights, which are reconstructed from the period coefficients and retained member counts. No stability estimate from joined, fit-adjusted levels is used in this analysis.

'''
s=s.replace('### Statistical errors and conditional coverage',noise+'### Statistical errors and conditional coverage')
p.write_text(s);(R/'response_template.md').write_text(s);(R/'RESPONSE_EDITS.json').write_text(json.dumps(edits,indent=2))
# Clarify timestamps in documentation and new-run provenance without changing calculations.
p=O/'DATA_DICTIONARY.md';v=p.read_text().replace('actual mean timestamps','recorded bin-centre timestamps');p.write_text(v)
p=O/'scripts/check_full_sensitivity.py';v=p.read_text().replace('actual mean UTC times','recorded UTC bin centres');p.write_text(v)
p=O/'full_sensitivity/RESULTS.json';v=json.loads(p.read_text());v['frequency_basis']='sin/cos at recorded UTC bin centres; 24 h shared or 12 h separately in each of eight periods';p.write_text(json.dumps(v,indent=2))
audit=[dict(audit_id='AUD2-01',status='passed',location='Full response and grouped values',check='Frozen figures/results compared with v80',result='No numerical changes. Error definitions remain max(LS, UTC-day jackknife).'),dict(audit_id='AUD2-02',status='passed',location='Bin uncertainties',check='alpha/sqrt(n) on 3299 means',result=json.loads((O/'noise_weights/VERIFICATION.json').read_text())),dict(audit_id='AUD2-03',status='confirmed_internal_error',location='New full-sensitivity method timestamp wording',check='seconds field versus CSV t_utc and source raw-support timing record',result='Stored timestamps are bin centres, not mean raw-member timestamps. Wording and provenance corrected. Computation unchanged.'),dict(audit_id='AUD2-04',status='passed',location='Apparatus stability',check='Hou HTML 98–99 and PRL main.tex 359–373',result='5.4e-16/sqrt(tau/s) is reported comparison scale, not individual-clock stability. Origin disclosed in Methods; not used as current weight.'),dict(audit_id='AUD2-05',status='unresolved_input_needed',location='Solid template and actual residual covariance',check='Scope of calibration claims',result='No new potential-weighted or empirically calibrated noise calculation requested/performed; both limitations retained. No independent solar detection claim.' )]
(R/'FORENSIC_AUDIT.json').write_text(json.dumps(audit,indent=2))
(R/'SYNTHESIS_AND_RESPONSE_ZH.md').write_text('''# 第二轮综合与回应

三份隔离评审冻结后综合。所有评审认为中心潮汐检出有支持，未报告已确立的阻断缺陷；这不代表期刊接收或作者科学批准。

共识：三位均指出固体模板势加权对照未完成（R1-M2、R2-M1、R3-M1）。延续上一轮的明确限定，未把K1的18%转换成整体误差，也未凭润色宣称问题已闭环。R1-M1仍希望增强增量定位；根据用户最新指示，本轮不再重写论证，保留整体探测与分组约束两层结构、Hou重叠披露和欧洲末句。

R2-M2提出与实测相关结构相容的噪声检验，属后续精度验证建议，不是新增太阳潮检出的投稿门槛。本轮保留四种情景均不能充分描述实测短时相关的原文、按日/按期误差及有限符号枚举，不制造一个更高“σ”。R1-m1、R3-m1建议改图3b标记；用户要求保留v80图件，因此采用现有明确图注并列两种误差，图内重标仍列可选作者修改。R2-m1字段字典已补，下一轮评审包纳入该文件。

依据最新用户指示完成三项定向补充：
1. 核对实际noise.py并新增权重公式、alpha生成步骤和8期机器可读系数表。3299个sigma重建最大差7.11e-15（以1e-18为单位），只属舍入。此项为冻结权重重建，不冒称本轮重新处理原始计数。
2. 图1a装置介绍加入已报道两钟比较5.4e-16/sqrt(tau/s)性能标度；Methods注明来自历史夏季拼接图，当前权重仍在原段内构建，不引入长稳度检验。
3. 讨论保留一句未预报瞬变须在事件内达到精度的推广边界；AI声明具体区分实验表格代码制图与作者提供的地图。相关稿件在审状态、作者和访问事实由作者确认。

编辑审计另发现新加全模板敏感性文句把bin-centre写成mean time，已更正为记录的UTC箱中心。数值从未使用错误时间。摘要压缩，清除孤立末行。原始数据、样本、主系数、全部图及扩展表4不变。
''')
print('Round2 responses and user-directed methods/stability additions saved')
