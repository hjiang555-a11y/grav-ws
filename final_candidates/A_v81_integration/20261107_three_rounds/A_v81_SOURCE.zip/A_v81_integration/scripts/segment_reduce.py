"""A v78-equivalent segment reduction; never join calibrated frequency levels."""
from pathlib import Path
import hashlib
import json

import numpy as np
import pandas as pd

O=Path(__file__).resolve().parents[1]


def center(values,weights,segments):
    values=np.asarray(values);single=values.ndim==1
    array=values[:,None] if single else values
    codes=np.unique(segments,return_inverse=True)[1]
    sums=np.bincount(codes,weights=weights)
    means=np.column_stack([np.bincount(codes,weights=weights*array[:,k])/sums for k in range(array.shape[1])])
    result=array-means[codes]
    return (result[:,0] if single else result),means


def fit(S,y,sigma,segments):
    w=1/sigma**2;T,means=center(S,w,segments);z,levels=center(y,w,segments)
    A=T/sigma[:,None]
    beta=np.linalg.lstsq(A,z/sigma,rcond=None)[0]
    residual=z-T@beta
    df=len(y)-len(np.unique(segments))-S.shape[1]
    rss=np.sum(w*residual**2);scale=rss/df
    cov=scale*np.linalg.inv(A.T@A)
    return dict(A=beta,cov=cov,SE_LS=np.sqrt(np.diag(cov)),residual=residual,T=T,z=z,
                scale=scale,df=df,rss=rss,data_means=levels[:,0],template_means=means)


def main():
    d=np.load(O/'data/design.npz');S,y,sigma,seg,days=[d[k] for k in ['three','y','sigma','seg','days']]
    source=pd.read_csv(O/'data/primary_rows.csv')
    expected=json.loads((O/'data/RESULTS.json').read_text())
    result=fit(S,y,sigma,seg)
    Z=(seg[:,None]==np.unique(seg)[None,:]).astype(float)
    X=np.column_stack([S,Z]);A=X/sigma[:,None]
    Q,R=np.linalg.qr(A,mode='reduced');direct=np.linalg.solve(R,Q.T@(y/sigma))
    np.testing.assert_allclose(result['A'],direct[:3],atol=1e-11,rtol=0)
    for name,groups in [('day',days),('period',d['period'])]:
        reps=[]
        for group in np.unique(groups):
            keep=groups!=group
            reps.append(fit(S[keep],y[keep],sigma[keep],seg[keep])['A'])
        reps=np.array(reps);deviations=reps-reps.mean(axis=0)
        covariance=(len(reps)-1)/len(reps)*deviations.T@deviations
        result[name+'_SE']=np.sqrt(np.diag(covariance))
        result[name+'_cov']=covariance
    result['SE']=np.maximum(result['SE_LS'],result['day_SE'])
    for key,old in [('A','A'),('SE','u'),('SE_LS','scaled_ls'),('day_SE','day_jackknife'),('period_SE','period_jackknife')]:
        np.testing.assert_allclose(result[key],expected['primary'][old],atol=1e-10,rtol=0)
    np.testing.assert_allclose(result['residual'],source.primary_residual,atol=1e-9,rtol=0)

    # The non-lunar projection is performed only after segment reduction.
    nuisance=result['T'][:,1:]/sigma[:,None]
    q=np.linalg.qr(nuisance,mode='reduced')[0]
    def project(v):
        a=v/sigma
        return (a-q@(q.T@a))*sigma
    lunar_y=project(result['z']);lunar_unit=project(result['T'][:,0])
    np.testing.assert_allclose(lunar_y,source.projected_y,atol=1e-8,rtol=0)
    np.testing.assert_allclose(lunar_unit,source.projected_unit,atol=1e-8,rtol=0)

    rows=source.copy()
    rows['segment_centered_observation']=result['z']
    for i,name in enumerate(['lunar','near12','diurnal']):rows['centered_'+name]=result['T'][:,i]
    rows['centered_unit_total']=result['T'].sum(axis=1)
    rows['centered_fitted_total']=result['T']@result['A']
    rows['lunar_projected_observation']=lunar_y;rows['lunar_projected_unit']=lunar_unit
    rows.to_csv(O/'segment_reduction/segment_rows.csv',index=False)

    table=[];display=[];G=[];h=[];offset=0.0
    # pandas may store parsed datetimes in us or ns; timestamp() is always seconds.
    epoch=pd.to_datetime(rows.t_utc,utc=True).map(lambda x:x.timestamp()).to_numpy()
    np.testing.assert_allclose(np.diff(epoch),np.diff(d['seconds']),atol=1e-5,rtol=0)
    for s in np.unique(seg):
        ix=np.flatnonzero(seg==s);w=1/sigma[ix]**2;local=result['T'][ix]
        G.append(local.T@(w[:,None]*local));h.append(local.T@(w*result['z'][ix]))
        table.append(dict(seg=int(s),period=rows.iloc[ix[0]].period,first_utc=rows.iloc[ix[0]].t_utc,
                          last_utc=rows.iloc[ix[-1]].t_utc,rows=len(ix),accepted_members=int(rows.iloc[ix].n.sum()),
                          accepted_hours=rows.iloc[ix].n.sum()/3600,within_span_hours=np.ptp(epoch[ix])/3600,
                          observation_weighted_mean=result['data_means'][len(table)],
                          weight_sum=w.sum(),display_start=offset))
        # Fixed UTC 3-hour boundaries within each segment; no member is removed.
        groups=(epoch[ix]//10800).astype(np.int64)
        for group in np.unique(groups):
            ii=ix[groups==group];ww=1/sigma[ii]**2;sw=ww.sum()
            display.append(dict(seg=int(s),period=rows.iloc[ii[0]].period,UTC_bin=int(group),
                                t_utc=pd.to_datetime(np.average(epoch[ii],weights=ww),unit='s',utc=True).isoformat(),
                                x=offset+(np.average(epoch[ii],weights=ww)-epoch[ix].min())/3600,
                                mean=np.average(result['z'][ii],weights=ww),
                                unit=np.average(result['T'][ii].sum(axis=1),weights=ww),
                                fitted=np.average((result['T']@result['A'])[ii],weights=ww),
                                SE=np.sqrt(max(0,result['scale']*(1/sw-1/w.sum()))),
                                n_rows=len(ii),members=int(rows.iloc[ii].n.sum())))
        offset+=np.ptp(epoch[ix])/3600+2
    np.testing.assert_allclose(np.sum(G,axis=0)@result['A'],np.sum(h,axis=0),atol=1e-10,rtol=0)
    pd.DataFrame(table).to_csv(O/'segment_reduction/segment_ledger.csv',index=False)
    pd.DataFrame(display).to_csv(O/'segment_reduction/display_3h.csv',index=False)
    assert sum(x['n_rows'] for x in display)==3299
    assert sum(x['members'] for x in display)==1965327
    np.savez(O/'segment_reduction/sufficient_statistics.npz',G=G,h=h)
    record=dict(method='Weighted within-segment reduction, followed by one joint three-group estimate',
                source='A_v78 unchanged inputs',segments=54,rows=3299,members=1965327,
                A=result['A'],SE=result['SE'],scaled_LS=result['SE_LS'],day_SE=result['day_SE'],period_SE=result['period_SE'],
                RSS=result['rss'],df=result['df'],scale=result['scale'],covariance_LS=result['cov'],
                maximum_difference_from_full_QR=float(np.max(abs(result['A']-direct[:3]))),
                zero_rule='Weighted data and template means, separately in each segment; no fitted tidal coefficient enters centering.',
                new_observations=0,excluded_observations=0,
                display='Fixed UTC 3-hour means within segments only; all original rows/members retained; all-data 600-s estimator unchanged.',
                input_hashes={name:hashlib.sha256((O/'data'/name).read_bytes()).hexdigest() for name in ['design.npz','RESULTS.json','primary_rows.csv']})
    (O/'segment_reduction/RESULTS.json').write_text(json.dumps(record,indent=2,default=lambda a:a.tolist() if isinstance(a,np.ndarray) else a.item())+'\n')
    print(json.dumps({k:record[k] for k in ['A','SE','maximum_difference_from_full_QR','new_observations','excluded_observations']},default=lambda a:a.tolist()))


if __name__=='__main__':main()
