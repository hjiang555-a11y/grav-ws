"""One full-template amplitude, explicitly separate from the three-group fit."""
from pathlib import Path
import itertools,json
import numpy as np
import pandas as pd
from segment_reduce import center,fit

O=Path(__file__).resolve().parents[1]
d=np.load(O/'data/design.npz');rows=pd.read_csv(O/'data/primary_rows.csv')
sigma,seg,days,p,t=[d[k] for k in ['sigma','seg','days','period','seconds']]
S=(d['three'].sum(axis=1)+d['fixed'])[:,None]
y=rows.y.to_numpy()
out=fit(S,y,sigma,seg)
for name,groups in [('day',days),('period',p)]:
    replicates=[]
    for group in np.unique(groups):
        keep=groups!=group
        replicates.append(fit(S[keep],y[keep],sigma[keep],seg[keep])['A'][0])
    a=np.array(replicates)
    out[name+'_JK']=np.sqrt((len(a)-1)/len(a)*np.sum((a-a.mean())**2))
out['SE']=max(out['SE_LS'][0],out['day_JK'])
w=1/sigma**2;x=out['T'][:,0];z=out['z'];I=np.sum(w*x*x)
scores=np.array([np.sum((w*x*out['residual'])[days==day]) for day in np.unique(days)])
G=len(scores);K=55;N=len(y)
out['day_CR1']=np.sqrt(G/(G-1)*(N-1)/(N-K)*np.sum(scores*scores)/I**2)
g=x/sigma/np.sqrt(I);statistic=(g@(y/sigma))**2
out['null_RSS']=np.sum(w*z*z);out['delta_RSS']=statistic
np.testing.assert_allclose(out['null_RSS']-out['rss'],statistic,atol=1e-8,rtol=0)

records=[];draws=[]
for scenario,sequence in zip(['white','half_OU6h_segment','half_OU24h_period','student_t5'],np.random.SeedSequence(2026110711).spawn(4)):
    rng=np.random.default_rng(sequence);values=[]
    for batch in range(20):
        M=1000
        if scenario=='white':noise=rng.standard_normal((N,M))
        elif scenario=='student_t5':noise=rng.standard_t(5,(N,M))/np.sqrt(5/3)
        else:
            labels,tau=(seg,21600) if '6h' in scenario else (p,86400)
            ou=np.empty((N,M))
            for i in range(N):
                if i==0 or labels[i]!=labels[i-1]:ou[i]=rng.standard_normal(M)
                else:
                    rho=np.exp(-max(0,t[i]-t[i-1])/tau)
                    ou[i]=rho*ou[i-1]+np.sqrt(1-rho*rho)*rng.standard_normal(M)
            noise=(rng.standard_normal((N,M))+ou)/np.sqrt(2)
        values.extend((g@noise*np.sqrt(out['scale']))**2)
    values=np.array(values);k=int(np.sum(values>=statistic))
    records.append(dict(scenario=scenario,simulations=20000,exceedances=k,P_plus_one=(k+1)/20001,
                        observed_delta_RSS=statistic,null_q95=np.quantile(values,.95)))
    draws.append(pd.DataFrame(dict(scenario=scenario,draw=np.arange(len(values)),delta_RSS=values)))
    print(records[-1],flush=True)

contribution=np.array([g[p==period]@(z[p==period]/sigma[p==period]) for period in np.unique(p)])
patterns=np.array(list(itertools.product([-1,1],repeat=8)))
wild=(patterns@contribution)**2
result=dict(A=float(out['A'][0]),SE=float(out['SE']),scaled_LS=float(out['SE_LS'][0]),day_JK=float(out['day_JK']),
            day_CR1=float(out['day_CR1']),period_JK=float(out['period_JK']),working_95=[float(out['A'][0]-1.96*out['SE']),float(out['A'][0]+1.96*out['SE'])],
            delta_RSS=float(statistic),RSS_null=float(out['null_RSS']),RSS_full=float(out['rss']),df=out['df'],scale=float(out['scale']),
            period_restricted_wild_P=float(np.mean(wild>=statistic-1e-10)),period_patterns=256,
            conditional_stress_tests=records,seed=2026110711,
            scope='One scale multiplies the full combined prediction, including minor terms; original 3299 rows, 54 segment means, Allan weights.',
            note='Declared simulation laws are stress scenarios. Prior residual adequacy checks do not establish any as the true measurement-noise law.')
(O/'segment_reduction/FULL_TIDE.json').write_text(json.dumps(result,indent=2)+'\n')
pd.concat(draws).to_csv(O/'review_diagnostics/full_tide_null_draws.csv',index=False)
print(json.dumps(result,indent=2))
