from pathlib import Path
import json
O=Path(__file__).resolve().parents[1];R=O/'rounds/round2';R.mkdir();p=O/'manuscript_template.md';s=p.read_text();(R/'before_nature_polish.md').write_text(s)
nature={
'### Across observing periods and instrumental checks':'### Consistency across observing periods',
'The comparison also tests how well the observed variation can be assigned to neighbouring tidal components.':'The same record can also show which tidal components contribute to that variation.',
'These estimands share the observations but answer different questions. Both use':'The full-response model tests the combined waveform, whereas the grouped model allows the three astronomical bands to respond differently. Both use',
'The phase-relaxed model adds the lunar quadrature while retaining the prescribed M₂/N₂ relationship.':'The phase-relaxed model adds a lunar component shifted by a quarter-cycle while retaining the prescribed M₂/N₂ relationship.',
'The two-sided resolution is 2/256. No Gaussian sigma value is inferred from either finite enumeration.':'The two-sided resolution is 2/256; neither enumeration is converted to a Gaussian sigma value.',
}
for a,b in nature.items():assert a in s;s=s.replace(a,b)
(R/'nature_polished_template.md').write_text(s)
human={
'This raises an experimental question: can two clocks at fixed, distant sites detect changes in their potential difference over hours through their relative ticking rates?':'The experimental question is whether two clocks at fixed, distant sites can detect changes in their potential difference over hours through their relative ticking rates.',
'The broad neighbouring interval reflects direct competition with a same-frequency free term.':'The neighbouring interval broadens because the free term competes for variation at the same frequency.',
'The differing durations and phase coverage give unequal precision, including broad intervals in the shorter records.':'The periods differ in duration and phase coverage, giving broad intervals in the shorter records.',
'The minor theoretical remainder':'The minor theoretical remainder',
}
for a,b in list(human.items()):
 if a==b:del human[a];continue
 assert a in s;s=s.replace(a,b)
p.write_text(s);(R/'humanized_template.md').write_text(s);(R/'POLISH_EDITS.json').write_text(json.dumps({'nature':nature,'humanizer':human},indent=2))
print('Round 2 Nature and humanizer edits saved')
