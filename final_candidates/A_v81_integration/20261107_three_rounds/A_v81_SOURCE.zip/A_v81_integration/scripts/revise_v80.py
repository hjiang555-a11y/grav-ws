"""Local Nature-style edit: eight individual periods in Figure 4."""
from pathlib import Path
import re,json
O=Path(__file__).resolve().parents[1]
t=(O/'baseline_v79/manuscript_template.md').read_text()
old=t.split('### Consistency and experimental controls\n\n',1)[1].split('\n\nThe measurement extends',1)[0]
new=r'''Figure 4 shows the lunar and neighbouring responses estimated separately in each of the eight observing periods. Each estimate uses only that period's observations, with independent reference levels retained for its constituent segments. The different durations and lunar–solar phase coverage give unequal precision across periods. The full-record fit combines these within-period variations at their known astronomical phases.

A shared 24-h sine–cosine pair, motivated by daily operating schedules and environmental variation, gives a lunar coefficient of $1.04\pm0.13$. Allowing a separate 12-h pair in every period gives lunar $0.75\pm0.24$ and neighbouring $-5.10\pm15.01$. The broad neighbouring interval reflects direct competition between the free 12-h term and the astronomical template. These sensitivity scenarios, including the shared 12-h fit, are reported in Extended Data Table 4.

The simultaneous round-trip transmission monitor covers 246.6 member-hours in summer. Adding it on the same observation times changes the lunar coefficient by $0.0061\pm0.0063$ and the neighbouring coefficient by $0.00594\pm0.01453$ (Extended Data Fig. 3). This control constrains the monitored transmission route during the overlap.

The full-record response and lunar amplitude–phase agreement support tidal-potential detection. The neighbouring coefficient has weaker evidence under period-wise residual resampling, with a restricted wild sign-flip diagnostic of $P=0.0625$, and is reported as a component constraint within the specified physical model.'''
t=t.replace('### Consistency and experimental controls','### Measurements across observing periods').replace(old,new)
caption=r'''**Fig. 4 | Semidiurnal responses in eight individual observing periods.** **a,** Lunar M₂+N₂ coefficients. **b,** Neighbouring S₂+K₂ coefficients. Each point uses only the indicated period, jointly estimates all three physical groups, and retains independent reference levels for its original segments. All eight periods are shown in calendar order, with 163, 203, 409, 447, 429, 601, 595 and 452 ten-minute means, respectively. Error bars show one statistical standard error, the larger of scaled least squares and a UTC-day-deletion jackknife computed within that period. The periods contain 3, 3, 4, 5, 5, 9, 8 and 6 observed UTC dates. Both axes are linear and show the full error ranges; their scales differ. Dashed lines mark the unit prediction. The plotted periods use disjoint observations and are fitted separately; the full-record estimate is obtained by the common physical fit.'''
t,n=re.subn(r'\*\*Fig\. 4 \|[^\n]+',lambda m:caption,t)
assert n==1
anchor='The daily group is an auxiliary physical component;'
addition='For Fig. 4, we repeat the same three-group estimation separately on each of P1–P8. The data, fixed theoretical remainder and Allan-based weights are inherited from the frozen primary design; each period retains its original segment constants. The UTC-day jackknife is recomputed using only the dates present in that period. All period fits and day-deletion replicates retain full column rank and were independently checked against an explicit segment-intercept QR calculation. The individual-period errors use the same working standard-error rule as the full record.\n\n'
assert t.count(anchor)==1
t=t.replace(anchor,addition+anchor)
(O/'manuscript_template.md').write_text(t)
wc=lambda s:len(re.findall(r'\b\w+\b',s))
record=dict(scope='Figure 4 and related Results/Methods/caption',
    before_words=wc(old),after_words=wc(new),
    retained='All frozen observations, full-record results, physical definitions, uncertainty rules and other figures.',
    replaced='Overlapping deletion/grouping displays by eight individual-period estimates.',
    compressed='Repeated explanations of subset support and controls.',
    methods='Period-only estimation, within-period day jackknife and QR verification added; original grouping diagnostics remain in Extended Data.',
    main_claim='Tidal detection, followed by semidiurnal group constraints',
    title_changed=False,new_data=False)
(O/'verification/EDIT_RECORD.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record))
