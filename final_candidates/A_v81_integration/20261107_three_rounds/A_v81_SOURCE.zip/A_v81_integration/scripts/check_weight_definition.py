"""Reconstruct all bin weights from saved period noise coefficients and supports."""
from pathlib import Path
import hashlib,json,platform
import numpy as np
import pandas as pd
O=Path(__file__).resolve().parents[1];D=O/'noise_weights';D.mkdir(exist_ok=True)
r=pd.read_csv(O/'data/primary_rows.csv');j=json.loads((O/'sources/frozen_v72/evidence.json').read_text())
alpha=j['alpha_by_period'];calc=r.period.map(alpha).to_numpy()/np.sqrt(r.n.to_numpy())
np.testing.assert_allclose(calc,r.sigma.to_numpy(),atol=1e-12,rtol=0)
weights=1/calc**2;saved=1/r.sigma.to_numpy()**2
records=[]
for p in sorted(alpha):
 k=r.period==p;recovered=(r.sigma*np.sqrt(r.n))[k]
 records.append(dict(period=p,alpha_at_1s_1e18=alpha[p],n_bins=int(k.sum()),retained_members=int(r.loc[k,'n'].sum()),max_sigma_error=float(np.max(abs(calc[k]-r.sigma[k]))),recovered_alpha_range=float(recovered.max()-recovered.min())))
pd.DataFrame(records).to_csv(D/'period_coefficients.csv',index=False)
pd.DataFrame(dict(source_row=np.arange(len(r)),period=r.period,n=r.n,sigma_saved=r.sigma,sigma_reconstructed=calc,weight_reconstructed=weights)).to_csv(D/'bin_weights.csv',index=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result=dict(status='PASS',scope='Reconstruction of 3299 saved bin uncertainties and weights from archived alpha and membership counts. Static audit of raw-noise source; no new raw-counter replay.',n_rows=len(r),n_periods=len(alpha),max_abs_sigma_diff=float(max(abs(calc-r.sigma))),max_relative_weight_diff=float(max(abs(weights/saved-1))),
 formula='sigma_i = alpha_p / sqrt(n_i); alpha is the one-second fractional-rate coefficient in units 1e-18, equivalently Allan white-frequency-noise coefficient normalized at 1 s.',
 alpha_algorithm='Eligible original segments have >=8192 retained nominal one-second members. Subtract segment-centred fixed unit tide; overlapping Allan deviation at 256,512,1024,2048,4096 nominal seconds; length-weighted arithmetic average of deviations across eligible segments at each tau; geometric average of deviation*sqrt(tau/1s) across five taus.',
 source_hashes={f:sha(O/f) for f in ['sources/noise_definition.py','sources/frozen_v72/evidence.json','data/primary_rows.csv']},software=dict(python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__))
(D/'VERIFICATION.json').write_text(json.dumps(result,indent=2));print(pd.DataFrame(records).to_string(index=False));print('max sigma diff',result['max_abs_sigma_diff'])
