"""Recompute the integration draft's full-template sensitivity on v80 inputs."""
from pathlib import Path
import hashlib,json,shutil
import numpy as np
import pandas as pd
from segment_reduce import fit

O=Path(__file__).resolve().parents[1]
I=O/'integration_source';D=O/'full_sensitivity';D.mkdir(exist_ok=True)
source=I
d=np.load(O/'data/design.npz');e=np.load(source/'design.npz')
array_equal={k:bool(np.array_equal(d[k],e[k])) for k in d.files};assert all(array_equal.values())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(I/'NATURE_ARTICLE_FINAL_INTEGRATION.pdf')=='5035ebda5e21edc4d823b15bb8c375a28e6e0e355670f8b964fa7e75a8306048'
seconds=d['seconds'];T=d['three'].sum(axis=1)+d['fixed'];y=d['y']+d['fixed']
sigma=d['sigma'];seg=d['seg'];days=d['days'];period=d['period']
def harmonic(hours):
    z=seconds*2*np.pi/(hours*3600)
    return np.column_stack([np.sin(z),np.cos(z)])
h24=harmonic(24);h12=harmonic(12)
per12=np.column_stack([h12*(period==p)[:,None] for p in np.unique(period)])
models={'Whole template':T[:,None],'With shared 24-h pair':np.column_stack([T,h24]),
        'With period-specific 12-h pairs':np.column_stack([T,per12])}
reported=np.array([[.9551,.0973,.1082,.1082],[1.0316,.1028,.0980,.1028],[.7222,.1791,.2212,.2212]])
records=[];allrep=[];delta=0.
def direct(S,y,sig,segs):
    X=np.column_stack([S,segs[:,None]==np.unique(segs)[None,:]])
    A=X/sig[:,None];Q,R=np.linalg.qr(A,mode='reduced')
    assert np.linalg.matrix_rank(A)==X.shape[1]
    b=np.linalg.solve(R,Q.T@(y/sig));r=y-X@b
    inv=np.linalg.solve(R,np.eye(len(R)))
    cov=np.sum((r/sig)**2)/(len(y)-X.shape[1])*(inv@inv.T)
    return b[0],np.sqrt(cov[0,0])
for k,(name,S) in enumerate(models.items()):
    a=fit(S,y,sigma,seg);b,u=direct(S,y,sigma,seg)
    delta=max(delta,abs(a['A'][0]-b));np.testing.assert_allclose([a['A'][0],a['SE_LS'][0]],[b,u],atol=1e-10,rtol=0)
    reps=[]
    for day in np.unique(days):
        keep=days!=day;z=fit(S[keep],y[keep],sigma[keep],seg[keep]);bb,_=direct(S[keep],y[keep],sigma[keep],seg[keep])
        delta=max(delta,abs(z['A'][0]-bb));np.testing.assert_allclose(z['A'][0],bb,atol=1e-10,rtol=0)
        reps.append(z['A'][0]);allrep.append(dict(model=name,deleted_day=day,A_T=float(z['A'][0])))
    day_se=float(np.sqrt((len(reps)-1)/len(reps)*np.sum((reps-np.mean(reps))**2)))
    row=[float(a['A'][0]),float(a['SE_LS'][0]),day_se,max(day_se,float(a['SE_LS'][0]))]
    assert np.max(abs(np.array(row)-reported[k]))<.000051,(name,row)
    records.append(dict(model=name,A_T=row[0],scaled_LS=row[1],day_jackknife=row[2],reported_SE=row[3]))
table=pd.DataFrame(records);table.to_csv(D/'table.csv',index=False)
pd.DataFrame(allrep).to_csv(D/'day_replicates.csv',index=False)
out=dict(status='INDEPENDENTLY_RECOMPUTED',rows=len(y),segments=len(np.unique(seg)),UTC_days=len(np.unique(days)),
    source_commit='df4211fe619f8d611dc8b9c8a5fc86aa50f9e15e',source_table='FINAL_INTEGRATION Extended Data Table 4, PDF page 24',
    all_design_arrays_equal=array_equal,source_PDF_SHA256=sha(I/'NATURE_ARTICLE_FINAL_INTEGRATION.pdf'),
    input_SHA256=sha(O/'data/design.npz'),QR_max_difference=delta,results=records,
    verification_scope='Frozen derived means and numerical estimation; no independent raw-counter reconstruction.',
    frequency_basis='sin/cos at recorded UTC bin centres; 24 h shared or 12 h separately in each of eight periods')
(D/'RESULTS.json').write_text(json.dumps(out,indent=2))
print(table.to_string(index=False));print('Independent QR difference',delta)
