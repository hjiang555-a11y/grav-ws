"""Verify the v81 revision boundary, numerical additions and delivery artifacts."""
from pathlib import Path
import hashlib, json, re
import fitz
import numpy as np
import pandas as pd
import openpyxl

O = Path(__file__).resolve().parents[1]
h = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
baseline = json.loads((O/'baseline_v80/MANIFEST.json').read_text())
t = (O/'manuscript_template.md').read_text()
m = (O/'NATURE_ARTICLE_A_v81.md').read_text()
old = (O/'baseline_v80/manuscript_template.md').read_text()
c = {}
c['all_frozen_inputs_results_figures_unchanged'] = all(h(O/n) == v for n,v in baseline.items())
c['exact_title'] = t.splitlines()[0] == '# Tidal potential measured on a coastal–inland optical-clock baseline'
counts = json.loads((O/'verification/TEXT_STRUCTURE.json').read_text())
c['abstract_140_180_words'] = 140 <= counts['abstract'] <= 180
c['methods_under_3000_words'] = counts['methods'] <= 3000
c['four_main_figures_nine_extended_items'] = len(re.findall(r'^!\[Figure ',m,re.M)) == 4 and len(re.findall(r'^\*\*Extended Data (?:Fig\.|Table) [0-9]',m,re.M)) == 9
c['original_ED_table4_preserved'] = old.split('**Extended Data Table 4')[1].strip() == t.split('**Extended Data Table 4')[1].split('\\clearpage')[0].strip()
c['no_unexpanded_fields'] = not re.search(r'\{\{[A-Z_]+\}\}',m) and '[@' not in m
c['references_24'] = counts['references'] == 24
c['all_eight_figures_pixel_reproduced'] = all(v['pixel_identical'] for v in json.loads((O/'verification/PLOT_REPLAY.json').read_text()).values())
c['bin_weight_reconstruction'] = json.loads((O/'noise_weights/VERIFICATION.json').read_text())['status']=='PASS'
c['legends_under_250_words'] = all(n < 250 for label,n in counts['legends'])
main=m.split('## References')[0]
c['Europe_only_at_discussion_end'] = main.count('European') == 1 and bool(re.search(r'arXiv preprint\.\^\d+\^\s*\\clearpage\s*$', main))
c['Hou_overlap_disclosed'] = '16 overlapping summer segments' in main and r'$0.87\pm0.15$' in main
c['distinct_estimands'] = all(x in t for x in [r'A_TT_i',r'y_i-r_{0,i}',r'A_Ls_{L,i}+A_Ss_{S,i}+A_Ds_{D,i}'])
j = json.loads((O/'full_sensitivity/RESULTS.json').read_text())
c['new_table_independent_replay'] = j['status'] == 'INDEPENDENTLY_RECOMPUTED' and j['QR_max_difference'] < 1e-10 and all(j['all_design_arrays_equal'].values())
newtable=m.split('**Extended Data Table 5')[1]
tab=pd.read_csv(O/'full_sensitivity/table.csv')
printed_rows=[line for line in newtable.splitlines() if line.startswith('| ') and any(name in line for name in tab.model)]
printed=np.array([[float(x.strip()) for x in line.strip('|').split('|')[1:]] for line in printed_rows])
c['new_table_matches_numeric_output'] = printed.shape == (3,4) and np.allclose(printed,tab.select_dtypes('number').values,atol=.000051,rtol=0)
c['error_component_rule'] = np.allclose(tab.reported_SE,tab[['scaled_LS','day_jackknife']].max(axis=1),rtol=0,atol=1e-14)
for r in [1,2,3]:
    R=O/f'rounds/round{r}'
    hashes=json.loads((R/'FROZEN_REVIEWS.json').read_text())
    c[f'round{r}_three_frozen_reviews'] = len(hashes) == 3 and all(h(R/n) == v for n,v in hashes.items())
    c[f'round{r}_response_and_humanizer'] = all((R/n).is_file() for n in ['SYNTHESIS_AND_RESPONSE_ZH.md','HUMANIZER_CHECK.txt','FORENSIC_AUDIT.json']) and 'RESULT: all invariants hold' in (R/'HUMANIZER_CHECK.txt').read_text()
    packet=json.loads((R/'PACKET_SHA256.json').read_text())
    c[f'round{r}_packet_immutable'] = all(h(R/'packet'/n) == v for n,v in packet.items())
build=json.loads((O/'render_final/BUILD_RESULTS.json').read_text())
c['PDF_Word_build_clean'] = len(build['builds']) == 2 and all(x['exit'] == 0 and not x['warnings'] for x in build['builds'])
p=O/'render_final/NATURE_ARTICLE_A_v81.pdf'
doc=fitz.open(p)
c['PDF_under_30MB'] = p.stat().st_size < 30e6
c['no_single_line_or_blank_pages'] = all(len(pg.get_text()) > 180 for pg in doc)
w=openpyxl.load_workbook(O/'release/Source_Data_A_v81.xlsx',read_only=True)
c['source_workbook_complete'] = w['Observations_3299'].max_row == 3300 and w['Fig4_individual_periods'].max_row == 9 and w['EDT5_full_sensitivity'].max_row == 4 and w['EDT5_day_JK'].max_row == 130
out=dict(status='PASS' if all(c.values()) else 'FAIL',checks=c,pages=len(doc),PDF_SHA256=h(p),counts=counts,
    scope='Editorial integration and frozen-derived-data full-template sensitivity replay; no new raw-counter reduction or empirical noise calibration.',
    scientific_acceptance_or_author_approval=False,external_submission=False)
(O/'verification/FINAL_CHECK.json').write_text(json.dumps(out,indent=2))
print(json.dumps(out,indent=2))
assert all(c.values()), [k for k,v in c.items() if not v]
