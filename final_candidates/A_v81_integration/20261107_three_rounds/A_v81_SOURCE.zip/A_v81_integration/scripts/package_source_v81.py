from pathlib import Path
import shutil, json, hashlib, zipfile
O=Path(__file__).resolve().parents[1];R=O/'release';E=O/'verification/export_v81/A_v81_integration';E.mkdir(parents=True)
for n in ['scripts','vendor','assets','data','segment_reduction','review_diagnostics','period_estimates','full_sensitivity','noise_weights','sources','editorial','integration_source','baseline_v80','rounds','figures']:
 shutil.copytree(O/n,E/n,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
for n in ['NATURE_ARTICLE_A_v81.md','manuscript_template.md','render_candidate.py','layout_working.lua','requirements_analysis.txt','README.md','REPRODUCE_V81.md','REVISION_V81_ZH.md','DATA_DICTIONARY.md','COVER_LETTER_DRAFT.md','AUTHOR_SUBMISSION_CHECKLIST.md','THREE_ROUND_REVIEWS.md','PLAN_V81.md']:
 shutil.copy2(O/n,E/n)
for ext in ['pdf','tex']:shutil.copy2(O/'render_final'/f'NATURE_ARTICLE_A_v81.{ext}',E/f'NATURE_ARTICLE_A_v81.{ext}')
V=E/'verification';V.mkdir()
for p in (O/'verification').iterdir():
 if p.is_file() and p.suffix in ['.json','.md']:shutil.copy2(p,V/p.name)
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={str(p.relative_to(E)):h(p) for p in sorted(E.rglob('*')) if p.is_file()}
(V/'SOURCE_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
archive=R/'A_v81_SOURCE.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(E.rglob('*')):
  if p.is_file():z.write(p,str(Path('A_v81_integration')/p.relative_to(E)))
print('Archive bytes',archive.stat().st_size,'files',len(manifest))
