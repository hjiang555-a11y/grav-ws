"""Freeze a manuscript for three isolated mock reviews; supplies no concern ledger."""
from pathlib import Path
import argparse, shutil, json, hashlib
O=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('round',type=int);a=p.parse_args();R=O/f'rounds/round{a.round}';R.mkdir(exist_ok=True);P=R/'packet';P.mkdir()
shutil.copy2(O/'NATURE_ARTICLE_A_v81.md',P/'manuscript.md')
shutil.copy2(O/f'render_round{a.round}/NATURE_ARTICLE_A_v81.pdf',P/'manuscript.pdf')
E=P/'evidence';E.mkdir()
for src,out in [('data/RESULTS.json','primary.json'),('segment_reduction/FULL_TIDE.json','full_response.json'),('full_sensitivity/RESULTS.json','full_sensitivity.json'),('review_diagnostics/REVIEW_RESULTS.json','weak_group.json'),('period_estimates/RESULTS.json','individual_periods.json'),('data/design.npz','design.npz'),('data/primary_rows.csv','primary_rows.csv')]:shutil.copy2(O/src,E/out)
for src in ['DATA_DICTIONARY.md','noise_weights/period_coefficients.csv','noise_weights/VERIFICATION.json','sources/noise_definition.py']:
    if (O/src).exists():shutil.copy2(O/src,E/Path(src).name)
F=P/'figures';F.mkdir()
for f in (O/'figures').glob('*.pdf'):shutil.copy2(f,F/f.name)
shutil.copy2(O/'rounds/round1/packet/CRITERIA.md',P/'CRITERIA.md')
shutil.copy2(O/'rounds/round1/REVIEW_SETUP.json',R/'REVIEW_SETUP.json')
for n in range(1,4):(R/f'r{n}').mkdir()
(R/'PACKET_SHA256.json').write_text(json.dumps({str(f.relative_to(P)):hashlib.sha256(f.read_bytes()).hexdigest() for f in P.rglob('*') if f.is_file()},indent=2))
print(P)
