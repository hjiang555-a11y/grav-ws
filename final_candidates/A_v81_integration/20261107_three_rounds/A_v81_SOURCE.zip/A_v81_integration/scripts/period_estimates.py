"""Eight disjoint observing-period estimates from the frozen segment design."""
from pathlib import Path
import hashlib
import json
import platform
import numpy as np
import pandas as pd
from segment_reduce import fit

O = Path(__file__).resolve().parents[1]
D = O / 'period_estimates'
D.mkdir(exist_ok=True)
d = np.load(O / 'data/design.npz')
rows = pd.read_csv(O / 'data/primary_rows.csv')
ledger = pd.read_csv(O / 'data/period_ledger.csv').set_index('period')

def direct(S, y, sigma, seg):
    X = np.column_stack([S, seg[:, None] == np.unique(seg)[None, :]])
    A = X / sigma[:, None]
    assert np.linalg.matrix_rank(A) == X.shape[1]
    Q, R = np.linalg.qr(A, mode='reduced')
    beta = np.linalg.solve(R, Q.T @ (y/sigma))
    scale = np.sum(((y-X@beta)/sigma)**2)/(len(y)-X.shape[1])
    inv = np.linalg.solve(R, np.eye(len(R)))
    return beta[:3], np.sqrt(np.diag(scale*(inv@inv.T)))[:3]

records, replicas, membership = [], [], []
max_difference = 0.0
for period in np.unique(d['period']):
    ix = np.flatnonzero(d['period'] == period)
    S,y,sigma,seg,days = [d[k][ix] for k in ['three','y','sigma','seg','days']]
    a = fit(S,y,sigma,seg)
    b, ls = direct(S,y,sigma,seg)
    max_difference = max(max_difference, float(np.max(abs(a['A']-b))))
    np.testing.assert_allclose(a['A'], b, rtol=0, atol=1e-10)
    np.testing.assert_allclose(a['SE_LS'], ls, rtol=0, atol=1e-10)
    reps, direct_reps = [], []
    for day in np.unique(days):
        keep = days != day
        r = fit(S[keep],y[keep],sigma[keep],seg[keep])
        br,_ = direct(S[keep],y[keep],sigma[keep],seg[keep])
        np.testing.assert_allclose(r['A'],br,rtol=0,atol=1e-10)
        max_difference = max(max_difference,float(np.max(abs(r['A']-br))))
        reps.append(r['A']);direct_reps.append(br)
        replicas.append(dict(period=period,omitted_UTC_day=day,**{n:float(v) for n,v in zip(['A_L','A_S','A_D'],r['A'])}))
    G=len(reps); assert G>=2
    z=np.array(reps)-np.mean(reps,axis=0)
    day_cov=(G-1)/G*z.T@z
    day_se=np.sqrt(np.diag(day_cov))
    zz=np.array(direct_reps)-np.mean(direct_reps,axis=0)
    np.testing.assert_allclose(day_cov,(G-1)/G*zz.T@zz,rtol=1e-10,atol=1e-10)
    u=np.maximum(a['SE_LS'],day_se)
    T=a['T']/sigma[:,None]
    condition=np.linalg.cond(T/np.linalg.norm(T,axis=0))
    corr=a['cov'][0,1]/np.sqrt(a['cov'][0,0]*a['cov'][1,1])
    record=dict(period=period,n_rows=len(ix),n_segments=len(np.unique(seg)),n_UTC_days=G,
                accepted_hours=float(ledger.loc[period,'accepted_hours']),
                start=ledger.loc[period,'start'],end=ledger.loc[period,'end'],
                condition_normalized=float(condition),corr_LS=float(corr),df=a['df'])
    for k,name in enumerate(['L','S','D']):
        record.update({f'A_{name}':float(a['A'][k]),f'u_{name}':float(u[k]),
                       f'LS_{name}':float(a['SE_LS'][k]),f'day_JK_{name}':float(day_se[k])})
    records.append(record)
    membership.extend(dict(period=period,source_row=int(i),segment=int(d['seg'][i]),t_utc=rows.iloc[i].t_utc) for i in ix)
table=pd.DataFrame(records)
assert len(table)==8 and table.n_rows.sum()==3299 and table.n_segments.sum()==54
assert sorted(x['source_row'] for x in membership)==list(range(3299))
table.to_csv(D/'period_estimates.csv',index=False)
pd.DataFrame(replicas).to_csv(D/'day_jackknife_replicates.csv',index=False)
pd.DataFrame(membership).to_csv(D/'row_membership.csv',index=False)
result=dict(status='PASS',input_sha256={n:hashlib.sha256((O/'data'/n).read_bytes()).hexdigest() for n in ['design.npz','primary_rows.csv','RESULTS.json']},
            method='Each period fitted separately; unchanged three groups, fixed remainder, weights and within-segment means.',
            error='One working statistical standard error: max(scaled LS, leave-one-UTC-day-out jackknife) within each period.',
            number_periods=8,rows=3299,segments=54,new_exclusions=0,
            QR_max_coefficient_difference=max_difference,
            period_estimates=records,python=platform.python_version(),numpy=np.__version__,pandas=pd.__version__)
(D/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(table[['period','n_rows','n_UTC_days','A_L','u_L','A_S','u_S','condition_normalized']].to_string(index=False))
print('Independent QR maximum difference',max_difference)
