from pathlib import Path
import json
O=Path(__file__).resolve().parents[1];R=O/'rounds/round3';R.mkdir();p=O/'manuscript_template.md';s=p.read_text();(R/'before_nature_polish.md').write_text(s)
# Targeted methods and consistency pass; no restructuring or new estimation.
nature={
'The eight coefficients and all reconstructed bin uncertainties are supplied in the machine-readable source data.':'The machine-readable source data provide all eight period coefficients, bin member counts and reconstructed uncertainties.',
'The scalar response multiplies the complete solid-Earth and ocean-loading waveform, including the minor remainder.':'The scalar response multiplies the complete solid-Earth and ocean-loading waveform, including the minor-constituent remainder.',
}
for a,b in nature.items():assert a in s;s=s.replace(a,b)
(R/'nature_polished_template.md').write_text(s)
human={
'The apparatus instability benchmark quoted with Fig. 1a comes from the previously reported spliced summer comparison.':'The instability benchmark quoted with Fig. 1a was reported for the spliced summer comparison.',
'The source-data workbook and reproducibility archive':'The source-data workbook and reproducibility archive',
}
for a,b in list(human.items()):
 if a==b:del human[a];continue
 assert a in s;s=s.replace(a,b)
p.write_text(s);(R/'humanized_template.md').write_text(s);(R/'POLISH_EDITS.json').write_text(json.dumps({'nature':nature,'humanizer':human},indent=2))
print('Round3 targeted whole-text consistency and humanizer pass recorded')
