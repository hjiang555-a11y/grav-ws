from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
O=Path(__file__).resolve().parents[1];R=O/'rounds/round1'
for name,sha in json.loads((R/'FROZEN_REVIEWS.json').read_text()).items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==sha
D=np.load(O/'data/design.npz');rows=pd.read_csv(O/'data/primary_rows.csv');j=json.loads((O/'data/RESULTS.json').read_text())
assert np.max(abs(D['y']+D['fixed']-rows.y.to_numpy()))<1e-12
checks=[dict(audit_id='AUD-01',status='passed',location='Whole record and Figure 4',check='Sum period row counts, member hours and 54 labels',result={'rows':len(rows),'periods':len(set(D['period'])),'segments':len(set(D['seg']))}),dict(audit_id='AUD-02',status='passed',location='ED Tables 4/5',check='Distinct scalar versus grouped fit and four-decimal values',result=json.loads((O/'full_sensitivity/RESULTS.json').read_text())['results']),dict(audit_id='AUD-03',status='aggregation_ambiguity',location='Derived-data y fields',check='NPZ y plus fixed versus CSV y',result='Equality verified within 1e-12; variable dictionary added below.'),dict(audit_id='AUD-04',status='unresolved_input_needed',location='Figure 1a',check='Amplitude/phase meaning of supplied raster map',result='Generation grid absent in source provenance. Caption identifies illustrative fields; author must confirm field convention. Quantitative panels and fits do not use image.'),dict(audit_id='AUD-05',status='unresolved_input_needed',location='Solid template',check='Potential-weighted reference on same rows',result='Not included in this frozen revision; 18% K1 discrepancy is not propagated to all bands or declared a model uncertainty bound.'),dict(audit_id='AUD-06',status='passed',location='Figure 3b',check='LS covariance versus reported marginal working errors',result={'quadrature_LS':j['iq']['scaled_ls'][1],'quadrature_reported':j['iq']['u'][1]})]
(R/'FORENSIC_AUDIT.json').write_text(json.dumps(checks,indent=2))
p=O/'manuscript_template.md';s=p.read_text()
changes={
'The response to the complete solid-Earth and ocean-loading prediction is $0.96\\pm0.11$ (one statistical standard error).':'The response to the complete solid-Earth and ocean-loading prediction is $0.96\\pm0.11$ (one statistical standard error), where unity denotes the predicted amplitude.',
'We first estimate one response to the complete prediction, then jointly estimate the responses of two semidiurnal groups.':'The extended record tests a common tidal response across interrupted operation and constrains neighbouring semidiurnal groups that a single waveform scale does not distinguish.',
'The apparatus and frequency-comparison chain are described by Hou and colleagues. Clock evaluations and field-fibre experiments provide the metrological basis.[@hou,jia,zhu,chenlink]':'The apparatus and frequency-comparison chain are described by Hou and colleagues.[@hou] Clock evaluations and field-fibre experiments provide the metrological basis.[@jia,zhu,chenlink]',
'The coefficient agrees with the predicted amplitude of the potential variation between the sites.':'The coefficient agrees with the amplitude of the specified prediction.',
'The error bars propagate uncertainty from that operation. The display exposes the lunar variation contained in the joint fit.':'The error bars propagate uncertainty from that projection.',
'The spectrum, phase fold and template fit describe the same observations and their probabilities are not combined. The spectrum displays frequency structure, while the physical coefficients come from the simultaneous group fit.':'Frequency structure and joint physical coefficients describe the same record; they are not independent detection tests.',
'The relative rates of the Shanghai and Wuhan clocks contain the predicted tidal variation of their gravitational potential difference. Agreement in the full waveform response, the lunar phase and the observed semidiurnal structure supports detection on this fixed coastal–inland baseline.':'The clock-rate record detects the tidal variation of the Shanghai–Wuhan potential difference. Its full waveform response, lunar phase and semidiurnal structure agree with the combined prediction.',
'The measurement therefore uses both the changes within runs and their known forcing phase across dates. This provides a practical way for intermittently operating clock comparisons to measure changing potential differences.':'This links variation within runs to the known forcing phase across dates, allowing interrupted clock comparisons to constrain time-dependent components of the potential.',
'Land shading and contours illustrate the model M₂ clock-rate response in $10^{-18}$; sea contours show M₂ ocean-tide height in centimetres.':'The supplied map illustrates an M₂ fractional clock-rate field over land in $10^{-18}$ and ocean-tide height contours at sea in centimetres.',
'Contours have covariance radii one and two under scaled LS, not independently calibrated joint confidence levels.':'Contours use scaled-LS covariance radii one and two. The marginal working errors reported in the text are 0.13 and 0.20; the scaled-LS quadrature error is 0.127. These are not independently calibrated joint confidence levels.',
'Uncertainty in the solid model remains separate from the quoted statistical errors.':'The quoted statistical errors are conditional on this solid template. A same-sampling potential-weighted comparison has not been completed for these estimates, so the K₁ discrepancy is not assigned as an error on the semidiurnal response.',
}
for a,b in changes.items():assert a in s,a;s=s.replace(a,b)
p.write_text(s);(R/'response_template.md').write_text(s);(R/'RESPONSE_EDITS.json').write_text(json.dumps(changes,indent=2))
(O/'DATA_DICTIONARY.md').write_text('''# Frozen derived-data dictionary

`data/primary_rows.csv`: `y` is the period-relative observed fractional clock rate in units of 1e-18, before subtracting the fixed theoretical remainder. It is a derived observation, not a raw counter reading.

`data/design.npz`: `y` is already CSV.y minus `fixed`, in the same units. `three` contains columns lunar M2+N2, neighbouring S2+K2, diurnal K1+O1+P1+Q1. `fixed` is the minor theoretical remainder. Thus full-response y = NPZ.y + fixed = CSV.y; full template = sum(three) + fixed. For grouped fitting use NPZ.y directly; do not subtract fixed again.

`sigma` supplies the frozen Allan-based weights 1/sigma², in the same fractional-rate units; `seg` has 54 labels, `period` eight labels, `days` UTC day labels, and `seconds` actual UTC mean times expressed on the archived epoch. No interpolation or missing-time compression is applied. CSV utc specifies readable UTC times. `quad` is the lunar quadrature column. Original row memberships are unchanged.

Reported standard errors take the larger of residual-scaled least squares and UTC-day jackknife. Period deletion is a separate diagnostic. Figures 1–4 and ED figures use saved source tables; Figure 3c alone uses the documented equal-weight spectral scan. All files retain v80 hashes. Original counter reconstruction is outside this revision.
''')
(R/'SYNTHESIS_AND_RESPONSE_ZH.md').write_text('''# 第一轮综合与回应

三份报告先分别冻结SHA256，再比较。本轮Nature全文润色、人类化和三份隔离评审已经完成。共同意见与编辑核查分开记录。

## 共识及处理

R1-M1、R2-M2、R3-M2均要求更清楚界定新增问题。引言末句改为：跨中断检验共同潮汐响应，并估计单一总模板不能区分的邻近组。Hou重叠16夏季段与0.87±0.15保留，欧洲仍仅讨论末句。不以预印本日期或“首次”建立贡献。扩大到Nature的突出重要性仍由作者及编辑判断，不能靠语言完全关闭。

R2-M1、R3-M1要求势加权固体模板对照。未把K1的18%差异泛化为半日误差；Methods明确尚未完成针对当前估计器的同采样比较。本轮按用户约束保留冻结v80计算和图，不能假称此科学补强已完成。作为作者待核验项保留，评审均标记非阻断。

## 逐项修改

R1-m1：摘要首次系数后解释1代表预测振幅。R1-m2：保留原图3b，图注明列正文边际误差0.13、0.20与LS正交误差0.127，避免把原椭圆读成正文区间；未擅自改变冻结图件。R2-m1：增加DATA_DICTIONARY.md并核对NPZ.y+fixed=CSV.y，防止重扣余项。R3-m1：图注明确作者提供的地图为分数钟速场与海面高度两种物理量；其振幅/瞬时相位定义缺少生成网格，列作者确认，未猜测。

关于新增日期的信息，冻结同估计器结果为夏季1648行A_L=0.7691±0.1816、早期1651行1.2147±0.2269，全记录1.0004±0.1320。此对照已在data/RESULTS.json中，不能借用Hou或其他归算数值。工作标准误减少约27.3%，不是普适信息增益或独立重复探测。本轮不增加新的摘要主结果。

编辑审计另见FORENSIC_AUDIT.json。新增表与原表定义区分正确；图3b误差口径差异不是数值错误。噪声律仍为条件压力测试，不宣称真实噪声已校准。作者及数据访问声明仍待确认。
''')
print('Round 1 responses applied; no changes to numerical inputs or figures.')
