from pathlib import Path
import json,hashlib
O=Path(__file__).resolve().parents[1];R=O/'rounds/round3'
for n,h in json.loads((R/'FROZEN_REVIEWS.json').read_text()).items():assert hashlib.sha256((R/n).read_bytes()).hexdigest()==h
p=O/'manuscript_template.md';s=p.read_text();(R/'before_response.md').write_text(s)
edits={
'Here we use the record spanning 353 days to estimate both the full-template and grouped responses.':'Here the 353-day record supports full-template and grouped estimates.',
'Both ratios describe model contributions. The clock comparison tests their sum.':'These model ratios describe the combined prediction tested by the observations.',
'The coefficient agrees with the amplitude of the specified prediction.':'Unity represents the adopted combined prediction; the uncertainty is statistical and conditional on that template.',
'The clock-rate record detects the tidal variation of the Shanghai–Wuhan potential difference. Its full waveform response, lunar phase and semidiurnal structure agree with the combined prediction. The lunar component provides the clearest constraint, while attribution within the neighbouring group is more sensitive to 12-h disturbances.':'The clock-rate record detects tidal variation of the Shanghai–Wuhan potential difference, with the lunar component providing the clearest constraint. Attribution within the neighbouring group remains more sensitive to 12-h disturbances.',
}
for a,b in edits.items():assert a in s;s=s.replace(a,b)
p.write_text(s);(R/'response_template.md').write_text(s);(R/'RESPONSE_EDITS.json').write_text(json.dumps(edits,indent=2))
audit=[dict(audit_id='AUD3-01',status='passed',location='Headline estimates',check='Independent reviewer fits plus fresh-sandbox scalar QR replay',result='0.9551/0.1082 full; 1.0004/0.1320 lunar; 0.9251/0.3649 neighbouring unchanged.'),dict(audit_id='AUD3-02',status='passed',location='Weights',check='Nominal-member support and period alpha',result='3299 weights reconstructed; source algorithm, alpha table and schema available.'),dict(audit_id='AUD3-03',status='unresolved_input_needed',location='Quantitative physical prediction and actual noise',check='Scope relative to reviewers R1-M2/R2-M1/M2/R3-M1',result='Statistical error conditional on adopted template stated beside primary full response; no new physical-template error bound or universal noise calibration claimed.'),dict(audit_id='AUD3-04',status='passed',location='Figures 1–4',check='Fresh-directory source plotting versus preserved v80 PNGs',result='All four main figures pixel-identical. No supplied figure changed.'),dict(audit_id='AUD3-05',status='unresolved_input_needed',location='Author approvals and controlled-access source',check='Actual submission readiness',result='Names, grants, conflicts, source-map field convention, editor access and related-manuscript status await authors; no external submission.'),dict(audit_id='AUD3-06',status='passed',location='ED figure references',check='Display number versus legacy filename',result='Displayed ED1 points to ed_figure2, displayed ED2 to ed_figure1. Recovered plotting entry point follows original filenames; no manuscript cross-reference error.' )]
(R/'FORENSIC_AUDIT.json').write_text(json.dumps(audit,indent=2))
(R/'SYNTHESIS_AND_RESPONSE_ZH.md').write_text('''# 第三轮综合与最终回应

九份报告均在独立上下文完成；本轮三份先冻结再综合。它们是AI模拟预审，不是人类期刊外审。没有评审认定已证实的Blocking Yes核心缺陷，不等于全部Major已关闭或已获Nature送审承诺。

## 共识及实际处理

R1-M2、R2-M2、R3-M1要求界定固体模板近似的传播。按R3给出的文字关闭选项，主结果旁明确统计误差条件于采用的模板。Methods保留具体近似及尚无同采样势加权比较的事实。进一步物理量化仍待作者，不捏造上限，不把K1的18%直接套到半日潮。

R1-M1、R2-M3要求更强增量论证。按用户最新决策，不继续重写结构，维持检测位差潮汐为首层、相邻组约束为次层，披露Hou重叠、Stahl末句。本文没有首次或独立太阳检出的主张。该贡献能否达到Nature广泛重要性，由实际编辑判断。

R2-M1对真实相关噪声仍有补强建议。保留条件模拟不匹配实测短滞后结构、日/期诊断及统计误差定义，不把有限P值换算成σ，不以太阳组确认作为投稿门槛。本轮没有新增噪声拟合。

三位Minor均建议图3b面内重标LS椭圆。依用户保留v80图件要求，图件不改；图注明确0.127与0.20的区别和轮廓半径。该图内标注建议作为可选最终制作事项保留，不宣称已完全满足。

## 完成的技术闭环

全部主图在独立目录由源代码重新生成，与冻结PNG逐像素相同。新全模板表与43次删日结果在新目录再次复算。权重3299行均由alpha和n恢复；机器表和字段字典随包提供。正文补入5.4e-16/sqrt(tau/s)装置性能，准确归属于历史两钟比对，未用于当前权重或长期稳定度宣称。

最终仅压缩重复句及修正排版，不改变论证架构、数据或结果。标题、4主图/4扩展图/5扩展表、图2真实UTC展示、八期图4、原EDT4均保留。编辑审计与评审共识分列，未将尚待作者确认的事实补造成已完成事项。
''')
print('Round3 response complete; final manuscript ready for production checks')
