"""Separate experimental data from noise stress tests; assess residual structure."""
from pathlib import Path
import itertools
import json

import numpy as np
import pandas as pd
from review_statistics import design, solve, serial, SCENARIOS

O=Path(__file__).resolve().parents[1]
a=np.load(O/'data/design.npz')
S,y,sigma,t,seg,period=[a[n] for n in ['three','y','sigma','seconds','seg','period']]
X=design(S,seg);A=X/sigma[:,None]
Q=np.linalg.qr(A,mode='reduced')[0]
fit=solve(X,y,sigma)
residual=fit['residual']/sigma
index={}
for lag in [1,2,3]:
    take=(seg[lag:]==seg[:-lag])&(t[lag:]-t[:-lag]<=lag*900)
    index[lag]=(np.arange(len(y)-lag)[take],np.arange(lag,len(y))[take])

def correlation(x,left,right):
    if x.ndim==1:x=x[:,None]
    u=x[left]-x[left].mean(axis=0);v=x[right]-x[right].mean(axis=0)
    return np.sum(u*v,axis=0)/np.sqrt(np.sum(u*u,axis=0)*np.sum(v*v,axis=0))

def statistics(x):
    if x.ndim==1:x=x[:,None]
    values=[correlation(x,*index[lag]) for lag in [1,2,3]]
    standardized=(x-x.mean(axis=0))/x.std(axis=0,ddof=1)
    values.append(np.mean(abs(standardized)>4,axis=0))
    return np.column_stack(values)

observed=statistics(residual)[0]
results=[];draws=[]
for scenario,seed in zip(SCENARIOS,np.random.SeedSequence(2026110710).spawn(4)):
    rng=np.random.default_rng(seed);values=[]
    for batch in range(4):
        count=500
        if scenario=='white':z=rng.standard_normal((len(y),count))
        elif scenario=='student_t5':z=rng.standard_t(5,(len(y),count))/np.sqrt(5/3)
        else:
            labs,tau=(seg,6*3600) if '6h' in scenario else (period,24*3600)
            u=np.empty((len(y),count))
            for i in range(len(y)):
                if i==0 or labs[i]!=labs[i-1]:u[i]=rng.standard_normal(count)
                else:
                    rho=np.exp(-max(0,t[i]-t[i-1])/tau)
                    u[i]=rho*u[i-1]+np.sqrt(1-rho*rho)*rng.standard_normal(count)
            z=(rng.standard_normal((len(y),count))+u)/np.sqrt(2)
        projected=z-Q@(Q.T@z)
        values.append(statistics(projected))
    values=np.concatenate(values)
    for k,label in enumerate(['lag1','lag2','lag3','fraction_above_4_SD']):
        # Distribution position, not a prespecified discovery significance test.
        tail=2*min((1+np.sum(values[:,k]<=observed[k]))/2001,(1+np.sum(values[:,k]>=observed[k]))/2001)
        results.append(dict(scenario=scenario,metric=label,observed=observed[k],
                            simulated_median=np.median(values[:,k]),simulated_2_5=np.quantile(values[:,k],.025),
                            simulated_97_5=np.quantile(values[:,k],.975),two_tail_simulation_position=min(1,tail),n=2000))
    draws.append(pd.DataFrame(values,columns=['lag1','lag2','lag3','fraction_above_4_SD']).assign(scenario=scenario))

X0=np.delete(X,1,axis=1);restricted=solve(X0,y,sigma)
Q0=np.linalg.qr(X0/sigma[:,None],mode='reduced')[0]
g=S[:,1]/sigma-Q0@(Q0.T@(S[:,1]/sigma));g/=np.linalg.norm(g)
e0=restricted['residual']/sigma;h=np.sum(Q0*Q0,axis=1)
patterns=np.array(list(itertools.product([-1,1],repeat=8)))
observed_delta=(g@(y/sigma))**2
wild=[]
for correction,e in [('unadjusted',e0),('diagonal_HC2',e0/np.sqrt(1-h))]:
    contributions=np.array([g[period==p]@e[period==p] for p in np.unique(period)])
    statistics_wild=(patterns@contributions)**2
    wild.append(dict(method=correction,patterns=256,exceedances=int(np.sum(statistics_wild>=observed_delta-1e-10)),
                     approximate_wild_P=float(np.mean(statistics_wild>=observed_delta-1e-10)),
                     observed_delta=observed_delta,minimum_two_sided=2/256,
                     scope='Restricted period wild sign flips; assumes period independence/symmetry; not an exact experimental randomization test.'))

pd.DataFrame(results).to_csv(O/'review_diagnostics/noise_adequacy.csv',index=False)
pd.concat(draws,ignore_index=True).to_csv(O/'review_diagnostics/noise_adequacy_draws.csv',index=False)
(O/'review_diagnostics/NOISE_ADEQUACY.json').write_text(json.dumps(dict(
    status='COMPLETED_DIAGNOSTIC',observed_metrics=dict(zip(['lag1','lag2','lag3','fraction_above_4_SD'],observed)),
    comparisons=results,restricted_period_wild=wild,
    interpretation='The four declared simulation laws are stress cases, not established measurements of the actual noise. Do not select a law using its tidal P value.',
    experimental_rows_added=0,original_sample_rows=len(y),seed=2026110710),indent=2,default=serial)+'\n')
print(pd.DataFrame(results).to_string(index=False));print(json.dumps(wild,indent=2))
