# v81整合与三轮增强
v80唯一主底稿，全部图件保持；题目严格采用 Tidal potential measured on a coastal–inland optical-clock baseline。核对整合版固定提交df4211fe619f8d611dc8b9c8a5fc86aa50f9e15e的PDF、结果表和代码，新增全模板敏感性表作为EDT5，原EDT4保留。所有校验使用冻结3299行、54段、Allan权重，逐日jackknife和缩放LS取大；不修改原数据、掩膜和主结果。Hou按新指示说明16夏季段重叠及0.87±0.15，欧洲末句。先完成英文实质修订，再三轮Nature润色、人类化、隔离评审、据证据修改；每轮保存快照和评审，不宣称通过评审等于获期刊认可。新图不生成。作者占位保留，提供源稿PDF中文一页说明，按既有授权私有grav-ws交付，不投稿。
