# Nature初投格式核对，2026-11-07

本轮核对Nature官方页面的搜索索引摘录，部分正文页面受访问跳转限制。采用初投要求，不把接受后的制作规范当作初投硬门槛。

- [Initial submission](https://www.nature.com/nature/for-authors/initial-submission)：约200词的带引文summary；典型6页Article约2500词、4个展示项。本文使用用户要求的140–180词摘要，正文不为凑足指南字数扩写。
- [Formatting guide](https://www.nature.com/nature/for-authors/formatting-guide)：初投鼓励文本与图同一PDF或Word，文件不超过30MB。采用连续行号、双倍正文行距；图与图注相邻。主图4幅，扩展图4幅、扩展表5张；数字表保留可编辑。
- [Preprints & Conference Proceedings](https://www.nature.com/nature/editorial-policies/preprints-conference-proceedings)：预印本不按既往正式发表处理，评估在审稿件进展时不计入预印本服务器稿件。正文按研究内容引用，投稿信披露重叠及独立同期研究，不按日期宣称优先权。

稿件已整理为供作者终审的初投结构。作者、通讯、基金、贡献、利益声明及实际审稿访问权限仍需作者确认；这不是已经提交或已达到期刊接受标准的声明。

2026-11-07补核：[AI政策](https://www.nature.com/nature/editorial-policies/ai)要求研究与写作中的AI使用可核验、责任由人承担；本稿按实际英文起草、脚本复核/数值重放和基于实验表格制图披露，不把AI列为作者。[初投规则](https://www.nature.com/nature/for-authors/initial-submission)要求披露作者重叠、在审（含申诉）或待刊的相关稿件并提供材料；实际稿件状态须由通讯作者填写。
