# 两钟比对稳定度标度来源

已核对 Hou 等 arXiv:2610.34250v1 第98–99行（HTML），以及本地 paper/prl/main.tex 第359–373行。原文报告两钟比较的白频率噪声标度为5.4×10⁻¹⁶/√(τ/s)，来源为16段夏季拼接比值记录的稳定度展示，非两台钟各自独立评定值。

原文链接：https://arxiv.org/html/2610.34250v1
本地源稿：/home/room115/gravitation-whsh/paper/prl/main.tex

v81正文图1a对应装置段将明确归属于reported clock-comparison instability scale。Methods说明其来源及与当前分期段内权重的区别。正文不宣称当前数据已独立验证延续至4.6天，也不使用拟合调整零点后的长稳度生成当前权重。
