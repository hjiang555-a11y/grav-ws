# v81 author-review revision

Main manuscript: NATURE_ARTICLE_A_v81.md. Final PDF and editable Word are in render_final/ and release/. v80 is the sole scientific baseline. All four main figures and four Extended Data figures are preserved.

See REVISION_V81_ZH.md for the one-page Chinese handover, REPRODUCE_V81.md for replay, DATA_DICTIONARY.md for data meanings, verification/CLAIM_SOURCES_V81.md for numerical provenance and rounds/ for three independent mock-review cycles. The new full-template sensitivity is Extended Data Table 5; the original grouped-model Table 4 remains.

The current findings are conditional on the stated physical template and working statistical-error rule. Nine isolated AI mock reviews are preparation aids, not human external peer review. Author identities, approvals and actual data-access arrangements remain author decisions. No submission has been made.

Current figure hashes and plotting sources are in verification/CURRENT_FIGURE_PROVENANCE.json. The inherited figures/PROVENANCE.json is a historical record from earlier drafts; use the current manifest for this delivery.
