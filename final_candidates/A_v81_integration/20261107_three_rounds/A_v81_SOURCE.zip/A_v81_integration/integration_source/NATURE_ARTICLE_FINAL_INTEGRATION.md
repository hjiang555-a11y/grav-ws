# Tidal potential measured on a coastal–inland optical-clock baseline

*Scientific text for author review. Authorship and submission declarations await confirmation.*

## Abstract

Optical clocks measure changes in the gravitational potential difference between distant sites through their relative frequencies.^1,2^ Resolving neighbouring tidal responses becomes difficult when observations are interrupted and their frequency reference levels are unknown. Here we use the evolving astronomical phase between lunar and solar tides to distinguish two semidiurnal responses in a Shanghai–Wuhan clock comparison. The 692-km coastal–inland baseline provides 545.9 hours of observations in 54 segments over 353 days. We retain the actual observation times and jointly fit physical tidal templates with an independent constant for each segment. The lunar–solar phase is defined at every measurement time, without requiring a common frequency zero across interruptions. Relative to the combined solid-Earth and ocean-loading prediction, the responses are $1.00\pm0.13$ for the lunar M₂+N₂ group and $0.93\pm0.36$ for the neighbouring S₂+K₂ group, with statistical standard errors. The measured spectrum and conditional scans support features near both principal frequencies. Combining within-segment variations with astronomical phase information across dates resolves these two model-defined semidiurnal responses of the gravitational potential.

## Main text

Earth's gravitational potential changes as the Moon and Sun move, the solid Earth deforms and ocean water is redistributed. Optical clocks sense these changes through gravitational shifts of their relative frequencies, providing a direct observable of the evolving potential difference between distant sites.^1,2,3^ Laboratory and remote-clock experiments have measured static potential differences.^4,5,6,7^ Stable frequency transfer now connects laboratories over continental distances.^8,9^ These capabilities make it possible to ask how distinct components of the changing potential can be measured in practical, interrupted clock comparisons.

The principal lunar semidiurnal tide M₂ repeats every 12.42 h, whereas the principal solar tide S₂ repeats every 12 h. Their frequencies differ by only about 0.78 µHz, so their variations can be difficult to distinguish within a short observation. Extending the calendar span does not by itself create a continuous measurement: operating interruptions can leave different segments with unknown frequency reference levels. Joining them under one assumed zero can then confuse changes in the reference level with the slowly evolving difference between the two tidal waveforms.

Their relative phase nevertheless remains predictable. A corresponding M₂ maximum occurs about 50 minutes later on successive solar days. Their relative phase therefore drifts with date, bringing the lunar pattern through different parts of the solar day. Each observation has a calculable astronomical phase determined by its actual time, even when the frequency zero has not been transferred from the preceding segment. Observations on different dates consequently sample different combinations of the lunar and solar semidiurnal patterns. The time dependence within each segment and the changing relative phase across dates can be used together.

Here we apply this physical reference to a strontium clock in coastal Shanghai and a ytterbium clock in inland Wuhan. We preserve the actual UTC sampling and assign an independent constant to each of 54 observing segments. Complete physical templates for M₂+N₂ and S₂+K₂ are estimated jointly, with their constituent amplitude ratios and phase relationships fixed by the solid-Earth and ocean-loading prediction; a diurnal template is retained as an auxiliary component. K₂ contains lunar and solar forcing. The two semidiurnal coefficients and their frequency-domain signatures allow us to test neighbouring tidal responses on a baseline where the ocean load contributes appreciably to the predicted potential.

### A coastal–inland prediction

The Shanghai Sr and Wuhan Yb clocks are 692 km apart, connected through Hefei by a 1,350-km phase-stabilized fibre link (Fig. 1a).^10^ Published clock evaluations and field-fibre dissemination experiments establish the metrological basis for these remote comparisons.^11,12,13^ The summer observations overlap the absolute frequency-ratio measurement reported by Hou and colleagues; here we study the time-dependent tidal response. A positive frequency-ratio variation denotes Wuhan Yb running faster relative to Shanghai Sr. With the geodetic potential convention used here, $y=-[\delta W_{\mathrm{Wuhan}}-\delta W_{\mathrm{Shanghai}}]/c^2$.

The prediction combines the changing astronomical potential with the potential induced by Earth's deformation and the displacement of each clock. Ocean tides add the attraction of redistributed seawater and the Earth's response to that load. We combine an IERS-based solid-tide prediction with FES2022 ocean elevations and an effective-potential loading kernel containing all three loading contributions (Methods).^14,15,16,17^ Shanghai's proximity to the East China Sea and Wuhan's inland location give the sites different loading responses. Their comparison tests the resulting combined solid-Earth and ocean-loading potential difference.

The predicted differential M₂ amplitudes are $3.43\times10^{-18}$ for the solid tide and $1.42\times10^{-18}$ for loading, in fractional clock-rate units. Their 19.8° phase difference gives a vector sum of $4.78\times10^{-18}$ (Fig. 1b). Loading therefore changes both the size and phase of the waveform being tested. The complete sampled prediction has the loading-to-total RMS ratio defined in the figure legend; these quantities characterize the physical model.

The record spans September 2025 to August 2026. Its 54 valid segments are organized into eight observing periods and contain 3,299 ten-minute means, representing 545.9 h of accepted nominal one-second measurements (Fig. 1c). Observations occur in eight calendar months within the 353-day span. The June–August periods supply 273.9 h at a broad range of relative lunar–solar phases; earlier periods add other phases and operating conditions (Fig. 1d). All actual observation times and gaps are retained.

### Two nearby semidiurnal responses

We estimate common tidal responses from the time-dependent variations within the segments, while allowing each segment its own constant level. These constants accommodate unknown frequency references; they do not assert a physical frequency jump at every boundary. At the sampled times, the tidal templates overlap, so fitting them separately could attribute part of one response to another. We therefore fit the two complete semidiurnal groups simultaneously, together with the auxiliary diurnal waveform and the segment constants, using the recorded Allan-based weights. Fixed constituent relationships keep each group tied to its predicted physical waveform. Astronomical phase relates those waveforms across dates without imposing a shared frequency zero.

The joint estimate gives $A_L=1.00\pm0.13$ for M₂+N₂ and $A_S=0.93\pm0.36$ for S₂+K₂ (Fig. 3a). Both are consistent with unit response to the combined solid-Earth and ocean-loading prediction. The lunar amplitude is determined more precisely; the wider uncertainty of the neighbouring response is retained in the joint assessment. For each coefficient, the statistical standard error is the larger of residual-scaled least squares and UTC-day-deletion jackknife. The former sets the lunar error and the latter sets the neighbouring-group error (Extended Data Table 1).

Figure 2 places the complete measured record on a common M₂ phase coordinate. After subtracting the fixed minor tidal remainder, we apply the same weighted projection to the observations and the unit lunar prediction, removing segment constants and the other two fitted groups. Twelve phase intervals reveal the recurring modulation, with every projected observation and the number in each interval also shown. The propagated covariance accounts for nuisance estimation and correlations between phase means. The response coefficient is estimated from the original ten-minute means.

Allowing a lunar component one quarter-cycle from the predicted phase gives in-phase and quadrature responses of $1.00\pm0.13$ and $-0.10\pm0.20$ (Fig. 3b), compatible with the prescribed waveform. The auxiliary diurnal coefficient and all covariance contributions remain in the joint analysis. Conditional simulations assess the reported error rule under the specified noise models (Methods and Extended Data Table 2).

### The measured semidiurnal spectrum

The measured spectrum retains the real UTC times, so observations on separate dates contribute with their actual frequency-dependent phases (Fig. 3c). An equal-weight sinusoidal scan with 54 segment constants has local maxima at 22.361 and 23.147 µHz, near M₂ at 22.364 µHz and S₂ at 23.148 µHz. The principal frequencies are about 0.78 µHz apart; the inverse calendar span is 0.0328 µHz. The left and right axes express the same nominal spectral density in potential and fractional-frequency units. A fractional variation of $10^{-18}$ corresponds to about $0.09\,\mathrm{m^2/s^2}$ of potential difference.

The observation window spreads power from a narrow tidal line into sidelobes. Single-constituent injections through the actual sampling and spectral operator give 8.03% M₂-to-S₂ cross-power and 8.15% in the reverse direction. Conditional scans retain a local feature near each principal frequency after projecting out the sine and cosine at the other (Extended Data Fig. 2). These checks connect the two spectral features to the sampling response of the interrupted record.

The primary quantitative results remain the simultaneously estimated M₂+N₂ and S₂+K₂ response coefficients. Their physical templates include the fixed constituent relationships and use the original noise weights, whereas the spectral scan uses equal weights. The spectrum and conditional scans supply frequency-domain evidence from the same observations; they neither separately determine N₂ and K₂ nor constitute additional independent experiments. The residual curve shows the spectrum after subtraction of the fixed unit physical prediction.

### Consistency across observing periods

The lunar response is supported by observations on both sides of summer. With the segment design, the coefficient is $1.21\pm0.23$ before summer and $0.77\pm0.18$ in summer. Deleting each observing period in turn gives lunar point estimates from 0.885 to 1.093. Figure 4 reports both semidiurnal groups for these subsets and deletions, showing how different dates contribute to their joint constraints. The full-record estimate remains primary.

An alternative model assigns one constant to each of the eight observing periods, rather than to every segment. On the same observations, templates and weights, it gives $0.987\pm0.123$ for the lunar group and $1.129\pm0.288$ for the neighbouring group. The 54-segment design accommodates the unknown segment references without requiring calibrated transfers between them. Residual and deletion comparisons are retained in Extended Data Fig. 1 and Table 1; proximity of a fitted coefficient to one is not a model-selection criterion.

Adding one shared 24-h sine–cosine pair gives a lunar response of $1.04\pm0.13$. The more permissive sensitivity model with period-specific 12-h terms examines overlap with variations at the signal's own timescale (Methods). These designs assess sensitivity to additional temporal structure without assigning it a measured laboratory origin. A matched round-trip monitoring control changes the two semidiurnal coefficients by $0.0061\pm0.0063$ and $0.0059\pm0.0145$, respectively; its sampling, paired errors and full results are given in Extended Data Fig. 3.

### Discussion

The Shanghai–Wuhan comparison resolves neighbouring semidiurnal responses despite interruptions and unknown frequency reference levels between observing segments. The lunar M₂+N₂ and neighbouring S₂+K₂ coefficients provide separate constraints on the combined solid-Earth and ocean-loading potential. Their amplitudes, the lunar phase response and the measured and conditional spectra jointly support this interpretation. The coastal–inland geometry makes ocean loading relevant to the tested waveform, although the present coefficients describe the combined potential.

Celestial motion supplies a common forcing-phase reference across observing segments. A segment constant changes its mean level but leaves its time-dependent tidal shape available to the fit; observations on later dates then constrain a different combination of lunar and solar phases. The information comes from those within-segment variations, their relative phase coverage and the measurement precision. A longer calendar span is useful when its observations add distinguishable physical patterns. This is how the astronomical reference supports a common measurement across gaps without replacing missing observations or calibrating their frequency zeroes.

For optical-clock networks that operate intermittently, retaining accurate times and sampling different relative phases can therefore extend what is learned from separate observing runs. The present result concerns the separation of nearby periodic responses over the accumulated record. Tracking an unpredicted transient would instead require sufficient precision during the event itself. Phase-referenced comparisons offer a practical route to repeated measurements of the changing potential and to its treatment in precision frequency metrology.^1,2^

\clearpage

## Figure legends

![Figure 1](figures/figure1.png)

**Fig. 1 | Geometry and changing lunar–solar phase.** **a,** Shanghai Sr and Wuhan Yb, 692 km apart, with the 1,350-km fibre connection through Hefei drawn schematically. **b,** Predicted differential M₂ solid and ocean-loading phasors, with the solid component defining phase zero; amplitudes are fractional clock rates in units of $10^{-18}$. For the complete predicted waveforms at the observed times, removing each segment's weighted mean gives loading and combined RMS values of $1.328\times10^{-18}$ and $4.011\times10^{-18}$: a ratio of 33.1%. This whole-waveform norm ratio is distinct from the M₂ phasor amplitudes, is not an additive power fraction and is not an independently measured loading fraction. **c,** Actual UTC sampling in eight observing periods, with accepted nominal member-hours. **d,** The S₂−M₂ astronomical phase at those same samples, including nodal corrections. Summer periods P6–P8 are orange. Geography and phasors describe the prediction; the lower panels describe the observation window.

\clearpage

![Figure 2](figures/figure2.png)

**Fig. 2 | The full record ordered by lunar phase.** **a,** Twelve 30° M₂ phase means of all 3,299 observations, after subtracting the fixed minor remainder and projecting against 54 segment constants and the neighbouring semidiurnal and daily groups. Identical weighted projection and averaging are applied to the unit lunar prediction; the fitted curve uses the unbinned primary coefficient. Error bars are one working standard error with the nuisance projection propagated; phase means are correlated. **b,** Every projected observation, with the full observed vertical range. **c,** Number of rows in each bin. Data, weights and templates are the primary segment design throughout. This is a display of the main observations, not an independent experiment.

\clearpage

![Figure 3](figures/figure3.png)

**Fig. 3 | Semidiurnal responses, phase and measured spectral structure.** **a,** The two semidiurnal responses and the auxiliary diurnal coefficient (grey), with one standard error, defined as the larger of scaled least-squares and UTC-day jackknife errors. **b,** Lunar in-phase and quadrature coefficients; the cross marks the unit prediction. Contours have covariance radii one and two from scaled least squares, not separately calibrated joint confidence levels. **c,** Equal-weight spectral calculation: 3,299 real UTC means, 54 segment constants and equal weights. Blue shows the observed scan; orange follows subtraction of the fixed unit total prediction. No gap is filled or compressed. Both axes show the same nominal one-sided projection density per µHz, related by $S_W=c^4S_y$. Sampling sidelobes contribute about 8% bidirectional M₂/S₂ cross-power. Peak locations support the principal-frequency attribution; group coefficients in **a** use the physical templates and Allan-based weights. All panels use the same observation rows.

\clearpage

![Figure 4](figures/figure4.png)

**Fig. 4 | Semidiurnal responses across observing periods.** **a,** Lunar M₂+N₂ and **b,** neighbouring S₂+K₂ coefficients from the full record, the pre-summer and summer subsets, and deletion of each observing period. All values and uncertainties are taken from the saved S54 results, with the original physical templates and Allan-based weights. Error bars are one statistical standard error, using the larger of scaled least squares and UTC-day jackknife for each retained subset. Shading marks the corresponding full-record one-standard-error interval; dashed lines denote unit response. The fits share observations. Both panels display every stored estimate and its full error bar on a common horizontal scale.

\clearpage

## Methods

### Observations, frequency sign and averaging

The Shanghai and Wuhan coordinates used by the frozen prediction are 31.130° N, 121.570° E and 30.529° N, 114.357° E. The measured ratio is Wuhan Yb/Shanghai Sr. With positive geodetic potential $W$, its tidal fractional variation is $-[\delta W_{\mathrm{Wuhan}}-\delta W_{\mathrm{Shanghai}}]/c^2$. The period-relative beat conversion is $-d_p(f_{\mathrm{beat}}-f_{{\mathrm{ref}},p})/F_{1550}$, where $F_{1550}=1.933992\times10^{14}$ Hz and $d_p=2$ in 2025 and 1 in 2026. Thus a 2026 beat deviation of 1 Hz has fractional magnitude $5.17\times10^{-15}$. The 2025 division factor is applied before forming the small clock-rate variation.

The supplied valid-interval table defines 54 segments in 29 operating groups and eight periods. Counter members are read across midnight before binning. Beijing-time labels are converted to UTC. Summer group corrections follow the decimal-arithmetic frequency-chain calculation; early absolute correction entries remain incomplete. Their constant part is represented by segment intercepts, while any time variation within a segment remains a possible systematic contribution. Fitted intercepts are never applied to join the runs for long-term stability estimation.

The membership audit contains 1,966,908 nominal one-second rows before the minimum-bin-support cut. Three boundary rows reconcile its difference from the printed interval total. Means are formed in nominal 600-s bins separately within each segment and require at least 180 retained members. The 3,299 accepted means contain 1,965,327 members, or 545.924 h. There are 3,291 unique bin centres: eight centres contain separate partial means from different segments, with disjoint members. The 353.39-day span contains observations on 43 UTC dates. The inherited valid mask is retained; this work neither applies an additional triangular filter nor selects points using tidal residuals. Exact raw-file memberships and hashes are retained in the controlled archive.

### What the constituent names mean

Semidiurnal tides produce approximately two cycles per day. M₂ is the principal lunar constituent; N₂ describes an additional lunar variation associated with orbital ellipticity. S₂ is the principal solar semidiurnal constituent, whereas K₂ contains lunar and solar forcing. The names identify astronomical frequencies. The diurnal group contains K₁ (lunisolar), O₁ (principal lunar), P₁ (principal solar) and Q₁ (lunar elliptic). Their periods are listed in Extended Data Table 3.^18^ Internal relative amplitudes, phases and nodal modulation are fixed within each physical group. A group response therefore tests that complete specified pattern. The diurnal coefficient is an auxiliary parameter, estimated as $A_D=0.58\pm0.54$; its covariance with the semidiurnal coefficients is retained.

### Combined solid and loading potential

The physical target includes the direct astronomical potential, the Earth's induced potential and the effect of clock displacement. The selected frozen solid sequence implements these through the IERS radial displacement $u$ and a fixed effective-potential conversion,

$$y_{\mathrm{solid}}=-\frac{1+k_2-h_2}{h_2}\frac{g(u_{\mathrm{Wuhan}}-u_{\mathrm{Shanghai}})}{c^2},$$

with $h_2=0.6078$, $k_2=0.3010$ and $g=9.794\,\mathrm{m/s^2}$. This is a displacement-based approximation to the combined solid potential, not the alternative frequency-resolved direct-potential implementation. The same conversion also acts on degree-three and frequency-dependent displacement contributions in the supplied sequence. A previous implementation comparison found an approximately 18% K₁ amplitude deficit relative to a potential-weighted reference. The daily response is accordingly not used to infer a Love number. Uncertainty in the solid model remains separate from the quoted statistical errors.

For loading, FES2022 sea-surface elevations $\zeta$ are convolved with the effective-potential kernel

$$\delta W_{\mathrm{load}}=\int \rho_w\zeta(\mathbf{r}',t)G_W(\psi)\,\mathrm{d}A,\qquad
G_W(\psi)=\frac{ga}{M_E}\sum_n(1+k'_n-h'_n)P_n(\cos\psi).$$

Here $\rho_w$ is seawater density, $a$ is the Earth-radius scale, $M_E$ is Earth mass, $\psi$ is the angular separation of the load and evaluation points, and $P_n$ is the Legendre polynomial of degree $n$. The load Love numbers $k'_n$ and $h'_n$ describe induced potential and radial displacement, respectively; $\mathrm{d}A$ is a surface-area element. The three terms represent direct water attraction, induced potential and clock displacement. PREM load Love numbers are retained through degree 696 with the archived high-degree continuation. Eighteen loading constituents are synthesized with their astronomical nodal corrections. The complex convention is $f\,\mathrm{Re}[C\exp(-i\phi)]$; reversing the exponential sign requires conjugating $C$. The present analysis reads the frozen constituent and time-series tables rather than substituting an older loading sequence.

The eight named constituents are grouped as described above. Minor terms remain once as a fixed remainder $r_0$. On the actual weighted segment-centred sampling, solid, loading and total root-mean-square variations are respectively 2.928, 1.328 and $4.011\times10^{-18}$. Their ratio 0.331 is an amplitude-norm ratio, not an additive fraction of total power. The separately reported $0.89\pm0.55$ loading coefficient belongs to the alternative directly modelled, filtered reduction described below; it has not been recalculated as a separate coefficient of the present estimator.

### Joint estimator and zero-point choice

We fit

$$y_i=c_{s(i)}+A_Ls_{L,i}+A_Ss_{S,i}+A_Ds_{D,i}+r_{0,i}+\epsilon_i,$$

Here $s(i)$ identifies the observing segment, $c_{s(i)}$ is its constant reference level, and $s_{L,i}$, $s_{S,i}$ and $s_{D,i}$ are the predicted fractional-frequency variations for unit group response at observation $i$. The $A$ coefficients are dimensionless; the minor remainder $r_0$ retains unit coefficient, and $\epsilon_i$ is the residual. The model has 54 segment intercepts and three physical response coefficients. Weighted least squares uses the frozen Allan-based uncertainties $\sigma_i$, with $W_{ii}=1/\sigma_i^2$. A period noise coefficient $\alpha_p$ is estimated from within-segment overlapping Allan deviations at 256, 512, 1,024, 2,048 and 4,096 s, after removing the fixed unit tide. No Allan window crosses a segment boundary. The bin uncertainty is $\sigma_i=\alpha_{p(i)}/\sqrt{n_i}$, where $n_i$ is its retained member count. This is a working noise model, not stability calculated after joining fit-adjusted levels. Independent QR replay reproduces the eight-period design on the same rows before changing only its intercept grouping. The intercept-design comparisons hold the observations, correction values, physical templates and weights fixed.

The inspected interval and correction records contain no documented calibrated zero transfer for the 46 adjacent segment boundaries that share an eight-period intercept. They give valid times, but not a signed boundary transfer with uncertainty or a lock/relock history establishing unchanged reference levels. This motivates the segment design. The eight-period model's weighted residual sum of squares is 3,781.58; the segment model's is 3,713.64, with 46 additional intercept parameters. Their unweighted residual root-mean-square values are 24.114 and $23.934\times10^{-18}$. Reduced residual sums of squares are 1.1501 and 1.1455. The numerical improvement alone does not establish a physical jump at each boundary.

With period constants, weighted segment-mean residuals range from $-6.75$ to $12.00\times10^{-18}$. Adjacent standardized residual correlations, restricted to the same segment and separations of at most 900 s, are −0.127 and −0.148 for the period and segment designs. Deleting a period gives lunar point-estimate ranges 0.877–1.052 and 0.885–1.093, respectively (Extended Data Fig. 1). These checks retain substantial lunar support under either reference-level assumption.

### Statistical errors and conditional coverage

For each group the reported standard error is the larger of residual-scaled least squares and leave-one-UTC-day-out jackknife errors. Deletions remove a calendar day, refit all remaining coefficients and drop empty intercept columns. The jackknife variance is $(G-1)G^{-1}\sum_g(\hat A_{(-g)}-\overline A)^2$. Here $G$ is the number of UTC dates containing observations in the fitted subset, and $\overline A$ is the mean of the leave-one-day-out estimates. In the statistical intervals below, $u$ denotes the reported standard error of a response coefficient. Period-deletion errors are recorded separately. Extended Data Table 1 gives all components and the same-data intercept comparisons. Observations are repeated measurements of one clock pair.

The conditional simulations apply both designs to the same 3,299-row sampling and heteroscedastic uncertainties. Each of four scenarios has 1,000 realizations: independent Gaussian noise; equal variance contributions from Gaussian white noise and a 6-h Ornstein–Uhlenbeck process within segments; the corresponding 24-h process within periods; and standardized Student-$t_5$ noise. The overall scale is the observed segment-model residual scale; all true physical response coefficients are one. Each realization recomputes both components of the standard-error rule. Seed 2026110617 fixes the simulation. Coverage of $\hat A\pm1.96u$ is 95.1–97.4% for the segment-model lunar coefficient and 95.4–96.8% for its neighbouring coefficient; Monte Carlo standard errors are about 0.4–0.7 percentage points (Extended Data Table 2). These are tests under declared noise laws, not a calibration against every possible disturbance.

The phase-relaxed model adds the lunar quadrature while retaining the prescribed M₂/N₂ relationship. Covariance contours use scaled least squares. Subset and deletion fits refit the same model on their retained rows. Shared-data estimates are not averaged.

### Phase means, spectral density and sampling sidelobes

For the phase plot, $N$ contains segment constants and the two non-lunar groups. We project both $y-r_0$ and the unit lunar prediction with $M_N=I-N(N^TWN)^{-1}N^TW$, and average in twelve fixed M₂ phase bins. If $B$ is weighted bin averaging, the mean covariance is $BM_NC_yM_N^TB^T$, where $C_y$ is the scaled working observation covariance. It retains correlations between means and propagates nuisance estimation. The full unbinned response remains primary.

Figure 3c preserves the independently specified equal-weight, 54-intercept scan of the unchanged observed means, rather than replacing it with the amplitude fit's weights. Every trial sine–cosine pair and the data are projected against the same constants. For a reduction in squared residuals $\Delta\mathrm{RSS}(f)$ with dimensionless $y$, the nominal one-sided projection density is $S_y(f)=600\,\mathrm{s}\,\Delta\mathrm{RSS}(f)$ per Hz, or $10^{-6}$ times that value per µHz. Potential density is $S_W=c^4S_y$; amplitude density is $c^2\sqrt{S_y}$. Uniform-grid checks reproduce the conventional one-sided Fourier density. For interrupted data this normalization is a stated projection density, not a Parseval-calibrated variance over a filled year.^19^

The frequency step is 0.002729 µHz; the inverse calendar span is 0.032752 µHz. Fine plotting steps do not improve physical resolution. M₂-only and S₂-only astronomical injections use the same actual times, nodal factors and equal-weight segment projection. Power at the opposite principal frequency, divided by power at the injected frequency, gives 0.08027 and 0.08149. Conditional scans project out a freely phased sinusoid at the other frequency before scanning the target neighbourhood. Amplitude interference means that such corrections act on sampled waveforms or complex coefficients, not by subtracting scalar power spectra. Gaps alone do not predict the realization of measurement noise. Residual density can describe remaining measurement fluctuations, but includes possible model mismatch and cannot be called a pure instrumental noise floor.

### Instruments, environmental checks and the alternative reduction

The matched monitor calculation uses 1,482 rows with 887,882 nominal members, or 246.634 h, in P6–P8. Both baseline and augmented fits have identical members, segment labels and weights. Paired day-deletion replicates propagate uncertainty in their difference. The lunar, neighbouring and daily coefficient changes are respectively $0.00606\pm0.00627$, $0.00594\pm0.01453$ and $0.00791\pm0.01388$. The calculation is displayed in Extended Data Fig. 3. It supplements published field-fibre dissemination results, which characterize the transfer technology in a separate 2067-km experiment conducted in January 2025.^13^

The alternative v68 reduction reports $A_L=0.97\pm0.14$ from approximately 544 h in 54 segments, with a 1,200-s triangular filter sampled every 600 s, equal weights, a direct-potential solid model and a continuous-run circular-residual-shift error. It reports $0.98\pm0.13$ with two-site ERA5 temperature regressors and a 474-h round-trip overlap changing lunar and whole-template coefficients by less than 0.005. These are author-reported manuscript results, not the present replay. The stated 98-h Sr chamber record is a distinct thermometer measurement; ERA5 2-m air temperatures are environmental proxies. The 474-h control and temperature-regression support have not been independently replayed with matching memberships here; these reported checks are not combined with the current uncertainty.

On the selected data and model, a common 24-h sine–cosine pair gives $A_L=1.036\pm0.133$; separate 24-h pairs in each period give $1.003\pm0.136$. These are mechanism-motivated daily sensitivity designs, not measurements of an independently observed thermal amplitude. Free 12-h pairs in each period give $0.751\pm0.242$ and a very poorly constrained neighbouring coefficient; the design competes with astronomical semidiurnal variation within short periods. It is retained as a sensitivity boundary, with no assumed laboratory disturbance assigned to it.

## Data availability

The accompanying author-review archive contains the derived ten-minute observations, frozen templates, noise weights, saved statistical results and figure-source tables used in this manuscript, with input hashes. The previously released R7 bin-level spectral input is available in a [versioned GitHub repository](https://github.com/hjiang555-a11y/gravitation-whsh/tree/7cfe60d9e5c5c3525eb536f1801e56c099612f27/paper/nature/merge-v68-r7-opencode/spectral-input). Original counter records and the membership ledger are held in the controlled experimental archive. Access terms and a permanent identifier for the complete analysis archive await author confirmation.

## Code availability

The author-review archive includes the scripts for assembling this manuscript, transferring the saved results into the revised displays and checking scientific consistency. The original numerical-replay implementation remains identified by its source provenance. The existing [v72 manuscript release](https://github.com/hjiang555-a11y/gravitation-whsh/tree/4c4babaf3d11534363e4b3acdf27c27ecad28199/paper/nature/author-revisions-opencode-v72) is a public editorial archive. Author confirmation of access, licensing and permanent archiving for the complete numerical-analysis code is pending.

## Author information and declarations

The author list, order, affiliation assignments, corresponding authors, contributions, funding, acknowledgements and competing-interest declarations have not yet been confirmed for this manuscript. Their status is recorded in the accompanying author-confirmation document.

**AI-assisted preparation.** OpenAI Codex assisted earlier English drafting, numerical replay and figure preparation. OpenCode assisted the present scientific-narrative integration, source checks, figure reorganization and consistency checks. Scientific interpretation, verification of the final content and approval for submission remain the responsibility of the authors.

**Note added.** Independent measurements of time-varying tidal potential with a European optical-clock network have been reported by Stahl et al.^20^

\clearpage

## References

1. Mehlstäubler, T. E., Grosche, G., Lisdat, C., Schmidt, P. O. & Denker, H. Atomic clocks for geodesy. *Rep. Prog. Phys.* **81**, 064401 (2018). [https://doi.org/10.1088/1361-6633/aab409](https://doi.org/10.1088/1361-6633/aab409)
2. Voigt, C., Denker, H. & Timmen, L. Time-variable gravity potential components for optical clock comparisons and the definition of international time scales. *Metrologia* **53**, 1365–1383 (2016). [https://doi.org/10.1088/0026-1394/53/6/1365](https://doi.org/10.1088/0026-1394/53/6/1365)
3. Ludlow, A. D., Boyd, M. M., Ye, J., Peik, E. & Schmidt, P. O. Optical atomic clocks. *Rev. Mod. Phys.* **87**, 637–701 (2015). [https://doi.org/10.1103/revmodphys.87.637](https://doi.org/10.1103/revmodphys.87.637)
4. Denker, H. et al. Geodetic methods to determine the relativistic redshift at the level of $10^{-18}$ in the context of international timescales: a review and practical results. *J. Geod.* **92**, 487–516 (2018). [https://doi.org/10.1007/s00190-017-1075-1](https://doi.org/10.1007/s00190-017-1075-1)
5. Chou, C. W., Hume, D. B., Rosenband, T. & Wineland, D. J. Optical Clocks and Relativity. *Science* **329**, 1630–1633 (2010). [https://doi.org/10.1126/science.1192720](https://doi.org/10.1126/science.1192720)
6. McGrew, W. F. et al. Atomic clock performance enabling geodesy below the centimetre level. *Nature* **564**, 87–90 (2018). [https://doi.org/10.1038/s41586-018-0738-2](https://doi.org/10.1038/s41586-018-0738-2)
7. Grotti, J. et al. Geodesy and metrology with a transportable optical clock. *Nat. Phys.* **14**, 437–441 (2018). [https://doi.org/10.1038/s41567-017-0042-3](https://doi.org/10.1038/s41567-017-0042-3)
8. Lisdat, C. et al. A clock network for geodesy and fundamental science. *Nat. Commun.* **7**, 12443 (2016). [https://doi.org/10.1038/ncomms12443](https://doi.org/10.1038/ncomms12443)
9. Riehle, F. Optical clock networks. *Nat. Photon.* **11**, 25–31 (2017). [https://doi.org/10.1038/nphoton.2016.235](https://doi.org/10.1038/nphoton.2016.235)
10. Hou, L. et al. Yb/Sr optical clock comparison at $2.2\times10^{-18}$ uncertainty over a 1350-km fiber link. *arXiv*, 2610.34250v1 (2026). [https://arxiv.org/abs/2610.34250v1](https://arxiv.org/abs/2610.34250v1)
11. Jia, Z.-P. et al. Improved systematic evaluation of a strontium optical clock with uncertainty below $1\times10^{-18}$. *Metrologia* **63**, 025002 (2026). [https://doi.org/10.1088/1681-7575/ae449e](https://doi.org/10.1088/1681-7575/ae449e)
12. Zhu, Q. et al. Ytterbium lattice clock with systematic uncertainty of $1.3\times 10^{-18}$ and instability at the $10^{-19}$ level. *arXiv*, 2606.10514v2 (2026). [https://arxiv.org/abs/2606.10514v2](https://arxiv.org/abs/2606.10514v2)
13. Chen, F.-X. et al. $10^{-21}$-Level optical frequency dissemination over 2067 km of noise-loaded field-deployed fiber network. *Light Sci. Appl.* **15**, 276 (2026). [https://doi.org/10.1038/s41377-026-02299-1](https://doi.org/10.1038/s41377-026-02299-1)
14. CNES. FES2022 (Finite Element Solution) Tidal model (Version 2024). CNES [https://doi.org/10.24400/527896/A01-2024.004](https://doi.org/10.24400/527896/A01-2024.004) (2024).
15. Farrell, W. E. Deformation of the Earth by surface loads. *Rev. Geophys.* **10**, 761–797 (1972). [https://doi.org/10.1029/RG010i003p00761](https://doi.org/10.1029/RG010i003p00761)
16. Petit, G. & Luzum, B. (eds) IERS Conventions (2010). *IERS Technical Note* **36** (2010). [https://iers-conventions.obspm.fr/content/tn36.pdf](https://iers-conventions.obspm.fr/content/tn36.pdf)
17. Han, D. & Wahr, J. The viscoelastic relaxation of a realistically stratified earth, and a further analysis of postglacial rebound. *Geophys. J. Int.* **120**, 287–311 (1995). [https://doi.org/10.1111/j.1365-246x.1995.tb01819.x](https://doi.org/10.1111/j.1365-246x.1995.tb01819.x)
18. NOAA. Harmonic constituents. *NOAA Tides and Currents*. [https://tidesandcurrents.noaa.gov/harcon.html?id=8577330](https://tidesandcurrents.noaa.gov/harcon.html?id=8577330) (accessed 6 November 2026).
19. VanderPlas, J. T. Understanding the Lomb–Scargle periodogram. *Astrophys. J. Suppl. Ser.* **236**, 16 (2018). https://doi.org/10.3847/1538-4365/aab766
20. Stahl, K. et al. Optical clock network tracks tidal variations of the gravity potential. *arXiv*, 2610.39635v1 (2026). [https://arxiv.org/abs/2610.39635v1](https://arxiv.org/abs/2610.39635v1)

\clearpage

## Extended Data

![Extended Data Figure 1](figures/ed_figure1.png)

**Extended Data Fig. 1 | Same-data comparison of reference-level designs.** **a,** Weighted mean residual of each segment after the eight-period joint fit. The additional segment intercepts make these means zero by construction, so a zero line would not demonstrate calibration. **b,** Lunar point estimates after deleting each observing period under eight-period and 54-segment designs. Both use the same frozen observations, physical templates, corrections and noise weights. These diagnostics do not replace lock/relock or zero-transfer records.

![Extended Data Figure 2](figures/ed_figure2.png)

**Extended Data Fig. 2 | Conditional semidiurnal scans.** Equal-weight scans of the same 3,299 observations with 54 segment intercepts. **a,** M₂ neighbourhood before and after projection of a sine–cosine pair at S₂. **b,** S₂ neighbourhood before and after projection at M₂. Dotted lines show the astronomical target frequencies. These are descriptive projections on shared observations, not additional detection probabilities.



![Extended Data Figure 3](figures/ed_figure3.png)

**Extended Data Fig. 3 | Matched transmission-monitor control.** Changes in the lunar, neighbouring semidiurnal and auxiliary diurnal coefficients when the simultaneous round-trip monitor is included in the S54 model. Both fits use identical clock/monitor members and the original weights: 1,482 means representing 887,882 accepted nominal one-second members, or 246.634 h, from 29 June to 25 August 2026. Error bars are paired UTC-day-jackknife standard errors; the vertical line denotes no change. The three changes are $0.00606\pm0.00627$, $0.00594\pm0.01453$ and $0.00791\pm0.01388$. The matched calculation and published field-fibre dissemination experiment provide distinct forms of evidence for the transfer system (Methods).


\clearpage

**Extended Data Table 1 | Estimator and uncertainty comparison.** All directly replayed designs use the same 3,299 means, physical templates and Allan-based weights. Errors are standard errors. S54, G29 and P8 denote constants for 54 segments, 29 operating groups and eight observing periods, respectively. The alternative filtered estimate is separately labelled author-reported.

| Design                | Lunar         | S₂+K₂      | Diurnal       | Status          |
|:----------------------|:--------------|:--------------|:--------------|:----------------|
| S54                   | 1.000 ± 0.132 | 0.925 ± 0.365 | 0.579 ± 0.538 | Replayed        |
| G29                   | 0.984 ± 0.124 | 1.093 ± 0.298 | 0.759 ± 0.420 | Replayed        |
| P8                    | 0.987 ± 0.123 | 1.129 ± 0.288 | 0.678 ± 0.359 | Replayed        |
| Filtered, 54 segments | 0.97 ± 0.14   | 0.90 ± 0.29   | 0.35 ± 0.51   | Author-reported |

| Group     |   Estimate |   Scaled LS |   Day jackknife |   Period jackknife |   Reported SE |
|:----------|-----------:|------------:|---------:|------------:|--------------:|
| Lunar     |     1.0004 |      0.132  |   0.1218 |      0.147  |        0.132  |
| S₂+K₂ |     0.9251 |      0.2993 |   0.3649 |      0.3531 |        0.3649 |
| Diurnal   |     0.5792 |      0.3887 |   0.5381 |      0.7735 |        0.5381 |

**Extended Data Table 2 | Conditional 95% interval coverage.** Each scenario has 1,000 simulated realizations per design, with fixed observed sampling and weights. Values are percentages for the larger-of-LS-and-day-jackknife rule, using multiplier 1.96. They assess the specified scenarios, not unknown systematic effects.

| scenario            | design   |   Diurnal |   Lunar |   S₂+K₂ |
|:--------------------|:---------|----------:|--------:|----------:|
| 50% OU 24 h, period | P8       |      97.9 |    98   |      97.3 |
| 50% OU 24 h, period | S54      |      96.4 |    95.1 |      95.4 |
| 50% OU 6 h, segment | P8       |      94.7 |    95.7 |      96   |
| 50% OU 6 h, segment | S54      |      95.8 |    95.6 |      96.3 |
| Student t (df 5)    | P8       |      96.8 |    96.3 |      96.2 |
| Student t (df 5)    | S54      |      96.2 |    96.1 |      96.8 |
| Gaussian            | P8       |      95.7 |    96.2 |      95.9 |
| Gaussian            | S54      |      95.5 |    97.4 |      96.7 |

**Extended Data Table 3 | Astronomical constituent guide.** Names specify forcing and frequency; one response coefficient multiplies each complete group with its internal ratios and phases fixed.

| Symbol   |   Period (h) | Meaning                     | Group     |
|:---------|-----------:|:----------------------------|:----------|
| M2       |     12.421 | Principal lunar semidiurnal | Lunar     |
| N2       |     12.658 | Lunar elliptic semidiurnal  | Lunar     |
| S2       |     12     | Principal solar semidiurnal | S₂+K₂ |
| K2       |     11.967 | Lunisolar semidiurnal       | S₂+K₂ |
| K1       |     23.934 | Lunisolar diurnal           | Diurnal   |
| O1       |     25.819 | Principal lunar diurnal     | Diurnal   |
| P1       |     24.066 | Principal solar diurnal     | Diurnal   |
| Q1       |     26.868 | Lunar elliptic diurnal      | Diurnal   |
