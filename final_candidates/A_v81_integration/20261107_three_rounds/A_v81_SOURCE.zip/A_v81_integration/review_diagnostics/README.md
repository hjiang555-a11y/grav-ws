# Simulations and diagnostics, not new observations

Every synthetic record is a conditional noise simulation. The experimental input is always the unchanged 3299-row file in data/. No simulation is ever concatenated with observations. Noise laws are declared sensitivity assumptions and are not selected using a favourable tidal P value.
