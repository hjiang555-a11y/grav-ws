# Reviewer 3

**来源边界与总体判断**

仅审阅冻结 packet 内完整 manuscript.md、八幅图的 PDF 及数值证据，未接触其他评审或作者讨论。独立重算全模板和三组系数，与报告值一致。原始计数器重建、外部文献真实性及作者声明不在本次可核验范围。证据支持本基线上的潮汐变化检测，尤其是月潮组；未发现足以否定该中心结论的已确立缺陷。

**优点与读者**

实际 UTC 相位与分段常数的结合，使间断观测仍能检验潮汐预测。图 2 同时展示相位平均、真实时间和全部原始十分钟均值，图 4 保留短期估计的宽误差范围。正文明确区分负荷模型贡献与独立测量，也没有把频谱、相位与振幅当作独立证据叠加。工作对光钟计量、时变大地测量及质量迁移研究者有吸引力。

**Major Concerns**

**R3-M1 · Major · Blocking No · 物理推断**

Claim pointer 为摘要及 Detection in the full clock record 中全模板响应与预测振幅一致。Evidence pointer 为 Methods 的 Combined solid and loading potential、Extended Data Table 5 和 evidence/full_response.json。固体项使用统一位移换算，且已知 K₁ 相对势加权参考存在约 18% 振幅差；这不能外推为 M₂ 的同等误差，但稿件未量化该近似对全模板或半日组系数的影响。统计误差与模型误差虽已区分，单位响应的物理解释仍缺少尺度依据。建议用势加权参考重算，或给出有依据的模型扰动及系数变化。该问题影响定量模型一致性，不足以推翻月潮检测。

**R3-M2 · Major · Blocking No · 原创性与重要性**

Claim pointer 为摘要“从静态势差延伸至小时变化”的贡献定位。Evidence pointer 为 A coastal–inland baseline and its predicted signal 首段，已述 Hou 等用重叠的 16 段得到 0.87±0.15 的合成潮响应。当前增量应明确落在更长记录及组分约束，不能仅以动态检测区别于静态前作。建议具体比较新增日期带来的辨识能力，并阐明它改变了什么物理认识。此项关乎 Nature 层级的创新论证，不否定测量本身。

**Minor Comments**

**R3-m1 · Minor · 图表可读性**

Claim pointer 为图 1a 的陆地模型场。Evidence pointer 为 figures/figure1.pdf 及其图注。图内称其为 tidal potential，却使用无量纲的 10⁻¹⁸，且未明确等值线表示振幅还是指定相位的瞬时值。应直接注明分数频率及其振幅或相位定义，使读者能与图 1b 的差分相量对应。

**Nature 标准与建议姿态**

技术链条较完整，非专业读者可理解主要问题。跨领域价值可信，但“杰出科学重要性”仍需通过 R3-M2 的增量论证建立；负荷尚未独立分离、近 12 小时归因受限，限制了目前地球物理结论的范围。建议实质修订后再评估投稿定位，不作接收或期刊适配保证。
