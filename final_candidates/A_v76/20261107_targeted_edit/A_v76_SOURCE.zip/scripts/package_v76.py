"""Versioned author-review export. No upload or scientific recomputation."""
from pathlib import Path
import hashlib,json,shutil,zipfile
O=Path(__file__).resolve().parents[1]
assert json.loads((O/'verification/FINAL_CHECK_A_v76.json').read_text())['status']=='PASS'
stage=O/'verification/export_A_v76';stage.mkdir()
paths=set()
for folder in ['data','figures','vendor','sources/frozen_v72','editorial/network_research','verification/baseline_A_v72']:
    paths.update(p.relative_to(O) for p in (O/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
names=['NATURE_ARTICLE_A_v76.md','manuscript_template.md','render_candidate.py','layout_working.lua',
       'PLAN_v76.md','REPRODUCE_v76.md','COVER_LETTER_v76.md','CHANGELOG_V75_V76_ZH.md',
       'NARRATIVE_CHANGES_ZH.md','SCIENTIFIC_INVARIANCE_CHECK_ZH.md','AUTHOR_CHECKS_ZH.md',
       'ANALYSIS_REPORT_v76_ZH.md','REVISION_RECORD_ZH.md','INPUT_MANIFEST_v76.json',
       'review/EDIT_OPERATIONS.json','review/PHYSICIST_READING_REVIEW_ZH.md',
       'original/A_v75_manuscript_template.md','original/A_v75.md','original/A_v75_FROZEN_FILES.json',
       'sources/v72/NATURE_ARTICLE_v72.md','sources/v68.md','sources/noise_definition.py',
       'sources/prior_single_bin_integration.json','sources/v71/data/annual_spectrum_dual_units.csv',
       'sources/spectral/annual_spectrum_20261106T0857Z/data/RESULTS.json',
       'editorial/REFERENCE_ORDER.json','editorial/added_references_v76.json',
       'verification/FROZEN_INPUT_COMPARISON.json','verification/INVARIANCE_A_v76.json',
       'verification/VISUAL_REVIEW_A_v76.json','verification/PDF_PAGE_CHECK.json',
       'verification/FINAL_CHECK_A_v76.json','verification/SOFTWARE.json',
       'verification/TEXT_STRUCTURE.json','verification/humanizer_audit_A_v76.txt',
       'verification/humanizer_compare_A_v76.txt']
paths.update(Path(n) for n in names)
paths.update(Path('scripts')/n for n in ['edit_v76.py','assemble_candidate.py','draw_candidate.py','verify_v76.py','package_v76.py','recompute_candidate.py','check_coverage.py'])
for rel in sorted(paths):
    src=O/rel;assert src.is_file() and not src.is_symlink(),str(rel)
    dst=stage/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
shutil.copy2(O/'render_A_v76_03/NATURE_ARTICLE_A_v76.tex',stage/'NATURE_ARTICLE_A_v76.tex')
files=[dict(path=str(p.relative_to(stage)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(stage.rglob('*')) if p.is_file()]
manifest=dict(scope='Targeted A_v76 edit, frozen derived means/templates, display source and author-review reports',excluded='Raw counters, previous/colleague PDFs, full Light article, credentials and other worktrees',files=files)
(stage/'EXPORT_MANIFEST.json').write_text(json.dumps(manifest,indent=2))
rel=O/'release';assert not list(rel.iterdir())
for ext in ['pdf','docx','tex']:shutil.copy2(O/f'render_A_v76_03/NATURE_ARTICLE_A_v76.{ext}',rel/f'NATURE_ARTICLE_A_v76.{ext}')
for name in ['NATURE_ARTICLE_A_v76.md','COVER_LETTER_v76.md','CHANGELOG_V75_V76_ZH.md','NARRATIVE_CHANGES_ZH.md','SCIENTIFIC_INVARIANCE_CHECK_ZH.md','AUTHOR_CHECKS_ZH.md','ANALYSIS_REPORT_v76_ZH.md','REVISION_RECORD_ZH.md','REPRODUCE_v76.md']:
    shutil.copy2(O/name,rel/name)
shutil.copy2(O/'verification/FINAL_CHECK_A_v76.json',rel/'FINAL_CHECK.json')
shutil.copy2(stage/'EXPORT_MANIFEST.json',rel/'EXPORT_MANIFEST.json')
with zipfile.ZipFile(rel/'A_v76_SOURCE.zip','x',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(stage.rglob('*')):
        if p.is_file():z.write(p,p.relative_to(stage))
print(json.dumps({'source_files':len(files),'release_files':len(list(rel.iterdir()))}))
