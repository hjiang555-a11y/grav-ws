"""Build a versioned review package from an explicit allowlist; no upload."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

O = Path(__file__).resolve().parents[1]
assert json.loads((O / 'verification/FINAL_CHECK.json').read_text())['status'] == 'PASS'
stage = O / 'verification/export_stage'
stage.mkdir()
roots = ['data', 'figures', 'vendor', 'sources/frozen_v72', 'editorial/network_research',
         'verification/baseline_A_v72']
paths = {p.relative_to(O) for name in roots for p in (O/name).rglob('*')
         if p.is_file() and '__pycache__' not in p.parts}
paths.update(p.relative_to(O) for p in (O/'scripts').glob('*.py')
             if not p.name.startswith('upload_'))
names = [
    'NATURE_ARTICLE_A_v74.md', 'manuscript_template.md', 'render_candidate.py',
    'layout_working.lua', 'REPRODUCE.md', 'INPUT_MANIFEST.json', 'PLAN.md',
    'COVER_LETTER.md', 'REVISION_NOTE_ZH.md', 'NETWORK_SIGNIFICANCE_RESEARCH_ZH.md',
    'ANALYSIS_REPORT_ZH.md', 'original/manuscript_template_A_v72.md',
    'original/NATURE_ARTICLE_A_v72.md', 'sources/v72/NATURE_ARTICLE_v72.md',
    'sources/v68.md', 'sources/noise_definition.py', 'sources/prior_single_bin_integration.json',
    'sources/v71/data/annual_spectrum_dual_units.csv',
    'sources/spectral/annual_spectrum_20261106T0857Z/data/RESULTS.json',
    'editorial/REFERENCE_ORDER.json', 'editorial/POSITIONING_EVIDENCE.json',
    'editorial/POSITIONING_REVIEW.md', 'verification/FINAL_CHECK.json',
    'verification/EDITORIAL_CHECK.json', 'verification/VISUAL_REVIEW.json',
    'verification/PDF_PAGES_04.json', 'verification/TEXT_STRUCTURE.json',
    'verification/SOFTWARE.json', 'verification/ORIGINAL_A_V72_HASHES.json',
    'verification/humanizer_revision_audit_final.txt',
    'verification/humanizer_comparison_final.txt',
]
paths.update(Path(n) for n in names)
for rel in sorted(paths):
    src = O / rel
    assert src.is_file() and not src.is_symlink(), str(src)
    dst = stage / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dst)
shutil.copy2(O/'render_A_v74_04/NATURE_ARTICLE_A_v74.tex',stage/'NATURE_ARTICLE_A_v74.tex')
manifest = []
for p in sorted(stage.rglob('*')):
    if p.is_file():
        manifest.append(dict(path=str(p.relative_to(stage)), bytes=p.stat().st_size,
                             sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
(stage/'EXPORT_MANIFEST.json').write_text(json.dumps(dict(
    scope='Frozen derived means, templates, code, vector figures and author-review text',
    excluded='Original counter files, author-uploaded PDFs, former manuscript PDFs, drafts and credentials',
    files=manifest), indent=2))
release = O / 'release'
release.mkdir(exist_ok=True)
assert not list(release.iterdir()), 'Refuse to overwrite an existing release'
for ext in ['pdf','docx','tex']:
    shutil.copy2(O/f'render_A_v74_04/NATURE_ARTICLE_A_v74.{ext}',release/f'NATURE_ARTICLE_A_v74.{ext}')
for name in ['NATURE_ARTICLE_A_v74.md','REVISION_NOTE_ZH.md','REVISION_NOTE_ZH.pdf',
             'NETWORK_SIGNIFICANCE_RESEARCH_ZH.md','ANALYSIS_REPORT_ZH.md',
             'COVER_LETTER.md','REPRODUCE.md']:
    shutil.copy2(O/name,release/name)
shutil.copy2(O/'verification/FINAL_CHECK.json', release/'FINAL_CHECK.json')
shutil.copy2(stage/'EXPORT_MANIFEST.json', release/'EXPORT_MANIFEST.json')
with zipfile.ZipFile(release/'A_v74_SOURCE.zip','x',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(stage.rglob('*')):
        if p.is_file():
            z.write(p,p.relative_to(stage))
rows=[f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}'
      for p in sorted(release.iterdir()) if p.is_file()]
(release/'SHA256SUMS.txt').write_text('\n'.join(rows)+'\n')
print(json.dumps(dict(files=len(rows)+1,source_files=len(manifest),
                     zip_bytes=(release/'A_v74_SOURCE.zip').stat().st_size)))
