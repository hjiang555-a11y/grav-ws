"""Add the author's requested network/timekeeping context after the A_v72 rewrite."""
from pathlib import Path

O = Path(__file__).resolve().parents[1]
p = O/'manuscript_template.md'
t = p.read_text()
old = "Stabilized optical-fibre networks extend these measurements across regions without transporting the clocks.[@lisdat,riehle] Measuring a changing potential requires its temporal components to be distinguished from fluctuations in the clocks and transfer system. Astronomical tides provide a physical test of this capability because their frequencies and phases are predictable independently of the clock observations.[@voigt,denker,schroder]"
new = "Stabilized optical-fibre networks extend these measurements across regions without transporting the clocks.[@lisdat,riehle] Coordinated international comparisons now connect optical standards across national borders, supporting their use in shared time scales.[@lindvall,dimarcq] The same links can repeatedly sample potential differences between distant sites, complementing levelling surveys and satellite gravity measurements.[@denker,schroder] Measuring a changing potential requires its temporal components to be distinguished from fluctuations in the clocks and transfer system. Astronomical tides provide a physical test of this capability because their frequencies and phases are predictable independently of the clock observations.[@voigt]"
assert t.count(old)==1
t=t.replace(old,new)
anchor = "Together they show the scope of clock networks as instruments for time-dependent gravitational potential. Longer coastal records and calibrated local transfer paths could allow the solid and loading responses to be tested separately."
context = """Together they show the scope of clock networks as instruments for time-dependent gravitational potential. Longer coastal records and calibrated local transfer paths could allow the solid and loading responses to be tested separately.

Clock networks connect this geophysical capability to the realization of time itself. International comparisons already link optical standards across countries, and intermittently operated optical clocks have steered continuous time scales.[@lindvall,yao] A common time scale requires clock frequencies to be referred to a consistent gravitational potential; Earth monitoring treats changes in that potential as the signal.[@denker,dimarcq] Once a frequency-transfer link is established, it can repeatedly compare distant endpoints during operation without resurveying the intervening terrain. Such observations complement levelling surveys and the standard monthly gravity products from satellites.[@denker,schroder] The temporal resolution attainable for a particular signal depends on clock stability and simultaneous operation. With improved continuity, calibrated reference levels and colocated height measurements, future networks could extend these differential observations to atmospheric and hydrological mass changes.[@schroder,vincent] Resolving known tidal components across interruptions tests the signal discrimination that those applications require."""
assert t.count(anchor)==1
t=t.replace(anchor,context)
p.write_text(t)
print('Added sourced clock-network/timekeeping/Earth-monitoring context; numerical analysis unchanged.')
