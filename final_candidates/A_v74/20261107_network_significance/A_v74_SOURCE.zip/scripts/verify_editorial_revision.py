"""Check A_v74 editorial provenance without refitting or selecting observations."""
from pathlib import Path
from collections import Counter
import hashlib, json, re, sys
import pandas as pd

O = Path(__file__).resolve().parents[1]
B = O.parent / 'A_v72'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
checks = []

def record(name, passed, detail):
    checks.append(dict(check=name, passed=bool(passed), detail=detail))

original = json.loads((O/'verification/ORIGINAL_A_V72_HASHES.json').read_text())
changed = [r['path'] for r in original if not Path(r['path']).exists() or sha(Path(r['path'])) != r['sha256']]
record('Original A_v72 files unchanged', not changed, dict(files=len(original), changed=changed))
for folder in ['data', 'figures']:
    files = sorted(p for p in (O/folder).rglob('*') if p.is_file())
    differences = [str(p.relative_to(O)) for p in files if not (B/p.relative_to(O)).exists() or sha(p) != sha(B/p.relative_to(O))]
    record(folder+' byte identity to A_v72', not differences, dict(files=len(files), differences=differences))

manifest = json.loads((O/'INPUT_MANIFEST.json').read_text())
items = manifest['files']
bad = [r['copy'] for r in items if sha(O/r['copy']) != r['sha256']]
record('Frozen inputs', not bad, dict(files=len(items), differences=bad))

j = json.loads((O/'data/RESULTS.json').read_text())
e = json.loads((O/'editorial/POSITIONING_EVIDENCE.json').read_text())
df = (j['spectrum']['frequency_Hz']['S2']-j['spectrum']['frequency_Hz']['M2'])*1e6
ratio = j['phasors_M2']['loading']/j['phasors_M2']['total']
record('Frequency separation and loading ratios', abs(df-e['frequency_difference_uHz'])<1e-12 and abs(ratio-e['loading_M2_amplitude_ratio'])<1e-12 and abs(j['loading_rms_fraction']-e['loading_record_rms_ratio'])<1e-12, dict(principal_frequency_separation_uHz=df, observed_peak_separation_uHz=e['observed_peak_difference_uHz'], M2_loading_amplitude_ratio=ratio, full_record_rms_ratio=j['loading_rms_fraction']))

diag = O/'sources/prior_single_bin_integration.json'
record('Archived point diagnostic hash', sha(diag)==e['single_bin_source_sha256'], dict(path=str(diag.relative_to(O)), sha256=sha(diag)))
d = e['single_bin_diagnostic']; row = d['selected']
rows = pd.read_csv(O/'data/primary_rows.csv')
point = rows.loc[(rows.t_utc==row['t_utc']) & (rows.seg==row['seg'])]
record('Diagnostic point retained', len(point)==1 and int(point.iloc[0]['n'])==row['n'] and abs(point.iloc[0]['y']-row['y_1e18'])<1e-10, dict(utc=row['t_utc'], segment=row['seg'], retained=len(point)))
v = next(r for r in d['results'] if r['model']=='three')
record('Archived P8 diagnostic compatible with baseline', all(abs(a-b)<1e-9 for a,b in zip(v['original'],j['designs']['P8']['A'])), dict(diurnal_original=v['original'][2], diurnal_without_point=v['analytic_single_bin_omission'][2], diurnal_shift=v['delta_A'][2], original_diurnal_SE=j['designs']['P8']['u'][2], lunar_shift=v['delta_A'][0], scope='Archived P8 fixed-weight diagnostic; no refit or new uncertainty in this revision'))

old=(O/'original/NATURE_ARTICLE_A_v72.md').read_text()
new=(O/'NATURE_ARTICLE_A_v74.md').read_text()
formula = r'\$\$[\s\S]*?\$\$|(?<!\$)\$(?!\$)[^\n$]+\$(?!\$)'
removed = Counter(re.findall(formula,old))-Counter(re.findall(formula,new))
added = Counter(re.findall(formula,new))-Counter(re.findall(formula,old))
record('Equation and result conservation', removed==Counter({r'$0.006\pm0.006$':1}) and not added, dict(removed=dict(removed), added=dict(added), explanation='Rounded monitor check removed from abstract only; precise paired result remains in main text and Methods'))
keys=lambda t:list(dict.fromkeys(k for group in re.findall(r'\[@([a-z,]+)\]',t) for k in group.split(',')))
oldkeys=keys((O/'original/manuscript_template_A_v72.md').read_text()); newkeys=keys((O/'manuscript_template.md').read_text())
newrefs=json.loads((O/'editorial/network_research/additional_references.json').read_text())
mapping=json.loads((O/'editorial/REFERENCE_ORDER.json').read_text())
record('Citation first-appearance order', set(newkeys)==set(oldkeys)|set(newrefs) and all(mapping[k]['number']==i+1 for i,k in enumerate(newkeys)), dict(keys=newkeys, added=list(newrefs), scope='Four verified literature additions; first-appearance numbering regenerated'))
oldmap=json.loads((B/'editorial/REFERENCE_ORDER.json').read_text())
record('Existing reference entries preserved', all(mapping[k]['text']==v['text'] for k,v in oldmap.items()), 'All 20 original entries unchanged; four additions verified through metadata and primary sources')
record('Figure resources preserved', re.findall(r'!\[[^]]*\]\(([^)]+)\)',old)==re.findall(r'!\[[^]]*\]\(([^)]+)\)',new), 'Same four main figures, two Extended Data figures and order')
record('Primary text values retained', all(s in new for s in [r'$A_L=1.00\pm0.13$',r'$A_S=0.93\pm0.36$',r'$A_D=0.58\pm0.54$']), 'S54, same rows/template/weights/error rule as A_v72')
record('No follow-up or priority framing', not re.search(r'following Stahl|building on Stahl|for the first time|preceded Stahl',new,re.I), 'Contemporaneous independent parallel work; no ranking by upload date')
build=json.loads((O/'render_A_v74_04/BUILD_RESULTS.json').read_text())
record('Clean PDF and Word build', build['status']=='BUILT_FOR_REVIEW' and all(r['exit']==0 and not r['warnings'] for r in build['builds']) and build['source_sha256']==sha(O/'NATURE_ARTICLE_A_v74.md'), build)
result=dict(status='PASS' if all(r['passed'] for r in checks) else 'FAIL', scope='Editorial provenance and frozen-result checks, not a new scientific fit or author approval', checks=checks)
(O/'verification/EDITORIAL_CHECK.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
print(json.dumps(dict(status=result['status'],checks=len(checks),failed=[r['check'] for r in checks if not r['passed']]),ensure_ascii=False))
sys.exit(0 if result['status']=='PASS' else 1)
