"""Reorganize A_v72 around demonstrated capability; keep its analysis and figures."""
from pathlib import Path

O=Path(__file__).resolve().parents[1]
t=(O/'original/manuscript_template_A_v72.md').read_text()

abstract=r'''Optical clocks measure changes in Earth's gravitational potential through their relative rates.[@ludlow,mehlstaubler] Resolving neighbouring tidal components is difficult when observations are interrupted and their frequency zero points are not transferred. Here we resolve semidiurnal responses with principal frequencies only 0.78 µHz apart on a coastal–inland clock baseline. Shanghai strontium and Wuhan ytterbium clocks accumulated 545.9 hours over 353 days. The changing lunar–solar phase provides an external reference across 54 segments with independent frequency offsets. The measured spectrum has local peaks near the principal lunar and solar frequencies. Joint estimation of astronomical templates gives responses of $1.00\pm0.13$ for M₂+N₂ and $0.93\pm0.36$ for S₂+K₂ relative to the combined solid-Earth and ocean-loading prediction (one statistical standard error). These results demonstrate spectrally resolved measurements of a changing gravitational potential with an optical-clock link operated intermittently.'''
intro=r'''Optical clocks measure gravitational potential through their relative rates.[@ludlow,mehlstaubler] Laboratory comparisons have resolved height-dependent redshifts, and remote comparisons have supported geodetic measurements between distant sites.[@chou,mcgrew,grotti] Stabilized optical-fibre networks extend these measurements across regions without transporting the clocks.[@lisdat,riehle] Measuring a changing potential requires its temporal components to be distinguished from fluctuations in the clocks and transfer system. Astronomical tides provide a physical test of this capability because their frequencies and phases are predictable independently of the clock observations.[@voigt,denker,schroder]

The principal lunar and solar semidiurnal tides are a demanding pair of nearby signals. M₂ repeats every 12.42 h and S₂ every 12 h, giving a frequency separation of only 0.78 µHz. Over a short comparison their variations can look much alike. Their relative phase changes with date, allowing observations distributed over different lunar–solar phases to separate their responses. That astronomical phase remains defined through interruptions, even when the frequency offset between observing runs is unknown.

Here we use this external phase reference in a comparison between coastal Shanghai and inland Wuhan. Across a 353-day span, 54 valid segments provide 545.9 h of observations. Independent constants represent their reference levels; the tidal phase is retained at every actual observing time. We jointly estimate complete physical templates for the lunar semidiurnal group M₂+N₂, the neighbouring group S₂+K₂ and the approximately daily group K₁+O₁+P₁+Q₁. Internal amplitude ratios and phases remain fixed by the astronomical model, so the fit propagates overlap between the groups. K₂ contains lunar and solar forcing. The spectrum displays local peaks near M₂ and S₂, and both fitted semidiurnal responses agree with the combined solid-Earth and ocean-loading prediction. The experiment thus tests spectral separation in an intermittently operated clock link, on a baseline where loading is a sizeable part of the signal.

'''
t=t.split('## Abstract')[0]+'## Abstract\n\n'+abstract+'\n\n## Main text\n\n'+intro+'### A coastal–inland prediction'+t.split('### A coastal–inland prediction',1)[1]

def replace_once(a,b):
    global t
    assert t.count(a)==1,(a[:100],t.count(a))
    t=t.replace(a,b)

replace_once(
    'Their vector sum matters because the two contributions do not reach their maxima together. On the sampled record, after removing segment means, loading has 33.1% of the combined prediction\'s weighted root-mean-square variation. This describes the model contribution.',
    'The loading amplitude is about 30% of the combined M₂ amplitude; their vector sum accounts for the phase difference. On the sampled record, after removing segment means, loading has 33.1% of the combined prediction\'s weighted root-mean-square variation. These amplitude ratios describe the model contribution, making this coastal–inland geometry a useful setting for testing the combined potential.'
)
replace_once('### Two nearby semidiurnal responses','### Jointly resolved semidiurnal responses')
replace_once('### The measured semidiurnal spectrum','### Spectral separation through the observation window')
replace_once(
    'The reported errors are the larger of residual-scaled least-squares and UTC-day-deletion standard errors. Their components, period-deletion checks and conditional interval coverage are given in Methods. Separating the three groups preserves uncertainty from their overlap. It does not require the daily group to be measured with the same precision as the half-daily groups.',
    'The reported errors are the larger of residual-scaled least-squares and UTC-day-deletion standard errors. Their components, period-deletion checks and conditional interval coverage are given in Methods. Joint estimation preserves uncertainty from overlap among the physical groups. Improving the daily response calls for longer uninterrupted clock operation and sustained link comparisons with all valid observations retained under data-quality rules fixed independently of the tidal fit. An existing single-bin influence check is described in Methods.'
)
replace_once(
    'Their separation is much larger than the inverse calendar span, 0.0328 µHz.',
    'The prescribed principal frequencies are 0.78 µHz apart, compared with an inverse calendar span of 0.0328 µHz. Resolving this pair is the demonstrated spectral capability; the interrupted observation window determines the accompanying sidelobes.'
)
replace_once(
    'The two features thus support their assignment to the principal lunar and solar semidiurnal neighbourhoods. They do not separately measure N₂ or K₂.',
    'The two features and the conditional scans support distinct contributions in the principal lunar and solar semidiurnal neighbourhoods. This attribution does not separately measure N₂ or K₂.'
)
old='The experiment uses the changing lunar–solar phase to carry information between separated observing dates while allowing their reference levels to remain independent. Its combined potential includes a sizeable ocean-loading contribution, although loading is not separately resolved. Contemporaneous European clock-network observations by Stahl and colleagues use different baselines and tidal mixtures and provide a complementary realization of time-dependent chronometric geodesy.[@stahl] Longer coastal records, together with calibrated local transfer paths, could turn this sensitivity to the combined prediction into a distinct test of ocean loading.'
new='''The comparison resolves nearby gravitational signals from observations separated by interruptions in clock and link operation. A phase reference supplied by celestial motion connects the physical waveforms across the observing dates, while segment constants accommodate frequency levels that have not been transferred between runs. The measured peaks and jointly estimated groups resolve neighbouring semidiurnal responses without forcing the clock record onto a common level. This allows an intermittently operated clock link to measure distinct temporal components of the gravitational potential.

Our observations and contemporaneous European clock-network measurements by Stahl and colleagues are independent, parallel demonstrations.[@stahl] The European network tracks composite tidal variations on different baselines; the present coastal–inland comparison emphasizes separation of neighbouring semidiurnal responses across interrupted records. Together they show the scope of clock networks as instruments for time-dependent gravitational potential. Longer coastal records and calibrated local transfer paths could allow the solid and loading responses to be tested separately.'''
replace_once(old,new)

replace_once(
    '**c,** Equal-weight spectral calculation: 3,299 real UTC means, 54 segment constants and equal weights.',
    '**c,** Equal-weight spectral calculation around the principal M₂ and S₂ frequencies, separated by 0.78 µHz: 3,299 real UTC means, 54 segment constants and equal weights.'
)

needle='### Instruments, environmental checks and the alternative reduction\n\n'
diagnostic=r'''An existing fixed-weight single-bin diagnostic in the eight-period reduction examined the pre-identified extreme mean at 2026-07-07 01:25 Beijing time (segment 46). Omitting that mean changed the daily coefficient from 0.678 to 0.721, a shift of 0.043 compared with its 0.359 standard error. The lunar coefficient changed by 0.039. This archived diagnostic kept the template and weights fixed; it did not recalibrate uncertainty. The point remains in the present 3,299-row sample. Its influence does not explain the weaker daily constraint or justify selecting observations to improve agreement with the tide.

'''
replace_once(needle,needle+diagnostic)
(O/'manuscript_template.md').write_text(t)
print('A_v74 template written directly from A_v72. Figures and estimates unchanged.')
