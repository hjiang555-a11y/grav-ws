# v80: eight individual observing periods

Current manuscript: NATURE_ARTICLE_A_v80.md. Final PDF and Word: render_v80_02/. Only Figure 4 and related prose/method descriptions were revised. See REVISION_V80_ZH.md and REPRODUCE_V80.md.
